# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# MARKDOWN ********************

# ##   **🥈 SILVER LAYER CONFIG**

# MARKDOWN ********************

# ###### IMPORTS AND SETUP

# CELL ********************

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import col
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor as tpe
import time
import json

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### JOB & NOTEBOOK TRACKER

# CELL ********************

class JobStatus:
    def __init__(self, job_name, status, start_time):
        self.job_name = job_name
        self.status = status
        self.start_time = start_time
        self.end_time = None
        self.duration = None
        self.records_processed = 0
        self.error_message = None
        self.warning_messages = []
        self.additional_info = {}
    
    def to_dict(self):
        return {
            "job_name": self.job_name,
            "status": self.status,
            "start_time": self.start_time.strftime("%Y-%m-%d %H:%M:%S"),
            "end_time": self.end_time.strftime("%Y-%m-%d %H:%M:%S") if self.end_time else None,
            "duration": self.duration,
            "records_processed": self.records_processed,
            "error_message": self.error_message,
            "warning_messages": self.warning_messages,
            "additional_info": self.additional_info
        }

class NotebookTracker:
    def __init__(self, notebook_name="unknown_notebook"):
        self.jobs = {}
        self.notebook_name = notebook_name
        self.notebook_start_time = datetime.now()
        self.execution_id = f"exec_{int(time.time())}"
    
    def start_job(self, job_name):
        job_status = JobStatus(job_name, "RUNNING", datetime.now())
        self.jobs[job_name] = job_status
        print(f"🟡 STARTING: {job_name}")
        return job_status
    
    def end_job(self, job_name, status, records_processed=0, error_message=None, 
                warning_messages=None, additional_info=None):
        if job_name not in self.jobs:
            self.start_job(job_name)
        
        job = self.jobs[job_name]
        job.end_time = datetime.now()
        job.duration = (job.end_time - job.start_time).total_seconds()
        job.status = status
        job.records_processed = records_processed
        job.error_message = error_message
        
        if warning_messages:
            job.warning_messages.extend(warning_messages)
        if additional_info:
            job.additional_info.update(additional_info)
        
        icon = "✅" if status == "SUCCESS" else "❌" if status == "FAILED" else "⚠️"
        print(f"{icon} {job_name}: {status} ({job.duration:.2f}s, {records_processed} records)")
        
        if error_message:
            print(f"   Error: {error_message}")
        for warning in (warning_messages or []):
            print(f"   Warning: {warning}")    
        
    def get_execution_summary(self):
        total_jobs = len(self.jobs)
        notebook_duration = (datetime.now() - self.notebook_start_time).total_seconds()
        successful = len([j for j in self.jobs.values() if j.status == "SUCCESS"])
        failed = len([j for j in self.jobs.values() if j.status == "FAILED"])
        warnings = len([j for j in self.jobs.values() if j.status == "WARNING"])
        
        print("\n" + "="*60)
        print("📊 SILVER EXECUTION SUMMARY")
        print("="*60)
        print(f"Notebook: {self.notebook_name}")
        print(f"Execution ID: {self.execution_id}")
        print(f"Duration: {notebook_duration:.2f}s")
        print(f"Total Jobs: {total_jobs}")
        print(f"✅ Successful: {successful}")
        print(f"⚠️  Warnings: {warnings}") 
        print(f"❌ Failed: {failed}")
        print("="*60)
        
        return {
            "execution_id": self.execution_id,
            "notebook_name": self.notebook_name,
            "total_jobs": total_jobs,
            "successful_jobs": successful,
            "failed_jobs": failed,
            "warning_jobs": warnings,
            "notebook_duration": notebook_duration,
            "detailed_jobs": {name: job.to_dict() for name, job in self.jobs.items()}
        }

# Global tracker instance
tracker = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### PARAMETER INITALISATION

# CELL ********************

def initialize_silver_parameters():
    """Initialize silver-specific parameters"""
    params = {
        "p_workSpace": globals().get("p_workSpace", "Fabric_SandBox"),
        "p_accountName": globals().get("p_accountName", "onelake"),
        "p_relativeBRONZEPath": globals().get("p_relativeBRONZEPath", "LH_100_Bronze.Lakehouse/Files"),
        "p_db_bronzeFolder": globals().get("p_db_bronzeFolder", '["SAP","Athena_A4E","Essex_STORM","Bail","operationalPlanningCalendar"]'),
        "p_todaysFile": globals().get("p_todaysFile", datetime.now().strftime("%Y%m%d"))
    }
    
    print("✅ Silver Parameters initialized:")
    for key, value in params.items():
        print(f"   {key}: {value}")
    
    return params

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### BRONZE PATH CONFIG

# CELL ********************

def setup_bronze_paths(params):
    """Set up bronze file paths and configurations"""
    db_bronzePath = f"abfss://{params['p_workSpace']}@{params['p_accountName']}.dfs.fabric.microsoft.com/{params['p_relativeBRONZEPath']}/bronze"
    
    try:
        db_bronzeFolder = json.loads(params['p_db_bronzeFolder'])
    except:
        db_bronzeFolder = ["SAP", "Athena_A4E", "Essex_STORM", "Bail", "operationalPlanningCalendar"]
    
    # Create Bronze file paths
    db_bronzeFile_Path = [f"{db_bronzePath}/{path}/{params['p_todaysFile']}" for path in db_bronzeFolder]
    
    # Define domain-specific bronze file paths
    db_bronzeFile_Paths = {
        "SAP": [f"{db_bronzePath}/SAP/{params['p_todaysFile']}"],
        "Bail": [f"{db_bronzePath}/Bail/{params['p_todaysFile']}"],
        "Essex_STORM": [f"{db_bronzePath}/Essex_STORM/{params['p_todaysFile']}"],
        "Athena_A4E": [f"{db_bronzePath}/Athena_A4E/{params['p_todaysFile']}"],
        "operationalPlanningCalendar": [f"{db_bronzePath}/operationalPlanningCalendar/{params['p_todaysFile']}"]
    }
    
    print(f"📁 Bronze Paths configured for {len(db_bronzeFolder)} domains")
    
    return {
        "db_bronzePath": db_bronzePath,
        "db_bronzeFolder": db_bronzeFolder,
        "db_bronzeFile_Path": db_bronzeFile_Path,
        "db_bronzeFile_Paths": db_bronzeFile_Paths
    }


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### CORE SILVER FUNCTIONS

# CELL ********************

def createTable(createtable, job_name="create_silver_tables"):
    """Create tables if they don't exist with comprehensive tracking"""
    job = tracker.start_job(job_name)
    tables_created = 0
    tables_skipped = 0
    errors = []
    
    for tableName, sql in createtable:
        try:
            if spark.catalog.tableExists(tableName):
                print(f"   ⏭️  Skipping existing table: {tableName}")
                tables_skipped += 1
            else:
                print(f"   🛠️  Creating table: {tableName}")
                spark.sql(sql)
                tables_created += 1
                print(f"   ✅ {tableName} created successfully")
        except Exception as e:
            error_msg = f"Table {tableName} creation failed: {str(e)}"
            print(f"   ❌ {error_msg}")
            errors.append(error_msg)
    
    additional_info = {
        "tables_created": tables_created,
        "tables_skipped": tables_skipped,
        "total_tables": len(createtable)
    }
    
    status = "FAILED" if errors else "SUCCESS"
    tracker.end_job(job_name, status, tables_created, 
                   error_message="; ".join(errors) if errors else None,
                   additional_info=additional_info)

def create_temp_views_by_domain(domain_paths_dict, domain_keys, job_name=None):
    """Create temporary views from bronze parquet files with comprehensive tracking"""
    if isinstance(domain_keys, str):
        domain_keys = [domain_keys]
    
    job_name = job_name or f"temp_views_{'_'.join(domain_keys)}"
    job = tracker.start_job(job_name)
    
    total_views_created = 0
    total_records = 0
    errors = []
    warnings = []
    
    for domain_key in domain_keys:
        if domain_key not in domain_paths_dict:
            warning_msg = f"Domain '{domain_key}' not found in provided paths"
            warnings.append(warning_msg)
            print(f"   ⚠️  {warning_msg}")
            continue

        paths = domain_paths_dict[domain_key]
        domain_views_created = 0
        domain_records = 0

        for path in paths:
            try:
                if not mssparkutils.fs.exists(path):
                    warning_msg = f"Path does not exist: {path}"
                    warnings.append(warning_msg)
                    print(f"   ⚠️  {warning_msg}")
                    continue

                parquetFiles = [f.path for f in mssparkutils.fs.ls(path) if f.name.endswith(".parquet")]
                if not parquetFiles:
                    warning_msg = f"No parquet files found in {path}"
                    warnings.append(warning_msg)
                    print(f"   ⚠️  {warning_msg}")
                    continue

                for filePath in parquetFiles:
                    try:
                        tableName = filePath.split("/")[-1].replace(".parquet", "").rsplit("_2")[0]
                        df = spark.read.parquet(filePath)
                        record_count = df.count()
                        df.createOrReplaceTempView(f"temp_{tableName}")
                        print(f"   ✅ Created temp view: temp_{tableName} - {record_count} records")
                        total_views_created += 1
                        total_records += record_count
                        domain_views_created += 1
                        domain_records += record_count
                    except Exception as e:
                        error_msg = f"Error processing file {filePath}: {str(e)}"
                        errors.append(error_msg)
                        print(f"   ❌ {error_msg}")
                        
            except Exception as e:
                error_msg = f"Error accessing path {path}: {str(e)}"
                errors.append(error_msg)
                print(f"   ❌ {error_msg}")
        
        print(f"   📊 Domain '{domain_key}': {domain_views_created} views, {domain_records} records")

    additional_info = {
        "domains_processed": domain_keys,
        "views_created": total_views_created,
        "total_domains_requested": len(domain_keys),
        "domains_with_errors": len([e for e in errors if "Domain" in e])
    }
    
    # Determine status
    if errors and total_views_created == 0:
        status = "FAILED"
    elif errors or warnings:
        status = "WARNING"
    else:
        status = "SUCCESS"
    
    tracker.end_job(job_name, status, total_records,
                   error_message="; ".join(errors) if errors else None,
                   warning_messages=warnings if warnings else None,
                   additional_info=additional_info)
    
    return total_views_created

def run_sql_static_statement(sqlstatement, job_name="silver_sql_statements"):
    """Execute static SQL statements with tracking"""
    job = tracker.start_job(job_name)
    successful = 0
    errors = []
    
    for table_name, sql in sqlstatement:
        try:
            spark.sql(sql)
            successful += 1
            print(f"   ✅ {table_name} completed successfully")
        except Exception as e:
            error_msg = f"{table_name} failed: {str(e)}"
            errors.append(error_msg)
            print(f"   ❌ {error_msg}")
    
    additional_info = {
        "total_statements": len(sqlstatement),
        "successful_statements": successful
    }
    
    status = "FAILED" if errors and successful == 0 else "WARNING" if errors else "SUCCESS"
    tracker.end_job(job_name, status, successful,
                   error_message="; ".join(errors) if errors else None,
                   additional_info=additional_info)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### UTILITY FUNCTIONS

# CELL ********************

def list_bronze_files(bronze_file_paths, job_name="list_bronze_files"):
    """List all bronze files for inspection"""
    job = tracker.start_job(job_name)
    total_files = 0
    
    print("📁 Bronze Files Inventory:")
    for file_list in bronze_file_paths:
        print(f"   {file_list}")
        total_files += 1
    
    tracker.end_job(job_name, "SUCCESS", total_files, 
                   additional_info={"total_paths_listed": total_files})

def validate_bronze_paths(bronze_file_paths_dict, job_name="validate_bronze_paths"):
    """Validate that bronze paths exist"""
    job = tracker.start_job(job_name)
    valid_paths = 0
    invalid_paths = 0
    warnings = []
    
    for domain, paths in bronze_file_paths_dict.items():
        for path in paths:
            if mssparkutils.fs.exists(path):
                valid_paths += 1
                print(f"   ✅ {domain}: {path} - EXISTS")
            else:
                invalid_paths += 1
                warning_msg = f"{domain}: {path} - NOT FOUND"
                warnings.append(warning_msg)
                print(f"   ⚠️  {warning_msg}")
    
    additional_info = {
        "valid_paths": valid_paths,
        "invalid_paths": invalid_paths,
        "total_paths_checked": valid_paths + invalid_paths
    }
    
    status = "WARNING" if invalid_paths > 0 else "SUCCESS"
    tracker.end_job(job_name, status, valid_paths,
                   warning_messages=warnings if warnings else None,
                   additional_info=additional_info)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# def save_execution_summary(tracker, table_name="Test-execution_logs"):
#     """Save execution summary to monitoring table"""
#     summary = tracker.get_execution_summary()
    
#     execution_log_data = {
#         "execution_id": summary["execution_id"],
#         "notebook_name": summary["notebook_name"],
#         "total_jobs": summary["total_jobs"],
#         "successful_jobs": summary["successful_jobs"],
#         "failed_jobs": summary["failed_jobs"],
#         "warning_jobs": summary["warning_jobs"],
#         "notebook_duration": summary["notebook_duration"],
#         "execution_timestamp": datetime.now(),
#         "detailed_jobs": json.dumps(summary["detailed_jobs"])
#     }
    
#     execution_log_df = spark.createDataFrame([execution_log_data])
#     execution_log_df.write.mode("append").saveAsTable(table_name)
#     print(f"✅ Execution summary saved to {table_name} table!")

# # t6
# def save_execution_summary(tracker, table_name="Test_execution_logs"):
#     """Save execution summary using SQL INSERT"""
#     summary = tracker.get_execution_summary()
    
#     # Escape single quotes in JSON
#     detailed_jobs_json = json.dumps(summary["detailed_jobs"]).replace("'", "''")
    
#     insert_sql = f"""
#     INSERT INTO {table_name} 
#     VALUES (
#         '{summary["execution_id"]}',
#         '{summary["notebook_name"]}',
#         {summary["total_jobs"]},
#         {summary["successful_jobs"]},
#         {summary["failed_jobs"]},
#         {summary["warning_jobs"]},
#         {summary["notebook_duration"]},
#         CURRENT_TIMESTAMP(),
#         '{detailed_jobs_json}'
#     )
#     """
    
#     spark.sql(insert_sql)
#     print(f"✅ Execution summary saved to {table_name} table!")

# t7:
def save_execution_summary(tracker, table_name="Test_execution_logs", layer="unknown"):
    """Save execution summary using only SQL INSERT"""
    job = tracker.start_job("save_to_monitoring")
    
    summary = tracker.get_execution_summary()
    
    try:
        # Escape single quotes in JSON
        detailed_jobs_json = json.dumps(summary["detailed_jobs"]).replace("'", "''")
        
        insert_sql = f"""
        INSERT INTO {table_name} 
        VALUES (
            '{summary["execution_id"]}',
            '{summary["notebook_name"]}',
            '{layer}',
            {summary["total_jobs"]},
            {summary["successful_jobs"]},
            {summary["failed_jobs"]},
            {summary["warning_jobs"]},
            {summary["notebook_duration"]},
            CURRENT_TIMESTAMP(),
            '{detailed_jobs_json}'
        )
        """
        
        spark.sql(insert_sql)
        tracker.end_job("save_to_monitoring", "SUCCESS", 1)
        print(f"✅ Execution summary saved to {table_name} table!")
        print(f"✅ {layer.upper()} Execution summary saved to {table_name} table!")
        
    except Exception as e:
        tracker.end_job("save_to_monitoring", "FAILED", 0, error_message=str(e))
        print(f"❌ Failed to save execution summary: {str(e)}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### INITIALISATION FUNCTION

# CELL ********************

def initialize_silver_config(notebook_name="unknown_silver_notebook"):
    """Initialize the silver config for use in consumer notebooks"""
    global tracker
    tracker = NotebookTracker(notebook_name)
    
    # Initialize parameters and paths
    params = initialize_silver_parameters()
    paths_config = setup_bronze_paths(params)
    
    # Set as globals for convenience
    for key, value in paths_config.items():
        globals()[key] = value
        print(f"📁 {key}: {value if isinstance(value, str) else '[...]'}")
    
    return {
        "tracker": tracker,
        "params": params,
        "paths": paths_config
    }

# Initialize when imported
initialize_silver_config("config_silver_layer")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
