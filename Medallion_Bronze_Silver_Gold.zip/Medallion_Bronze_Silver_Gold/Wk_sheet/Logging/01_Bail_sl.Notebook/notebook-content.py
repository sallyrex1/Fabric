# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "6a459f05-6527-49bd-8600-74065f42a607",
# META       "default_lakehouse_name": "LH_200_Silver_Test",
# META       "default_lakehouse_workspace_id": "a3e4d0e6-6b32-498b-addc-1629a4b29a47",
# META       "known_lakehouses": [
# META         {
# META           "id": "6a459f05-6527-49bd-8600-74065f42a607"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run /config_logs_sl

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Optional: Override parameters BEFORE initialization if needed
p_workSpace = "a3e4d0e6-6b32-498b-addc-1629a4b29a47"
p_todaysFile = "Year_2025/Month_11/Day_03"
p_db_bronzeFolder = '["Bail"]'  # Only process these domains

# Initialize with your actual notebook name
config = initialize_silver_config("01_Bail_bl_sl")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# cell 2 - Validate that bronze paths exist (recommended)
validate_bronze_paths(db_bronzeFile_Paths)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# cell 3 - Create temp views for specific domains
create_temp_views_by_domain(db_bronzeFile_Paths, ["Bail"], job_name="create_bronze_tables_ingest")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# cell 4 - Create silver tables (if they don't exist)
createTable([

# bail_UTIL_DISTRICT
("bail_UTIL_DISTRICT",
"""CREATE TABLE IF NOT EXISTS bail_UTIL_DISTRICT(
    BAIL_UTIL_DISTRICT_ID INT
    ,DISTRICT STRING
    ,AREA_ID INT
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# bail_UTIL_AREA
("bail_UTIL_AREA",
"""CREATE TABLE IF NOT EXISTS bail_UTIL_AREA(
    BAIL_UTIL_AREA_ID INT
    ,POLICE_FORCE STRING
    ,AREA STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# bail_custodyrecord
("bail_custodyrecord",
"""CREATE TABLE IF NOT EXISTS bail_custodyrecord(
    ID	INT
    ,BAILSTARTDATE	TIMESTAMP
    ,CREATED	TIMESTAMP
    ,EXPIREDDATE	TIMESTAMP
    ,FINALISEDATE	TIMESTAMP
    ,REFERENCE	STRING
    ,RELEASEDATE	TIMESTAMP
    ,STATUS	STRING
    ,TERMINATEDDATE	TIMESTAMP
    ,DISTRICT_ID	INT
    ,OIC_ID	STRING
    ,SUPERVISOR_ID	STRING
    ,BAILTORETURNDATE	DATE
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
    )USING DELTA;
"""),
], job_name="create_silver_tables")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# cell 5 - Run your silver ETL logic
run_sql_static_statement([
# bail_UTIL_DISTRICT
('bail_UTIL_DISTRICT', """INSERT OVERWRITE bail_UTIL_DISTRICT(BAIL_UTIL_DISTRICT_ID, DISTRICT, AREA_ID, OA_REC_PROCESSED_DATE, OA_RECORDID)
    WITH bailUTILDISTRICT AS (
        SELECT DISTINCT
        TRY_CAST(id AS INT) AS bail_util_district_id
        ,TRY_CAST(district AS STRING) AS district
        ,TRY_CAST(area_id AS INT) AS area_id
		,ROW_NUMBER() OVER (PARTITION BY ID ORDER BY area_id DESC) AS bailUTILDISTRICT_duplicate
		,SHA2(CONCAT_WS('|', COALESCE(TRY_CAST(BAIL_UTIL_DISTRICT_ID AS STRING), ''), COALESCE(DISTRICT, ''), COALESCE(TRY_CAST(AREA_ID AS STRING), '')), 256) AS OA_RECORDID
        FROM  temp_UTIL_DISTRICT
        WHERE id IS NOT NULL
    )
    SELECT BAIL_UTIL_DISTRICT_ID, DISTRICT, AREA_ID, COALESCE(NULL, CURRENT_TIMESTAMP()), OA_RECORDID FROM bailUTILDISTRICT WHERE bailUTILDISTRICT_duplicate =1
    """),

# bail_UTIL_AREA
('bail_UTIL_AREA', """INSERT OVERWRITE bail_UTIL_AREA(BAIL_UTIL_AREA_ID, POLICE_FORCE, AREA, OA_REC_PROCESSED_DATE, OA_RECORDID)
    WITH bailUTILAREAS AS (
        SELECT DISTINCT
        TRY_CAST(id           AS INT) AS bail_util_area_id
        ,TRY_CAST(police_force AS STRING) AS police_force
        ,TRY_CAST(area		   AS STRING) AS area
        ,ROW_NUMBER() OVER (PARTITION BY ID ORDER BY area DESC) AS bailUTILAREA_duplicate
		,SHA2(CONCAT_WS('|', COALESCE(TRY_CAST(BAIL_UTIL_AREA_ID AS STRING), ''), COALESCE(POLICE_FORCE, ''), COALESCE(AREA, '')), 256) AS OA_RECORDID
        FROM
        temp_UTIL_AREA 
        WHERE id IS NOT NULL
    )
    SELECT BAIL_UTIL_AREA_ID, POLICE_FORCE, AREA, COALESCE(NULL, CURRENT_TIMESTAMP()), OA_RECORDID FROM bailUTILAREAS WHERE bailUTILAREA_duplicate = 1
	"""),

## bail_custodyRecord
("bail_custodyRecord", """INSERT OVERWRITE bail_custodyRecord(id ,bailStartDate ,created ,expiredDate ,finaliseDate ,reference ,releaseDate ,status 
,terminatedDate ,district_id ,oic_id ,supervisor_id ,bailToReturnDate,OA_REC_PROCESSED_DATE,OA_RECORDID)
WITH custodyRecord AS(SELECT DISTINCT
	   TRY_CAST(id AS INT) AS id
      ,TRY_CAST(LEFT(bailStartDate,19) AS timestamp) AS bailStartDate
      ,TRY_CAST(LEFT(created,19) AS timestamp) AS created
      ,TRY_CAST(LEFT(expiredDate,19) AS timestamp) AS expiredDate
      ,TRY_CAST(LEFT(finaliseDate,19) AS timestamp) AS finaliseDate
      ,TRY_CAST(reference AS VARCHAR(20)) AS reference
      ,TRY_CAST(LEFT(releaseDate,19) AS timestamp) AS releaseDate
      ,TRY_CAST(status AS VARCHAR(20)) AS status
      ,TRY_CAST(LEFT(terminatedDate,19) AS timestamp) AS terminatedDate
	  ,TRY_CAST(district_id AS INT) AS district_id
	  ,TRY_CAST(RIGHT('00000000' + TRY_CAST(oic_id AS VARCHAR(15)), 8) AS VARCHAR(15)) AS oic_id
	  ,TRY_CAST(RIGHT('00000000' + TRY_CAST(supervisor_id AS VARCHAR(15)), 8) AS VARCHAR(15)) AS supervisor_id
	  ,TRY_CAST(bailToReturnDate AS DATE) AS bailToReturnDate
	  ,ROW_NUMBER() OVER(PARTITION BY id ORDER BY created) AS custodyRecord_duplicate 
	  ,SHA2(CONCAT_WS('|',COALESCE(TRY_CAST(id AS INT), ''), COALESCE(created, ''), COALESCE(reference, ''), COALESCE(status, '')
	  , COALESCE(district_id, ''), COALESCE(oic_id, ''), COALESCE(supervisor_id, '')),256) AS OA_RECORDID
FROM temp_custodyRecord
WHERE id IS NOT NULL)
SELECT id ,bailStartDate ,created ,expiredDate ,finaliseDate ,reference ,releaseDate ,status ,terminatedDate ,district_id ,oic_id ,supervisor_id ,bailToReturnDate, COALESCE(NULL, CURRENT_TIMESTAMP()),OA_RECORDID FROM custodyRecord WHERE custodyRecord_duplicate =1
"""),
], job_name="silver_etl_processing")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# cell 6 - Get final summary and save to monitoring
summary = tracker.get_execution_summary()

# Save to your control table
spark.createDataFrame([summary]).write.mode("append").saveAsTable("Test_execution_logs")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

save_execution_summary(tracker, "Test_execution_logs", "silver")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Single cell to create the table
spark.sql("""
CREATE TABLE IF NOT EXISTS Test_execution_logs (
    execution_id STRING,
    notebook_name STRING,
    layer STRING,
    total_jobs INT,
    successful_jobs INT,
    failed_jobs INT,
    warning_jobs INT,
    notebook_duration DOUBLE,
    execution_timestamp TIMESTAMP,
    detailed_jobs STRING
) USING DELTA
""")
print("✅ Test_execution_logs table ready!")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

# MAGIC %%sql 
# MAGIC -- DESCRIBE Test_execution_logs
# MAGIC -- DROP TABLE Test_execution_logs
# MAGIC 
# MAGIC -- select * FROM Test_execution_logs
# MAGIC 
# MAGIC SELECT * FROM LH_200_Silver_Test.test_execution_logs LIMIT 1000

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": true
# META }
