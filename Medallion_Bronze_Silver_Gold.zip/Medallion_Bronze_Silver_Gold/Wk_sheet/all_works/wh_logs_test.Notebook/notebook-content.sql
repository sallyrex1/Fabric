-- Fabric notebook source

-- METADATA ********************

-- META {
-- META   "kernel_info": {
-- META     "name": "sqldatawarehouse"
-- META   },
-- META   "dependencies": {
-- META     "warehouse": {
-- META       "default_warehouse": "65b85860-6e65-95e7-4399-e89ee955f64e",
-- META       "known_warehouses": [
-- META         {
-- META           "id": "65b85860-6e65-95e7-4399-e89ee955f64e",
-- META           "type": "Datawarehouse"
-- META         }
-- META       ]
-- META     }
-- META   }
-- META }

-- MARKDOWN ********************

-- ###### Create the table 

-- CELL ********************


-- Create if not exists

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'ctrl')
BEGIN
    EXEC('CREATE SCHEMA [ctrl]');
END




-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- CELL ********************


IF NOT EXISTS ( SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'ctrl' AND TABLE_NAME = 'tbl_DWLoadLog')
BEGIN
    CREATE TABLE [ctrl].[tbl_DWLoadLog] (
        NOTEBOOK_NAME       VARCHAR(255)  NOT NULL,
        STATUS              VARCHAR(50)   NOT NULL,
        ERROR_SUMMARY       VARCHAR(MAX)  NULL,
        PROCESS_TIMESTAMP   DATETIME2(6)   NOT NULL,
        RUN_ID              VARCHAR(1000) NOT NULL,
        ROWS_AFFECTED       INT            NULL,
        -- New columns (as requested)
        SOURCE              VARCHAR(50)   NULL,
        SUCCESSFUL          BIT            NOT NULL,
        FOLDERDATETIME      VARCHAR(14)    NOT NULL
    );
END


-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- MARKDOWN ********************

-- ###### Original -  functional

-- CELL ********************

-- MERGE for: rprt.tbl_d_athena_geo
BEGIN TRY
    DECLARE @wh_db_rprt_tbl_d_athena_geo NVARCHAR(255) = N'WH_400_Gold_Test';
    DECLARE @lh_db_rprt_tbl_d_athena_geo NVARCHAR(255) = N'LH_300_Gold_Test';
    DECLARE @table_name_rprt_tbl_d_athena_geo NVARCHAR(255) = 'rprt.tbl_d_athena_geo';
    DECLARE @rows_affected_rprt_tbl_d_athena_geo INT = 0;
    DECLARE @sql_rprt_tbl_d_athena_geo NVARCHAR(MAX) = N'BEGIN TRY
WITH s_src AS (
    SELECT * FROM ' + QUOTENAME(@lh_db_rprt_tbl_d_athena_geo) + N'.rprt.tbl_d_athena_geo AS s
),
s_dedup AS (
    SELECT s_src.*,
           ROW_NUMBER() OVER (
               PARTITION BY s_src.OA_RECORDID
               ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
           ) AS rn
    FROM s_src
)
MERGE INTO ' + QUOTENAME(@wh_db_rprt_tbl_d_athena_geo) + N'.rprt.tbl_d_athena_geo AS t
USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
ON t.OA_RECORDID = s.OA_RECORDID

WHEN MATCHED THEN
    UPDATE SET 
        t.D_ATHENA_GEO_ID = s.D_ATHENA_GEO_ID,
                t.D_ATHENA_GEO_CODE = s.D_ATHENA_GEO_CODE,
                t.D_ATHENA_GEO_POSTCODE = s.D_ATHENA_GEO_POSTCODE,
                t.D_ATHENA_GEO_DISTRICT = s.D_ATHENA_GEO_DISTRICT,
                t.D_ATHENA_GEO_SECTOR = s.D_ATHENA_GEO_SECTOR,
                t.D_ATHENA_LAT = s.D_ATHENA_LAT,
                t.D_ATHENA_LONG = s.D_ATHENA_LONG,
                t.D_ATHENA_GEO_LOCATION_ID = s.D_ATHENA_GEO_LOCATION_ID,
                t.D_ATHENA_GEO_FORCE = s.D_ATHENA_GEO_FORCE,
                t.D_ATHENA_GEO_BEAT_CODE = s.D_ATHENA_GEO_BEAT_CODE,
                t.D_ATHENA_GEO_BEAT_CODE_DESC = s.D_ATHENA_GEO_BEAT_CODE_DESC,
                t.D_ATHENA_GEO_LOC_TYPE = s.D_ATHENA_GEO_LOC_TYPE,
                t.D_ATHENA_GEO_URBAN_RURAL = s.D_ATHENA_GEO_URBAN_RURAL,
                t.D_ATHENA_GEO_PREMISES_TYPE = s.D_ATHENA_GEO_PREMISES_TYPE,
                t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
                t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
                t.OA_REC_END_DATE = s.OA_REC_END_DATE,
                t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
                t.OA_VERSION = s.OA_VERSION

WHEN NOT MATCHED THEN
    INSERT (D_ATHENA_GEO_ID, D_ATHENA_GEO_CODE, D_ATHENA_GEO_POSTCODE, D_ATHENA_GEO_DISTRICT, D_ATHENA_GEO_SECTOR, D_ATHENA_LAT, D_ATHENA_LONG, D_ATHENA_GEO_LOCATION_ID, D_ATHENA_GEO_FORCE, D_ATHENA_GEO_BEAT_CODE, D_ATHENA_GEO_BEAT_CODE_DESC, D_ATHENA_GEO_LOC_TYPE, D_ATHENA_GEO_URBAN_RURAL, D_ATHENA_GEO_PREMISES_TYPE, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
    VALUES (s.D_ATHENA_GEO_ID, s.D_ATHENA_GEO_CODE, s.D_ATHENA_GEO_POSTCODE, s.D_ATHENA_GEO_DISTRICT, s.D_ATHENA_GEO_SECTOR, s.D_ATHENA_LAT, s.D_ATHENA_LONG, s.D_ATHENA_GEO_LOCATION_ID, s.D_ATHENA_GEO_FORCE, s.D_ATHENA_GEO_BEAT_CODE, s.D_ATHENA_GEO_BEAT_CODE_DESC, s.D_ATHENA_GEO_LOC_TYPE, s.D_ATHENA_GEO_URBAN_RURAL, s.D_ATHENA_GEO_PREMISES_TYPE, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);

SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
    DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
    THROW 50001, @msg, 1;
END CATCH';

    EXEC sp_executesql @sql_rprt_tbl_d_athena_geo, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_athena_geo OUTPUT;

    DECLARE @run_id_rprt_tbl_d_athena_geo NVARCHAR(1000) = @table_name_rprt_tbl_d_athena_geo + '_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + '-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), ':','');

    PRINT 'COMPLETE - SUCCESS | ' + @table_name_rprt_tbl_d_athena_geo + ': ' + CAST(@rows_affected_rprt_tbl_d_athena_geo AS NVARCHAR(20)) + ' rows affected (run_id=' + @run_id_rprt_tbl_d_athena_geo + ')';
    SELECT 'COMPLETE - SUCCESS' AS Status, @table_name_rprt_tbl_d_athena_geo AS TableName, @rows_affected_rprt_tbl_d_athena_geo AS RowsAffected, @run_id_rprt_tbl_d_athena_geo AS RunId;

    DECLARE @sql_log_rprt_tbl_d_athena_geo NVARCHAR(MAX);
    IF EXISTS (
        SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = 'ctrl' AND TABLE_NAME = 'notebook_process_logs' AND COLUMN_NAME = 'ROWS_AFFECTED'
    )
    BEGIN
        SET @sql_log_rprt_tbl_d_athena_geo =
            N'INSERT INTO ' + QUOTENAME(@wh_db_rprt_tbl_d_athena_geo) + N'.[ctrl].[notebook_process_logs]
              (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, PROCESS_TIMESTAMP, RUN_ID, ROWS_AFFECTED)
              VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows);';
        EXEC sp_executesql
            @sql_log_rprt_tbl_d_athena_geo,
            N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int',
            @nb = @table_name_rprt_tbl_d_athena_geo,
            @st = N'COMPLETE - SUCCESS',
            @err = NULL,
            @runid = @run_id_rprt_tbl_d_athena_geo,
            @rows = @rows_affected_rprt_tbl_d_athena_geo;
    END
    ELSE
    BEGIN
        SET @sql_log_rprt_tbl_d_athena_geo =
            N'INSERT INTO ' + QUOTENAME(@wh_db_rprt_tbl_d_athena_geo) + N'.[ctrl].[notebook_process_logs]
              (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, PROCESS_TIMESTAMP, RUN_ID)
              VALUES (@nb, @st, @err, SYSDATETIME(), @runid);';
        EXEC sp_executesql
            @sql_log_rprt_tbl_d_athena_geo,
            N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000)',
            @nb = @table_name_rprt_tbl_d_athena_geo,
            @st = N'COMPLETE - SUCCESS',
            @err = NULL,
            @runid = @run_id_rprt_tbl_d_athena_geo;
    END
END TRY
BEGIN CATCH
    DECLARE @run_id_err_rprt_tbl_d_athena_geo NVARCHAR(1000) = 'rprt.tbl_d_athena_geo' + '_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + '-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), ':','');
    DECLARE @err_msg_rprt_tbl_d_athena_geo NVARCHAR(MAX) = ERROR_MESSAGE();
    DECLARE @err_details_rprt_tbl_d_athena_geo NVARCHAR(MAX) = 'Status=COMPLETE WITH ERROR' + ' | Table=' + 'rprt.tbl_d_athena_geo' + ' | Message=' + @err_msg_rprt_tbl_d_athena_geo + ' | MergeSnippet=' +
        LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db_rprt_tbl_d_athena_geo) + N'.rprt.tbl_d_athena_geo AS s) MERGE INTO ' + QUOTENAME(@wh_db_rprt_tbl_d_athena_geo) + N'.rprt.tbl_d_athena_geo AS t ...', 800);

    PRINT 'COMPLETE WITH ERROR | rprt.tbl_d_athena_geo: ' + @err_msg_rprt_tbl_d_athena_geo + ' (run_id=' + @run_id_err_rprt_tbl_d_athena_geo + ')';
    SELECT 'COMPLETE WITH ERROR' AS Status, 'rprt.tbl_d_athena_geo' AS TableName, @err_msg_rprt_tbl_d_athena_geo AS ErrorMessage, @run_id_err_rprt_tbl_d_athena_geo AS RunId;

    DECLARE @sql_log_err_rprt_tbl_d_athena_geo NVARCHAR(MAX) =
        N'INSERT INTO ' + QUOTENAME(@wh_db_rprt_tbl_d_athena_geo) + N'.[ctrl].[notebook_process_logs]
          (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, PROCESS_TIMESTAMP, RUN_ID, ROWS_AFFECTED)
          VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows);';
    EXEC sp_executesql
        @sql_log_err_rprt_tbl_d_athena_geo,
        N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int',
        @nb = 'rprt.tbl_d_athena_geo',
        @st = N'COMPLETE WITH ERROR',
        @err = @err_details_rprt_tbl_d_athena_geo,
        @runid = @run_id_err_rprt_tbl_d_athena_geo,
        @rows = 0;
END CATCH

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- MARKDOWN ********************

-- ###### Update with ctrl tbl_DWLoadLog

-- CELL ********************



-- MERGE for: calc.tbl_storm_priority
BEGIN TRY
    DECLARE @wh_db_calc_tbl_storm_priority NVARCHAR(255) = N'WH_400_Gold_Test';
    DECLARE @lh_db_calc_tbl_storm_priority NVARCHAR(255) = N'LH_300_Gold_Test';
    DECLARE @table_name_calc_tbl_storm_priority NVARCHAR(255) = N'calc.tbl_storm_priority';

    DECLARE @rows_affected_calc_tbl_storm_priority INT = 0;

    -- Logging-only variables (aligned with your working pattern)
    DECLARE @source_calc_tbl_storm_priority NVARCHAR(50) = N'Storm';  -- domain: Storm, Bail, SAP, Athena_A4E, etc.
    DECLARE @folder_dt_calc_tbl_storm_priority VARCHAR(14) =
        CONVERT(VARCHAR(8), SYSDATETIME(), 112) + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), ':', '');

    DECLARE @sql_calc_tbl_storm_priority NVARCHAR(MAX) = N'
BEGIN TRY
    SET NOCOUNT ON;

    ;WITH s_src AS (
        SELECT * FROM ' + QUOTENAME(@lh_db_calc_tbl_storm_priority) + N'.calc.tbl_storm_priority AS s
    ),
    s_dedup AS (
        SELECT s_src.*,
               ROW_NUMBER() OVER (
                   PARTITION BY s_src.OA_RECORDID
                   ORDER BY s_src.OA_REC_CREATED_DATE DESC,
                            s_src.OA_VERSION DESC,
                            s_src.OA_REC_PROCESSED_DATE DESC
               ) AS rn
        FROM s_src
    )
    MERGE INTO ' + QUOTENAME(@wh_db_calc_tbl_storm_priority) + N'.calc.tbl_storm_priority AS t
    USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
        ON t.OA_RECORDID = s.OA_RECORDID

    WHEN MATCHED THEN
        UPDATE SET 
            t.PRIORITYID            = s.PRIORITYID,
            t.PRIORITY              = s.PRIORITY,
            t.TARGETRESPONSETIME    = s.TARGETRESPONSETIME,
            t.TARGETALLOCATIONTIME  = s.TARGETALLOCATIONTIME,
            t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
            t.OA_REC_CREATED_DATE   = s.OA_REC_CREATED_DATE,
            t.OA_REC_END_DATE       = s.OA_REC_END_DATE,
            t.OA_IS_ACTIVE          = s.OA_IS_ACTIVE,
            t.OA_VERSION            = s.OA_VERSION

    WHEN NOT MATCHED THEN
        INSERT (
            PRIORITYID,
            PRIORITY,
            TARGETRESPONSETIME,
            TARGETALLOCATIONTIME,
            OA_REC_PROCESSED_DATE,
            OA_REC_CREATED_DATE,
            OA_REC_END_DATE,
            OA_IS_ACTIVE,
            OA_VERSION,
            OA_RECORDID
        )
        VALUES (
            s.PRIORITYID,
            s.PRIORITY,
            s.TARGETRESPONSETIME,
            s.TARGETALLOCATIONTIME,
            s.OA_REC_PROCESSED_DATE,
            s.OA_REC_CREATED_DATE,
            s.OA_REC_END_DATE,
            s.OA_IS_ACTIVE,
            s.OA_VERSION,
            s.OA_RECORDID
        );

    SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
    DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
    THROW 50001, @msg, 1;
END CATCH
';

    EXEC sp_executesql
        @sql_calc_tbl_storm_priority,
        N'@rows INT OUTPUT',
        @rows_affected_calc_tbl_storm_priority OUTPUT;

    DECLARE @run_id_calc_tbl_storm_priority NVARCHAR(1000) =
        @table_name_calc_tbl_storm_priority + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112)
        + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');

    PRINT N'COMPLETE - SUCCESS | ' + @table_name_calc_tbl_storm_priority + N': '
          + CAST(@rows_affected_calc_tbl_storm_priority AS NVARCHAR(20))
          + N' rows affected (run_id=' + @run_id_calc_tbl_storm_priority + N')';

    SELECT
        'COMPLETE - SUCCESS' AS Status,
        @table_name_calc_tbl_storm_priority AS TableName,
        @rows_affected_calc_tbl_storm_priority AS RowsAffected,
        @run_id_calc_tbl_storm_priority AS RunId;

    -- Success log (renamed + extended) using three-part name and parameter binding
    DECLARE @sql_log_success_storm NVARCHAR(MAX) =
        N'INSERT INTO ' + QUOTENAME(@wh_db_calc_tbl_storm_priority) + N'.[ctrl].[tbl_DWLoadLog]
          (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, PROCESS_TIMESTAMP, RUN_ID, ROWS_AFFECTED, SOURCE, SUCCESSFUL, FOLDERDATETIME)
          VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';

    EXEC sp_executesql
        @sql_log_success_storm,
        N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
        @nb     = @table_name_calc_tbl_storm_priority,
        @st     = N'COMPLETE - SUCCESS',
        @err    = NULL,
        @runid  = @run_id_calc_tbl_storm_priority,
        @rows   = @rows_affected_calc_tbl_storm_priority,
        @src    = @source_calc_tbl_storm_priority,
        @folder = @folder_dt_calc_tbl_storm_priority;
END TRY
BEGIN CATCH
    DECLARE @run_id_err_calc_tbl_storm_priority NVARCHAR(1000) =
        N'calc.tbl_storm_priority' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112)
        + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');

    DECLARE @err_msg_calc_tbl_storm_priority NVARCHAR(MAX) = ERROR_MESSAGE();

    DECLARE @err_details_calc_tbl_storm_priority NVARCHAR(MAX) =
        N'Status=COMPLETE WITH ERROR'
        + N' | Table=' + N'calc.tbl_storm_priority'
        + N' | Message=' + @err_msg_calc_tbl_storm_priority
        + N' | MergeSnippet='
        + LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db_calc_tbl_storm_priority)
               + N'.calc.tbl_storm_priority AS s) MERGE INTO '
               + QUOTENAME(@wh_db_calc_tbl_storm_priority)
               + N'.calc.tbl_storm_priority AS t ...', 800);

    PRINT N'COMPLETE WITH ERROR | calc.tbl_storm_priority: '
          + @err_msg_calc_tbl_storm_priority
          + N' (run_id=' + @run_id_err_calc_tbl_storm_priority + N')';

    SELECT
        'COMPLETE WITH ERROR' AS Status,
        'calc.tbl_storm_priority' AS TableName,
        @err_msg_calc_tbl_storm_priority AS ErrorMessage,
        @run_id_err_calc_tbl_storm_priority AS RunId;

    -- Error log (renamed + extended) using three-part name and parameter binding
    DECLARE @sql_log_error_storm NVARCHAR(MAX) =
        N'INSERT INTO ' + QUOTENAME(@wh_db_calc_tbl_storm_priority) + N'.[ctrl].[tbl_DWLoadLog]
          (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, PROCESS_TIMESTAMP, RUN_ID, ROWS_AFFECTED, SOURCE, SUCCESSFUL, FOLDERDATETIME)
          VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';

    EXEC sp_executesql
        @sql_log_error_storm,
        N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
        @nb     = N'calc.tbl_storm_priority',
        @st     = N'COMPLETE WITH ERROR',
        @err    = @err_details_calc_tbl_storm_priority,
        @runid  = @run_id_err_calc_tbl_storm_priority,
        @rows   = 0,
        @src    = @source_calc_tbl_storm_priority,
        @folder = @folder_dt_calc_tbl_storm_priority;
END CATCH;



-- MERGE for: rprt.tbl_d_athena_geo
BEGIN TRY
    DECLARE @wh_db_rprt_tbl_d_athena_geo NVARCHAR(255) = N'WH_400_Gold_Test';
    DECLARE @lh_db_rprt_tbl_d_athena_geo NVARCHAR(255) = N'LH_300_Gold_Test';
    DECLARE @table_name_rprt_tbl_d_athena_geo NVARCHAR(255) = N'rprt.tbl_d_athena_geo';

    DECLARE @rows_affected_rprt_tbl_d_athena_geo INT = 0;

    -- New: logging-only variables (no logic changes)
    DECLARE @source_rprt_tbl_d_athena_geo NVARCHAR(50) = N'Athena_A4E';  -- e.g., Storm, Bail, SAP, Athena_A4E
    DECLARE @folder_dt_rprt_tbl_d_athena_geo VARCHAR(14) =
        CONVERT(VARCHAR(8), SYSDATETIME(), 112) + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), ':', '');

    DECLARE @sql_rprt_tbl_d_athena_geo NVARCHAR(MAX) = N'
BEGIN TRY
    SET NOCOUNT ON;

    ;WITH s_src AS (
        SELECT * FROM ' + QUOTENAME(@lh_db_rprt_tbl_d_athena_geo) + N'.rprt.tbl_d_athena_geo AS s
    ),
    s_dedup AS (
        SELECT s_src.*,
               ROW_NUMBER() OVER (
                   PARTITION BY s_src.OA_RECORDID
                   ORDER BY s_src.OA_REC_CREATED_DATE DESC,
                            s_src.OA_VERSION DESC,
                            s_src.OA_REC_PROCESSED_DATE DESC
               ) AS rn
        FROM s_src
    )
    MERGE INTO ' + QUOTENAME(@wh_db_rprt_tbl_d_athena_geo) + N'.rprt.tbl_d_athena_geo AS t
    USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
        ON t.OA_RECORDID = s.OA_RECORDID

    WHEN MATCHED THEN
        UPDATE SET 
            t.D_ATHENA_GEO_ID             = s.D_ATHENA_GEO_ID,
            t.D_ATHENA_GEO_CODE           = s.D_ATHENA_GEO_CODE,
            t.D_ATHENA_GEO_POSTCODE       = s.D_ATHENA_GEO_POSTCODE,
            t.D_ATHENA_GEO_DISTRICT       = s.D_ATHENA_GEO_DISTRICT,
            t.D_ATHENA_GEO_SECTOR         = s.D_ATHENA_GEO_SECTOR,
            t.D_ATHENA_LAT                = s.D_ATHENA_LAT,
            t.D_ATHENA_LONG               = s.D_ATHENA_LONG,
            t.D_ATHENA_GEO_LOCATION_ID    = s.D_ATHENA_GEO_LOCATION_ID,
            t.D_ATHENA_GEO_FORCE          = s.D_ATHENA_GEO_FORCE,
            t.D_ATHENA_GEO_BEAT_CODE      = s.D_ATHENA_GEO_BEAT_CODE,
            t.D_ATHENA_GEO_BEAT_CODE_DESC = s.D_ATHENA_GEO_BEAT_CODE_DESC,
            t.D_ATHENA_GEO_LOC_TYPE       = s.D_ATHENA_GEO_LOC_TYPE,
            t.D_ATHENA_GEO_URBAN_RURAL    = s.D_ATHENA_GEO_URBAN_RURAL,
            t.D_ATHENA_GEO_PREMISES_TYPE  = s.D_ATHENA_GEO_PREMISES_TYPE,
            t.OA_REC_PROCESSED_DATE       = s.OA_REC_PROCESSED_DATE,
            t.OA_REC_CREATED_DATE         = s.OA_REC_CREATED_DATE,
            t.OA_REC_END_DATE             = s.OA_REC_END_DATE,
            t.OA_IS_ACTIVE                = s.OA_IS_ACTIVE,
            t.OA_VERSION                  = s.OA_VERSION

    WHEN NOT MATCHED THEN
        INSERT (
            D_ATHENA_GEO_ID,
            D_ATHENA_GEO_CODE,
            D_ATHENA_GEO_POSTCODE,
            D_ATHENA_GEO_DISTRICT,
            D_ATHENA_GEO_SECTOR,
            D_ATHENA_LAT,
            D_ATHENA_LONG,
            D_ATHENA_GEO_LOCATION_ID,
            D_ATHENA_GEO_FORCE,
            D_ATHENA_GEO_BEAT_CODE,
            D_ATHENA_GEO_BEAT_CODE_DESC,
            D_ATHENA_GEO_LOC_TYPE,
            D_ATHENA_GEO_URBAN_RURAL,
            D_ATHENA_GEO_PREMISES_TYPE,
            OA_REC_PROCESSED_DATE,
            OA_REC_CREATED_DATE,
            OA_REC_END_DATE,
            OA_IS_ACTIVE,
            OA_VERSION,
            OA_RECORDID
        )
        VALUES (
            s.D_ATHENA_GEO_ID,
            s.D_ATHENA_GEO_CODE,
            s.D_ATHENA_GEO_POSTCODE,
            s.D_ATHENA_GEO_DISTRICT,
            s.D_ATHENA_GEO_SECTOR,
            s.D_ATHENA_LAT,
            s.D_ATHENA_LONG,
            s.D_ATHENA_GEO_LOCATION_ID,
            s.D_ATHENA_GEO_FORCE,
            s.D_ATHENA_GEO_BEAT_CODE,
            s.D_ATHENA_GEO_BEAT_CODE_DESC,
            s.D_ATHENA_GEO_LOC_TYPE,
            s.D_ATHENA_GEO_URBAN_RURAL,
            s.D_ATHENA_GEO_PREMISES_TYPE,
            s.OA_REC_PROCESSED_DATE,
            s.OA_REC_CREATED_DATE,
            s.OA_REC_END_DATE,
            s.OA_IS_ACTIVE,
            s.OA_VERSION,
            s.OA_RECORDID
        );

    SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
    DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
    THROW 50001, @msg, 1;
END CATCH
';

    EXEC sp_executesql
        @sql_rprt_tbl_d_athena_geo,
        N'@rows INT OUTPUT',
        @rows_affected_rprt_tbl_d_athena_geo OUTPUT;

    DECLARE @run_id_rprt_tbl_d_athena_geo NVARCHAR(1000) =
        @table_name_rprt_tbl_d_athena_geo + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112)
        + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');

    PRINT N'COMPLETE - SUCCESS | ' + @table_name_rprt_tbl_d_athena_geo + N': '
          + CAST(@rows_affected_rprt_tbl_d_athena_geo AS NVARCHAR(20))
          + N' rows affected (run_id=' + @run_id_rprt_tbl_d_athena_geo + N')';

    SELECT
        'COMPLETE - SUCCESS' AS Status,
        @table_name_rprt_tbl_d_athena_geo AS TableName,
        @rows_affected_rprt_tbl_d_athena_geo AS RowsAffected,
        @run_id_rprt_tbl_d_athena_geo AS RunId;

    -- Build success log SQL (renamed + extended) safely in a variable
    DECLARE @sql_log_success NVARCHAR(MAX) =
        N'INSERT INTO ' + QUOTENAME(@wh_db_rprt_tbl_d_athena_geo) + N'.[ctrl].[tbl_DWLoadLog]
          (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, PROCESS_TIMESTAMP, RUN_ID, ROWS_AFFECTED, SOURCE, SUCCESSFUL, FOLDERDATETIME)
          VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';

    EXEC sp_executesql
        @sql_log_success,
        N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
        @nb     = @table_name_rprt_tbl_d_athena_geo,
        @st     = N'COMPLETE - SUCCESS',
        @err    = NULL,
        @runid  = @run_id_rprt_tbl_d_athena_geo,
        @rows   = @rows_affected_rprt_tbl_d_athena_geo,
        @src    = @source_rprt_tbl_d_athena_geo,
        @folder = @folder_dt_rprt_tbl_d_athena_geo;
END TRY
BEGIN CATCH
    DECLARE @run_id_err_rprt_tbl_d_athena_geo NVARCHAR(1000) =
        N'rprt.tbl_d_athena_geo' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112)
        + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');

    DECLARE @err_msg_rprt_tbl_d_athena_geo NVARCHAR(MAX) = ERROR_MESSAGE();

    DECLARE @err_details_rprt_tbl_d_athena_geo NVARCHAR(MAX) =
        N'Status=COMPLETE WITH ERROR'
        + N' | Table=' + N'rprt.tbl_d_athena_geo'
        + N' | Message=' + @err_msg_rprt_tbl_d_athena_geo
        + N' | MergeSnippet='
        + LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db_rprt_tbl_d_athena_geo)
               + N'.rprt.tbl_d_athena_geo AS s) MERGE INTO '
               + QUOTENAME(@wh_db_rprt_tbl_d_athena_geo)
               + N'.rprt.tbl_d_athena_geo AS t ...', 800);

    PRINT N'COMPLETE WITH ERROR | rprt.tbl_d_athena_geo: '
          + @err_msg_rprt_tbl_d_athena_geo
          + N' (run_id=' + @run_id_err_rprt_tbl_d_athena_geo + N')';

    SELECT
        'COMPLETE WITH ERROR' AS Status,
        'rprt.tbl_d_athena_geo' AS TableName,
        @err_msg_rprt_tbl_d_athena_geo AS ErrorMessage,
        @run_id_err_rprt_tbl_d_athena_geo AS RunId;

    -- Build error log SQL (renamed + extended) safely in a variable
    DECLARE @sql_log_error NVARCHAR(MAX) =
        N'INSERT INTO ' + QUOTENAME(@wh_db_rprt_tbl_d_athena_geo) + N'.[ctrl].[tbl_DWLoadLog]
          (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, PROCESS_TIMESTAMP, RUN_ID, ROWS_AFFECTED, SOURCE, SUCCESSFUL, FOLDERDATETIME)
          VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';

    EXEC sp_executesql
        @sql_log_error,
        N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
        @nb     = N'rprt.tbl_d_athena_geo',
        @st     = N'COMPLETE WITH ERROR',
        @err    = @err_details_rprt_tbl_d_athena_geo,
        @runid  = @run_id_err_rprt_tbl_d_athena_geo,
        @rows   = 0,
        @src    = @source_rprt_tbl_d_athena_geo,
        @folder = @folder_dt_rprt_tbl_d_athena_geo;
END CATCH;


-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse",
-- META   "frozen": true,
-- META   "editable": false
-- META }

-- CELL ********************


/* ============================================================
   Run-wide variables for this cell
   ============================================================ */
DECLARE @wh_db NVARCHAR(255) = N'WH_400_Gold_Test';
DECLARE @lh_db NVARCHAR(255) = N'LH_300_Gold_Test';

-- One FolderDateTime (yyyyMMddHHmmss) shared by all MERGEs in this cell
DECLARE @runFolder VARCHAR(14) =
    CONVERT(VARCHAR(8), SYSDATETIME(), 112) + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), ':', '');


/* ==================================================================
   MERGE #1: calc.tbl_storm_priority        SOURCE = 'Storm'
   ================================================================== */
BEGIN TRY
    DECLARE @table_name_calc_tbl_storm_priority NVARCHAR(255) = N'calc.tbl_storm_priority';
    DECLARE @rows_affected_calc_tbl_storm_priority INT = 0;

    -- Domain/source label for logging
    DECLARE @source_calc_tbl_storm_priority NVARCHAR(50) = N'Storm';

    DECLARE @sql_calc_tbl_storm_priority NVARCHAR(MAX) = N'
BEGIN TRY
    SET NOCOUNT ON;

    ;WITH s_src AS (
        SELECT * FROM ' + QUOTENAME(@lh_db) + N'.calc.tbl_storm_priority AS s
    ),
    s_dedup AS (
        SELECT s_src.*,
               ROW_NUMBER() OVER (
                   PARTITION BY s_src.OA_RECORDID
                   ORDER BY s_src.OA_REC_CREATED_DATE DESC,
                            s_src.OA_VERSION DESC,
                            s_src.OA_REC_PROCESSED_DATE DESC
               ) AS rn
        FROM s_src
    )
    MERGE INTO ' + QUOTENAME(@wh_db) + N'.calc.tbl_storm_priority AS t
    USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
        ON t.OA_RECORDID = s.OA_RECORDID

    WHEN MATCHED THEN
        UPDATE SET 
            t.PRIORITYID            = s.PRIORITYID,
            t.PRIORITY              = s.PRIORITY,
            t.TARGETRESPONSETIME    = s.TARGETRESPONSETIME,
            t.TARGETALLOCATIONTIME  = s.TARGETALLOCATIONTIME,
            t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
            t.OA_REC_CREATED_DATE   = s.OA_REC_CREATED_DATE,
            t.OA_REC_END_DATE       = s.OA_REC_END_DATE,
            t.OA_IS_ACTIVE          = s.OA_IS_ACTIVE,
            t.OA_VERSION            = s.OA_VERSION

    WHEN NOT MATCHED THEN
        INSERT (
            PRIORITYID,
            PRIORITY,
            TARGETRESPONSETIME,
            TARGETALLOCATIONTIME,
            OA_REC_PROCESSED_DATE,
            OA_REC_CREATED_DATE,
            OA_REC_END_DATE,
            OA_IS_ACTIVE,
            OA_VERSION,
            OA_RECORDID
        )
        VALUES (
            s.PRIORITYID,
            s.PRIORITY,
            s.TARGETRESPONSETIME,
            s.TARGETALLOCATIONTIME,
            s.OA_REC_PROCESSED_DATE,
            s.OA_REC_CREATED_DATE,
            s.OA_REC_END_DATE,
            s.OA_IS_ACTIVE,
            s.OA_VERSION,
            s.OA_RECORDID
        );

    SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
    DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
    THROW 50001, @msg, 1;
END CATCH
';

    EXEC sp_executesql
        @sql_calc_tbl_storm_priority,
        N'@rows INT OUTPUT',
        @rows_affected_calc_tbl_storm_priority OUTPUT;

    DECLARE @run_id_calc_tbl_storm_priority NVARCHAR(1000) =
        @table_name_calc_tbl_storm_priority + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112)
        + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');

    PRINT N'COMPLETE - SUCCESS | ' + @table_name_calc_tbl_storm_priority + N': '
          + CAST(@rows_affected_calc_tbl_storm_priority AS NVARCHAR(20))
          + N' rows affected (run_id=' + @run_id_calc_tbl_storm_priority + N')';

    -- Success log to ctrl.tbl_DWLoadLog
    DECLARE @sql_log_success_storm NVARCHAR(MAX) =
        N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
          (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, PROCESS_TIMESTAMP, RUN_ID, ROWS_AFFECTED, SOURCE, SUCCESSFUL, FOLDERDATETIME)
          VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';

    EXEC sp_executesql
        @sql_log_success_storm,
        N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
        @nb     = @table_name_calc_tbl_storm_priority,
        @st     = N'COMPLETE - SUCCESS',
        @err    = NULL,
        @runid  = @run_id_calc_tbl_storm_priority,
        @rows   = @rows_affected_calc_tbl_storm_priority,
        @src    = @source_calc_tbl_storm_priority,
        @folder = @runFolder;
END TRY
BEGIN CATCH
    DECLARE @run_id_err_calc_tbl_storm_priority NVARCHAR(1000) =
        N'calc.tbl_storm_priority' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112)
        + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');

    DECLARE @err_msg_calc_tbl_storm_priority NVARCHAR(MAX) = ERROR_MESSAGE();

    DECLARE @err_details_calc_tbl_storm_priority NVARCHAR(MAX) =
        N'Status=COMPLETE WITH ERROR'
        + N' | Table=' + N'calc.tbl_storm_priority'
        + N' | Message=' + @err_msg_calc_tbl_storm_priority
        + N' | MergeSnippet='
        + LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db)
               + N'.calc.tbl_storm_priority AS s) MERGE INTO '
               + QUOTENAME(@wh_db)
               + N'.calc.tbl_storm_priority AS t ...', 800);

    PRINT N'COMPLETE WITH ERROR | calc.tbl_storm_priority: '
          + @err_msg_calc_tbl_storm_priority
          + N' (run_id=' + @run_id_err_calc_tbl_storm_priority + N')';

    -- Error log to ctrl.tbl_DWLoadLog
    DECLARE @sql_log_error_storm NVARCHAR(MAX) =
        N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
          (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, PROCESS_TIMESTAMP, RUN_ID, ROWS_AFFECTED, SOURCE, SUCCESSFUL, FOLDERDATETIME)
          VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';

    EXEC sp_executesql
        @sql_log_error_storm,
        N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
        @nb     = N'calc.tbl_storm_priority',
        @st     = N'COMPLETE WITH ERROR',
        @err    = @err_details_calc_tbl_storm_priority,
        @runid  = @run_id_err_calc_tbl_storm_priority,
        @rows   = 0,
        @src    = @source_calc_tbl_storm_priority,
        @folder = @runFolder;
END CATCH;


/* ==================================================================
   MERGE #2: rprt.tbl_d_athena_geo          SOURCE = 'Athena_A4E'
   ================================================================== */
BEGIN TRY
    DECLARE @table_name_rprt_tbl_d_athena_geo NVARCHAR(255) = N'rprt.tbl_d_athena_geo';
    DECLARE @rows_affected_rprt_tbl_d_athena_geo INT = 0;

    DECLARE @source_rprt_tbl_d_athena_geo NVARCHAR(50) = N'Athena_A4E';

    DECLARE @sql_rprt_tbl_d_athena_geo NVARCHAR(MAX) = N'
BEGIN TRY
    SET NOCOUNT ON;

    ;WITH s_src AS (
        SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_athena_geo AS s
    ),
    s_dedup AS (
        SELECT s_src.*,
               ROW_NUMBER() OVER (
                   PARTITION BY s_src.OA_RECORDID
                   ORDER BY s_src.OA_REC_CREATED_DATE DESC,
                            s_src.OA_VERSION DESC,
                            s_src.OA_REC_PROCESSED_DATE DESC
               ) AS rn
        FROM s_src
    )
    MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_athena_geo AS t
    USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
        ON t.OA_RECORDID = s.OA_RECORDID

    WHEN MATCHED THEN
        UPDATE SET 
            t.D_ATHENA_GEO_ID             = s.D_ATHENA_GEO_ID,
            t.D_ATHENA_GEO_CODE           = s.D_ATHENA_GEO_CODE,
            t.D_ATHENA_GEO_POSTCODE       = s.D_ATHENA_GEO_POSTCODE,
            t.D_ATHENA_GEO_DISTRICT       = s.D_ATHENA_GEO_DISTRICT,
            t.D_ATHENA_GEO_SECTOR         = s.D_ATHENA_GEO_SECTOR,
            t.D_ATHENA_LAT                = s.D_ATHENA_LAT,
            t.D_ATHENA_LONG               = s.D_ATHENA_LONG,
            t.D_ATHENA_GEO_LOCATION_ID    = s.D_ATHENA_GEO_LOCATION_ID,
            t.D_ATHENA_GEO_FORCE          = s.D_ATHENA_GEO_FORCE,
            t.D_ATHENA_GEO_BEAT_CODE      = s.D_ATHENA_GEO_BEAT_CODE,
            t.D_ATHENA_GEO_BEAT_CODE_DESC = s.D_ATHENA_GEO_BEAT_CODE_DESC,
            t.D_ATHENA_GEO_LOC_TYPE       = s.D_ATHENA_GEO_LOC_TYPE,
            t.D_ATHENA_GEO_URBAN_RURAL    = s.D_ATHENA_GEO_URBAN_RURAL,
            t.D_ATHENA_GEO_PREMISES_TYPE  = s.D_ATHENA_GEO_PREMISES_TYPE,
            t.OA_REC_PROCESSED_DATE       = s.OA_REC_PROCESSED_DATE,
            t.OA_REC_CREATED_DATE         = s.OA_REC_CREATED_DATE,
            t.OA_REC_END_DATE             = s.OA_REC_END_DATE,
            t.OA_IS_ACTIVE                = s.OA_IS_ACTIVE,
            t.OA_VERSION                  = s.OA_VERSION

    WHEN NOT MATCHED THEN
        INSERT (
            D_ATHENA_GEO_ID,
            D_ATHENA_GEO_CODE,
            D_ATHENA_GEO_POSTCODE,
            D_ATHENA_GEO_DISTRICT,
            D_ATHENA_GEO_SECTOR,
            D_ATHENA_LAT,
            D_ATHENA_LONG,
            D_ATHENA_GEO_LOCATION_ID,
            D_ATHENA_GEO_FORCE,
            D_ATHENA_GEO_BEAT_CODE,
            D_ATHENA_GEO_BEAT_CODE_DESC,
            D_ATHENA_GEO_LOC_TYPE,
            D_ATHENA_GEO_URBAN_RURAL,
            D_ATHENA_GEO_PREMISES_TYPE,
            OA_REC_PROCESSED_DATE,
            OA_REC_CREATED_DATE,
            OA_REC_END_DATE,
            OA_IS_ACTIVE,
            OA_VERSION,
            OA_RECORDID
        )
        VALUES (
            s.D_ATHENA_GEO_ID,
            s.D_ATHENA_GEO_CODE,
            s.D_ATHENA_GEO_POSTCODE,
            s.D_ATHENA_GEO_DISTRICT,
            s.D_ATHENA_GEO_SECTOR,
            s.D_ATHENA_LAT,
            s.D_ATHENA_LONG,
            s.D_ATHENA_GEO_LOCATION_ID,
            s.D_ATHENA_GEO_FORCE,
            s.D_ATHENA_GEO_BEAT_CODE,
            s.D_ATHENA_GEO_BEAT_CODE_DESC,
            s.D_ATHENA_GEO_LOC_TYPE,
            s.D_ATHENA_GEO_URBAN_RURAL,
            s.D_ATHENA_GEO_PREMISES_TYPE,
            s.OA_REC_PROCESSED_DATE,
            s.OA_REC_CREATED_DATE,
            s.OA_REC_END_DATE,
            s.OA_IS_ACTIVE,
            s.OA_VERSION,
            s.OA_RECORDID
        );

    SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
    DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
    THROW 50001, @msg, 1;
END CATCH
';

    EXEC sp_executesql
        @sql_rprt_tbl_d_athena_geo,
        N'@rows INT OUTPUT',
        @rows_affected_rprt_tbl_d_athena_geo OUTPUT;

    DECLARE @run_id_rprt_tbl_d_athena_geo NVARCHAR(1000) =
        @table_name_rprt_tbl_d_athena_geo + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112)
        + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');

    PRINT N'COMPLETE - SUCCESS | ' + @table_name_rprt_tbl_d_athena_geo + N': '
          + CAST(@rows_affected_rprt_tbl_d_athena_geo AS NVARCHAR(20))
          + N' rows affected (run_id=' + @run_id_rprt_tbl_d_athena_geo + N')';

    -- Success log to ctrl.tbl_DWLoadLog
    DECLARE @sql_log_success_athena_geo NVARCHAR(MAX) =
        N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
          (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, PROCESS_TIMESTAMP, RUN_ID, ROWS_AFFECTED, SOURCE, SUCCESSFUL, FOLDERDATETIME)
          VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';

    EXEC sp_executesql
        @sql_log_success_athena_geo,
        N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
        @nb     = @table_name_rprt_tbl_d_athena_geo,
        @st     = N'COMPLETE - SUCCESS',
        @err    = NULL,
        @runid  = @run_id_rprt_tbl_d_athena_geo,
        @rows   = @rows_affected_rprt_tbl_d_athena_geo,
        @src    = @source_rprt_tbl_d_athena_geo,
        @folder = @runFolder;
END TRY
BEGIN CATCH
    DECLARE @run_id_err_rprt_tbl_d_athena_geo NVARCHAR(1000) =
        N'rprt.tbl_d_athena_geo' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112)
        + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');

    DECLARE @err_msg_rprt_tbl_d_athena_geo NVARCHAR(MAX) = ERROR_MESSAGE();

    DECLARE @err_details_rprt_tbl_d_athena_geo NVARCHAR(MAX) =
        N'Status=COMPLETE WITH ERROR'
        + N' | Table=' + N'rprt.tbl_d_athena_geo'
        + N' | Message=' + @err_msg_rprt_tbl_d_athena_geo
        + N' | MergeSnippet='
        + LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db)
               + N'.rprt.tbl_d_athena_geo AS s) MERGE INTO '
               + QUOTENAME(@wh_db)
               + N'.rprt.tbl_d_athena_geo AS t ...', 800);

    PRINT N'COMPLETE WITH ERROR | rprt.tbl_d_athena_geo: '
          + @err_msg_rprt_tbl_d_athena_geo
          + N' (run_id=' + @run_id_err_rprt_tbl_d_athena_geo + N')';

    -- Error log to ctrl.tbl_DWLoadLog
    DECLARE @sql_log_error_athena_geo NVARCHAR(MAX) =
        N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
          (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, PROCESS_TIMESTAMP, RUN_ID, ROWS_AFFECTED, SOURCE, SUCCESSFUL, FOLDERDATETIME)
          VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';

    EXEC sp_executesql
        @sql_log_error_athena_geo,
        N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
        @nb     = N'rprt.tbl_d_athena_geo',
        @st     = N'COMPLETE WITH ERROR',
        @err    = @err_details_rprt_tbl_d_athena_geo,
        @runid  = @run_id_err_rprt_tbl_d_athena_geo,
        @rows   = 0,
        @src    = @source_rprt_tbl_d_athena_geo,
        @folder = @runFolder;
END CATCH;


/* ==================================================================
   MERGE #3: calc.athena_reason_for_arrest   SOURCE = 'Athena_A4E'
   ================================================================== */
BEGIN TRY
    DECLARE @table_name_calc_athena_reason_for_arrest NVARCHAR(255) = N'calc.athena_reason_for_arrest';
    DECLARE @rows_affected_calc_athena_reason_for_arrest INT = 0;

    DECLARE @source_calc_athena_reason_for_arrest NVARCHAR(50) = N'Athena_A4E';

    DECLARE @sql_calc_athena_reason_for_arrest NVARCHAR(MAX) = N'
BEGIN TRY
    SET NOCOUNT ON;

    ;WITH s_src AS (
        SELECT * FROM ' + QUOTENAME(@lh_db) + N'.calc.athena_reason_for_arrest AS s
    ),
    s_dedup AS (
        SELECT s_src.*,
               ROW_NUMBER() OVER (
                   PARTITION BY s_src.OA_RECORDID
                   ORDER BY s_src.OA_REC_CREATED_DATE DESC,
                            s_src.OA_VERSION DESC,
                            s_src.OA_REC_PROCESSED_DATE DESC
               ) AS rn
        FROM s_src
    )
    MERGE INTO ' + QUOTENAME(@wh_db) + N'.calc.athena_reason_for_arrest AS t
    USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
        ON t.OA_RECORDID = s.OA_RECORDID

    WHEN MATCHED THEN
        UPDATE SET
            t.ID                   = s.ID,
            t.ACPO_GROUPING_GCV    = s.ACPO_GROUPING_GCV,
            t.OA_REC_PROCESSED_DATE= s.OA_REC_PROCESSED_DATE,
            t.OA_REC_CREATED_DATE  = s.OA_REC_CREATED_DATE,
            t.OA_REC_END_DATE      = s.OA_REC_END_DATE,
            t.OA_IS_ACTIVE         = s.OA_IS_ACTIVE,
            t.OA_VERSION           = s.OA_VERSION

    WHEN NOT MATCHED THEN
        INSERT (ID, ACPO_GROUPING_GCV, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
        VALUES (s.ID, s.ACPO_GROUPING_GCV, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);

    SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
    DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
    THROW 50001, @msg, 1;
END CATCH
';

    EXEC sp_executesql
        @sql_calc_athena_reason_for_arrest,
        N'@rows INT OUTPUT',
        @rows_affected_calc_athena_reason_for_arrest OUTPUT;

    DECLARE @run_id_calc_athena_reason_for_arrest NVARCHAR(1000) =
        @table_name_calc_athena_reason_for_arrest + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112)
        + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');

    PRINT N'COMPLETE - SUCCESS | ' + @table_name_calc_athena_reason_for_arrest + N': '
          + CAST(@rows_affected_calc_athena_reason_for_arrest AS NVARCHAR(20))
          + N' rows affected (run_id=' + @run_id_calc_athena_reason_for_arrest + N')';

    -- Success log to ctrl.tbl_DWLoadLog
    DECLARE @sql_log_success_athena_reason NVARCHAR(MAX) =
        N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
          (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, PROCESS_TIMESTAMP, RUN_ID, ROWS_AFFECTED, SOURCE, SUCCESSFUL, FOLDERDATETIME)
          VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';

    EXEC sp_executesql
        @sql_log_success_athena_reason,
        N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
        @nb     = @table_name_calc_athena_reason_for_arrest,
        @st     = N'COMPLETE - SUCCESS',
        @err    = NULL,
        @runid  = @run_id_calc_athena_reason_for_arrest,
        @rows   = @rows_affected_calc_athena_reason_for_arrest,
        @src    = @source_calc_athena_reason_for_arrest,
        @folder = @runFolder;
END TRY
BEGIN CATCH
    DECLARE @run_id_err_calc_athena_reason_for_arrest NVARCHAR(1000) =
        N'calc.athena_reason_for_arrest' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112)
        + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');

    DECLARE @err_msg_calc_athena_reason_for_arrest NVARCHAR(MAX) = ERROR_MESSAGE();

    DECLARE @err_details_calc_athena_reason_for_arrest NVARCHAR(MAX) =
        N'Status=COMPLETE WITH ERROR'
        + N' | Table=' + N'calc.athena_reason_for_arrest'
        + N' | Message=' + @err_msg_calc_athena_reason_for_arrest
        + N' | MergeSnippet='
        + LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db)
               + N'.calc.athena_reason_for_arrest AS s) MERGE INTO '
               + QUOTENAME(@wh_db)
               + N'.calc.athena_reason_for_arrest AS t ...', 800);

    PRINT N'COMPLETE WITH ERROR | calc.athena_reason_for_arrest: '
          + @err_msg_calc_athena_reason_for_arrest
          + N' (run_id=' + @run_id_err_calc_athena_reason_for_arrest + N')';

    -- Error log to ctrl.tbl_DWLoadLog
    DECLARE @sql_log_error_athena_reason NVARCHAR(MAX) =
        N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
          (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, PROCESS_TIMESTAMP, RUN_ID, ROWS_AFFECTED, SOURCE, SUCCESSFUL, FOLDERDATETIME)
          VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';

    EXEC sp_executesql
        @sql_log_error_athena_reason,
        N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
        @nb     = N'calc.athena_reason_for_arrest',
        @st     = N'COMPLETE WITH ERROR',
        @err    = @err_details_calc_athena_reason_for_arrest,
        @runid  = @run_id_err_calc_athena_reason_for_arrest,
        @rows   = 0,
        @src    = @source_calc_athena_reason_for_arrest,
        @folder = @runFolder;
END CATCH;


/* ============================================================
   Final consolidated grid for this cell (no table variables)
   ============================================================ */
DECLARE @sql_show NVARCHAR(MAX) =
    N'SELECT
         STATUS        AS Status,
         NOTEBOOK_NAME AS TableName,
         ROWS_AFFECTED AS RowsAffected,
         RUN_ID        AS RunId
      FROM ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
      WHERE FOLDERDATETIME = @f
      ORDER BY TableName;';

EXEC sp_executesql
    @sql_show,
    N'@f varchar(14)',
    @f = @runFolder;


-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse",
-- META   "frozen": true,
-- META   "editable": false
-- META }

-- MARKDOWN ********************

-- ###### update

-- CELL ********************


-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- MARKDOWN ********************

-- CURRENT THAT WORKS

-- CELL ********************

/* ============================================================
 Run-wide variables for this cell
 ============================================================ */
DECLARE @wh_db NVARCHAR(255) = N'WH_400_Gold_Test';
DECLARE @lh_db NVARCHAR(255) = N'LH_300_Gold_Test';
DECLARE @source NVARCHAR(50) = N'Bail';
-- One FolderDateTime (yyyyMMddHHmmss) shared by all MERGEs in this cell
DECLARE @runFolder VARCHAR(14) =
  CONVERT(VARCHAR(8), SYSDATETIME(), 112) + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), ':', '');
  
/* ==================================================================
 MERGE #1: rprt.tbl_d_bail_geo SOURCE = 'Bail'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_bail_geo NVARCHAR(255) = N'rprt.tbl_d_bail_geo';
DECLARE @rows_affected_rprt_tbl_d_bail_geo INT = 0;
DECLARE @run_id_rprt_tbl_d_bail_geo NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_bail_geo NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_bail_geo NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_bail_geo NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_bail_geo NVARCHAR(MAX);

BEGIN TRY
  DECLARE @sql_rprt_tbl_d_bail_geo NVARCHAR(MAX) = N'
BEGIN TRY
  SET NOCOUNT ON;
  ;WITH s_src AS (
     SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_bail_geo AS s
  ),
  s_dedup AS (
     SELECT s_src.*,
            ROW_NUMBER() OVER (
              PARTITION BY s_src.OA_RECORDID
              ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
            ) AS rn
     FROM s_src
  )
  MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_bail_geo AS t
  USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
  ON t.OA_RECORDID = s.OA_RECORDID
  WHEN MATCHED THEN
    UPDATE SET
    t.D_BAIL_GEO_DISTRICT_ID = s.D_BAIL_GEO_DISTRICT_ID,
    t.D_BAIL_GEO_DISTRICT = s.D_BAIL_GEO_DISTRICT,
    t.D_BAIL_GEO_AREA_ID = s.D_BAIL_GEO_AREA_ID,
    t.D_BAIL_GEO_AREA = s.D_BAIL_GEO_AREA,
    t.D_BAIL_GEO_POLICE_FORCE = s.D_BAIL_GEO_POLICE_FORCE,
    t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
    t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
    t.OA_REC_END_DATE = s.OA_REC_END_DATE,
    t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
    t.OA_VERSION = s.OA_VERSION
  WHEN NOT MATCHED THEN
    INSERT (D_BAIL_GEO_DISTRICT_ID, D_BAIL_GEO_DISTRICT, D_BAIL_GEO_AREA_ID, D_BAIL_GEO_AREA, D_BAIL_GEO_POLICE_FORCE, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
    VALUES (s.D_BAIL_GEO_DISTRICT_ID, s.D_BAIL_GEO_DISTRICT, s.D_BAIL_GEO_AREA_ID, s.D_BAIL_GEO_AREA, s.D_BAIL_GEO_POLICE_FORCE, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
  SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
  DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
  THROW 50001, @msg, 1;
END CATCH
';
  EXEC sp_executesql @sql_rprt_tbl_d_bail_geo, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_bail_geo OUTPUT;
  SET @run_id_rprt_tbl_d_bail_geo = @table_name_rprt_tbl_d_bail_geo + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
  PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_bail_geo + N': ' + CAST(@rows_affected_rprt_tbl_d_bail_geo AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_bail_geo + N')';
  SET @sql_log_success_rprt_tbl_d_bail_geo =
    N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
      (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, PROCESS_TIMESTAMP, RUN_ID, ROWS_AFFECTED, SOURCE, SUCCESSFUL, FOLDERDATETIME)
      VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
  EXEC sp_executesql
    @sql_log_success_rprt_tbl_d_bail_geo,
    N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
    @nb = @table_name_rprt_tbl_d_bail_geo,
    @st = N'COMPLETE - SUCCESS',
    @err = NULL,
    @runid = @run_id_rprt_tbl_d_bail_geo,
    @rows = @rows_affected_rprt_tbl_d_bail_geo,
    @src = @source,
    @folder = @runFolder;
END TRY
BEGIN CATCH
  SET @run_id_rprt_tbl_d_bail_geo = N'rprt.tbl_d_bail_geo' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
  SET @err_msg_rprt_tbl_d_bail_geo = ERROR_MESSAGE();
  SET @err_details_rprt_tbl_d_bail_geo =
    N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_bail_geo' + N' \n Message=' + @err_msg_rprt_tbl_d_bail_geo + N' \n MergeSnippet=' +
    LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_bail_geo AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_bail_geo AS t ...', 800)
  PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_bail_geo: ' + @err_msg_rprt_tbl_d_bail_geo + N' (run_id=' + @run_id_rprt_tbl_d_bail_geo + N')';
  SET @sql_log_error_rprt_tbl_d_bail_geo =
    N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
      (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, PROCESS_TIMESTAMP, RUN_ID, ROWS_AFFECTED, SOURCE, SUCCESSFUL, FOLDERDATETIME)
      VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
  EXEC sp_executesql
    @sql_log_error_rprt_tbl_d_bail_geo,
    N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
    @nb = N'rprt.tbl_d_bail_geo',
    @st = N'COMPLETE WITH ERROR',
    @err = @err_details_rprt_tbl_d_bail_geo,
    @runid = @run_id_rprt_tbl_d_bail_geo,
    @rows = 0,
    @src = @source,
    @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #2: rprt.tbl_d_bail SOURCE = 'Bail'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_bail NVARCHAR(255) = N'rprt.tbl_d_bail';
DECLARE @rows_affected_rprt_tbl_d_bail INT = 0;
DECLARE @run_id_rprt_tbl_d_bail NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_bail NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_bail NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_bail NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_bail NVARCHAR(MAX);

BEGIN TRY
  DECLARE @sql_rprt_tbl_d_bail NVARCHAR(MAX) = N'
BEGIN TRY
  SET NOCOUNT ON;
  ;WITH s_src AS (
     SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_bail AS s
  ),
  s_dedup AS (
     SELECT s_src.*,
            ROW_NUMBER() OVER (
              PARTITION BY s_src.OA_RECORDID
              ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
            ) AS rn
     FROM s_src
  )
  MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_bail AS t
  USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
  ON t.OA_RECORDID = s.OA_RECORDID
  WHEN MATCHED THEN
    UPDATE SET
    t.D_BAIL_ID = s.D_BAIL_ID,
    t.D_BAIL_CUSTODY_ID = s.D_BAIL_CUSTODY_ID,
    t.D_BAIL_TYPE = s.D_BAIL_TYPE,
    t.D_BAIL_TYPE_FULL = s.D_BAIL_TYPE_FULL,
    t.D_BAIL_CRIME_TYPE = s.D_BAIL_CRIME_TYPE,
    t.D_BAIL_CREATED_ON = s.D_BAIL_CREATED_ON,
    t.D_BAIL_RELEASE_DATE = s.D_BAIL_RELEASE_DATE,
    t.D_BAIL_RUI_FINALISE_DATE = s.D_BAIL_RUI_FINALISE_DATE,
    t.D_BAIL_BAIL_EXPIRY_DATE = s.D_BAIL_BAIL_EXPIRY_DATE,
    t.D_BAIL_BAIL_DATE = s.D_BAIL_BAIL_DATE,
    t.D_BAIL_TERMINATED_DATE = s.D_BAIL_TERMINATED_DATE,
    t.D_BAIL_REVIEW_DUE_DATE = s.D_BAIL_REVIEW_DUE_DATE,
    t.D_BAIL_LIVE_OR_HISTORIC = s.D_BAIL_LIVE_OR_HISTORIC,
    t.D_BAIL_STAGE = s.D_BAIL_STAGE,
    t.D_BAIL_END_DATE = s.D_BAIL_END_DATE,
    t.D_BAIL_CUSTODY_REF = s.D_BAIL_CUSTODY_REF,
    t.D_BAIL_BAIL_TO_RETURN_DATE = s.D_BAIL_BAIL_TO_RETURN_DATE,
    t.D_BAIL_SUSPENSION = s.D_BAIL_SUSPENSION,
    t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
    t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
    t.OA_REC_END_DATE = s.OA_REC_END_DATE,
    t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
    t.OA_VERSION = s.OA_VERSION
  WHEN NOT MATCHED THEN
    INSERT (D_BAIL_ID, D_BAIL_CUSTODY_ID, D_BAIL_TYPE, D_BAIL_TYPE_FULL, D_BAIL_CRIME_TYPE, D_BAIL_CREATED_ON, D_BAIL_RELEASE_DATE, D_BAIL_RUI_FINALISE_DATE, D_BAIL_BAIL_EXPIRY_DATE, D_BAIL_BAIL_DATE, D_BAIL_TERMINATED_DATE, D_BAIL_REVIEW_DUE_DATE, D_BAIL_LIVE_OR_HISTORIC, D_BAIL_STAGE, D_BAIL_END_DATE, D_BAIL_CUSTODY_REF, D_BAIL_BAIL_TO_RETURN_DATE, D_BAIL_SUSPENSION, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
    VALUES (s.D_BAIL_ID, s.D_BAIL_CUSTODY_ID, s.D_BAIL_TYPE, s.D_BAIL_TYPE_FULL, s.D_BAIL_CRIME_TYPE, s.D_BAIL_CREATED_ON, s.D_BAIL_RELEASE_DATE, s.D_BAIL_RUI_FINALISE_DATE, s.D_BAIL_BAIL_EXPIRY_DATE, s.D_BAIL_BAIL_DATE, s.D_BAIL_TERMINATED_DATE, s.D_BAIL_REVIEW_DUE_DATE, s.D_BAIL_LIVE_OR_HISTORIC, s.D_BAIL_STAGE, s.D_BAIL_END_DATE, s.D_BAIL_CUSTODY_REF, s.D_BAIL_BAIL_TO_RETURN_DATE, s.D_BAIL_SUSPENSION, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
  SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
  DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
  THROW 50001, @msg, 1;
END CATCH
';
  EXEC sp_executesql @sql_rprt_tbl_d_bail, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_bail OUTPUT;
  SET @run_id_rprt_tbl_d_bail = @table_name_rprt_tbl_d_bail + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
  PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_bail + N': ' + CAST(@rows_affected_rprt_tbl_d_bail AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_bail + N')';
  SET @sql_log_success_rprt_tbl_d_bail =
    N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
      (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, PROCESS_TIMESTAMP, RUN_ID, ROWS_AFFECTED, SOURCE, SUCCESSFUL, FOLDERDATETIME)
      VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
  EXEC sp_executesql
    @sql_log_success_rprt_tbl_d_bail,
    N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
    @nb = @table_name_rprt_tbl_d_bail,
    @st = N'COMPLETE - SUCCESS',
    @err = NULL,
    @runid = @run_id_rprt_tbl_d_bail,
    @rows = @rows_affected_rprt_tbl_d_bail,
    @src = @source,
    @folder = @runFolder;
END TRY
BEGIN CATCH
  SET @run_id_rprt_tbl_d_bail = N'rprt.tbl_d_bail' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
  SET @err_msg_rprt_tbl_d_bail = ERROR_MESSAGE();
  SET @err_details_rprt_tbl_d_bail =
    N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_bail' + N' \n Message=' + @err_msg_rprt_tbl_d_bail + N' \n MergeSnippet=' +
    LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_bail AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_bail AS t ...', 800)
  PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_bail: ' + @err_msg_rprt_tbl_d_bail + N' (run_id=' + @run_id_rprt_tbl_d_bail + N')';
  SET @sql_log_error_rprt_tbl_d_bail =
    N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
      (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, PROCESS_TIMESTAMP, RUN_ID, ROWS_AFFECTED, SOURCE, SUCCESSFUL, FOLDERDATETIME)
      VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
  EXEC sp_executesql
    @sql_log_error_rprt_tbl_d_bail,
    N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
    @nb = N'rprt.tbl_d_bail',
    @st = N'COMPLETE WITH ERROR',
    @err = @err_details_rprt_tbl_d_bail,
    @runid = @run_id_rprt_tbl_d_bail,
    @rows = 0,
    @src = @source,
    @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #3: rprt.tbl_f_bail SOURCE = 'Bail'
 ================================================================== */
DECLARE @table_name_rprt_tbl_f_bail NVARCHAR(255) = N'rprt.tbl_f_bail';
DECLARE @rows_affected_rprt_tbl_f_bail INT = 0;
DECLARE @run_id_rprt_tbl_f_bail NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_f_bail NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_f_bail NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_f_bail NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_f_bail NVARCHAR(MAX);

BEGIN TRY
  DECLARE @sql_rprt_tbl_f_bail NVARCHAR(MAX) = N'
BEGIN TRY
  SET NOCOUNT ON;
  ;WITH s_src AS (
     SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_f_bail AS s
  ),
  s_dedup AS (
     SELECT s_src.*,
            ROW_NUMBER() OVER (
              PARTITION BY s_src.OA_RECORDID
              ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
            ) AS rn
     FROM s_src
  )
  MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_f_bail AS t
  USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
  ON t.OA_RECORDID = s.OA_RECORDID
  WHEN MATCHED THEN
    UPDATE SET
    t.FK_D_BAIL_CUSTODY_ID = s.FK_D_BAIL_CUSTODY_ID,
    t.FK_D_CREATE_DATE_ID = s.FK_D_CREATE_DATE_ID,
    t.FK_D_CREATE_TIME_ID = s.FK_D_CREATE_TIME_ID,
    t.FK_D_CUSTODY_REF = s.FK_D_CUSTODY_REF,
    t.FK_D_BAIL_OIC_ID = s.FK_D_BAIL_OIC_ID,
    t.F_BAIL_OIC_ID = s.F_BAIL_OIC_ID,
    t.FK_D_BAIL_GEO_DISTRICT_ID = s.FK_D_BAIL_GEO_DISTRICT_ID,
    t.FK_D_BAIL_SUPERVISOR_ID = s.FK_D_BAIL_SUPERVISOR_ID,
    t.FK_D_BAIL_AUTHORISING_OFFICER_ID = s.FK_D_BAIL_AUTHORISING_OFFICER_ID,
    t.F_MET_LENGTH_DAYS = s.F_MET_LENGTH_DAYS,
    t.F_MET_PROXIMITY_EXPIRY = s.F_MET_PROXIMITY_EXPIRY,
    t.BAIL_TYPE = s.BAIL_TYPE,
    t.LIVE_OR_HISTORIC = s.LIVE_OR_HISTORIC,
    t.STAFF_MOVE_ID = s.STAFF_MOVE_ID,
    t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
    t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
    t.OA_REC_END_DATE = s.OA_REC_END_DATE,
    t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
    t.OA_VERSION = s.OA_VERSION
  WHEN NOT MATCHED THEN
    INSERT (FK_D_BAIL_CUSTODY_ID, FK_D_CREATE_DATE_ID, FK_D_CREATE_TIME_ID, FK_D_CUSTODY_REF, FK_D_BAIL_OIC_ID, F_BAIL_OIC_ID, FK_D_BAIL_GEO_DISTRICT_ID, FK_D_BAIL_SUPERVISOR_ID, FK_D_BAIL_AUTHORISING_OFFICER_ID, F_MET_LENGTH_DAYS, F_MET_PROXIMITY_EXPIRY, BAIL_TYPE, LIVE_OR_HISTORIC, STAFF_MOVE_ID, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
    VALUES (s.FK_D_BAIL_CUSTODY_ID, s.FK_D_CREATE_DATE_ID, s.FK_D_CREATE_TIME_ID, s.FK_D_CUSTODY_REF, s.FK_D_BAIL_OIC_ID, s.F_BAIL_OIC_ID, s.FK_D_BAIL_GEO_DISTRICT_ID, s.FK_D_BAIL_SUPERVISOR_ID, s.FK_D_BAIL_AUTHORISING_OFFICER_ID, s.F_MET_LENGTH_DAYS, s.F_MET_PROXIMITY_EXPIRY, s.BAIL_TYPE, s.LIVE_OR_HISTORIC, s.STAFF_MOVE_ID, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
  SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
  DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
  THROW 50001, @msg, 1;
END CATCH
';
  EXEC sp_executesql @sql_rprt_tbl_f_bail, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_f_bail OUTPUT;
  SET @run_id_rprt_tbl_f_bail = @table_name_rprt_tbl_f_bail + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
  PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_f_bail + N': ' + CAST(@rows_affected_rprt_tbl_f_bail AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_f_bail + N')';
  SET @sql_log_success_rprt_tbl_f_bail =
    N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
      (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, PROCESS_TIMESTAMP, RUN_ID, ROWS_AFFECTED, SOURCE, SUCCESSFUL, FOLDERDATETIME)
      VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
  EXEC sp_executesql
    @sql_log_success_rprt_tbl_f_bail,
    N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
    @nb = @table_name_rprt_tbl_f_bail,
    @st = N'COMPLETE - SUCCESS',
    @err = NULL,
    @runid = @run_id_rprt_tbl_f_bail,
    @rows = @rows_affected_rprt_tbl_f_bail,
    @src = @source,
    @folder = @runFolder;
END TRY
BEGIN CATCH
  SET @run_id_rprt_tbl_f_bail = N'rprt.tbl_f_bail' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
  SET @err_msg_rprt_tbl_f_bail = ERROR_MESSAGE();
  SET @err_details_rprt_tbl_f_bail =
    N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_f_bail' + N' \n Message=' + @err_msg_rprt_tbl_f_bail + N' \n MergeSnippet=' +
    LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_f_bail AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_f_bail AS t ...', 800)
  PRINT N'COMPLETE WITH ERROR \n rprt.tbl_f_bail: ' + @err_msg_rprt_tbl_f_bail + N' (run_id=' + @run_id_rprt_tbl_f_bail + N')';
  SET @sql_log_error_rprt_tbl_f_bail =
    N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
      (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, PROCESS_TIMESTAMP, RUN_ID, ROWS_AFFECTED, SOURCE, SUCCESSFUL, FOLDERDATETIME)
      VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
  EXEC sp_executesql
    @sql_log_error_rprt_tbl_f_bail,
    N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
    @nb = N'rprt.tbl_f_bail',
    @st = N'COMPLETE WITH ERROR',
    @err = @err_details_rprt_tbl_f_bail,
    @runid = @run_id_rprt_tbl_f_bail,
    @rows = 0,
    @src = @source,
    @folder = @runFolder;
END CATCH;


/* ==================================================================
 MERGE #4: rprt.tbl_b_case_custody SOURCE = 'Bail'
 ================================================================== */
DECLARE @table_name_rprt_tbl_b_case_custody NVARCHAR(255) = N'rprt.tbl_b_case_custody';
DECLARE @rows_affected_rprt_tbl_b_case_custody INT = 0;
DECLARE @run_id_rprt_tbl_b_case_custody NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_b_case_custody NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_b_case_custody NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_b_case_custody NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_b_case_custody NVARCHAR(MAX);

BEGIN TRY
  DECLARE @sql_rprt_tbl_b_case_custody NVARCHAR(MAX) = N'
BEGIN TRY
  SET NOCOUNT ON;
  ;WITH s_src AS (
     SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_b_case_custody AS s
  ),
  s_dedup AS (
     SELECT s_src.*,
            ROW_NUMBER() OVER (
              PARTITION BY s_src.OA_RECORDID
              ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
            ) AS rn
     FROM s_src
  )
  MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_b_case_custody AS t
  USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
  ON t.OA_RECORDID = s.OA_RECORDID
  WHEN MATCHED THEN
    UPDATE SET
    t.B_CASE_CUSTODY_LINK_ID = s.B_CASE_CUSTODY_LINK_ID,
    t.FK_D_CASE_ID = s.FK_D_CASE_ID,
    t.FK_F_CUSTODY_RECORD_ID = s.FK_F_CUSTODY_RECORD_ID,
    t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
    t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
    t.OA_REC_END_DATE = s.OA_REC_END_DATE,
    t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
    t.OA_VERSION = s.OA_VERSION
  WHEN NOT MATCHED THEN
    INSERT (B_CASE_CUSTODY_LINK_ID, FK_D_CASE_ID, FK_F_CUSTODY_RECORD_ID, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
    VALUES (s.B_CASE_CUSTODY_LINK_ID, s.FK_D_CASE_ID, s.FK_F_CUSTODY_RECORD_ID, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
  SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
  DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
  THROW 50001, @msg, 1;
END CATCH
';
  EXEC sp_executesql @sql_rprt_tbl_b_case_custody, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_b_case_custody OUTPUT;
  SET @run_id_rprt_tbl_b_case_custody = @table_name_rprt_tbl_b_case_custody + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
  PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_b_case_custody + N': ' + CAST(@rows_affected_rprt_tbl_b_case_custody AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_b_case_custody + N')';
  SET @sql_log_success_rprt_tbl_b_case_custody =
    N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
      (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, PROCESS_TIMESTAMP, RUN_ID, ROWS_AFFECTED, SOURCE, SUCCESSFUL, FOLDERDATETIME)
      VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
  EXEC sp_executesql
    @sql_log_success_rprt_tbl_b_case_custody,
    N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
    @nb = @table_name_rprt_tbl_b_case_custody,
    @st = N'COMPLETE - SUCCESS',
    @err = NULL,
    @runid = @run_id_rprt_tbl_b_case_custody,
    @rows = @rows_affected_rprt_tbl_b_case_custody,
    @src = @source,
    @folder = @runFolder;
END TRY
BEGIN CATCH
  SET @run_id_rprt_tbl_b_case_custody = N'rprt.tbl_b_case_custody' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
  SET @err_msg_rprt_tbl_b_case_custody = ERROR_MESSAGE();
  SET @err_details_rprt_tbl_b_case_custody =
    N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_b_case_custody' + N' \n Message=' + @err_msg_rprt_tbl_b_case_custody + N' \n MergeSnippet=' +
    LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_b_case_custody AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_b_case_custody AS t ...', 800)
  PRINT N'COMPLETE WITH ERROR \n rprt.tbl_b_case_custody: ' + @err_msg_rprt_tbl_b_case_custody + N' (run_id=' + @run_id_rprt_tbl_b_case_custody + N')';
  SET @sql_log_error_rprt_tbl_b_case_custody =
    N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
      (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, PROCESS_TIMESTAMP, RUN_ID, ROWS_AFFECTED, SOURCE, SUCCESSFUL, FOLDERDATETIME)
      VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
  EXEC sp_executesql
    @sql_log_error_rprt_tbl_b_case_custody,
    N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
    @nb = N'rprt.tbl_b_case_custody',
    @st = N'COMPLETE WITH ERROR',
    @err = @err_details_rprt_tbl_b_case_custody,
    @runid = @run_id_rprt_tbl_b_case_custody,
    @rows = 0,
    @src = @source,
    @folder = @runFolder;
END CATCH;

/* ============================================================
 Final consolidated grid for this cell (no table variables)
 ============================================================ */
DECLARE @sql_show NVARCHAR(MAX) =
  N'SELECT
     STATUS AS Status,
     NOTEBOOK_NAME AS TableName,
     ROWS_AFFECTED AS RowsAffected,
     RUN_ID AS RunId
   FROM ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
   WHERE FOLDERDATETIME = @f
   ORDER BY TableName;';
EXEC sp_executesql
  @sql_show,
  N'@f varchar(14)',
  @f = @runFolder;

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- CELL ********************

SELECT * FROM
-- DELETE 
ctrl.tbl_DWLoadLog 
WHERE 1=1 
-- AND NOTEBOOK_NAME IN('rprt.tbl_d_bail')
-- AND NOTEBOOK_NAME LIKE 'rprt.tbl_d_%'
ORDER BY 9;

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- CELL ********************



-- =========================================
-- Optional: verify all tables are empty
-- =========================================

DECLARE @SchemaName SYSNAME = N'rprt';

SELECT QUOTENAME(s.name) + N'.' + QUOTENAME(t.name) AS table_name,
       COALESCE(SUM(p.rows), 0) AS row_count
FROM sys.tables t
JOIN sys.schemas s    ON s.schema_id = t.schema_id
LEFT JOIN sys.partitions p ON p.object_id = t.object_id AND p.index_id IN (0,1)
WHERE s.name = @SchemaName
GROUP BY s.name, t.name
ORDER BY table_name;


-- =========================================
-- Inspect which FKs are blocking truncation
-- =========================================

DECLARE @SchemaName SYSNAME = N'rprt';  -- <-- set your schema

SELECT
    fk.name                               AS fk_name,
    QUOTENAME(sp.name) + '.' + QUOTENAME(tp.name) AS referencing_table,
    QUOTENAME(sr.name) + '.' + QUOTENAME(tr.name) AS referenced_table
FROM sys.foreign_keys AS fk
JOIN sys.tables        AS tp ON fk.parent_object_id     = tp.object_id      -- child table
JOIN sys.schemas       AS sp ON tp.schema_id            = sp.schema_id
JOIN sys.tables        AS tr ON fk.referenced_object_id = tr.object_id      -- parent table
JOIN sys.schemas       AS sr ON tr.schema_id            = sr.schema_id
WHERE sr.name = @SchemaName
ORDER BY referenced_table, fk_name;


-- =========================================
-- Drop all FKs that reference your schema’s tables
-- =========================================

DECLARE @SchemaName SYSNAME = N'rprt';  -- <-- set your schema
DECLARE @sql NVARCHAR(MAX);

-- Build drop statements for all FKs where the referenced table is in @SchemaName
SELECT @sql = STRING_AGG(
    N'ALTER TABLE ' + QUOTENAME(sp.name) + N'.' + QUOTENAME(tp.name) +
    N' DROP CONSTRAINT ' + QUOTENAME(fk.name),
    N';' + CHAR(10)
)
FROM sys.foreign_keys AS fk
JOIN sys.tables        AS tp ON fk.parent_object_id     = tp.object_id
JOIN sys.schemas       AS sp ON tp.schema_id            = sp.schema_id
JOIN sys.tables        AS tr ON fk.referenced_object_id = tr.object_id
JOIN sys.schemas       AS sr ON tr.schema_id            = sr.schema_id
WHERE sr.name = @SchemaName;

IF @sql IS NOT NULL AND LEN(@sql) > 0
BEGIN
    PRINT N'-- Dropping FKs referencing schema ' + @SchemaName;
    PRINT @sql;
    EXEC sp_executesql @sql;
END
ELSE
BEGIN
    PRINT N'No FKs found referencing schema ' + @SchemaName;
END





-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- MARKDOWN ********************

-- ###### Check Table count

-- CELL ********************



DECLARE @schema SYSNAME = N'rprt';
DECLARE @sql NVARCHAR(MAX);

-- Build a single UNION ALL query; force NVARCHAR(MAX) so STRING_AGG returns LOB
SELECT @sql =
(
    SELECT STRING_AGG(
               CONVERT(NVARCHAR(MAX),
                   'SELECT ''' + QUOTENAME(@schema) + '.' + QUOTENAME(t.name) + ''' AS table_name, ' +
                   'COUNT_BIG(*) AS row_count FROM ' + QUOTENAME(@schema) + '.' + QUOTENAME(t.name)
               ),
               NCHAR(10) + 'UNION ALL' + NCHAR(10)
           )
    FROM sys.tables AS t
    JOIN sys.schemas AS s ON s.schema_id = t.schema_id
    WHERE s.name = @schema
);

-- Return one combined grid
EXEC sp_executesql @sql;


-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- MARKDOWN ********************

-- ###### DELET FK ROUTE CHILD -> PARENT (B TABLES -> F TABLES -> D TALBES) YOU REVERSE WHEN ADDING THEM BACK

-- MARKDOWN ********************

-- ###### CHECK IF FK/PK/UK EXIST

-- CELL ********************

SELECT CONSTRAINT_SCHEMA, TABLE_NAME, CONSTRAINT_NAME, CONSTRAINT_TYPE, 
CONCAT('ALTER TABLE ', CONSTRAINT_SCHEMA,' . ', TABLE_NAME, ' DROP CONSTRAINT ', CONSTRAINT_NAME)
FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
WHERE CONSTRAINT_TYPE <> 'PRIMARY KEY'

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- CELL ********************


DECLARE @SchemaName SYSNAME = 'rprt';
DECLARE @sql VARCHAR(MAX);

SELECT @sql =
(
    SELECT STRING_AGG(
               CONVERT(VARCHAR(MAX),
                   'ALTER TABLE ' + QUOTENAME(sp.name) + '.' + QUOTENAME(tp.name) +
                   ' DROP CONSTRAINT ' + QUOTENAME(fk.name)
               ),
               ';' + CHAR(10)
           )
    FROM sys.foreign_keys AS fk
    JOIN sys.tables        AS tp ON fk.parent_object_id     = tp.object_id   -- child table
    JOIN sys.schemas       AS sp ON tp.schema_id            = sp.schema_id   -- child schema
    JOIN sys.tables        AS tr ON fk.referenced_object_id = tr.object_id   -- parent table
    JOIN sys.schemas       AS sr ON tr.schema_id            = sr.schema_id   -- parent schema
    WHERE sr.name = @SchemaName
);

IF @sql IS NOT NULL AND LEN(@sql) > 0
BEGIN
    PRINT '-- Dropping FKs whose referenced (parent) table is in schema ' + @SchemaName;
    PRINT @sql;
    EXEC sp_executesql @sql;
END
ELSE
BEGIN
    PRINT 'No FKs found that reference tables in schema ' + @SchemaName;
END


-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- CELL ********************

-- =========================================
-- Use this when all foreign keys have been manually dropped
-- =========================================-

DECLARE @SchemaName SYSNAME = N'rprt';  -- change to your schema
DECLARE @sql NVARCHAR(MAX);

-- Build TRUNCATE statements for all user tables in the schema
SELECT @sql = STRING_AGG(
    N'TRUNCATE TABLE ' + QUOTENAME(s.name) + N'.' + QUOTENAME(t.name),
    N';' + CHAR(10)
)
FROM sys.tables t
JOIN sys.schemas s ON s.schema_id = t.schema_id
WHERE s.name = @SchemaName;

-- Execute only if we have statements
IF @sql IS NOT NULL AND LEN(@sql) > 0
BEGIN
    PRINT N'-- Truncate batch --';
    PRINT @sql;
    EXEC sp_executesql @sql;
END
ELSE
BEGIN
    PRINT N'No tables found in schema ' + @SchemaName;
END


-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- CELL ********************


DECLARE @SchemaName SYSNAME = 'rprt';
DECLARE @sql VARCHAR(MAX);

SELECT @sql =
(
    SELECT STRING_AGG(
               CONVERT(VARCHAR(MAX),
                   'ALTER TABLE ' + QUOTENAME(sp.name) + '.' + QUOTENAME(tp.name) +
                   ' DROP CONSTRAINT ' + QUOTENAME(fk.name)
               ),
               ';' + CHAR(10)
           )
    FROM sys.foreign_keys AS fk
    JOIN sys.tables        AS tp ON fk.parent_object_id     = tp.object_id   -- child table
    JOIN sys.schemas       AS sp ON tp.schema_id            = sp.schema_id   -- child schema
    WHERE sp.name = @SchemaName
);

IF @sql IS NOT NULL AND LEN(@sql) > 0
BEGIN
    PRINT '-- Dropping FKs on child tables in schema ' + @SchemaName;
    PRINT @sql;
    EXEC sp_executesql @sql;
END
ELSE
BEGIN
    PRINT 'No FKs found on child tables in schema ' + @SchemaName;
END


-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- CELL ********************


DECLARE @SchemaName SYSNAME = 'rprt';
DECLARE @sql VARCHAR(MAX);

SELECT @sql =
(
    SELECT STRING_AGG(
               CONVERT(VARCHAR(MAX),
                   'TRUNCATE TABLE ' + QUOTENAME(s.name) + '.' + QUOTENAME(t.name)
               ),
               ';' + CHAR(10)
           )
    FROM sys.tables t
    JOIN sys.schemas s ON s.schema_id = t.schema_id
    WHERE s.name = @SchemaName
);

IF @sql IS NOT NULL AND LEN(@sql) > 0
BEGIN
    PRINT '-- Truncate batch --';
    PRINT @sql;
    EXEC sp_executesql @sql;
END
ELSE
BEGIN
    PRINT 'No tables found in schema ' + @SchemaName;
END


-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }
