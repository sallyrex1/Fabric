# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "42396a50-8b85-4951-9850-b36abfe2a28d",
# META       "default_lakehouse_name": "LH_300_Gold_Test",
# META       "default_lakehouse_workspace_id": "a3e4d0e6-6b32-498b-addc-1629a4b29a47",
# META       "known_lakehouses": [
# META         {
# META           "id": "42396a50-8b85-4951-9850-b36abfe2a28d"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# ### CDC CONFIG

# CELL ********************

import com.microsoft.spark.fabric
from com.microsoft.spark.fabric import Constants

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# CDC PROCESS

# CELL ********************

def smart_cdc_sync(warehouse="WH_400_Gold_Test", schema="rprt", table_pattern="tbl_b_*"):
    """Smart CDC that detects actual changes for both CDC and non-CDC tables"""
    
    tables = [r.tableName for r in spark.sql(f"SHOW TABLES IN {schema} LIKE '{table_pattern}'").collect()]
    print(f"🔄 Smart CDC sync for {len(tables)} tables...")
    
    for table in tables:
        try:
            print(f"{table}: ", end="", flush=True)
            
            # Read source data
            source_df = spark.read.table(f"{schema}.{table}")
            source_cols = source_df.columns
            source_count = source_df.count()
            
            # Check if table exists in target and get current state
            try:
                target_df = spark.read.synapsesql(f"{warehouse}.{schema}.{table}")
                target_count = target_df.count()
                target_exists = True
            except:
                target_exists = False
                target_count = 0
            
            # Check CDC capability
            has_cdc = all(col in source_cols for col in ['OA_RECORDID', 'OA_IS_ACTIVE', 'OA_REC_PROCESS_DATETIME'])
            
            if not has_cdc:
                # Non-CDC table - only refresh if data changed or table doesn't exist
                if not target_exists:
                    # First time - create table
                    source_df.write.mode("overwrite").synapsesql(f"{warehouse}.{schema}.{table}")
                    print(f"📦 Created ({source_count} records)")
                elif source_count != target_count:
                    # Count changed - refresh
                    source_df.write.mode("overwrite").synapsesql(f"{warehouse}.{schema}.{table}")
                    print(f"📦 Refreshed ({source_count} records, was {target_count})")
                else:
                    # No changes detected
                    print(f"✅ No changes ({source_count} records)")
                continue
            
            # CDC Table Logic
            from pyspark.sql.functions import col
            
            # Get active records from source
            source_active = source_df.filter(col("OA_IS_ACTIVE") == 1)
            source_active_count = source_active.count()
            
            if not target_exists:
                # First sync - create with active records
                source_active.write.mode("overwrite").synapsesql(f"{warehouse}.{schema}.{table}")
                print(f"✅ Initial sync ({source_active_count} active records)")
                continue
            
            # Get latest timestamp from target
            try:
                target_time_df = spark.sql(f"SELECT MAX(OA_REC_PROCESS_DATETIME) as max_time FROM {warehouse}.{schema}.{table}")
                last_sync_time = target_time_df.collect()[0]['max_time']
            except:
                last_sync_time = None
            
            if last_sync_time:
                # Incremental sync
                new_records = source_active.filter(col("OA_REC_PROCESS_DATETIME") > last_sync_time)
                new_count = new_records.count()
                
                if new_count > 0:
                    # Handle updates
                    record_ids = [r.OA_RECORDID for r in new_records.select("OA_RECORDID").collect()]
                    if record_ids:
                        ids_str = "','".join(record_ids)
                        spark.sql(f"DELETE FROM {warehouse}.{schema}.{table} WHERE OA_RECORDID IN ('{ids_str}')")
                    
                    new_records.write.mode("append").synapsesql(f"{warehouse}.{schema}.{table}")
                    print(f"✅ {new_count} new records")
                else:
                    print(f"✅ No changes ({source_active_count} active records)")
            else:
                # Should not happen for existing table, but handle it
                source_active.write.mode("overwrite").synapsesql(f"{warehouse}.{schema}.{table}")
                print(f"✅ Re-synced ({source_active_count} active records)")
                
        except Exception as e:
            print(f"❌ {str(e)}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ### CREATE TEMPLATE CONSTRAINT

# MARKDOWN ********************

# ###### TEMP ENVIRONMENT

# CELL ********************

from pyspark.sql.types import StructType, StructField, StringType
import re

def generate_fabric_constraint_statements(constraint_sql):
    """
    Generate MS Fabric-compliant ALTER TABLE statements from multiple constraint definitions
    """
    
    # Split the input into sections for each table
    sections = re.split(r'\n(?=\d+\.\s*--)', constraint_sql.strip())
    
    table_constraints = {}  # Dictionary to store constraints by table
    
    for section in sections:
        if not section.strip():
            continue
            
        lines = [line.strip() for line in section.split('\n') if line.strip()]
        current_table = None
        
        # Extract table name from the section header
        header_match = re.search(r'--\s*([\w\.]+)\s+definition', section, re.IGNORECASE)
        if header_match:
            current_table = header_match.group(1)
            table_constraints[current_table] = []  # Initialize list for this table
        
        for line in lines:
            # Skip comments and empty lines
            if line.startswith('--') or not line:
                continue
                
            # Primary Key constraint - Fabric compliant format
            if 'PRIMARY KEY' in line.upper() and 'CONSTRAINT' in line.upper():
                # Extract constraint name and columns using regex
                pk_match = re.search(r'CONSTRAINT\s+(\w+)\s+PRIMARY\s+KEY\s*\(\s*([^)]+)\s*\)', line, re.IGNORECASE)
                if pk_match and current_table:
                    constraint_name = pk_match.group(1)
                    columns = pk_match.group(2).strip()
                    # Fabric compliant primary key template
                    constraint_stmt = f"ALTER TABLE {current_table} ADD CONSTRAINT {constraint_name} PRIMARY KEY NONCLUSTERED ({columns}) NOT ENFORCED;"
                    table_constraints[current_table].append(constraint_stmt)
            
            # Foreign Key constraints - Fabric compliant format
            elif 'ADD CONSTRAINT' in line.upper() and 'FOREIGN KEY' in line.upper():
                # Extract foreign key details using regex
                fk_match = re.search(r'ALTER TABLE\s+([\w\.]+)\s+ADD CONSTRAINT\s+(\w+)\s+FOREIGN KEY\s*\(\s*([^)]+)\s*\)\s*REFERENCES\s+([^(]+)\s*\(\s*([^)]+)\s*\)', line, re.IGNORECASE)
                if fk_match:
                    source_table = fk_match.group(1)
                    constraint_name = fk_match.group(2)
                    fk_columns = fk_match.group(3).strip()
                    ref_table = fk_match.group(4).strip()
                    ref_columns = fk_match.group(5).strip()
                    # Fabric compliant foreign key template
                    constraint_stmt = f"ALTER TABLE {source_table} ADD CONSTRAINT {constraint_name} FOREIGN KEY ({fk_columns}) REFERENCES {ref_table}({ref_columns}) NOT ENFORCED;"
                    
                    # Ensure the table exists in our dictionary
                    if source_table not in table_constraints:
                        table_constraints[source_table] = []
                    table_constraints[source_table].append(constraint_stmt)
    
    return table_constraints

# Your input constraint SQL with multiple tables
constraint_sql = """

	CONSTRAINT PK__tbl_b_cr__276758C7E5BD7181 PRIMARY KEY (B_CRIME_CUSTODY_LINK_ID),
	CONSTRAINT FK_B_CRIME_CUSTODY_CRIME_FK FOREIGN KEY (FK_D_CRIME_ID) REFERENCES prod.rprt.tbl_d_crime(D_CRIME_ID),
	CONSTRAINT FK_B_CRIME_CUSTODY_CUSTODY_FK FOREIGN KEY (FK_F_CUSTODY_RECORD_ID) REFERENCES prod.rprt.tbl_f_custody_record(F_CUSTODY_RECORD_ID)


"""

# Generate the Fabric-compliant ALTER statements grouped by table
table_constraints = generate_fabric_constraint_statements(constraint_sql)

# Display results grouped by table
print("Generated MS Fabric-Compliant Constraint Statements:")
print("=" * 60)

all_statements = []
for table_name, constraints in table_constraints.items():
    if constraints:  # Only show tables that have constraints
        print(f"\n=========={table_name}==========")
        for i, statement in enumerate(constraints, 1):
            print(f"{i}. {statement}")
            all_statements.append(statement)

# Create a Spark DataFrame with all results
schema = StructType([StructField("fabric_constraint_statements", StringType(), True)])
constraints_df = spark.createDataFrame([(stmt,) for stmt in all_statements], schema)

print(f"\nGenerated {len(all_statements)} Fabric-compliant constraint statements across {len(table_constraints)} tables")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### TABLE CORRECTION MANUL

# CELL ********************

# MAGIC %%sql
# MAGIC -- 1. Create a new table with correct schema
# MAGIC CREATE TABLE IF NOT EXISTS rprt.tbl_b_crime_custody_new(
# MAGIC     B_CRIME_CUSTODY_LINK_ID	INT
# MAGIC     ,FK_D_CRIME_ID INT
# MAGIC     ,FK_F_CUSTODY_RECORD_ID INT
# MAGIC     ,OA_REC_PROCESSED_DATE TIMESTAMP
# MAGIC     ,OA_REC_CREATED_DATE TIMESTAMP
# MAGIC     ,OA_REC_END_DATE TIMESTAMP
# MAGIC     ,OA_IS_ACTIVE INT
# MAGIC     ,OA_VERSION INT
# MAGIC     ,OA_RECORDID STRING
# MAGIC     )USING DELTA;
# MAGIC 
# MAGIC 
# MAGIC -- 2. Insert data from old table (handle NULLs and cast ID)
# MAGIC INSERT INTO rprt.tbl_b_crime_custody_new
# MAGIC SELECT CAST(COALESCE(B_CRIME_CUSTODY_LINK_ID, 0) AS INT) AS B_CRIME_CUSTODY_LINK_ID
# MAGIC 
# MAGIC 
# MAGIC ,FK_D_CRIME_ID
# MAGIC ,FK_F_CUSTODY_RECORD_ID
# MAGIC ,OA_REC_PROCESSED_DATE
# MAGIC ,OA_REC_CREATED_DATE
# MAGIC ,OA_REC_END_DATE
# MAGIC ,OA_IS_ACTIVE
# MAGIC ,OA_VERSION
# MAGIC ,OA_RECORDID
# MAGIC 
# MAGIC FROM rprt.tbl_b_crime_custody;
# MAGIC 
# MAGIC -- 3. Drop old table and rename new one
# MAGIC DROP TABLE rprt.tbl_b_crime_custody;
# MAGIC ALTER TABLE rprt.tbl_b_crime_custody_new RENAME TO rprt.tbl_b_crime_custody;

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql 
# MAGIC DESCRIBE rprt.tbl_b_crime_custody

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### AUTOMATED

# CELL ********************

from pyspark.sql import SparkSession
from pyspark.sql.utils import AnalysisException

def generate_dynamic_migration(source_table, target_schema_ddl):
    """
    Generates a complete migration script dynamically
    """
    
    spark = SparkSession.builder.getOrCreate()
    
    # Extract schema and table names
    if '.' in source_table:
        schema_name = source_table.split('.')[0]
        table_name = source_table.split('.')[1]
    else:
        schema_name = 'default'
        table_name = source_table
    
    temp_table = f"{schema_name}.{table_name}_temp"
    
    # Parse target schema from DDL
    target_columns = []
    lines = target_schema_ddl.split('\n')
    for line in lines:
        line = line.strip().strip(',')
        if line and not any(line.startswith(keyword) for keyword in 
                           ['CREATE', ')', 'USING', '--']):
            if '(' in line and ')' in line:
                col_def = line.split('(')[0].strip()
            else:
                col_def = line
            if col_def:
                target_columns.append(col_def)
    
    # Get source schema
    try:
        source_df = spark.table(source_table)
        source_schema = source_df.schema
    except AnalysisException:
        return f"Error: Source table {source_table} not found"
    
    # Build SELECT expressions and CREATE TABLE columns
    select_expressions = []
    create_table_columns = []
    
    for col_def in target_columns:
        parts = col_def.split()
        if not parts:
            continue
            
        col_name = parts[0]
        col_type = ' '.join(parts[1:]) if len(parts) > 1 else 'STRING'
        
        # Add to CREATE TABLE clause
        create_table_columns.append(f"  {col_def}")
        
        # Check if column exists in source
        if col_name in source_df.columns:
            source_col = source_df.schema[col_name]
            
            # Handle special cases
            if col_name.upper() == 'ID' and 'NOT NULL' in col_type.upper():
                select_expressions.append(f"CAST(COALESCE({col_name}, 0) AS INT) AS {col_name}")
            elif source_col.dataType.simpleString() != col_type.split()[0].lower():
                # Type conversion needed
                select_expressions.append(f"CAST({col_name} AS {col_type.split()[0]}) AS {col_name}")
            else:
                select_expressions.append(col_name)
        else:
            # Column doesn't exist in source - use default based on type
            if 'INT' in col_type:
                select_expressions.append(f"0 AS {col_name}")
            elif 'TIMESTAMP' in col_type:
                select_expressions.append(f"NULL AS {col_name}")
            elif 'STRING' in col_type:
                select_expressions.append(f"'' AS {col_name}")
            else:
                select_expressions.append(f"NULL AS {col_name}")
    
    select_clause = ",\n  ".join(select_expressions)
    create_table_clause = ",\n".join(create_table_columns)
    
    # Generate COMPLETELY DYNAMIC script
    script = f"""
%%sql
-- 1. Create temporary table with target schema
CREATE TABLE {temp_table} (
{create_table_clause}
) USING DELTA;

-- 2. Dynamic INSERT with automatic type handling
INSERT INTO {temp_table}
SELECT 
  {select_clause}
FROM {source_table};

-- 3. Swap tables
DROP TABLE {source_table};
ALTER TABLE {temp_table} RENAME TO {table_name};
"""
    
    return script

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC describe rprt.tbl_d_time

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# YOU NEED TO PROVIDE THE SOURCE TABLE NAME HERE
source_table_name = "rprt.tbl_d_vcc_history"  # ⬅️ CHANGE THIS to your actual source table

# Define your target schema
target_ddl = """


CREATE TABLE IF NOT EXISTS rprt.tbl_d_vcc_history (
    D_VCC_HISTORY_ID INT NOT NULL,
    FK_D_VCC_ID INT NOT NULL,
    FK_D_VCC_DUE_DATE_ID INT NOT NULL,
    D_VCC_OFFICER_ID STRING,
    D_VCC_CONTACT_DUE DATE,
    D_VCC_UPDATE_FREQUENCY INT,
    D_VCC_MISSED INT,
    D_VCC_OVERDUE_DAYS INT,
    D_VCC_DRIVERS_MISSED STRING,
    D_VCC_OPT_OUT STRING,
    D_STAFF_MOVE_ID STRING,
    OA_REC_PROCESSED_DATE TIMESTAMP,
    OA_REC_CREATED_DATE TIMESTAMP,
    OA_REC_END_DATE TIMESTAMP,
    OA_IS_ACTIVE INT,
    OA_VERSION INT,
    OA_RECORDID STRING
) USING DELTA;

"""

# Call the function with YOUR parameters
migration_script = generate_dynamic_migration(source_table_name, target_ddl)

print("GENERATED MIGRATION SCRIPT:")
print("=" * 60)
print(migration_script)
print("=" * 60)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC -- 1. Create temporary table with target schema
# MAGIC CREATE TABLE rprt.tbl_d_vcc_history_temp (
# MAGIC   D_VCC_HISTORY_ID INT NOT NULL,
# MAGIC   FK_D_VCC_ID INT NOT NULL,
# MAGIC   FK_D_VCC_DUE_DATE_ID INT NOT NULL,
# MAGIC   D_VCC_OFFICER_ID STRING,
# MAGIC   D_VCC_CONTACT_DUE DATE,
# MAGIC   D_VCC_UPDATE_FREQUENCY INT,
# MAGIC   D_VCC_MISSED INT,
# MAGIC   D_VCC_OVERDUE_DAYS INT,
# MAGIC   D_VCC_DRIVERS_MISSED STRING,
# MAGIC   D_VCC_OPT_OUT STRING,
# MAGIC   D_STAFF_MOVE_ID STRING,
# MAGIC   OA_REC_PROCESSED_DATE TIMESTAMP,
# MAGIC   OA_REC_CREATED_DATE TIMESTAMP,
# MAGIC   OA_REC_END_DATE TIMESTAMP,
# MAGIC   OA_IS_ACTIVE INT,
# MAGIC   OA_VERSION INT,
# MAGIC   OA_RECORDID STRING
# MAGIC ) USING DELTA;
# MAGIC 
# MAGIC -- 2. Dynamic INSERT with automatic type handling
# MAGIC INSERT INTO rprt.tbl_d_vcc_history_temp
# MAGIC SELECT 
# MAGIC   D_VCC_HISTORY_ID,
# MAGIC   FK_D_VCC_ID,
# MAGIC   FK_D_VCC_DUE_DATE_ID,
# MAGIC   D_VCC_OFFICER_ID,
# MAGIC   D_VCC_CONTACT_DUE,
# MAGIC   D_VCC_UPDATE_FREQUENCY,
# MAGIC   D_VCC_MISSED,
# MAGIC   D_VCC_OVERDUE_DAYS,
# MAGIC   D_VCC_DRIVERS_MISSED,
# MAGIC   D_VCC_OPT_OUT,
# MAGIC   D_STAFF_MOVE_ID,
# MAGIC   OA_REC_PROCESSED_DATE,
# MAGIC   OA_REC_CREATED_DATE,
# MAGIC   OA_REC_END_DATE,
# MAGIC   OA_IS_ACTIVE,
# MAGIC   OA_VERSION,
# MAGIC   OA_RECORDID
# MAGIC FROM rprt.tbl_d_vcc_history;
# MAGIC 
# MAGIC -- 3. Swap tables
# MAGIC DROP TABLE rprt.tbl_d_vcc_history;
# MAGIC ALTER TABLE rprt.tbl_d_vcc_history_temp RENAME TO tbl_d_vcc_history;

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

 %%sql
drop table 
-- select * from 
rprt.tbl_d_time_temp
-- limit 5;
-- ALTER TABLE rprt.tbl_d_custody_offence_temp RENAME TO tbl_d_custody_offence;

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def smart_cdc_sync_with_fk(warehouse="WH_400_Gold_Test", schema="rprt", table_pattern="tbl_f_*"):
    """Smart CDC sync that handles foreign key constraints"""
    tables = [r.tableName for r in spark.sql(f"SHOW TABLES IN {schema} LIKE '{table_pattern}'").collect()]
    print(f"🔄 Smart CDC sync for {len(tables)} tables...")
    
    for table in tables:
        try:
            print(f"{table}: ", end="", flush=True)
            
            # Read source data from Lakehouse
            source_df = spark.read.table(f"{schema}.{table}")
            source_cols = source_df.columns
            source_count = source_df.count()
            
            # Check if target table exists
            try:
                target_df = spark.read.synapsesql(f"{warehouse}.{schema}.{table}")
                target_count = target_df.count()
                target_exists = True
            except:
                target_exists = False
                target_count = 0

            # Check CDC capability
            has_cdc = all(col in source_cols for col in ['OA_RECORDID', 'OA_IS_ACTIVE', 'OA_REC_PROCESS_DATETIME'])
            
            if not has_cdc:
                # Non-CDC table - only refresh if data changed or table doesn't exist
                if not target_exists:
                    # First time - create table
                    source_df.write.mode("overwrite").synapsesql(f"{warehouse}.{schema}.{table}")
                    print(f"📦 Created ({source_count} records)")
                elif source_count != target_count:
                    # For tables with foreign keys, use DELETE + INSERT instead of overwrite
                    try:
                        # Try DELETE + INSERT approach (avoids TRUNCATE)
                        spark.sql(f"DELETE FROM {warehouse}.{schema}.{table}")
                        source_df.write.mode("append").synapsesql(f"{warehouse}.{schema}.{table}")
                        print(f"📦 Refreshed ({source_count} records, was {target_count})")
                    except Exception as delete_error:
                        # If DELETE fails due to foreign keys, use overwrite with caution
                        print(f"⚠️ DELETE failed due to constraints, using overwrite... ")
                        source_df.write.mode("overwrite").synapsesql(f"{warehouse}.{schema}.{table}")
                        print(f"📦 Refreshed with overwrite ({source_count} records)")
                else:
                    print(f"✅ No changes ({source_count} records)")
                continue
            
            # CDC Table Logic
            from pyspark.sql.functions import col
            
            # Get active records from source
            source_active = source_df.filter(col("OA_IS_ACTIVE") == 1)
            source_active_count = source_active.count()
            
            if not target_exists:
                # First sync - create with active records
                source_active.write.mode("overwrite").synapsesql(f"{warehouse}.{schema}.{table}")
                print(f"✅ Initial sync ({source_active_count} active records)")
                continue
            
            # Get latest timestamp from target
            try:
                target_time_df = spark.sql(f"SELECT MAX(OA_REC_PROCESS_DATETIME) as max_time FROM {warehouse}.{schema}.{table}")
                last_sync_time = target_time_df.collect()[0]['max_time']
            except:
                last_sync_time = None
            
            if last_sync_time:
                # Incremental sync
                new_records = source_active.filter(col("OA_REC_PROCESS_DATETIME") > last_sync_time)
                new_count = new_records.count()
                
                if new_count > 0:
                    # Handle updates - use targeted DELETE for specific records
                    record_ids = [str(r.OA_RECORDID) for r in new_records.select("OA_RECORDID").distinct().collect()]
                    
                    if record_ids:
                        # Build safe DELETE statement
                        ids_str = "','".join(record_ids)
                        
                        try:
                            # Try to delete only the specific records that will be updated
                            spark.sql(f"DELETE FROM {warehouse}.{schema}.{table} WHERE OA_RECORDID IN ('{ids_str}')")
                            new_records.write.mode("append").synapsesql(f"{warehouse}.{schema}.{table}")
                            print(f"✅ {new_count} updated records")
                        except Exception as e:
                            # If targeted delete fails, fall back to full refresh
                            print(f"⚠️ Targeted update failed, using full refresh... ")
                            source_active.write.mode("overwrite").synapsesql(f"{warehouse}.{schema}.{table}")
                            print(f"✅ Full refresh ({source_active_count} active records)")
                    else:
                        print(f"✅ No changes ({source_active_count} active records)")
                else:
                    print(f"✅ No changes ({source_active_count} active records)")
            else:
                # Full refresh for CDC tables
                source_active.write.mode("overwrite").synapsesql(f"{warehouse}.{schema}.{table}")
                print(f"✅ Re-synced ({source_active_count} active records)")
                
        except Exception as e:
            print(f"❌ {str(e)}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# 🚀 Run the smart version ---8mins/30 sec
smart_cdc_sync_with_fk("WH_400_Gold_Test", "rprt", "tbl_b_*")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### CREATE EXISTING TABLES AND IT'S SCHEMA

# CELL ********************

from pyspark.sql import SparkSession
from pyspark.sql.types import *

def get_table_structure_flexible(schemas_tables=None, specific_tables=None):
    """
    Extract table structure with flexible input options
    
    Parameters:
    - schemas_tables: Can be a string (single schema), list of schemas, or dict with specific tables per schema
    - specific_tables: List of full table names (e.g., ['schema1.table1', 'schema2.table2'])
    """
    spark = SparkSession.builder.getOrCreate()
    
    table_structures = {}
    
    # Case 1: Specific tables provided
    if specific_tables:
        print("Extracting specific tables...")
        for full_table_name in specific_tables:
            try:
                schema_name, table_name = parse_table_name(full_table_name)
                table_structure = process_single_table(spark, schema_name, table_name)
                if table_structure:
                    table_structures[full_table_name] = table_structure
            except Exception as e:
                print(f"Error processing table {full_table_name}: {e}")
    
    # Case 2: Schemas/tables dict provided
    elif isinstance(schemas_tables, dict):
        print("Extracting tables based on schema-table mapping...")
        for schema_name, tables in schemas_tables.items():
            if tables == "all":  # All tables in schema
                process_all_tables_in_schema(spark, schema_name, table_structures)
            elif isinstance(tables, list):  # Specific tables in schema
                for table_name in tables:
                    full_table_name = f"{schema_name}.{table_name}"
                    table_structure = process_single_table(spark, schema_name, table_name)
                    if table_structure:
                        table_structures[full_table_name] = table_structure
    
    # Case 3: Single schema (all tables)
    elif isinstance(schemas_tables, str):
        print(f"Extracting all tables from schema: {schemas_tables}")
        process_all_tables_in_schema(spark, schemas_tables, table_structures)
    
    # Case 4: List of schemas (all tables in each)
    elif isinstance(schemas_tables, list):
        print(f"Extracting all tables from schemas: {schemas_tables}")
        for schema_name in schemas_tables:
            process_all_tables_in_schema(spark, schema_name, table_structures)
    
    else:
        print("No valid input provided. Please specify schemas, tables, or both.")
    
    return table_structures

def parse_table_name(full_table_name):
    """Parse full table name into schema and table name"""
    if '.' in full_table_name:
        parts = full_table_name.split('.')
        schema_name = parts[0]
        table_name = parts[1]
    else:
        schema_name = "default"  # or your default schema
        table_name = full_table_name
    return schema_name, table_name

def process_single_table(spark, schema_name, table_name):
    """Process a single table and return its structure"""
    full_table_name = f"{schema_name}.{table_name}"
    
    try:
        # Check if table exists
        df = spark.table(full_table_name)
        schema = df.schema
        
        print(f"\n{'='*50}")
        print(f"Table: {full_table_name}")
        print(f"{'='*50}")
        
        # Generate CREATE TABLE statement
        create_statement = generate_create_table_statement(schema_name, table_name, schema)
        
        print("Columns:")
        for field in schema:
            nullable = "NULL" if field.nullable else "NOT NULL"
            print(f"  - {field.name}: {field.dataType.simpleString()} {nullable}")
        
        print(f"\nGenerated CREATE TABLE statement:")
        print(create_statement)
        
        return {
            'create_statement': create_statement,
            'columns': [(field.name, field.dataType.simpleString(), field.nullable) for field in schema]
        }
    
    except Exception as e:
        print(f"Error processing table {full_table_name}: {e}")
        return None

def process_all_tables_in_schema(spark, schema_name, table_structures):
    """Process all tables in a schema"""
    try:
        tables = spark.catalog.listTables(schema_name)
        
        if not tables:
            print(f"No tables found in schema: {schema_name}")
            return
        
        for table in tables:
            table_name = table.name
            full_table_name = f"{schema_name}.{table_name}"
            table_structure = process_single_table(spark, schema_name, table_name)
            if table_structure:
                table_structures[full_table_name] = table_structure
                
    except Exception as e:
        print(f"Error processing schema {schema_name}: {e}")

def generate_create_table_statement(schema_name, table_name, schema):
    """Generate a CREATE TABLE statement from schema"""
    columns = []
    for field in schema:
        spark_type = field.dataType.simpleString()
        sql_type = convert_spark_type_to_sql(spark_type)
        nullable = "" if field.nullable else "NOT NULL"
        column_def = f"    {field.name} {sql_type} {nullable}".strip()
        columns.append(column_def)
    
    columns_str = ",\n".join(columns)
    # create_stmt = f"CREATE TABLE {schema_name}.{table_name} (\n{columns_str}\n)"

    create_stmt = f"IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = {schema_name}.{table_name})\nBEGIN\n(\n{columns_str}\n)\nEND;"
    
    
    return create_stmt

def convert_spark_type_to_sql(spark_type):
    """Convert Spark data types to SQL data types"""
    type_mapping = {
        'int': 'INT',
        'bigint': 'BIGINT',
        'smallint': 'SMALLINT',
        'tinyint': 'TINYINT',
        'string': 'VARCHAR(1000)',
        'boolean': 'BOOLEAN',
        'double': 'DOUBLE',
        'float': 'FLOAT',
        'decimal': 'DECIMAL(10,2)',
        'date': 'DATE',
        'timestamp': 'TIMESTAMP',
        'binary': 'BINARY',
        'long': 'BIGINT'
    }
    
    # Handle complex types
    if spark_type.startswith('decimal'):
        return spark_type.upper().replace('DECIMAL', 'DECIMAL')
    elif spark_type.startswith('varchar'):
        return spark_type.upper()
    elif spark_type.startswith('char'):
        return spark_type.upper()
    elif spark_type.startswith('array'):
        return 'VARCHAR(1000)'  # Simplified for arrays
    elif spark_type.startswith('struct'):
        return 'VARCHAR(1000)'  # Simplified for structs
    else:
        return type_mapping.get(spark_type.lower(), 'VARCHAR(255)')

# Additional utility function to export results
def export_structures_to_file(table_structures, output_file_path):
    """Export table structures to a SQL file"""
    with open(output_file_path, 'w') as f:
        f.write("-- Generated Table Structures\n")
        f.write("-- ==========================\n\n")
        
        for table_name, structure in table_structures.items():
            f.write(f"-- Table: {table_name}\n")
            f.write(structure['create_statement'])
            f.write(";\n\n")
    
    print(f"Table structures exported to: {output_file_path}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# # Complex scenario: different tables from different schemas
# schemas_tables = {
#     "dbo": ["customers", "products"],  # Specific tables from dbo
#     "sales": "all",                    # All tables from sales
#     "hr": ["employees", "departments"] # Specific tables from hr
# }
# result = get_table_structure_flexible(schemas_tables=schemas_tables)   


# # Get specific tables from any schema
# specific_tables = [
#     "dbo.customers", 
#     "sales.orders", 
#     "hr.employees", 
#     "inventory.products"
# ]
# result = get_table_structure_flexible(specific_tables=specific_tables)    # Get all tables from multiple schemas
# result = get_table_structure_flexible(schemas_tables=["dbo", "sales", "hr"])  


# Get all tables from a single schema
result = get_table_structure_flexible(schemas_tables="calc")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import SparkSession
from pyspark.sql.types import *

def get_table_structure_exact_format(schemas_tables=None, specific_tables=None):
    """
    Extract table structure in exact format with first column as NOT NULL identifier
    """
    spark = SparkSession.builder.getOrCreate()
    
    table_structures = {}
    
    # Case 1: Specific tables provided
    if specific_tables:
        print("Extracting specific tables...")
        for full_table_name in specific_tables:
            try:
                schema_name, table_name = parse_table_name(full_table_name)
                table_structure = process_single_table_exact_format(spark, schema_name, table_name)
                if table_structure:
                    table_structures[table_name] = table_structure
            except Exception as e:
                print(f"Error processing table {full_table_name}: {e}")
    
    # Case 2: Schemas/tables dict provided
    elif isinstance(schemas_tables, dict):
        print("Extracting tables based on schema-table mapping...")
        for schema_name, tables in schemas_tables.items():
            if tables == "all":  # All tables in schema
                process_all_tables_exact_format(spark, schema_name, table_structures)
            elif isinstance(tables, list):  # Specific tables in schema
                for table_name in tables:
                    table_structure = process_single_table_exact_format(spark, schema_name, table_name)
                    if table_structure:
                        table_structures[table_name] = table_structure
    
    # Case 3: Single schema (all tables)
    elif isinstance(schemas_tables, str):
        print(f"Extracting all tables from schema: {schemas_tables}")
        process_all_tables_exact_format(spark, schemas_tables, table_structures)
    
    # Case 4: List of schemas (all tables in each)
    elif isinstance(schemas_tables, list):
        print(f"Extracting all tables from schemas: {schemas_tables}")
        for schema_name in schemas_tables:
            process_all_tables_exact_format(spark, schema_name, table_structures)
    
    else:
        print("No valid input provided. Please specify schemas, tables, or both.")
    
    return table_structures

def process_single_table_exact_format(spark, schema_name, table_name):
    """Process a single table and return its structure in exact format"""
    full_table_name = f"{schema_name}.{table_name}"
    
    try:
        # Check if table exists
        df = spark.table(full_table_name)
        schema = df.schema
        
        print(f"\n{'='*80}")
        print(f"Processing Table: {full_table_name}")
        print(f"{'='*80}")
        
        # Generate exact CREATE TABLE statement
        create_statement = generate_exact_create_table_statement(schema_name, table_name, schema)
        
        # Print detailed column information
        print("Column Details:")
        print(f"{'Column Name':<25} {'Data Type':<20} {'Nullable':<10} {'Is First Column'}")
        print("-" * 70)
        
        for i, field in enumerate(schema):
            is_first = "✓" if i == 0 else ""
            nullable = "NULL" if field.nullable else "NOT NULL"
            print(f"{field.name:<25} {field.dataType.simpleString():<20} {nullable:<10} {is_first}")
        
        print(f"\nGenerated CREATE TABLE statement:")
        print(create_statement)
        
        return create_statement
    
    except Exception as e:
        print(f"Error processing table {full_table_name}: {e}")
        return None

def process_all_tables_exact_format(spark, schema_name, table_structures):
    """Process all tables in a schema with exact format"""
    try:
        tables = spark.catalog.listTables(schema_name)
        
        if not tables:
            print(f"No tables found in schema: {schema_name}")
            return
        
        for table in tables:
            table_name = table.name
            table_structure = process_single_table_exact_format(spark, schema_name, table_name)
            if table_structure:
                table_structures[table_name] = table_structure
                
    except Exception as e:
        print(f"Error processing schema {schema_name}: {e}")

def generate_exact_create_table_statement(schema_name, table_name, schema):
    """Generate exact CREATE TABLE statement following the specified format"""
    columns = []
    
    for i, field in enumerate(schema):
        spark_type = field.dataType.simpleString()
        
        # Convert Spark types to appropriate SQL types
        sql_type = convert_to_exact_sql_type(spark_type)
        
        # First column (identifier) should always be NOT NULL
        if i == 0:
            nullable = "NOT NULL"
        else:
            nullable = "" if field.nullable else "NOT NULL"
        
        # Format with exact spacing and tabs
        column_def = f"\t{field.name} {sql_type} {nullable}".strip()
        columns.append(column_def)
    
    columns_str = "\n\t,".join(columns)
    
    # Exact format as specified
    create_stmt = f"""(\"{table_name}\",
\"\"\"
\tCREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
{columns_str}
\t)USING DELTA
\"\"\"
)"""
    
    return create_stmt

def convert_to_exact_sql_type(spark_type):
    """
    Convert Spark data types to exact SQL types used in Lakehouse
    """
    # Map Spark types to appropriate SQL types
    type_mapping = {
        'int': 'INT',
        'integer': 'INT',
        'bigint': 'BIGINT',
        'long': 'BIGINT',
        'smallint': 'SMALLINT',
        'tinyint': 'TINYINT',
        'string': 'STRING',
        'varchar': 'STRING',
        'char': 'STRING',
        'text': 'STRING',
        'boolean': 'BOOLEAN',
        'bool': 'BOOLEAN',
        'double': 'DOUBLE',
        'float': 'FLOAT',
        'real': 'FLOAT',
        'decimal': 'DECIMAL',
        'numeric': 'DECIMAL',
        'date': 'DATE',
        'timestamp': 'TIMESTAMP',
        'datetime': 'TIMESTAMP',
        'binary': 'BINARY',
        'array<string>': 'STRING',
        'array<int>': 'STRING',
        'struct': 'STRING'
    }
    
    # Handle decimal with precision and scale
    if spark_type.startswith('decimal'):
        return spark_type.upper()
    
    # Handle varchar with length
    elif spark_type.startswith('varchar'):
        return 'STRING'
    
    # Handle char with length
    elif spark_type.startswith('char'):
        return 'STRING'
    
    # Handle array types
    elif spark_type.startswith('array'):
        return 'STRING'
    
    # Handle struct types
    elif spark_type.startswith('struct'):
        return 'STRING'
    
    # Handle map types
    elif spark_type.startswith('map'):
        return 'STRING'
    
    # Default mapping
    return type_mapping.get(spark_type.lower(), 'STRING')

def parse_table_name(full_table_name):
    """Parse full table name into schema and table name"""
    if '.' in full_table_name:
        parts = full_table_name.split('.')
        schema_name = parts[0]
        table_name = parts[1]
    else:
        schema_name = "dbo"  # Default schema
        table_name = full_table_name
    return schema_name, table_name

def export_exact_structures_to_file(table_structures, output_file_path):
    """Export table structures to a file in exact format"""
    with open(output_file_path, 'w') as f:
        f.write("# Table Structures in Exact Format\n")
        f.write("# =================================\n\n")
        
        for i, (table_name, create_statement) in enumerate(table_structures.items()):
            if i > 0:
                f.write(",\n")
            f.write(create_statement)
        
        f.write("\n")
    
    print(f"Table structures exported to: {output_file_path}")

def print_ready_to_use_code(table_structures):
    """Print code ready to be used in Python"""
    print("\n" + "="*80)
    print("READY-TO-USE PYTHON CODE:")
    print("="*80)
    print("table_definitions = [")
    
    for i, (table_name, create_statement) in enumerate(table_structures.items()):
        if i > 0:
            print(",")
        print(create_statement, end="")
    
    print("\n]")
    
    # Also show how to use it
    print("\n# Usage example:")
    print("for table_name, create_stmt in table_definitions:")
    print("    spark.sql(create_stmt)")

# Usage Examples:

def example_usage():
    """Show various usage examples"""
    
    # Example 1: Specific tables in exact format
    print("EXAMPLE 1: Specific tables")
    result = get_table_structure_exact_format(
        specific_tables=["dbo.optic", "sales.orders", "hr.employees"]
    )
    
    # Print ready-to-use code
    print_ready_to_use_code(result)
    
    # Export to file
    export_exact_structures_to_file(result, "/lakehouse/default/Files/exact_table_structures.txt")
    
    return result

# Run the example
if __name__ == "__main__":
    # Example usage - replace with your actual tables
    tables_result = get_table_structure_exact_format(
        specific_tables=["dbo.optic", "dbo.your_table1", "sales.orders"]
    )
    
    # Print the final output in ready-to-use format
    print_ready_to_use_code(tables_result)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# use this to generate tables from Lh to Wh

from pyspark.sql import SparkSession
from pyspark.sql.types import *

def get_table_structure_with_exists_check(schemas_tables=None, specific_tables=None):
    """
    Extract table structure with IF NOT EXISTS wrapper in the specified format
    """
    spark = SparkSession.builder.getOrCreate()
    
    table_structures = {}
    
    # Case 1: Specific tables provided
    if specific_tables:
        print("Extracting specific tables...")
        for full_table_name in specific_tables:
            try:
                schema_name, table_name = parse_table_name(full_table_name)
                table_structure = process_single_table_with_exists_check(spark, schema_name, table_name)
                if table_structure:
                    table_structures[full_table_name] = table_structure
            except Exception as e:
                print(f"Error processing table {full_table_name}: {e}")
    
    # Case 2: Schemas/tables dict provided
    elif isinstance(schemas_tables, dict):
        print("Extracting tables based on schema-table mapping...")
        for schema_name, tables in schemas_tables.items():
            if tables == "all":  # All tables in schema
                process_all_tables_with_exists_check(spark, schema_name, table_structures)
            elif isinstance(tables, list):  # Specific tables in schema
                for table_name in tables:
                    full_table_name = f"{schema_name}.{table_name}"
                    table_structure = process_single_table_with_exists_check(spark, schema_name, table_name)
                    if table_structure:
                        table_structures[full_table_name] = table_structure
    
    # Case 3: Single schema (all tables)
    elif isinstance(schemas_tables, str):
        print(f"Extracting all tables from schema: {schemas_tables}")
        process_all_tables_with_exists_check(spark, schemas_tables, table_structures)
    
    # Case 4: List of schemas (all tables in each)
    elif isinstance(schemas_tables, list):
        print(f"Extracting all tables from schemas: {schemas_tables}")
        for schema_name in schemas_tables:
            process_all_tables_with_exists_check(spark, schema_name, table_structures)
    
    else:
        print("No valid input provided. Please specify schemas, tables, or both.")
    
    return table_structures

def process_single_table_with_exists_check(spark, schema_name, table_name):
    """Process a single table and return its structure with IF NOT EXISTS wrapper"""
    full_table_name = f"{schema_name}.{table_name}"
    
    try:
        # Check if table exists
        df = spark.table(full_table_name)
        schema = df.schema
        
        # Generate CREATE TABLE statement with IF NOT EXISTS wrapper
        create_statement = generate_create_table_with_exists_check(schema_name, table_name, schema)
        
        # ONLY SHOW THE GENERATED CREATE TABLE STATEMENT (as requested)
        print(f"\n{'='*100}")
        print(f"GENERATED CREATE TABLE STATEMENT for {full_table_name}:")
        print(f"{'='*100}")
        print(create_statement)
        print(f"{'='*100}")
        
        return create_statement
    
    except Exception as e:
        print(f"Error processing table {full_table_name}: {e}")
        return None

def process_all_tables_with_exists_check(spark, schema_name, table_structures):
    """Process all tables in a schema with IF NOT EXISTS wrapper"""
    try:
        tables = spark.catalog.listTables(schema_name)
        
        if not tables:
            print(f"No tables found in schema: {schema_name}")
            return
        
        for table in tables:
            table_name = table.name
            full_table_name = f"{schema_name}.{table_name}"
            table_structure = process_single_table_with_exists_check(spark, schema_name, table_name)
            if table_structure:
                table_structures[full_table_name] = table_structure
                
    except Exception as e:
        print(f"Error processing schema {schema_name}: {e}")

def generate_create_table_with_exists_check(schema_name, table_name, schema):
    """
    Generate CREATE TABLE statement with IF NOT EXISTS wrapper in the specified format
    """
    columns = []
    
    for i, field in enumerate(schema):
        spark_type = field.dataType.simpleString()
        sql_type = convert_spark_type_to_sql_server_type(spark_type)
        
        # First column (identifier) should always be NOT NULL
        if i == 0:
            nullable = "NOT NULL"
        else:
            nullable = "NULL" if field.nullable else "NOT NULL"
        
        # Format with exact spacing - comma at beginning of line
        column_def = f"\t,{field.name} {sql_type} {nullable}".rstrip()
        columns.append(column_def)
    
    # Remove the comma from the first column and adjust spacing
    if columns:
        first_column = columns[0].lstrip(',')
        columns[0] = f"\t{first_column}"
    
    columns_str = "\n".join(columns)
    
    # Generate the exact format as specified
    create_stmt = f"""IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = '{schema_name}' AND TABLE_NAME = '{table_name}')
BEGIN
\tCREATE TABLE {schema_name}.{table_name}(
{columns_str}
\t)
END;"""
    
    return create_stmt

def convert_spark_type_to_sql_server_type(spark_type):
    """
    Convert Spark data types to SQL Server compatible data types
    """
    # Map Spark types to SQL Server types
    type_mapping = {
        'int': 'INT',
        'integer': 'INT',
        'bigint': 'BIGINT',
        'long': 'BIGINT',
        'smallint': 'SMALLINT',
        'tinyint': 'TINYINT',
        'string': 'VARCHAR(1000)',
        'varchar': 'VARCHAR(1000)',
        'char': 'CHAR(1)',
        'text': 'VARCHAR(MAX)',
        'boolean': 'BIT',
        'bool': 'BIT',
        'double': 'FLOAT',
        'float': 'REAL',
        'real': 'REAL',
        'decimal': 'DECIMAL(18,2)',
        'numeric': 'NUMERIC(18,2)',
        'date': 'DATE',
        'timestamp': 'DATETIME2(6)',
        'datetime': 'DATETIME2(6)',
        'binary': 'VARBINARY(MAX)',
        'array<string>': 'VARCHAR(MAX)',
        'array<int>': 'VARCHAR(MAX)',
        'struct': 'VARCHAR(MAX)'
    }
    
    # Handle decimal with precision and scale
    if spark_type.startswith('decimal'):
        # Extract precision and scale from decimal type
        if '(' in spark_type:
            precision_scale = spark_type.split('(')[1].split(')')[0]
            return f'DECIMAL({precision_scale})'
        else:
            return 'DECIMAL(18,2)'
    
    # Handle varchar with length
    elif spark_type.startswith('varchar'):
        if '(' in spark_type:
            length = spark_type.split('(')[1].split(')')[0]
            return f'VARCHAR({length})'
        else:
            return 'VARCHAR(255)'
    
    # Handle char with length
    elif spark_type.startswith('char'):
        if '(' in spark_type:
            length = spark_type.split('(')[1].split(')')[0]
            return f'CHAR({length})'
        else:
            return 'CHAR(1)'
    
    # Handle array types
    elif spark_type.startswith('array'):
        return 'VARCHAR(MAX)'
    
    # Handle struct types
    elif spark_type.startswith('struct'):
        return 'VARCHAR(MAX)'
    
    # Handle map types
    elif spark_type.startswith('map'):
        return 'VARCHAR(MAX)'
    
    # Default mapping
    return type_mapping.get(spark_type.lower(), 'VARCHAR(1000)')

# def parse_table_name(full_table_name):
#     """Parse full table name into schema and table name"""
#     if '.' in full_table_name:
#         parts = full_table_name.split('.')
#         schema_name = parts[0]
#         table_name = parts[1]
#     else:
#         schema_name = "dbo"  # Default schema
#         table_name = full_table_name
#     return schema_name, table_name

# def export_structures_to_sql_file(table_structures, output_file_path):
#     """Export table structures to a SQL file"""
#     with open(output_file_path, 'w') as f:
#         f.write("-- Generated Table Structures with IF NOT EXISTS check\n")
#         f.write("-- ==================================================\n\n")
        
#         for full_table_name, create_statement in table_structures.items():
#             f.write(f"-- Table: {full_table_name}\n")
#             f.write(create_statement)
#             f.write("\n\n")
    
#     print(f"Table structures exported to: {output_file_path}")

# def print_all_statements(table_structures):
#     """Print all generated statements in sequence"""
#     print(f"\n{'#'*100}")
#     print("ALL GENERATED CREATE TABLE STATEMENTS:")
#     print(f"{'#'*100}")
    
    # for full_table_name, create_statement in table_structures.items():
    #     print(create_statement)
    #     print("\n" + "-"*100 + "\n")

# # Usage Examples:

# def example_usage():
#     """Show various usage examples"""
    
#     print("EXAMPLE: Specific tables with IF NOT EXISTS wrapper")
#     result = get_table_structure_with_exists_check(
#         specific_tables=["dbo.optic", "sales.orders", "hr.employees"]
#     )
    
#     # Print all statements
#     print_all_statements(result)
    
#     # Export to file
#     export_structures_to_sql_file(result, "/lakehouse/default/Files/table_structures_with_exists_check.sql")
    
#     return result

# # Run directly with your example
# if __name__ == "__main__":
#     # Replace with your actual table names
#     tables_result = get_table_structure_with_exists_check(
#         specific_tables=["dbo.optic", "dbo.customers", "sales.orders"]
#     )
    
#     # Print all final statements
#     print_all_statements(tables_result)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

get_table_structure_with_exists_check("calc")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ### LOGGING

# MARKDOWN ********************

# ###### Type 1

# CELL ********************

# Config_Notebook_Logger
notebook_name = "notebookName from Parameter"
run_id = mssparkutils.env.getJobId()
all_errors = []

print(f"📝 Starting notebook logging for: {notebook_name}")
print(f"🏃 Run ID: {run_id}")

def capture_error(msg):
    """Capture error messages without stopping execution"""
    all_errors.append(msg)
    print(f"❌ CAPTURED ERROR: {msg}")
    print(f"🔍 DEBUG: Total errors captured so far: {len(all_errors)}")

def finalise_notebook_logging():
    """Finalize logging and exit - call this at the END of your notebook"""
    print(f"🔍 DEBUG: Starting finalise_notebook_logging()")
    print(f"🔍 DEBUG: All errors: {all_errors}")
    
    # Determine final status
    if any("NOTEBOOK CRASHED" in error for error in all_errors):
        status = "FAILED"
    elif all_errors:
        status = "COMPLETED_WITH_ERRORS"
    else:
        status = "SUCCESS"
    
    print(f"🔍 DEBUG: Determined status: {status}")
    
    # Create error summary
    error_summary = " | ".join(all_errors)[:2000] if all_errors else None
    print(f"🔍 DEBUG: Error summary: {error_summary}")
    
    # Log to existing monitoring table in ctlr schema
    try:
        print("🔍 DEBUG: Attempting to write to table...")
        
        if error_summary:
            # Escape single quotes for SQL
            error_summary_escaped = error_summary.replace("'", "''")
            insert_sql = f"""
            INSERT INTO ctlr.notebook_process_logs 
            VALUES ('{notebook_name}', '{status}', '{error_summary_escaped}', CURRENT_TIMESTAMP, '{run_id}')
            """
        else:
            insert_sql = f"""
            INSERT INTO ctlr.notebook_process_logs (notebook_name, status, timestamp, run_id)
            VALUES ('{notebook_name}', '{status}', CURRENT_TIMESTAMP, '{run_id}')
            """
        
        # print(f"🔍 DEBUG: SQL: {insert_sql}")
        spark.sql(insert_sql)
        print(f"✅ Logged to ctlr.notebook_process_logs: {status}")
        
    except Exception as e:
        print(f"⚠️ Failed to write to ctlr.notebook_process_logs: {str(e)}")
    
    # Exit for pipeline
    mssparkutils.notebook.exit(status)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC SELECT * FROM currentdate():

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

finalise_notebook_logging()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### Type 2

# CELL ********************

# Config_Notebook_Logger
notebook_name = "notebookName from Parameter"
run_id = mssparkutils.env.getJobId()
all_errors = []

print(f"📝 Starting notebook logging for: {notebook_name}")
print(f"🏃 Run ID: {run_id}")

def capture_error(msg):
    """Capture error messages without stopping execution"""
    all_errors.append(msg)
    print(f"❌ CAPTURED ERROR: {msg}")

def capture_exception(e, context=""):
    """Capture exceptions with context"""
    error_msg = f"{context}: {str(e)}" if context else str(e)
    all_errors.append(error_msg)
    print(f"❌ CAPTURED EXCEPTION: {error_msg}")

def execute_cell(cell_func, cell_name="anonymous_cell", continue_on_error=False):
    """
    Enhanced execute_cell that captures errors but allows continuation
    
    Args:
        cell_func: Function to execute
        cell_name: Name for logging
        continue_on_error: If True, continues execution even if this cell fails
    """
    print(f"🔵 Executing cell: {cell_name}")
    
    try:
        result = cell_func()
        print(f"✅ Cell completed successfully: {cell_name}")
        return result
        
    except Exception as e:
        error_msg = f"Cell '{cell_name}' failed: {str(e)}"
        capture_exception(e, f"Cell: {cell_name}")
        
        if continue_on_error:
            print(f"⚠️ Continuing despite error in: {cell_name}")
            return None
        else:
            print(f"🚨 Stopping execution due to error in: {cell_name}")
            raise

def execute_batch_operations(operations, batch_name="batch_operations"):
    """
    Execute multiple operations and capture individual failures
    Continues through all operations even if some fail
    """
    print(f"🔄 Executing batch: {batch_name} ({len(operations)} operations)")
    
    successful_ops = 0
    failed_ops = 0
    
    for i, operation in enumerate(operations, 1):
        op_name = f"{batch_name}_op_{i}"
        
        try:
            # Execute the operation
            if callable(operation):
                operation()
            else:
                # Assume it's a Spark SQL query
                spark.sql(operation)
                
            successful_ops += 1
            print(f"✅ Operation {i}/{len(operations)} completed: {op_name}")
            
        except Exception as e:
            failed_ops += 1
            capture_exception(e, f"Operation: {op_name}")
            print(f"❌ Operation {i}/{len(operations)} failed: {op_name}")
    
    print(f"📊 Batch '{batch_name}' completed: {successful_ops} successful, {failed_ops} failed")
    
    if failed_ops > 0:
        return False  # Indicates partial failure
    return True  # All operations successful

def finalise_notebook_logging():
    """Finalize logging and exit - call this at the END of your notebook"""
    print(f"🔍 Finalising notebook logging...")
    print(f"🔍 Total errors captured: {len(all_errors)}")
    
    # Determine final status
    if any("CRASHED" in error for error in all_errors):
        status = "FAILED"
    elif all_errors:
        status = "COMPLETED_WITH_ERRORS"
    else:
        status = "SUCCESS"
        
    print(f"📋 Final status: {status}")
    
    # Create error summary
    error_summary = " | ".join(all_errors)[:2000] if all_errors else None
    
    # Log to monitoring table
    try:
        if error_summary:
            error_summary_escaped = error_summary.replace("'", "''")
            insert_sql = f"""
            INSERT INTO ctlr.notebook_process_logs
            VALUES ('{notebook_name}', '{status}', '{error_summary_escaped}', CURRENT_TIMESTAMP, '{run_id}')
            """
        else:
            insert_sql = f"""
            INSERT INTO ctlr.notebook_process_logs (notebook_name, status, timestamp, run_id)
            VALUES ('{notebook_name}', '{status}', CURRENT_TIMESTAMP, '{run_id}')
            """
        
        spark.sql(insert_sql)
        print(f"✅ Logged to ctlr.notebook_process_logs: {status}")
        
    except Exception as e:
        print(f"⚠️ Failed to write to ctlr.notebook_process_logs: {str(e)}")
        mssparkutils.notebook.exit("FAILED")
    
    # Exit for pipeline
    mssparkutils.notebook.exit(status)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Define your table creation operations
table_operations = [
    "SELECT * FROM 'source_a'; GO";
    "SELECT * FROM source_b GO";, 
    "SELECT * FROM 1" GO;
]

# This will continue even if some tables fail to create
batch_success = execute_batch_operations(
    table_operations, 
    "initial_table_creation"
)

if not batch_success:
    print("⚠️ Some table creations failed, but continuing...")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

finalise_notebook_logging()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
