# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

df = spark.read("https://onelake.dfs.fabric.microsoft.com/70af0af6-451e-452c-a29c-6ebcfe2948cb/9273f74f-5f08-45a7-8d0d-bd5dba32377a/Files/LandingZone")



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
