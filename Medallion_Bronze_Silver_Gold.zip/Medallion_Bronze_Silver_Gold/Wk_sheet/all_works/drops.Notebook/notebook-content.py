# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "42396a50-8b85-4951-9850-b36abfe2a28d",
# META       "default_lakehouse_name": "LH_300_Gold_Test",
# META       "default_lakehouse_workspace_id": "a3e4d0e6-6b32-498b-addc-1629a4b29a47",
# META       "known_lakehouses": [
# META         {
# META           "id": "42396a50-8b85-4951-9850-b36abfe2a28d"
# META         },
# META         {
# META           "id": "62139ac1-f383-41dc-b7a5-64655894ccd2"
# META         },
# META         {
# META           "id": "6a459f05-6527-49bd-8600-74065f42a607"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# ### Refresh Tables In Schemas

# MARKDOWN ********************

# ###### DEALING WITH LH_200 TABLES  -=- MAKE THE LH_200 THE DEFAULT 1ST

# CELL ********************

# check tables exist. Note there is no schema here
tbls_200 = [tables.name for tables in spark.catalog.listTables()]
for tbl_200 in tbls_200:
    print(tbl_200)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#count how much each table has
tbls_200 = [tables.name for tables in spark.catalog.listTables()]
for tbl_200 in tbls_200: 
    tblCount_200 = spark.sql(f"SELECT COUNT(*) AS cnt FROM {tbl_200}")
    n = tblCount_200.first()["cnt"]
    print(f"{tbl_200} Count = {n}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

tbls_200 = [tables.name for tables in spark.catalog.listTables()]
for tbl_200 in tbls_200:
    spark.sql(f"DROP TABLE IF EXISTS {tbl_200}")  # Use this if you want to drop everything and start all over
    # spark.sql(f"TRUNCATE TABLE {tbl_200}")   # Use this if you just want to delete data
    print(tbl_200)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### DEALING WITH LH_3OO TABLES -=- MAKE THE LH_300 THE DEFAULT 1ST

# CELL ********************

# check tables exist. Note there is no schema here
tbls_300 = [tables.name for tables in spark.catalog.listTables("rprt")]  # "rprt", "calc" , "ctlr", "dbo" change the schema here if you don't intend to EFFECT ALL tables
for tbl_300 in tbls_300:
    print(tbl_300)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#count how much each table has
tbls_300 = [tables.name for tables in spark.catalog.listTables("rprt")] #"rprt", "calc" , "ctlr", "dbo"  #change the schema here
for tbl_300 in tbls_300: 
    tblCount_300 = spark.sql(f"SELECT COUNT(*) AS cnt FROM rprt.{tbl_300}") #change the schema here
    n = tblCount_300.first()["cnt"]
    print(f"rprt.{tbl_300} Count = {n}") #change the schema here

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ctlr
# this will literally delete all files under schema rprt when made active.
tbls_300 = [tables.name for tables in spark.catalog.listTables("ctlr")] # "rprt", "calc" , "ctlr", "dbo" change the schema here if you don't intend to EFFECT ALL tables
for tbl_300 in tbls_300:
    spark.sql(f"DROP TABLE IF EXISTS ctlr.{tbl_300}") #change the schema here
    # spark.sql(f"TRUNCATE TABLE ctlr.{tbl_300}") #change the schema here
    print(tbl_300)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# calc
tbls_300 = [tables.name for tables in spark.catalog.listTables("calc")] # "rprt", "calc" , "ctlr", "dbo" change the schema here if you don't intend to EFFECT ALL tables
for tbl_300 in tbls_300:
    # spark.sql(f"DROP TABLE IF EXISTS calc.{tbl_300}") #change the schema here
    # spark.sql(f"TRUNCATE TABLE calc.{tbl_300}") #change the schema here
    print(tbl_300)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# rprt
tbls_300 = [tables.name for tables in spark.catalog.listTables("rprt")] # "rprt", "calc" , "ctlr", "dbo" change the schema here if you don't intend to EFFECT ALL tables
for tbl_300 in tbls_300:
    # spark.sql(f"DROP TABLE IF EXISTS rprt.{tbl_300}") #change the schema here
    # spark.sql(f"TRUNCATE TABLE rprt.{tbl_300}") #change the schema here
    print(tbl_300)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# this will print the action and take it to the warehouse to delete
tbls = [tables.name for tables in spark.catalog.listTables("rprt")]   #change the schema here
for tbl in tbls:

    print(f"DELETE FROM rprt.{tbl}")



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

tbls = [tables.name for tables in spark.catalog.listTables("calc")] 
for tbl in tbls:
    # spark.sql(f"DROP TABLE IF EXISTS calc.{tbl}")
# print(tbl)
    print(tbl)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql 
# MAGIC 
# MAGIC -- ==========
# MAGIC -- DROP CALC TABLES
# MAGIC -- ==========
# MAGIC -- DROP TABLE IF EXISTS rprt.athena_crime_asb_keyword;
# MAGIC -- DROP TABLE IF EXISTS rprt.athena_gem_task_history;
# MAGIC -- DROP TABLE IF EXISTS rprt.athena_person;
# MAGIC -- DROP TABLE IF EXISTS rprt.athena_reason_for_arrest;
# MAGIC -- DROP TABLE IF EXISTS rprt.bail_custodyrecord;
# MAGIC -- DROP TABLE IF EXISTS rprt.sap_pa2003;
# MAGIC -- DROP TABLE IF EXISTS rprt.tbl_storm_priority;
# MAGIC 
# MAGIC -- ==========
# MAGIC -- TRUNCATE TABLE
# MAGIC -- ==========
# MAGIC 
# MAGIC -- TRUNCATE TABLE rprt.athena_crime_asb_keyword
# MAGIC -- TRUNCATE TABLE rprt.athena_gem_task_history
# MAGIC -- TRUNCATE TABLE rprt.athena_person
# MAGIC -- TRUNCATE TABLE rprt.athena_reason_for_arrest
# MAGIC -- TRUNCATE TABLE rprt.bail_custodyrecord
# MAGIC -- TRUNCATE TABLE rprt.sap_pa2003
# MAGIC -- TRUNCATE TABLE rprt.tbl_storm_priority


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ### Test Update Records

# CELL ********************

bronze_filePath = "abfss://Fabric_SandBox@onelake.dfs.fabric.microsoft.com/LH_100_Bronze.Lakehouse/Files/bronze"
silver_tablPath = "abfss://Fabric_SandBox@onelake.dfs.fabric.microsoft.com/LH_200_Silver_Test.Lakehouse/Tables"
gold_tablPath = "abfss://Fabric_SandBox@onelake.dfs.fabric.microsoft.com/LH_300_Gold_Test.Lakehouse/Tables"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

all_paths = [paths.name for paths in notebookutils.fs.ls(bronze_filePath)]
all_paths

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

domainName = "SA"
todayFile = "Year_2025/Month_11/Day_03"
for pathName in all_paths:
     if pathName.startswith(domainName):
        domain_path = f"{bronze_filePath}/{pathName}"
        domanContent = [books.name for books in notebookutils.fs.ls(f"{domain_path}/{todayFile}")]

        now read only just 1 file
domanContent

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df = spark.read.parquet(domain_path)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
