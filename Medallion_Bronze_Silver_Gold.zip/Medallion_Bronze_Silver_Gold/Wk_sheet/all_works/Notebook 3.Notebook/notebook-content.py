# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "62139ac1-f383-41dc-b7a5-64655894ccd2",
# META       "default_lakehouse_name": "LH_100_Bronze",
# META       "default_lakehouse_workspace_id": "a3e4d0e6-6b32-498b-addc-1629a4b29a47",
# META       "known_lakehouses": [
# META         {
# META           "id": "62139ac1-f383-41dc-b7a5-64655894ccd2"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# Welcome to your new notebook
# Type here in the cell editor to add code!


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_ax = spark.read.parquet("abfss://Fabric_SandBox@onelake.dfs.fabric.microsoft.com/LH_100_Bronze.Lakehouse/Files/bronze/Essex_STORM/Year_2025/Month_11/Day_03/LOCATION_2025_11_03_03_00_43.parquet")
# df now is a Spark DataFrame containing parquet data from "abfss://Fabric_SandBox@onelake.dfs.fabric.microsoft.com/LH_100_Bronze.Lakehouse/Files/bronze/Bail/Year_2025/Month_11/Day_03/UTIL_AREA_2025-11-03_01_25_03.parquet".
# display(df_a)

df_a.createTempView("src_ax")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC SELECT *--count(*) 
# MAGIC FROM src_ax 
# MAGIC where 1=1
# MAGIC 
# MAGIC limit 5
# MAGIC 
# MAGIC 
# MAGIC 


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql 
# MAGIC select * 
# MAGIC from src_d d
# MAGIC left join src_a a on d.area_id = a.id
# MAGIC where police_force = 'ESSEX'

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }
