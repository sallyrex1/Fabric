# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "42396a50-8b85-4951-9850-b36abfe2a28d",
# META       "default_lakehouse_name": "LH_300_Gold_Test",
# META       "default_lakehouse_workspace_id": "a3e4d0e6-6b32-498b-addc-1629a4b29a47",
# META       "known_lakehouses": [
# META         {
# META           "id": "42396a50-8b85-4951-9850-b36abfe2a28d"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import notebookutils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

vl = notebookutils.variableLibrary.get("$(/**/vl_medallion/v_relativeBronzePath)")
print(vl)



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

tblNames = [tbl.name for tbl in spark.catalog.listTables("calc")]
print(tblNames)

# tables = ['tbl_b_bailtoathena', 'tbl_b_case_custody', 'tbl_b_crime_custody', 'tbl_b_crime_person_info', 'tbl_b_custody_arrest', 'tbl_b_custody_offence', 
# 'tbl_b_custody_subfacility', 'tbl_d_arrest_crimetype', 'tbl_d_athena_custody', 'tbl_d_athena_geo', 'tbl_d_bail', 'tbl_d_bail_geo', 'tbl_d_case', 'tbl_d_court_orders', 
# 'tbl_d_court_warrant', 'tbl_d_crime', 'tbl_d_crime_da_riskassessment', 'tbl_d_crime_property', 'tbl_d_custody_arrest', 'tbl_d_custody_facility', 'tbl_d_custody_offence', 
# 'tbl_d_custody_subfacility', 'tbl_d_date', 'tbl_d_detainee_person', 'tbl_d_distance', 'tbl_d_eq_date', 'tbl_d_geo', 'tbl_d_incident', 'tbl_d_intel_reports', 
# 'tbl_d_inv_classification', 'tbl_d_location', 'tbl_d_org', 'tbl_d_person', 'tbl_d_personnel', 'tbl_d_priority', 'tbl_d_servicecode', 'tbl_d_staff_history', 
# 'tbl_d_storm_isr', 'tbl_d_storm_isr_timestamps', 'tbl_d_tag', 'tbl_d_time', 'tbl_d_unit_activity', 'tbl_d_vcc', 'tbl_d_vcc_history', 'tbl_f_bail', 'tbl_f_crime', 'tbl_f_custody_record', 
# 'tbl_f_incident', 'tbl_f_incidentofficerresponse', 'tbl_f_operational_planning', 'tbl_f_staffing_report', 'tbl_f_vcc', 'tbl_f_workload']

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

wh_serverName = "6adrx47zttnubfsnn74ynkl6hu-43iojizsnofutlo4cyu2jmu2i4.datawarehouse.fabric.microsoft.com"
wh_dbName = "WH_400_Gold_Test"
wh_cnx_url = f"jdbc:sqlserver://{wh_serverName}:1433;database={wh_dbName}"
src_schema = "calc"
tgt_schema = "mskd_calc"
mode = "append"




# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for tb in tblNames:
    src = f"{src_schema}.{tb}"
    tgt = f"{tgt_schema}.{tb}"

    try:
        print(f"Processing {src} -> {tgt}")

        # spark.table(src).write.format("synapsesql").option("table",tgt).mode(mode).save()
        spark.table(src).write.format("synapsesql").option("url", f"jdbc:sqlserver://{wh_serverName}:1433;database={wh_dbName}").option(tables, tgt).mode(mode).save()



        print(f"Successly Processed {src} -> {tgt}")

    except Exception as e:
        print(f"Failed Processed {src} -> {tgt}: {str(e)}")

print(f"Table Processed {src} -> {tgt}: Finishe")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql 
# MAGIC CREATE SCHEMA IF NOT EXISTS mskd_calc

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC -- SELECT * 
# MAGIC -- INTO mskd_calc.athena_crime_asb_keyword 
# MAGIC -- FROM calc.athena_crime_asb_keyword;
# MAGIC 
# MAGIC CREATE TABLE mskd_calc.athena_crime_asb_keyword 
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT * FROM calc.athena_crime_asb_keyword;

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC SELECT top(5)* FROM mskd_calc.athena_crime_asb_keyword LIMIT 5;

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC -- CREATE TABLE mskd_calc.sap_pa2003 USING DELTA AS SELECT * FROM calc.sap_pa2003 ;
# MAGIC -- CREATE TABLE mskd_calc.athena_person USING DELTA AS SELECT * FROM calc.athena_person ;
# MAGIC -- CREATE TABLE mskd_calc.athena_crime_asb_keyword USING DELTA AS SELECT * FROM calc.athena_crime_asb_keyword ;
# MAGIC 
# MAGIC CREATE TABLE mskd_calc.athena_reason_for_arrest USING DELTA AS SELECT * FROM calc.athena_reason_for_arrest ;
# MAGIC CREATE TABLE mskd_calc.athena_gem_task_history USING DELTA AS SELECT * FROM calc.athena_gem_task_history ;
# MAGIC CREATE TABLE mskd_calc.tbl_storm_priority USING DELTA AS SELECT * FROM calc.tbl_storm_priority ;
# MAGIC CREATE TABLE mskd_calc.bail_custodyrecord USING DELTA AS SELECT * FROM calc.bail_custodyrecord ;

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }
