# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "c8c83770-8433-46f0-ba9b-19a2b6ea55bc",
# META       "default_lakehouse_name": "LH_200_Silver",
# META       "default_lakehouse_workspace_id": "a3e4d0e6-6b32-498b-addc-1629a4b29a47",
# META       "known_lakehouses": [
# META         {
# META           "id": "62139ac1-f383-41dc-b7a5-64655894ccd2"
# META         },
# META         {
# META           "id": "c8c83770-8433-46f0-ba9b-19a2b6ea55bc"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# ###### Config

# CELL ********************

%run /Config_silver_layer

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import notebookutils
import json

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

vl = notebookutils.variableLibrary.getLibrary("vl_medallion")
p_workspaceName = vl.getVariable("v_workspaceName")
print(vl)
print(p_workspaceName)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

# Or in full
p_workspaceName = notebookutils.variableLibrary.getLibrary("vl_medallion").getVariable("v_workspaceName")
print(p_workspaceName)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# MARKDOWN ********************

# ###### Using the Variable Library

# CELL ********************


# Or shotcut
p_workspaceName = notebookutils.variableLibrary.get("$(/**/vl_medallion/v_workspaceName)")
p_accountName = notebookutils.variableLibrary.get("$(/**/vl_medallion/v_accountName)")
p_relativeBronzePath = notebookutils.variableLibrary.get("$(/**/vl_medallion/v_relativeBronzePath)")
p_todaysFile = notebookutils.variableLibrary.get("$(/**/vl_medallion/v_todaysFile)")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

# Eg 
db_bronzePath = f"abfss://{p_workspaceName}@{p_accountName}.dfs.fabric.microsoft.com/{p_relativeBronzePath}/bronze"
# db_bronzePath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************


domains = ["SAP", "Essex_STORM", "Bail","Athena_A4E"]

db_bronzeFolder = [
    # f"abfss://{p_workspaceName}@{p_accountName}.dfs.fabric.microsoft.com/{p_relativeBronzePath}/bronze/{domain}/Year_2025/Month_11/Day_03"
    f"abfss://{p_workspaceName}@{p_accountName}.dfs.fabric.microsoft.com/{p_relativeBronzePath}/bronze/{domain}/{p_todaysFile}"
    
    for domain in domains
]

for bronzeFolder in db_bronzeFolder:
    print(bronzeFolder)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# MARKDOWN ********************

# ###### MASKED

# MARKDOWN ********************

# 1ST SCHEMA & CREATE THE TABLES

# CELL ********************

# MAGIC %%sql 
# MAGIC CREATE SCHEMA IF NOT EXISTS mskd

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# SAP TABLES

# CELL ********************

createTable([

# mskd.sap_hrp1000
("mskd.SAP_HRP1000",
    """CREATE TABLE IF NOT EXISTS mskd.SAP_HRP1000(
    OBJ_ID STRING MASKED WITH (FUNCTION = 'default()') 
    ,OBJ_TYPE STRING
    ,OBJ_DESC STRING
    ,START_DATE DATE
    ,END_DATE DATE
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
    )USING DELTA;
"""),

# mskd.sap_hrpP1001
("mskd.SAP_HRP1001",
    """CREATE TABLE IF NOT EXISTS mskd.SAP_HRP1001(
    OBJ_ID STRING MASKED WITH (FUNCTION = 'default()') 
    ,OBJ_TYPE STRING
    ,OBJ_DESC STRING
    ,RELAT STRING
    ,TYPE_OF_RELATED_OBJ STRING
    ,ID_OF_RELATED_OBJ STRING  MASKED WITH (FUNCTION = 'default()') 
    ,RELAT_SPEC STRING
    ,START_DATE DATE
    ,END_DATE DATE
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
    )USING DELTA;
"""),

# mskd.sap_pa0001
("SAP_PA0001",
    """CREATE TABLE IF NOT EXISTS mskd.SAP_PA0001(
    PERSONNEL_NUMBER INT  MASKED WITH (FUNCTION = 'random(1,9999)') 
    ,EE_SUBGROUP STRING
    ,ORG_UNIT INT
    ,POSITION INT
    ,JOB INT
    ,NAME_SOFTWARE STRING MASKED WITH (FUNCTION = 'default()') 
    ,NAME_FORMATTED STRING MASKED WITH (FUNCTION = 'default()') 
    ,OBJ_TYPE STRING
    ,START_DATE DATE
    ,END_DATE DATE
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
    )USING DELTA;
"""),

# mskd.sap_pa0007
("sap_pa0007",
"""CREATE TABLE IF NOT EXISTS mskd.sap_pa0007(
    SAP_CLIENT INT
    ,PERSONNEL_NUMBER INT MASKED WITH (FUNCTION = 'random(1, 9999)')
    ,END_DATE DATE
    ,START_DATE DATE
    ,CHANGED_BY INT
    ,REASON_FOR_CHANGE STRING
    ,WORK_SCHED_RULE STRING
    ,EMP_TIME_MAN_STATUS INT
    ,WORKING_WK STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# mskd.sap_pa0008
("sap_pa0008",
"""CREATE TABLE IF NOT EXISTS mskd.sap_pa0008(
    PERNR INT
    ,ENDDA INT
    ,BEGDA INT
    ,BSGRD DECIMAL
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# mskd.sap_pa2001
("sap_pa2001",
"""CREATE TABLE IF NOT EXISTS mskd.sap_pa2001(
    PERSONNEL_NUMBER STRING MASKED WITH (FUNCTION = 'default()') 
    ,ABS_START_DATE DATE
    ,ABS_END_DATE DATE
    ,ABSENCE_TYPE STRING
    ,CHANGED_ON DATE
    ,ABSENCE_DAYS DECIMAL
    ,ABSENCE_HRS DECIMAL
    ,CAL_DAYS DECIMAL
    ,ABSENCE_SUBTYPE STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# mskd.sap_pa2002
("sap_pa2002",
"""CREATE TABLE IF NOT EXISTS mskd.sap_pa2002(
    PERSONNEL_NUMBER STRING MASKED WITH (FUNCTION = 'default()') 
    ,ATT_START_DATE DATE
    ,ATT_END_DATE DATE
    ,ATT_START_TIME STRING
    ,ATT_END_TIME STRING
    ,ATTENDANCE_TYPE STRING
    ,CHANGED_ON DATE
    ,ATTENDANCE_DAYS DECIMAL
    ,ATTENDANCE_HRS DECIMAL
    ,CAL_DAYS DECIMAL
    ,ATTENDANCE_SUBTYPE STRING
    ,COMPENSATION_TYPE STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# mskd.sap_pa2003
("sap_pa2003",
"""CREATE TABLE IF NOT EXISTS mskd.sap_pa2003(
    PERSONNEL_NUMBER INT MASKED WITH (FUNCTION = 'random(1, 9999)')
    ,SUBS_START_DATE DATE
    ,SUBS_END_DATE DATE
    ,CHANGED_ON DATE
    ,SUBSTITUTION_TYPE STRING
    ,WORK_BRK_SCHED STRING
    ,PUBLIC_HOL_CAL STRING
    ,WORK_SCHED_RULE STRING
    ,DAILY_WORK_SCHED STRING
    ,DAY_TYPE STRING
    ,POSITION STRING
    ,CHANGED_BY INT
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# mskd.sap_pa9046
("sap_pa9046",
"""CREATE TABLE IF NOT EXISTS mskd.sap_pa9046(
    PERSONNEL_NUMBER INT MASKED WITH (FUNCTION = 'random(1, 9999)')
    ,TEMP_START_DATE DATE
    ,TEMP_END_DATE DATE
    ,CHANGED_BY INT
    ,TEMP_GROUP INT
    ,TEMP_GROUP_DESC STRING
    ,TEMP_RANK STRING
    ,TEMP_RANK_DESC STRING
    ,TEMP_SECTION STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# mskd.sap_t503t
("sap_t503t",
"""CREATE TABLE IF NOT EXISTS mskd.sap_t503t(
    MANDT INT
    ,SPRSL STRING
    ,PERSK STRING
    ,PTEXT STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# mskd.sap_t508a
("sap_t508a",
"""CREATE TABLE IF NOT EXISTS mskd.sap_t508a(
    SAP_CLIENT INT
    ,PUBLIC_HOL_CAL STRING
    ,PERSON_TYPE STRING
    ,WORK_SCHED_RULE STRING
    ,SCHED_END_DATE DATE
    ,SCHED_START_DATE DATE
    ,PERIOD_WORK_SCHED STRING
    ,PERIOD_REF_DATE DATE
    ,DAY_OF_PERIOD INT
    ,REDUCED_HRS_RULE STRING
    ,DAY_TYPE_RULE STRING
    ,DAILY_HOURS DECIMAL
    ,HOURS_PER_WK DECIMAL
    ,MONTHLY_HRS DECIMAL
    ,ADD_MONTHLY_HRS DECIMAL
    ,WKLY_WRKDAYS DECIMAL
    ,ANNUAL_WORK_HRS DECIMAL
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# mskd.sap_t550a
("sap_t550a",
"""CREATE TABLE IF NOT EXISTS mskd.sap_t550a(
    PERSON_TYPE STRING
    ,DAILY_WORK_SCHED STRING
    ,SCHED_END_DATE DATE
    ,SCHED_START_DATE DATE
    ,DAILY_WORK_SCHED_RULE STRING
    ,PLANNED_WORKING_HRS DECIMAL
    ,PLANNED_WORKING_START STRING
    ,PLANNED_WORKING_END STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# mskd.sap_t550s
("sap_t550s",
"""CREATE TABLE IF NOT EXISTS mskd.sap_t550s(
    PERSON_TYPE STRING
    ,DAILY_WORK_SCHED STRING
    ,DAILY_WORK_SCHED_DESC STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# mskd.sap_t551a
("sap_t551a",
"""CREATE TABLE IF NOT EXISTS mskd.sap_t551a(
    SAP_CLIENT INT
    ,PERSON_TYPE STRING
    ,PERIOD_WORK_SCHED STRING
    ,WK_NUM STRING
    ,DAILY_WORK_SCHED_1 STRING
    ,DAILY_WORK_SCHED_2 STRING
    ,DAILY_WORK_SCHED_3 STRING
    ,DAILY_WORK_SCHED_4 STRING
    ,DAILY_WORK_SCHED_5 STRING
    ,DAILY_WORK_SCHED_6 STRING
    ,DAILY_WORK_SCHED_7 STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# mskd.sap_t551s
("sap_t551s",
"""CREATE TABLE IF NOT EXISTS mskd.sap_t551s(
    SAP_CLIENT INT
    ,PERSON_TYPE STRING
    ,PERIOD_WORK_SCHED STRING
    ,PERIOD_WORK_SCHED_DESC STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# mskd.sap_t554t
("sap_t554t",
"""CREATE TABLE IF NOT EXISTS mskd.sap_t554t(
    PERSON_TYPE STRING
    ,ATT_ABSENCE_TYPE STRING
    ,ATT_ABSENCE_DESC STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# mskd.sap_thoc
("sap_thoc",
"""CREATE TABLE IF NOT EXISTS mskd.sap_thoc(
    TICKET_ID STRING
    ,SYS_DATE DATE
    ,PUBLIC_HOL_KEY STRING
    ,PUBLIC_HOL_GUARANTEED_FLAG STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# mskd.sap_hrp1001_tempAssignment
("sap_hrp1001_tempAssignment",
"""CREATE TABLE IF NOT EXISTS mskd.sap_hrp1001_tempAssignment(
    START_DATE DATE
    ,END_DATE DATE
    ,OBJ_ID INT
    ,OBJ_TYPE STRING
    ,REASON STRING
    ,RELAT STRING
    ,RELAT_SPEC STRING
    ,TYPE_OF_RELATED_OBJ STRING
    ,ID_OF_RELATED_OBJ STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
)USING DELTA;
"""),

])


                                    # ================================================ 
                                    # TBL TABLES
                                    # ================================================

# createTable([

# # tbl_org
# ("tbl_org",
#     """CREATE TABLE IF NOT EXISTS tbl_org(
#     ORGID STRING
#     ,PERSONNELNUMBER	STRING
#     ,STARTDATE	DATE
#     ,ENDDATE	DATE
#     ,FULLNAME	STRING
#     ,SECTION	STRING
#     ,SECTIONID	STRING
#     ,UNIT	STRING
#     ,UNITID	STRING
#     ,LOCATION	STRING
#     ,LOCATIONID	STRING
#     ,DEPARTMENT	STRING
#     ,DEPARTMENTID	STRING
#     ,DIRECTORATE	STRING
#     ,DIRECTORATEID	STRING
#     ,COMMAND	STRING
#     ,COMMANDID	STRING
#     ,FORCE	STRING
#     ,FORCEID	STRING
#     ,CURRENT	INT
#     ,OA_REC_PROCESSED_DATE TIMESTAMP
#     ,OA_RECORDID STRING
#     )USING DELTA;
# """),


# # tbl_staff_history
# ("tbl_staff_history",
#     """CREATE TABLE IF NOT EXISTS tbl_staff_history(
#     PERSONNELNUMBER INT
#     ,STARTDATE DATE
#     ,ENDDATE DATE
#     ,FULLNAME STRING
#     ,ROLE STRING
#     ,ROLEID STRING
#     ,SECTION STRING
#     ,SECTIONID STRING
#     ,UNIT STRING
#     ,UNITID STRING
#     ,LOCATION STRING
#     ,LOCATIONID STRING
#     ,DEPARTMENT STRING
#     ,DEPARTMENTID STRING
#     ,COMMAND STRING
#     ,COMMANDID STRING
#     ,DIRECTORATE STRING
#     ,DIRECTORATEID STRING
#     ,FORCE STRING
#     ,FORCEID STRING
#     ,STAFFMOVEID STRING
#     ,CURRENTFLAG STRING
#     ,OA_REC_PROCESSED_DATE TIMESTAMP
#     ,OA_RECORDID STRING
#     )USING DELTA;
# """),

# # tbl_staffing_report   
# ("tbl_staffing_report",
# """CREATE TABLE IF NOT EXISTS tbl_staffing_report(
#     DATE DATE
#     ,PERSONNEL_NUMBER INT
#     ,PLANNED_SHIFT_DETAIL STRING
#     ,ACTUAL_SHIFT_DETAIL STRING
#     ,HRS STRING
#     ,OA_REC_PROCESSED_DATE TIMESTAMP
#     ,OA_RECORDID STRING
# )USING DELTA;
# """),

# ])

#                                               # =========================== 
#                                               # OPERATIONAL PLANNING
#                                               # ===========================

# createTable([                                             

# # operationalPlanningCalendar_util_cv
# ("operationalPlanningCalendar_util_cv",
# """CREATE TABLE IF NOT EXISTS operationalPlanningCalendar_util_cv(
#     ID BIGINT
#     ,CODE STRING
#     ,LOGICALDELETE STRING
#     ,SORTORDER INT
#     ,TITLE STRING
#     ,OA_REC_PROCESSED_DATE TIMESTAMP
#     ,OA_RECORDID STRING
# )USING DELTA;
# """),

# # operationalPlanningCalendar_opc_event
# ("operationalPlanningCalendar_opc_event",
# """CREATE TABLE IF NOT EXISTS operationalPlanningCalendar_opc_event(
#     DBID INT
#     ,ALLDAY STRING
#     ,DESCRIPTION STRING
#     ,ENDDATE DATE
#     ,SENSITIVE STRING
#     ,STARTDATE DATE
#     ,STATUS STRING
#     ,TITLE STRING
#     ,LOCATION_ID INT
#     ,POLICINGDEMAND_ID INT
#     ,OA_REC_PROCESSED_DATE TIMESTAMP
#     ,OA_RECORDID STRING
# )USING DELTA;
# """),

# # operationalPlanningCalendar_opc_event_resources
# ("operationalPlanningCalendar_opc_event_resources",
# """CREATE TABLE IF NOT EXISTS operationalPlanningCalendar_opc_event_resources(
#     OPC_EVENT_ID INT
#     ,UTIL_CV_ID INT
#     ,OA_REC_PROCESSED_DATE TIMESTAMP
#     ,OA_RECORDID STRING
# )USING DELTA;
# """),

# ])



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
