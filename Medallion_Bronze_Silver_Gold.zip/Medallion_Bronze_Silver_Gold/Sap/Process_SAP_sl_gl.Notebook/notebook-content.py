# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "42396a50-8b85-4951-9850-b36abfe2a28d",
# META       "default_lakehouse_name": "LH_300_Gold_Test",
# META       "default_lakehouse_workspace_id": "a3e4d0e6-6b32-498b-addc-1629a4b29a47",
# META       "known_lakehouses": [
# META         {
# META           "id": "42396a50-8b85-4951-9850-b36abfe2a28d"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# # **SAP GOLD LOAD**

# MARKDOWN ********************

# ###### CONFIG

# CELL ********************

%run /config_gold_layer

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

# # Only activate for Testing
p_current_domain = "SAP"
print(f"✅ STARTING {p_current_domain} PROCESSING")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": true
# META }

# CELL ********************

create_temp_views_by_domains(silverPath, p_current_domain)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### CREATE TABLE

# CELL ********************

                                    # ======================
                                    #     calc TABLES
                                    # ======================

createTable([

# calc.sap_pa2003
("calc.sap_pa2003",
"""CREATE TABLE IF NOT EXISTS calc.sap_pa2003 (
    PERSONNEL_NUMBER INT,
    SUBS_START_DATE DATE,
    SUBS_END_DATE DATE,
    CHANGED_ON DATE,
    SUBSTITUTION_TYPE STRING,
    WORK_BRK_SCHED STRING,
    PUBLIC_HOL_CAL STRING,
    WORK_SCHED_RULE STRING,
    DAILY_WORK_SCHED STRING,
    DAY_TYPE STRING,
    POSITION STRING,
    CHANGED_BY INT,
    OA_REC_PROCESSED_DATE TIMESTAMP,
    OA_REC_CREATED_DATE TIMESTAMP,
    OA_REC_END_DATE TIMESTAMP,
    OA_IS_ACTIVE INT,
    OA_VERSION INT,
    OA_RECORDID STRING
) USING DELTA;
""")

])
                                    # ======================
                                    #     rprt TABLES
                                    # ======================
createTable([
    
#rprt.tbl_d_staff_history
("rprt.tbl_d_staff_history",
    """CREATE TABLE IF NOT EXISTS rprt.tbl_d_staff_history(
    PersonnelNumber	STRING
    ,StartDate	TIMESTAMP
    ,EndDate	TIMESTAMP
    ,FullName	STRING
    ,Role	STRING
    ,RoleID	STRING
    ,Section	STRING
    ,SectionID	STRING
    ,Unit	STRING
    ,UnitID	STRING
    ,Location	STRING
    ,LocationID	STRING
    ,Department	STRING
    ,DepartmentID	STRING
    ,Command	STRING
    ,CommandID	STRING
    ,Directorate	STRING
    ,DirectorateID	STRING
    ,Force	STRING
    ,ForceID	STRING
    ,STAFF_MOVE_ID	STRING
    ,Current	INT
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_REC_CREATED_DATE TIMESTAMP
    ,OA_REC_END_DATE TIMESTAMP
    ,OA_IS_ACTIVE INT
    ,OA_VERSION INT
    ,OA_RECORDID STRING
    )USING DELTA;
    """),

#rprt.tbl_d_org
    ("rprt.tbl_d_org",
    """CREATE TABLE IF NOT EXISTS  rprt.tbl_d_org(
     OrgID	STRING NOT NULL
     ,LoadID INT
     ,PersonnelNumber	STRING
     ,StartDate	DATE
     ,EndDate	DATE
     ,FullName	STRING
     ,Section	STRING
     ,SectionID	STRING
     ,Unit	STRING
     ,UnitID	STRING
     ,Location	STRING
     ,LocationID	STRING
     ,Department	STRING
     ,DepartmentID	STRING
     ,Command	STRING
     ,CommandID	STRING
     ,Directorate	STRING
     ,DirectorateID	STRING
     ,Force	STRING
     ,ForceID	STRING
     ,STAFF_MOVE_ID	STRING
     ,Current	INT
     ,OA_REC_PROCESSED_DATE TIMESTAMP
     ,OA_REC_CREATED_DATE TIMESTAMP
     ,OA_REC_END_DATE TIMESTAMP
     ,OA_IS_ACTIVE INT
     ,OA_VERSION INT
     ,OA_RECORDID STRING
    )USING DELTA;
    """),
    
#tbl_f_operational_planning
    ("rprt.tbl_f_operational_planning",
    """CREATE TABLE IF NOT EXISTS rprt.tbl_f_operational_planning(
    OPCId	INT
    ,Start_Date	TIMESTAMP
    ,End_Date	TIMESTAMP
    ,Duration	INT
    ,Demand_Type	STRING
    ,Operation	STRING
    ,Description	STRING
    ,Sensitive	STRING
    ,Code	STRING
    ,Status	STRING
    ,Colour	STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_REC_CREATED_DATE TIMESTAMP
    ,OA_REC_END_DATE TIMESTAMP
    ,OA_IS_ACTIVE INT
    ,OA_VERSION INT
    ,OA_RECORDID STRING
    )USING DELTA;
    """),

#tbl_f_staffing_report
    ("rprt.tbl_f_staffing_report",
    """CREATE TABLE IF NOT EXISTS rprt.tbl_f_staffing_report(
    Date	DATE
    ,PersonnelNumber	STRING
    ,Name	STRING
    ,Personnel	STRING
    ,Command	STRING
    ,Department	STRING
    ,Location	STRING
    ,Unit	STRING
    ,Section	STRING
    ,Role	STRING
    ,TSA	STRING
    ,Rank	STRING
    ,Group_Rank	STRING
    ,Planned_Shift_Detail	STRING
    ,Actual_Shift_Detail	STRING
    ,Shift_Type	STRING
    ,FTE	DECIMAL
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_REC_CREATED_DATE TIMESTAMP
    ,OA_REC_END_DATE TIMESTAMP
    ,OA_IS_ACTIVE INT
    ,OA_VERSION INT
    ,OA_RECORDID STRING
    )USING DELTA;
    """),
    
])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### INGEST IN GOLD LAYER

# CELL ********************


                                                                                # ==================================
                                                                                # calc -TABLE LOAD 
                                                                                # ==================================

run_parallel_queries_gold([

# calc.sap_pa2003
("calc.sap_pa2003",
"""WITH version_data AS (
    SELECT PERSONNEL_NUMBER, MAX(OA_VERSION) AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate 
    FROM calc.sap_pa2003 
    GROUP BY PERSONNEL_NUMBER
),
dedup_source AS (
    SELECT *
    FROM (
        SELECT s.*, ROW_NUMBER() OVER (PARTITION BY PERSONNEL_NUMBER ORDER BY CHANGED_ON DESC) AS rn
        FROM temp_sap_pa2003 s
    ) WHERE rn = 1
),
prepared_source AS (
    SELECT s.*, 
           COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW, 
           CURRENT_TIMESTAMP() AS OA_REC_PROCESSED_DATE_NEW,
           CASE WHEN s.PERSONNEL_NUMBER = v.PERSONNEL_NUMBER THEN v.min_createdDate ELSE CURRENT_TIMESTAMP() END AS OA_REC_CREATED_DATE
    FROM dedup_source s
    LEFT JOIN version_data v ON s.PERSONNEL_NUMBER = v.PERSONNEL_NUMBER
)
MERGE INTO calc.sap_pa2003 AS t
USING prepared_source s
ON t.PERSONNEL_NUMBER = s.PERSONNEL_NUMBER AND t.OA_IS_ACTIVE = 1


WHEN MATCHED AND t.OA_RECORDID <> s.OA_RECORDID THEN
    UPDATE SET t.OA_IS_ACTIVE = 0, 
               t.OA_REC_END_DATE = s.OA_REC_PROCESSED_DATE_NEW, 
               t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE_NEW

WHEN NOT MATCHED THEN
    INSERT (PERSONNEL_NUMBER, SUBS_START_DATE, SUBS_END_DATE, CHANGED_ON, SUBSTITUTION_TYPE, WORK_BRK_SCHED, PUBLIC_HOL_CAL, WORK_SCHED_RULE, DAILY_WORK_SCHED, DAY_TYPE, POSITION, CHANGED_BY, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
    VALUES (s.PERSONNEL_NUMBER, s.SUBS_START_DATE, s.SUBS_END_DATE, s.CHANGED_ON, s.SUBSTITUTION_TYPE, s.WORK_BRK_SCHED, s.PUBLIC_HOL_CAL, s.WORK_SCHED_RULE, s.DAILY_WORK_SCHED, s.DAY_TYPE, s.POSITION, s.CHANGED_BY, s.OA_REC_PROCESSED_DATE_NEW, s.OA_REC_CREATED_DATE, TO_TIMESTAMP('9999-12-31'), 1, s.OA_VERSION_NEW, s.OA_RECORDID);
"""),

        
])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

                                                                                    #========================================
                                                                                    # rprt TABLES LOAD -approx xmins
                                                                                    # =======================================

run_parallel_queries_gold([
# tbl_d_staff_history
("rprt.tbl_d_staff_history",
        """WITH version_data AS(SELECT PERSONNELNUMBER, MAX(OA_VERSION) AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate FROM rprt.tbl_d_staff_history GROUP BY PERSONNELNUMBER),
    
        -- Step 3: Prepare source data with versions
        prepared_source AS(
        SELECT  s.*, COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW,  CURRENT_TIMESTAMP() AS OA_REC_PROCESSED_DATE_NEW, CASE WHEN s.PERSONNELNUMBER = v.PERSONNELNUMBER THEN v.min_createdDate ELSE CURRENT_TIMESTAMP() END OA_REC_CREATED_DATE
        FROM temp_tbl_staff_history s
        LEFT JOIN version_data v ON s.PERSONNELNUMBER = v.PERSONNELNUMBER
        -- WHERE s.OA_REC_PROCESSED_DATE = (SELECT MAX(OA_REC_PROCESSED_DATE) FROM temp_tbl_sap_staff_history) 
        ) 
        
        MERGE INTO rprt.tbl_d_staff_history AS t
        USING prepared_source s
        ON t.PERSONNELNUMBER = s.PERSONNELNUMBER AND t.OA_IS_ACTIVE = 1
    
        WHEN MATCHED AND t.OA_RECORDID <> s.OA_RECORDID THEN
            UPDATE SET t.OA_IS_ACTIVE = 0, t.OA_REC_END_DATE = OA_REC_PROCESSED_DATE_NEW, t.OA_REC_PROCESSED_DATE = OA_REC_PROCESSED_DATE_NEW
    
        WHEN NOT MATCHED THEN
        INSERT (PERSONNELNUMBER ,STARTDATE,ENDDATE,FULLNAME ,ROLE ,ROLEID ,SECTION ,SECTIONID ,UNIT ,UNITID ,LOCATION ,LOCATIONID ,DEPARTMENT ,DEPARTMENTID ,COMMAND ,COMMANDID ,DIRECTORATE ,DIRECTORATEID ,FORCE ,FORCEID ,STAFF_MOVE_ID ,CURRENT, 
        OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
        VALUES (s.PERSONNELNUMBER, s.STARTDATE,s.ENDDATE, s.FULLNAME ,s.ROLE ,s.ROLEID ,s.SECTION ,s.SECTIONID ,s.UNIT ,s.UNITID ,s.LOCATION ,s.LOCATIONID ,s.DEPARTMENT ,s.DEPARTMENTID ,s.COMMAND ,s.COMMANDID ,s.DIRECTORATE ,s.DIRECTORATEID ,s.FORCE ,s.FORCEID ,s.STAFFMOVEID ,s.CURRENTFLAG, 
        s.OA_REC_PROCESSED_DATE_NEW, s.OA_REC_CREATED_DATE, TO_TIMESTAMP('9999-12-31'), 1,s.OA_VERSION_NEW,s.OA_RECORDID)
        """
    ),

# # tbl_d_org
 ("rprt.tbl_d_org",
        """WITH version_data AS(SELECT PERSONNELNUMBER, MAX(OA_VERSION) AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate FROM rprt.tbl_d_org GROUP BY PERSONNELNUMBER),
    
        -- Step 3: Prepare source data with versions
        prepared_source AS(
        SELECT  s.*, COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW,  CURRENT_TIMESTAMP() AS OA_REC_PROCESSED_DATE_NEW, CASE WHEN s.PERSONNELNUMBER = v.PERSONNELNUMBER THEN v.min_createdDate ELSE CURRENT_TIMESTAMP() END OA_REC_CREATED_DATE
        FROM temp_tbl_org s
        LEFT JOIN version_data v ON s.PERSONNELNUMBER = v.PERSONNELNUMBER
        -- WHERE s.OA_REC_PROCESSED_DATE = (SELECT MAX(OA_REC_PROCESSED_DATE) FROM temp_tbl_sap_org) 
        )
        
        MERGE INTO rprt.tbl_d_org AS t
        USING prepared_source s
        ON t.PERSONNELNUMBER = s.PERSONNELNUMBER AND t.OA_IS_ACTIVE = 1
    
        WHEN MATCHED AND t.OA_RECORDID <> s.OA_RECORDID THEN
            UPDATE SET t.OA_IS_ACTIVE = 0, t.OA_REC_END_DATE = OA_REC_PROCESSED_DATE_NEW, t.OA_REC_PROCESSED_DATE = OA_REC_PROCESSED_DATE_NEW
    
    
        WHEN NOT MATCHED THEN
        INSERT (ORGID, LoadID, PERSONNELNUMBER, STARTDATE, ENDDATE, FULLNAME, SECTION, SECTIONID, UNIT, UNITID, LOCATION, LOCATIONID, DEPARTMENT, DEPARTMENTID, COMMAND, COMMANDID, DIRECTORATE, DIRECTORATEID, FORCE, FORCEID, CURRENT, 
        OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
        VALUES (s.ORGID, NULL, s.PERSONNELNUMBER, s.STARTDATE, s.ENDDATE, s.FULLNAME, s.SECTION, s.SECTIONID, s.UNIT, s.UNITID, s.LOCATION, s.LOCATIONID, s.DEPARTMENT, s.DEPARTMENTID, s.COMMAND, s.COMMANDID, s.DIRECTORATE, s.DIRECTORATEID, s.FORCE, s.FORCEID, s.CURRENT, 
        s.OA_REC_PROCESSED_DATE_NEW, s.OA_REC_CREATED_DATE, TO_TIMESTAMP('9999-12-31'), 1, s.OA_VERSION_NEW, s.OA_RECORDID)
        """
    ),

])

                                                                                # ==================================
                                                                                # F-TABLE 
                                                                                # ==================================


run_parallel_queries_gold([

# # tbl_f_staffing_report
("rprt.tbl_f_staffing_report",
    
"""WITH version_data AS(SELECT PERSONNELNUMBER, MAX(OA_VERSION) AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate  FROM rprt.tbl_f_staffing_report GROUP BY PERSONNELNUMBER),
     dates AS (SELECT 
            d.DateID,
            d.Date 
        FROM rprt.tbl_d_date d 
        WHERE d.Date BETWEEN DATEADD(DAY, -15 * 30, CURRENT_DATE()) AND DATEADD(DAY, 12 * 30, CURRENT_DATE())
    ),
    
    tmp_tbl_d_staffing_report_01 AS (
    SELECT
        d.DateID,
        d.Date,
        pa0007.PERSONNEL_NUMBER AS PERSONNELNUMBER,
        pa0007.START_DATE,
        pa0007.END_DATE,
        pa0007.WORK_SCHED_RULE
    FROM dates d
    LEFT JOIN temp_sap_pa0007 pa0007 ON d.Date BETWEEN pa0007.START_DATE AND pa0007.END_DATE 
        AND pa0007.WORK_SCHED_RULE <> 'EX LOAD'
    )
    
    -- SELECT * FROM tmp_tbl_d_staffing_report_01 LIMIT 5;
    ,tmp_tbl_d_staffing_report_02 AS (
        SELECT 
            PERSON_TYPE,
            PERIOD_WORK_SCHED,
            WK_NUM,
            DoW,
            DAILY_WORK_SCHED  
        FROM (
            SELECT 
                PERSON_TYPE,
                PERIOD_WORK_SCHED,
                WK_NUM,
                DAILY_WORK_SCHED_1,
                DAILY_WORK_SCHED_2,
                DAILY_WORK_SCHED_3,
                DAILY_WORK_SCHED_4,
                DAILY_WORK_SCHED_5,
                DAILY_WORK_SCHED_6,
                DAILY_WORK_SCHED_7
            FROM temp_sap_t551a
        ) t551a
        UNPIVOT (
            DAILY_WORK_SCHED FOR DoW IN (
                DAILY_WORK_SCHED_1,
                DAILY_WORK_SCHED_2,
                DAILY_WORK_SCHED_3,
                DAILY_WORK_SCHED_4,
                DAILY_WORK_SCHED_5,
                DAILY_WORK_SCHED_6,
                DAILY_WORK_SCHED_7
            )
        )
    ),
    
    daysinschedperiod AS (
        SELECT 
            t551a2.PERSON_TYPE,
            t551a2.PERIOD_WORK_SCHED,
            MAX(t551a2.WK_NUM) * 7 AS DaysInPeriod
        FROM temp_sap_t551a t551a2
        GROUP BY t551a2.PERSON_TYPE, t551a2.PERIOD_WORK_SCHED
    ),
    
    publichols AS (
        SELECT TICKET_ID, SYS_DATE 
        FROM temp_sap_thoc
        WHERE TICKET_ID IN ('ZP', 'ZS')
        GROUP BY TICKET_ID, SYS_DATE
    ),
    
    tmp_tbl_d_staffing_report_03 AS (
        SELECT
            tmp1.Date,
            tmp1.PERSONNELNUMBER,
            t508a.PERSON_TYPE,
            t508a.PERIOD_WORK_SCHED,
            (DATEDIFF(tmp1.Date, '2003-03-31') % 7) + 1 AS DayOfWeek,
            CASE 
                WHEN RIGHT(CONCAT('000', CAST(CEILING((DATEDIFF(tmp1.Date, DATE_SUB(t508a.PERIOD_REF_DATE, t508a.DAY_OF_PERIOD)) % dip.DaysInPeriod) / 7.0) AS STRING)), 3) = '000' 
                THEN RIGHT(CONCAT('000', CAST(dip.DaysInPeriod / 7 AS STRING)), 3)
                ELSE RIGHT(CONCAT('000', CAST(CEILING((DATEDIFF(tmp1.Date, DATE_SUB(t508a.PERIOD_REF_DATE, t508a.DAY_OF_PERIOD)) % dip.DaysInPeriod) / 7.0) AS STRING)), 3) 
            END AS WkNum,
            CASE WHEN zp.SYS_DATE IS NOT NULL THEN 'ZP' END AS ZP,
            CASE WHEN zs.SYS_DATE IS NOT NULL THEN 'ZS' END AS ZS
        FROM tmp_tbl_d_staffing_report_01 tmp1
        LEFT JOIN temp_sap_t508a t508a ON t508a.WORK_SCHED_RULE = tmp1.WORK_SCHED_RULE 
            AND tmp1.END_DATE BETWEEN t508a.SCHED_START_DATE AND t508a.SCHED_END_DATE 
            AND t508a.PUBLIC_HOL_CAL = CASE WHEN t508a.PERSON_TYPE = '01' THEN 'ZP' WHEN t508a.PERSON_TYPE = '02' THEN 'ZS' END
        LEFT JOIN daysinschedperiod dip ON dip.PERIOD_WORK_SCHED = t508a.PERIOD_WORK_SCHED AND dip.PERSON_TYPE = t508a.PERSON_TYPE
        LEFT JOIN publichols zp ON tmp1.Date = zp.SYS_DATE AND zp.TICKET_ID = 'ZP'
        LEFT JOIN publichols zs ON tmp1.Date = zs.SYS_DATE AND zs.TICKET_ID = 'ZS'
    ),
    
    shifthours AS (
        SELECT 
            t550a.PERSON_TYPE,
            t550a.DAILY_WORK_SCHED,
            t550a.SCHED_START_DATE,
            t550a.SCHED_END_DATE,
            MAX(t550a.PLANNED_WORKING_HRS) AS PLANNED_WORKING_HRS
        FROM temp_sap_t550a t550a
        GROUP BY t550a.PERSON_TYPE, t550a.DAILY_WORK_SCHED, t550a.SCHED_START_DATE, t550a.SCHED_END_DATE
    ),
    
    abs_hours AS (
        SELECT 
            tmp3.PERSONNELNUMBER,
            tmp3.Date,
            COALESCE(SUM(pa2001.absence_hrs), 0) AS total_absence_hrs,
            COALESCE(SUM(pa2002.attendance_hrs), 0) AS total_attendance_hrs
        FROM tmp_tbl_d_staffing_report_03 tmp3
        LEFT JOIN temp_sap_pa2001 pa2001 ON pa2001.PERSONNEL_NUMBER = tmp3.PERSONNELNUMBER 
            AND tmp3.Date BETWEEN pa2001.ABS_START_DATE AND pa2001.ABS_END_DATE
        LEFT JOIN temp_sap_pa2002 pa2002 ON pa2002.PERSONNEL_NUMBER = tmp3.PERSONNELNUMBER 
            AND tmp3.Date BETWEEN pa2002.ATT_START_DATE AND pa2002.ATT_END_DATE 
            AND pa2002.compensation_type = ' '
        GROUP BY tmp3.PERSONNELNUMBER, tmp3.Date
    ),
    
    tmp_tbl_d_staffing_report_04 AS (
        SELECT 
            tmp3.Date,
            tmp3.PERSONNELNUMBER,
            t550s.DAILY_WORK_SCHED_DESC AS Planned_Shift,
            CASE  
                WHEN tmp3.PERSON_TYPE = '01' AND tmp3.ZP IS NOT NULL THEN 
                    COALESCE(t554t.ATT_ABSENCE_DESC, t554t2.ATT_ABSENCE_DESC, t550s2.DAILY_WORK_SCHED_DESC, 'Public Hol')
                WHEN tmp3.PERSON_TYPE = '02' AND tmp3.ZS IS NOT NULL THEN 
                    COALESCE(t554t.ATT_ABSENCE_DESC, t554t2.ATT_ABSENCE_DESC, t550s2.DAILY_WORK_SCHED_DESC, 'Public Hol')
                ELSE 
                    CASE
                        WHEN abs_hours.total_absence_hrs + abs_hours.total_attendance_hrs > 0.5 * COALESCE(sh1.PLANNED_WORKING_HRS, 0) THEN 
                            COALESCE(t554t.ATT_ABSENCE_DESC, t554t2.ATT_ABSENCE_DESC, t550s2.DAILY_WORK_SCHED_DESC, t550s.DAILY_WORK_SCHED_DESC)
                        ELSE t550s.DAILY_WORK_SCHED_DESC
                    END
            END AS Actual_Shift,
            CASE
                WHEN abs_hours.total_absence_hrs + abs_hours.total_attendance_hrs > 0.5 * COALESCE(sh1.PLANNED_WORKING_HRS, 0) THEN
                    CASE
                        WHEN t554t.ATT_ABSENCE_DESC IS NOT NULL THEN 0
                        WHEN t554t2.ATT_ABSENCE_DESC IS NOT NULL THEN 0
                        WHEN sh2.PLANNED_WORKING_HRS IS NOT NULL THEN sh2.PLANNED_WORKING_HRS
                        ELSE t550s.DAILY_WORK_SCHED_DESC
                    END
                ELSE sh1.PLANNED_WORKING_HRS 
            END AS Hrs
        FROM tmp_tbl_d_staffing_report_03 tmp3
        LEFT JOIN tmp_tbl_d_staffing_report_02 tmp2 ON tmp2.PERIOD_WORK_SCHED = tmp3.PERIOD_WORK_SCHED 
            AND tmp2.WK_NUM = tmp3.WkNum 
            AND RIGHT(tmp2.DoW, 1) = CAST(tmp3.DayOfWeek AS STRING)
            AND tmp2.PERSON_TYPE = tmp3.PERSON_TYPE
        LEFT JOIN temp_sap_t550s t550s ON t550s.DAILY_WORK_SCHED = tmp2.DAILY_WORK_SCHED AND t550s.PERSON_TYPE = tmp3.PERSON_TYPE
        LEFT JOIN shifthours sh1 ON sh1.DAILY_WORK_SCHED = tmp2.DAILY_WORK_SCHED 
            AND sh1.PERSON_TYPE = tmp3.PERSON_TYPE 
            AND tmp3.Date BETWEEN sh1.SCHED_START_DATE AND sh1.SCHED_END_DATE
        LEFT JOIN temp_sap_pa2001 pa2001 ON pa2001.PERSONNEL_NUMBER = tmp3.PERSONNELNUMBER 
            AND tmp3.Date BETWEEN pa2001.ABS_START_DATE AND pa2001.ABS_END_DATE
        LEFT JOIN temp_sap_pa2002 pa2002 ON pa2002.PERSONNEL_NUMBER = tmp3.PERSONNELNUMBER 
            AND tmp3.Date BETWEEN pa2002.ATT_START_DATE AND pa2002.ATT_END_DATE 
            AND pa2002.compensation_type = ' '
        LEFT JOIN temp_sap_t554t t554t ON t554t.ATT_ABSENCE_TYPE = pa2001.ABSENCE_TYPE 
            AND CASE WHEN tmp3.PERSON_TYPE = '01' THEN '80' WHEN tmp3.PERSON_TYPE = '02' THEN '81' END = t554t.PERSON_TYPE
        LEFT JOIN temp_sap_t554t t554t2 ON t554t2.ATT_ABSENCE_TYPE = pa2002.ATTENDANCE_TYPE 
            AND CASE WHEN tmp3.PERSON_TYPE = '01' THEN '80' WHEN tmp3.PERSON_TYPE = '02' THEN '81' END = t554t2.PERSON_TYPE
        LEFT JOIN temp_sap_pa2003 pa2003 ON pa2003.PERSONNEL_NUMBER = tmp3.PERSONNELNUMBER 
            AND tmp3.Date BETWEEN pa2003.SUBS_START_DATE AND pa2003.SUBS_END_DATE 
            AND pa2003.DAY_TYPE = 0
        LEFT JOIN temp_sap_t550s t550s2 ON t550s2.DAILY_WORK_SCHED = pa2003.DAILY_WORK_SCHED AND t550s2.PERSON_TYPE = tmp3.PERSON_TYPE
        LEFT JOIN shifthours sh2 ON sh2.DAILY_WORK_SCHED = pa2003.DAILY_WORK_SCHED 
            AND sh2.PERSON_TYPE = tmp3.PERSON_TYPE 
            AND tmp3.Date BETWEEN sh2.SCHED_START_DATE AND sh2.SCHED_END_DATE
        LEFT JOIN abs_hours ON abs_hours.PERSONNELNUMBER = tmp3.PERSONNELNUMBER AND abs_hours.Date = tmp3.Date
    ),
    
    tmp_tbl_d_staffing_report_05 AS (
        SELECT
            tmp4.Date,
            tmp4.PERSONNELNUMBER AS PERSONNELNUMBER,
            SUBSTRING(TRIM(sh.FullName), LENGTH(TRIM(sh.FullName)) - POSITION(' ' IN REVERSE(TRIM(sh.FullName))) + 2) AS Name,
            CONCAT(tmp4.PERSONNELNUMBER, ' ', SUBSTRING(TRIM(sh.FullName), LENGTH(TRIM(sh.FullName)) - POSITION(' ' IN REVERSE(TRIM(sh.FullName))) + 2)) AS Personnel,
            COALESCE(com.OBJ_DESC, com2.OBJ_DESC, sh.Command) AS Command,
            COALESCE(dept.OBJ_DESC, dept2.OBJ_DESC, sh.Department) AS Department,
            COALESCE(loc.OBJ_DESC, loc2.OBJ_DESC, sh.Location) AS Location,
            COALESCE(unit.OBJ_DESC, unit2.OBJ_DESC, sh.Unit) AS Unit,
            COALESCE(sec.OBJ_DESC, sec2.OBJ_DESC, sh.Section) AS Section,
            COALESCE(pa9046.TEMP_RANK_DESC, 
                CASE
                    WHEN rl.Role LIKE '%TSA%' AND rl.Role NOT LIKE '%CTSA%' THEN
                        CASE 
                            WHEN t503t.PTEXT = 'Sergeant' AND (rl.Role LIKE '%Insp%' OR rl.Role LIKE '%Inspector%') THEN 'Inspector'
                            WHEN t503t.PTEXT = 'Det Sergeant' AND (rl.Role LIKE '%DI%' OR rl.Role LIKE '%Insp%' OR rl.Role LIKE '%Inspector%') THEN 'Det Inspector'
                            WHEN t503t.PTEXT = 'Det Constable' AND (rl.Role LIKE '%DS%' OR rl.Role LIKE '%SGT%' OR rl.Role LIKE '%Sergeant%') THEN 'Det Sergeant'
                            WHEN t503t.PTEXT = 'Constable' AND (rl.Role LIKE '%PS%' OR rl.Role LIKE '%SGT%' OR rl.Role LIKE '%Sergeant%') THEN 'Sergeant'
                            WHEN t503t.PTEXT = 'Constable' AND rl.Role LIKE '%DS%' THEN 'Det Sergeant'
                        END
                    WHEN COALESCE(sec.OBJ_DESC, sec2.OBJ_DESC, sh.Section) LIKE '%Insp%' THEN 'Inspector'
                    WHEN COALESCE(sec.OBJ_DESC, sec2.OBJ_DESC, sh.Section) LIKE '%DI%' THEN 'Det Inspector'
                    WHEN COALESCE(sec.OBJ_DESC, sec2.OBJ_DESC, sh.Section) LIKE '%SGT%' OR COALESCE(sec.OBJ_DESC, sec2.OBJ_DESC, sh.Section) LIKE '%Sergeant%' THEN 'Sergeant'
                    WHEN COALESCE(sec.OBJ_DESC, sec2.OBJ_DESC, sh.Section) LIKE '%DS%' THEN 'Det Sergeant'
                END,
                t503t.PTEXT) AS Rank,
            CASE
                WHEN REVERSE(tmp4.Planned_Shift) LIKE '%-%' THEN 
                    CONCAT(SUBSTRING(tmp4.Planned_Shift, 1, 5), ' - ', SUBSTRING(tmp4.Planned_Shift, 7, 5))
                ELSE tmp4.Planned_Shift 
            END AS Planned_Shift_Detail,
            CASE 
                WHEN tmp4.Planned_Shift = 'Rest day' AND tmp4.Actual_Shift = 'Priority Tasking Day' THEN 'Rest day'
                WHEN tmp4.Planned_Shift = 'Non-working day' AND tmp4.Actual_Shift = 'Priority Tasking Day' THEN 'Non-working day'
                WHEN REVERSE(tmp4.Actual_Shift) LIKE '%-%' THEN 
                    CONCAT(SUBSTRING(tmp4.Actual_Shift, 1, 5), ' - ', SUBSTRING(tmp4.Actual_Shift, 7, 5))
                ELSE tmp4.Actual_Shift
            END AS Actual_Shift_Detail,
            rl.Role,
            CASE WHEN rl.Role LIKE '%TSA%' AND rl.Role NOT LIKE '%CTSA%' THEN 'TSA' ELSE NULL END AS TSA,
            CAST(pa0008.BSGRD / 100.0 AS DECIMAL(3,2)) AS FTE,
            tmp4.Hrs,
            rl.OA_RECORDID
    
        FROM tmp_tbl_d_staffing_report_04 tmp4
        LEFT JOIN rprt.tbl_d_staff_history rl ON rl.PERSONNELNUMBER = tmp4.PERSONNELNUMBER AND tmp4.Date BETWEEN rl.StartDate AND rl.EndDate
        LEFT JOIN rprt.tbl_d_staff_history sh ON sh.PERSONNELNUMBER = tmp4.PERSONNELNUMBER AND tmp4.Date BETWEEN sh.StartDate AND sh.EndDate
        LEFT JOIN temp_sap_pa0001 pa0001 ON pa0001.PERSONNEL_NUMBER = tmp4.PERSONNELNUMBER AND tmp4.Date BETWEEN pa0001.START_DATE AND pa0001.END_DATE
        LEFT JOIN temp_sap_t503t t503t ON t503t.PERSK = pa0001.EE_SUBGROUP
        LEFT JOIN temp_sap_pa9046 pa9046 ON pa9046.PERSONNEL_NUMBER = tmp4.PERSONNELNUMBER AND tmp4.Date BETWEEN pa9046.TEMP_START_DATE AND pa9046.TEMP_END_DATE
        LEFT JOIN temp_sap_hrp1000 sec ON sec.OBJ_ID = pa9046.TEMP_SECTION AND tmp4.Date BETWEEN sec.START_DATE AND sec.END_DATE AND sec.OBJ_TYPE IN ('S', 'BA', 'C', 'O', 'L')
        LEFT JOIN temp_sap_hrp1001 lkpunit ON lkpunit.OBJ_ID = sec.OBJ_ID AND tmp4.Date BETWEEN lkpunit.START_DATE AND lkpunit.END_DATE AND lkpunit.OBJ_TYPE IN ('S', 'BA','C', 'O', 'L')
        LEFT JOIN temp_sap_hrp1000 unit ON unit.OBJ_ID = lkpunit.ID_OF_RELATED_OBJ AND tmp4.Date BETWEEN unit.START_DATE AND unit.END_DATE AND unit.OBJ_TYPE IN ('S', 'BA', 'C', 'O', 'L')
        LEFT JOIN temp_sap_hrp1001 lkploc ON lkploc.OBJ_ID = unit.OBJ_ID AND tmp4.Date BETWEEN lkploc.START_DATE AND lkploc.END_DATE AND lkploc.OBJ_TYPE IN ('S', 'BA','C', 'O', 'L')
        LEFT JOIN temp_sap_hrp1000 loc ON loc.OBJ_ID = lkploc.ID_OF_RELATED_OBJ AND tmp4.Date BETWEEN loc.START_DATE AND loc.END_DATE AND loc.OBJ_TYPE IN ('S', 'BA', 'C', 'O', 'L')
        LEFT JOIN temp_sap_hrp1001 lkpdept ON lkpdept.OBJ_ID = loc.OBJ_ID AND tmp4.Date BETWEEN lkpdept.START_DATE AND lkpdept.END_DATE AND lkpdept.OBJ_TYPE IN ('S', 'BA','C', 'O', 'L')
        LEFT JOIN temp_sap_hrp1000 dept ON dept.OBJ_ID = lkpdept.ID_OF_RELATED_OBJ AND tmp4.Date BETWEEN dept.START_DATE AND dept.END_DATE AND dept.OBJ_TYPE IN ('S', 'BA', 'C', 'O', 'L')
        LEFT JOIN temp_sap_hrp1001 lkpcom ON lkpcom.OBJ_ID = dept.OBJ_ID AND tmp4.Date BETWEEN lkpcom.START_DATE AND lkpcom.END_DATE AND lkpcom.OBJ_TYPE IN ('S', 'BA','C', 'O', 'L')
        LEFT JOIN temp_sap_hrp1000 com ON com.OBJ_ID = lkpcom.ID_OF_RELATED_OBJ AND tmp4.Date BETWEEN com.START_DATE AND com.END_DATE AND com.OBJ_TYPE IN ('S', 'BA', 'C', 'O', 'L')
    	LEFT JOIN temp_sap_pa0008 pa0008 ON pa0008.PERNR = tmp4.PERSONNELNUMBER AND tmp4.Date BETWEEN CAST(TO_DATE(CAST(pa0008.BEGDA AS STRING), 'yyyyMMdd') AS DATE) 
          AND CAST(TO_DATE(CAST(pa0008.ENDDA AS STRING), 'yyyyMMdd') AS DATE)    
    	  LEFT JOIN temp_sap_hrp1001_tempAssignment lkpsec2 ON lkpsec2.ID_OF_RELATED_OBJ = tmp4.PERSONNELNUMBER AND tmp4.Date BETWEEN lkpsec2.START_DATE AND lkpsec2.END_DATE
        LEFT JOIN temp_sap_hrp1000 sec2 ON sec2.OBJ_ID = lkpsec2.OBJ_ID AND tmp4.Date BETWEEN sec2.START_DATE AND sec2.END_DATE AND sec2.OBJ_TYPE IN ('S', 'BA', 'C', 'O', 'L')
        LEFT JOIN temp_sap_hrp1001 lkpunit2 ON lkpunit2.OBJ_ID = sec2.OBJ_ID AND tmp4.Date BETWEEN lkpunit2.START_DATE AND lkpunit2.END_DATE AND lkpunit2.OBJ_TYPE IN ('S', 'BA','C', 'O', 'L')
        LEFT JOIN temp_sap_hrp1000 unit2 ON unit2.OBJ_ID = lkpunit2.ID_OF_RELATED_OBJ AND tmp4.Date BETWEEN unit2.START_DATE AND unit2.END_DATE AND unit2.OBJ_TYPE IN ('S', 'BA', 'C', 'O', 'L')
        LEFT JOIN temp_sap_hrp1001 lkploc2 ON lkploc2.OBJ_ID = unit2.OBJ_ID AND tmp4.Date BETWEEN lkploc2.START_DATE AND lkploc2.END_DATE AND lkploc2.OBJ_TYPE IN ('S', 'BA','C', 'O', 'L')
        LEFT JOIN temp_sap_hrp1000 loc2 ON loc2.OBJ_ID = lkploc2.ID_OF_RELATED_OBJ AND tmp4.Date BETWEEN loc2.START_DATE AND loc2.END_DATE AND loc2.OBJ_TYPE IN ('S', 'BA', 'C', 'O', 'L')
        LEFT JOIN temp_sap_hrp1001 lkpdept2 ON lkpdept2.OBJ_ID = loc2.OBJ_ID AND tmp4.Date BETWEEN lkpdept2.START_DATE AND lkpdept2.END_DATE AND lkpdept2.OBJ_TYPE IN ('S', 'BA','C', 'O', 'L')
        LEFT JOIN temp_sap_hrp1000 dept2 ON dept2.OBJ_ID = lkpdept2.ID_OF_RELATED_OBJ AND tmp4.Date BETWEEN dept2.START_DATE AND dept2.END_DATE AND dept2.OBJ_TYPE IN ('S', 'BA', 'C', 'O', 'L')
        LEFT JOIN temp_sap_hrp1001 lkpcom2 ON lkpcom2.OBJ_ID = dept2.OBJ_ID AND tmp4.Date BETWEEN lkpcom2.START_DATE AND lkpcom2.END_DATE AND lkpcom2.OBJ_TYPE IN ('S', 'BA','C', 'O', 'L')
        LEFT JOIN temp_sap_hrp1000 com2 ON com2.OBJ_ID = lkpcom2.ID_OF_RELATED_OBJ AND tmp4.Date BETWEEN com2.START_DATE AND com2.END_DATE AND com2.OBJ_TYPE IN ('S', 'BA', 'C', 'O', 'L')
        
        WHERE sh.STAFF_MOVE_ID IS NOT NULL
    )
    -- select * from tmp_tbl_d_staffing_report_05 limit 5;
    
    ,tmp_tbl_d_staffing_report_06 AS (
        SELECT
            tmp5.Date,
            tmp5.PERSONNELNUMBER,
            tmp5.Name,
            tmp5.Personnel,
            tmp5.Command,
            tmp5.Department,
            tmp5.Location,
            tmp5.Unit,
            tmp5.Section,
            tmp5.role,
            tmp5.TSA,
            tmp5.Rank,
            CASE
                WHEN tmp5.Rank IN ('Asst Chief Constable', 'Tmp Asst Chief Const') THEN 'ACC'
                WHEN tmp5.Rank = 'Agency Staff' THEN 'Agency'
                WHEN tmp5.Rank = 'Ast Chief Officer' THEN 'Ast Ch Officer'
                WHEN tmp5.Rank = 'Casual' THEN 'Casual'
                WHEN tmp5.Rank = 'Chief Constable' THEN 'CC'
                WHEN tmp5.Rank IN ('Tmp Det Chief Insp', 'Det Chief Inspector', 'Tmp Chief Inspector', 'Chief Inspector') THEN 'Ch Insp'
                WHEN tmp5.Rank = 'Chief Officer' THEN 'Chief Officer'
                WHEN tmp5.Rank IN ('Det Chief Super.', 'Tmp Chief Super.', 'Tmp Det Chief Super.', 'Chief Superintendent') THEN 'Ch Supt'
                WHEN tmp5.Rank = 'Childs' THEN 'Childs'
                WHEN tmp5.Rank IN ('Det Constable', 'Constable') THEN 'Constable'
                WHEN tmp5.Rank = 'Contractors' THEN 'Contractors'
                WHEN tmp5.Rank = 'Credit Members' THEN 'Credit Members'
                WHEN tmp5.Rank IN ('Dep Chief Constable', 'Tmp Dep Chief Const.') THEN 'DCC'
                WHEN tmp5.Rank = 'Deferred Payment' THEN 'Deferred Payment'
                WHEN tmp5.Rank = 'Deputy Chief Officer' THEN 'Dep Chief Officer'
                WHEN tmp5.Rank = 'Ill-Health' THEN 'Ill Health'
                WHEN tmp5.Rank IN ('Tmp Inspector', 'Inspector', 'Tmp Det Inspector', 'Det Inspector') THEN 'Insp'
                WHEN tmp5.Rank = 'Ordinary' THEN 'Ordinary'
                WHEN tmp5.Rank = 'Others - Volunteers' THEN 'Others - Volunteers'
                WHEN tmp5.Rank = 'PCSO Essex' THEN 'PCSO'
                WHEN tmp5.Rank = 'Probationer' THEN 'Constable'
                WHEN tmp5.Rank IN ('Det Sergeant', 'Tmp Sergeant', 'Tmp Det Sergeant', 'Sergeant') THEN 'Sergeant'
                WHEN tmp5.Rank IN ('Special Chief Insp', 'Special Supt.', 'Tmp Spec Chief Insp', 'Special Sergeant', 'Tmp Spec Sergeant', 'Special Inspector', 'Special Constable', 'Tmp Spec Inspector') THEN 'Special'
                WHEN tmp5.Rank = 'Police Staff Essex' THEN 'Staff'
                WHEN tmp5.Rank = 'Student Constable' THEN 'Constable'
                WHEN tmp5.Rank IN ('Det Superintendent', 'Superintendent', 'Tmp Superintendent', 'Tmp Det Super.') THEN 'Supt'
                WHEN tmp5.Rank = 'Widowers' THEN 'Widowers' 
                ELSE tmp5.Rank
            END AS Group_Rank,
            tmp5.Planned_Shift_Detail,
            tmp5.Actual_Shift_Detail,
            CASE 
                WHEN tmp5.Actual_Shift_Detail = 'Public Hol' THEN NULL
                WHEN tmp5.Actual_Shift_Detail LIKE '%flexi%' THEN 'Flexi'
                WHEN tmp5.Actual_Shift_Detail = 'Flex Duty' THEN 'Flex Duty'
                WHEN tmp5.Actual_Shift_Detail = 'Rest day' THEN 'Rest day'
                WHEN tmp5.Hrs > 4 AND (tmp5.Section LIKE '%CAIT%' OR tmp5.Section LIKE '%DART%' OR tmp5.Section LIKE '%SCIU%') THEN 
                    CASE 
                        WHEN CAST(SUBSTRING(tmp5.Actual_Shift_Detail, 1, 2) AS INT) <= 10 THEN 'Day' 
                        WHEN CAST(SUBSTRING(tmp5.Actual_Shift_Detail, 1, 2) AS INT) < 22 THEN 'Late'
                        ELSE 'Night' 
                    END
                WHEN tmp5.Hrs > 4 AND (tmp5.Unit LIKE '%Reactive CID%' OR tmp5.Section LIKE '%DAIT%' OR tmp5.Section LIKE '%ASAIT%' OR tmp5.Unit LIKE '%MOSOVO%' OR tmp5.Unit LIKE '%Proactive orders%' OR tmp5.Unit LIKE '%MIR%' OR tmp5.Unit LIKE '%Border policing%') THEN
                    CASE 
                        WHEN CAST(SUBSTRING(tmp5.Actual_Shift_Detail, 1, 2) AS INT) <= 10 THEN 'Day' 
                        WHEN CAST(SUBSTRING(tmp5.Actual_Shift_Detail, 1, 2) AS INT) < 22 THEN 'Late'
                        ELSE 'Night' 
                    END
                WHEN tmp5.Hrs > 4 AND tmp5.Department LIKE '%Custody%' THEN
                    CASE 
                        WHEN CAST(SUBSTRING(tmp5.Actual_Shift_Detail, 1, 2) AS INT) <= 10 THEN 'Early' 
                        WHEN CAST(SUBSTRING(tmp5.Actual_Shift_Detail, 1, 2) AS INT) <= 16 THEN 'Late' 
                        ELSE 'Night' 
                    END
                WHEN tmp5.Hrs > 4 AND tmp5.Department LIKE '%Roads policing%' THEN
                    CASE 
                        WHEN CAST(SUBSTRING(tmp5.Actual_Shift_Detail, 1, 2) AS INT) <= 8 THEN 'Early' 
                        WHEN CAST(SUBSTRING(tmp5.Actual_Shift_Detail, 1, 2) AS INT) <= 10 THEN 'Day' 
                        WHEN CAST(SUBSTRING(tmp5.Actual_Shift_Detail, 1, 2) AS INT) <= 16 THEN 'Late'
                        ELSE 'Night' 
                    END
                WHEN tmp5.Hrs > 4 AND tmp5.Command LIKE '%Local Policing Area%' THEN
                    CASE 
                        WHEN CAST(SUBSTRING(tmp5.Actual_Shift_Detail, 1, 2) AS INT) <= 10 THEN 'Early' 
                        WHEN CAST(SUBSTRING(tmp5.Actual_Shift_Detail, 1, 2) AS INT) <= 17 THEN 'Late'
                        ELSE 'Night' 
                    END
                WHEN tmp5.Hrs > 4 AND tmp5.Command LIKE '%ERSOU%' AND tmp5.Section = 'Stansted Airport' AND tmp5.role LIKE '%SB%' THEN
                    CASE 
                        WHEN CAST(SUBSTRING(tmp5.Actual_Shift_Detail, 1, 2) AS INT) <= 10 THEN 'Early' 
                        ELSE 'Late' 
                    END
                WHEN tmp5.Hrs > 4 AND tmp5.Command LIKE '%ERSOU%' AND (tmp5.Section = 'Harwich Port' OR tmp5.Section = 'Southend Port') AND tmp5.role LIKE '%SB%' THEN
                    CASE 
                        WHEN CAST(SUBSTRING(tmp5.Actual_Shift_Detail, 1, 2) AS INT) <= 10 THEN 'Day' 
                        ELSE 'Late' 
                    END
                WHEN tmp5.Hrs > 4 THEN
                    CASE 
                        WHEN CAST(SUBSTRING(tmp5.Actual_Shift_Detail, 1, 2) AS INT) <= 10 THEN 'Early' 
                        WHEN CAST(SUBSTRING(tmp5.Actual_Shift_Detail, 1, 2) AS INT) <= 16 THEN 'Late' 
                        WHEN CAST(SUBSTRING(tmp5.Actual_Shift_Detail, 1, 2) AS INT) <= 19 THEN 'Half Night'
                        ELSE 'Night' 
                    END
                ELSE NULL 
            END AS Shift_Type,
            tmp5.FTE,
    
            COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW,
            CURRENT_TIMESTAMP() AS OA_REC_PROCESSED_DATE_NEW,
            CASE WHEN tmp5.PERSONNELNUMBER = v.PERSONNELNUMBER THEN v.min_createdDate ELSE CURRENT_TIMESTAMP() END OA_REC_CREATED_DATE,
            tmp5.OA_RECORDID
    
        FROM tmp_tbl_d_staffing_report_05 tmp5
            LEFT JOIN version_data v ON tmp5.PERSONNELNUMBER = v.PERSONNELNUMBER
    )
    -- select * from tmp_tbl_d_staffing_report_06 limit 5;
    
    ,distinctrows AS (
        SELECT DISTINCT * FROM tmp_tbl_d_staffing_report_06
    ),
    
    source_data AS (
        SELECT 
            dr.Date,
            dr.PERSONNELNUMBER,
            dr.Name,
            dr.Personnel,
            dr.Command,
            dr.Department,
            dr.Location,
            dr.Unit,
            dr.Section,
            dr.role,
            dr.TSA,
            dr.Rank,
            dr.Group_Rank,
            dr.Planned_Shift_Detail,
            CONCAT_WS(', ', COLLECT_LIST(dr.Actual_Shift_Detail)) AS Actual_Shift_Detail,
            CASE 
                WHEN CONCAT_WS(', ', COLLECT_LIST(dr.Actual_Shift_Detail)) LIKE '%Priority Tasking Day%' THEN 'Priority Tasking Day'  
                WHEN CONCAT_WS(', ', COLLECT_LIST(COALESCE(dr.Shift_Type, 'NULL'))) LIKE '%NULL%' THEN NULL 
                ELSE CONCAT_WS(', ', COLLECT_LIST(dr.Shift_Type)) 
            END AS Shift_Type,
            dr.FTE,
            dr.OA_VERSION_NEW,
            dr.OA_REC_PROCESSED_DATE_NEW,
            dr.OA_REC_CREATED_DATE,
            dr.OA_RECORDID
    
        FROM distinctrows dr
        GROUP BY 
            dr.Date,
            dr.PersonnelNumber,
            dr.Name,
            dr.Personnel,
            dr.Command,
            dr.Department,
            dr.Location,
            dr.Unit,
            dr.Section,
            dr.role,
            dr.TSA,
            dr.Rank,
            dr.Group_Rank,
            dr.Planned_Shift_Detail,
            dr.FTE,
            dr.OA_VERSION_NEW,
            dr.OA_REC_PROCESSED_DATE_NEW,
            dr.OA_REC_CREATED_DATE,
            dr.OA_RECORDID
    
    )
    
    -- select * from source_data
                -- Main MERGE statement
                     MERGE INTO rprt.tbl_f_staffing_report AS tgt
                     USING source_data AS src
                     ON tgt.PERSONNELNUMBER = src.PersonnelNumber AND tgt.OA_IS_ACTIVE = 1
    
                     WHEN MATCHED AND tgt.OA_RECORDID <> src.OA_RECORDID THEN
                         UPDATE SET tgt.OA_IS_ACTIVE = 0, tgt.OA_REC_END_DATE = src.OA_REC_CREATED_DATE, tgt.OA_REC_PROCESSED_DATE = src.OA_REC_CREATED_DATE
    
                     WHEN NOT MATCHED THEN
                         INSERT(DATE,PERSONNELNUMBER,NAME,PERSONNEL,COMMAND,DEPARTMENT,LOCATION,UNIT,SECTION,ROLE,TSA,RANK,GROUP_RANK,PLANNED_SHIFT_DETAIL,ACTUAL_SHIFT_DETAIL,SHIFT_TYPE, FTE, 
                         OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)   	
    
                         VALUES(src.DATE, src.PERSONNELNUMBER, src.NAME, src.PERSONNEL, src.COMMAND, src.DEPARTMENT, src.LOCATION, src.UNIT, src.SECTION, src.ROLE, src.TSA, src.RANK, src.GROUP_RANK, src.PLANNED_SHIFT_DETAIL, 
                         src.ACTUAL_SHIFT_DETAIL, src.SHIFT_TYPE, src.FTE, src.OA_REC_PROCESSED_DATE_NEW, src.OA_REC_CREATED_DATE, TO_TIMESTAMP('9999-12-31'), 1,src.OA_VERSION_NEW,src.OA_RECORDID)
    
"""),

])


																					# =========================
																					# OPERATIONAL PLANNING
																					# =========================


run_parallel_queries_gold([		
# rprt.tbl_f_operational_planning
("rprt.tbl_f_operational_planning",
    """WITH version_data AS(SELECT OPCId AS OPCId, MAX(OA_VERSION) AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate  FROM rprt.tbl_f_operational_planning GROUP BY OPCId),
			RankedEvents AS (
				SELECT
					ev.dbId,
					ev.startDate AS Start_Date,
					ev.ENDDATE AS End_Date,			
					DATEDIFF(day, ev.startDate, ev.endDate)+1 AS Duration,
					ut.title AS Demand_Type,
					ev.title AS Operation,
					CASE 
						WHEN ev.sensitive = 'True' THEN 'REMOVED (SENSITIVE INFORMATION)'
						WHEN ev.sensitive = 'False' THEN ev.description 
					END AS Description,
					ev.sensitive AS Sensitive,
					ut.code AS Code,
					ev.status AS Status,			
					colour.title AS Colour,
					ROW_NUMBER() OVER (PARTITION BY ev.dbId ORDER BY CASE WHEN ut.code = 'DEMAND' THEN 1 ELSE 2 END) AS rn
						
					,COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW
					,CURRENT_TIMESTAMP() AS OA_REC_PROCESSED_DATE_NEW
					,CASE WHEN ev.dbId = v.OPCId THEN v.min_createdDate ELSE CURRENT_TIMESTAMP() END OA_REC_CREATED_DATE
					,ev.OA_RECORDID
			
			
				FROM temp_operationalPlanningCalendar_opc_event ev
				LEFT JOIN version_data v ON ev.dbId = v.OPCId
				LEFT JOIN temp_operationalPlanningCalendar_util_cv ut ON ev.policingDemand_id = ut.id
				LEFT JOIN temp_operationalPlanningCalendar_util_cv colour ON colour.sortOrder = ut.sortOrder AND colour.code = 'DEMAND_COLOUR'			
			), 	    
			source_data AS(SELECT dbId AS OPCID, START_DATE, END_DATE, DURATION, DEMAND_TYPE, OPERATION, DESCRIPTION, SENSITIVE, CODE, STATUS, COLOUR, OA_REC_PROCESSED_DATE_NEW, OA_REC_CREATED_DATE, OA_VERSION_NEW, OA_RECORDID			
			FROM RankedEvents
			WHERE rn = 1 		
			)

            -- Main MERGE statement
                 MERGE INTO rprt.tbl_f_operational_planning AS tgt
                 USING source_data AS src
                 ON tgt.OPCId = src.OPCId AND tgt.OA_IS_ACTIVE = 1

                 WHEN MATCHED AND tgt.OA_RECORDID <> src.OA_RECORDID THEN
                     UPDATE SET tgt.OA_IS_ACTIVE = 0, tgt.OA_REC_END_DATE = src.OA_REC_CREATED_DATE, tgt.OA_REC_PROCESSED_DATE = src.OA_REC_CREATED_DATE

                 WHEN NOT MATCHED THEN
                     INSERT(OPCID, START_DATE, END_DATE, DURATION, DEMAND_TYPE, OPERATION, DESCRIPTION, SENSITIVE, CODE, STATUS, COLOUR, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)   	
                     VALUES( src.OPCID, src.START_DATE, src.END_DATE, src.DURATION, src.DEMAND_TYPE, src.OPERATION, src.DESCRIPTION, src.SENSITIVE, src.CODE, src.STATUS, src.COLOUR, 
                     src.OA_REC_PROCESSED_DATE_NEW, src.OA_REC_CREATED_DATE, TO_TIMESTAMP('9999-12-31'), 1,src.OA_VERSION_NEW,src.OA_RECORDID)    
    """),

])


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### LOGGING

# CELL ********************

# finalise_notebook_logging()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
