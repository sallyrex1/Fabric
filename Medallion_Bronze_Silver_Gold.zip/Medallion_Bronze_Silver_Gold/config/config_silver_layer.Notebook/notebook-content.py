# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# MARKDOWN ********************

# # 🟦 SILVER LAYER CONFIGURATION


# CELL ********************

print("-=- STARTING CONFIG FOR SILVER LAYER -=-")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import col
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor as tpe
import notebookutils
import time
import json

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
spark.conf.set("spark.sql.parquet.DATETIME2RebaseModeInWrite", "LEGACY")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "LEGACY")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "LEGACY")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "LEGACY")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Parameterised in pipeline
try:
    p_workSpace = p_workSpace
    p_accountName = p_accountName
    p_relativeBRONZEPath = p_relativeBRONZEPath
    p_todaysFile = p_todaysFile
    
    print(f"✅ Parameters received from pipeline")
    
except:
    p_workSpace = "a3e4d0e6-6b32-498b-addc-1629a4b29a47"
    p_accountName = "onelake"
    p_relativeBRONZEPath = "62139ac1-f383-41dc-b7a5-64655894ccd2/Files"  
    # today = datetime.today()
    # p_todaysFile = today.strftime("Year_%Y/Month_%m/Day_%d")
    p_todaysFile = "Year_2025/Month_11/Day_03"

    print(f"⚠ Using default parameters")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# PARAMETERS CELL ********************

#Variables in pipeline
try:
    v_workSpaceName = notebookutils.variableLibrary.get("$(/**/vl_medallion/v_workspaceName)")
    v_accountName = notebookutils.variableLibrary.get("$(/**/vl_medallion/v_accountName)")
    v_relativeBronzePath = notebookutils.variableLibrary.get("$(/**/vl_medallion/v_relativeBronzePath)")
    v_todaysFile = "Year_2025/Month_11/Day_03"
    p_current_domain = globals().get("p_current_domain", "STATIC,SAP,Bail,Essex_STORM,Athena_A4E,operationalPlanningCalendar,P_HOLDER_2") #added operationalPlanningCalendar

    print(f"✅ Varialbes from Library")
    
except:
    v_workSpaceName = "a3e4d0e6-6b32-498b-addc-1629a4b29a47"
    v_accountName = "onelake"
    v_relativeBronzePath = "62139ac1-f383-41dc-b7a5-64655894ccd2/Files"  
    # today = datetime.today()
    # p_todaysFile = today.strftime("Year_%Y/Month_%m/Day_%d")
    v_todaysFile = "Year_2025/Month_11/Day_03"

    print(f"⚠ Using default parameters")

# print("✅ Variable loaded:")
# print(f"Workspace: {v_workSpaceName}")
# print(f"accountName: {v_accountName}")
# print(f"relativeBronzePath: {v_relativeBronzePath}")
# print(f"todaysFile: {p_todaysFile}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# pr
db_bronzePath = f"abfss://{p_workSpaceName}@{p_accountName}.dfs.fabric.microsoft.com/{p_relativeBRONZEPath}/bronze"
print(f"db_bronzePath: {db_bronzePath}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

# vl
db_bronzePath = f"abfss://{v_workSpaceName}@{v_accountName}.dfs.fabric.microsoft.com/{v_relativeBronzePath}/bronze"
print(f"db_bronzePath: {db_bronzePath}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

try:
    db_bronzeFolder = json.loads(p_current_domain)   #p_db_bronzeFolder - p_current_domain, replaced 1st with 2nd
except:
    db_bronzeFolder = ["SAP","Athena_A4E", "Essex_STORM", "Bail", "operationalPlanningCalendar"]
 
# print(f"db_bronzeFolder: {db_bronzeFolder}")
# print(p_todaysFile)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Create Bronze file path
db_bronzeFile_Path = [f"{db_bronzePath}/{path}/{v_todaysFile}" for path in db_bronzeFolder]
# print(f"db_bronzeFile_Path: {db_bronzeFile_Path}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Define domain-specific bronze file paths
db_bronzeFile_Paths = {
    "SAP": [f"{db_bronzePath}/SAP/{v_todaysFile}"],
    "Bail": [f"{db_bronzePath}/Bail/{v_todaysFile}"],
    "Essex_STORM": [f"{db_bronzePath}/Essex_STORM/{v_todaysFile}"],
    "Athena_A4E": [f"{db_bronzePath}/Athena_A4E/{v_todaysFile}"],
    "operationalPlanningCalendar": [f"{db_bronzePath}/operationalPlanningCalendar/{v_todaysFile}"]
}
# print(f"db_bronzeFile_Paths: {db_bronzeFile_Paths}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# list all files in domain 
for fileList in db_bronzeFile_Path:
    print(fileList)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

def createTable(createtable):
    for tableName, sql in createtable:
        if spark.catalog.tableExists(tableName):
            print(f" 🕑 Skilpping .... Table {tableName} Exit Already")
        else:
            try:
                print(f"🕑 Creating Table... -=- {tableName} -=-")
                spark.sql(sql)
                print(f"✅ {tableName} -=- Created Successfully\n")
                # print("-=- Table Creation Completed -=-")
            except Exception as e:
                print(f"❌ Table {tableName} Creation FAILED !\n {str(e)}")
                # print("-=- Table Creation Completed With Error-=-")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def run_parallel_queries_silver(query_list, max_workers=10): #workerload can be adjusted for now it is 10
    def run_safe_query(name, sql, show_output=False):
        try:
            if show_output:
                start_time = time.time()
                print(f"🕑 Starting: {name} ....")
            
            # Execute the SQL
            spark.sql(sql)
            
            if show_output:
                # Get record count after loading
                count_sql = f"SELECT COUNT(*) FROM {name}"
                count = spark.sql(count_sql).first()[0]
                duration = time.time() - start_time
                print(f"✅ Success: {name} ({duration:.1f}s)")
                return True, show_output, count
            
            return True, show_output, 0
        except Exception as e:
            if show_output:
                duration = time.time() - start_time
                print(f"❌ Failed: {name} - {str(e)}")
            return False, show_output, 0

    # Execute with concurrent workers
    with tpe(max_workers=max_workers) as executor:
        futures = {
            executor.submit(run_safe_query, name, sql, show_output): name
            for name, sql, show_output in query_list
        }
        
        results = {
            futures[future]: future.result()
            for future in futures
        }
    
    # Print final summary
    print("\n=== LOAD RESULTS ===")
    for name, (success, show_output, count) in results.items():
        if show_output:
            print(f"{name}: {'SUCCESS' if success else 'FAILED'}: {count} Records")
    # print("\nALL QUERIES COMPLETED")
    
    return results



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def create_temp_views_by_domain(domain_paths_dict, domain_keys):
    if isinstance(domain_keys, str):
        domain_keys = [domain_keys]  # Convert single string to list

    for domain_key in domain_keys:
        if domain_key not in domain_paths_dict:
            print(f"❌ Domain '{domain_key}' not found in provided paths.")
            continue

        paths = domain_paths_dict[domain_key]

        for path in paths:
            try:
                if not mssparkutils.fs.exists(path):
                    print(f"⚠️ Path does not exist: {path}")
                    continue

                parquetFiles = [f.path for f in mssparkutils.fs.ls(path) if f.name.endswith(".parquet")]
                if not parquetFiles:
                    print(f"⚠️ No parquet files found in {path}")
                    continue

                for filePath in parquetFiles:
                    try:
                        tableName = filePath.split("/")[-1].replace(".parquet", "").rsplit("_2")[0]
                        df = spark.read.parquet(filePath)
                        df.createOrReplaceTempView(f"temp_{tableName}")
                        print(f"✅ Created temp view: temp_{tableName} -=- {df.count()} Records")
                    except Exception as e:
                        print(f"❌ Error processing file {filePath}: {str(e)}")
            except Exception as e:
                print(f"❌ Error accessing path {path}: {str(e)}")

# print("Temp Tables completed")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def run_sql_static_statement(sqlstatement: list):
    for table_name, sql in sqlstatement:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        try:
            spark.sql(sql)
            print(f"{table_name}, Completed Successfully -=- {now}")
        except Exception as e:
            print(f"{table_name}, Failed -=- {now}")
            print(f"Error: {str(e)}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def logProgress (domain, step, message, status = "INFO"):
    log_entry = {
        "timestamp": __import__ ('datetime').datetime.now().isoformat(),
        "domain":domain,
        "step": step,
        "message": message,
        "status" : status
    }

    print(json.dumps(log_entry))
    return log_entry

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### Logging

# CELL ********************

import logging
from pyspark.sql.utils import AnalysisException, ParseException

# Config_Notebook_Logger
notebook_name = "bail"
layer_type = "silver" 
run_id = mssparkutils.env.getJobId()
all_errors = []

# print(f"📝 Starting {layer_type.upper()} layer notebook: {notebook_name}")
# print(f"🏃 Run ID: {run_id}")

# Set up logging to capture errors
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()

class ErrorCaptureHandler(logging.Handler):
    def emit(self, record):
        if record.levelno >= logging.ERROR:
            all_errors.append(f"LOG_ERROR: {self.format(record)}")

# Add custom handler
error_handler = ErrorCaptureHandler()
error_handler.setLevel(logging.ERROR)
logger.addHandler(error_handler)

def capture_error(msg):
    """Capture error messages without stopping execution"""
    all_errors.append(msg)
    print(f"❌ CAPTURED ERROR: {msg}")
    logger.error(msg)

def capture_exception(e, context=""):
    """Capture exceptions with context"""
    error_msg = f"{context}: {str(e)}" if context else str(e)
    all_errors.append(error_msg)
    print(f"❌ CAPTURED EXCEPTION: {error_msg}")
    logger.error(error_msg)

def execute_sql_with_error_capture(sql_query, query_name=""):
    """
    Execute SQL and capture Spark analysis/parse errors
    """
    try:
        print(f"🔄 Executing SQL: {query_name}" if query_name else "🔄 Executing SQL")
        result = spark.sql(sql_query)
        
        # Check if the query was an INSERT/UPDATE that might have failed at execution time
        if sql_query.strip().upper().startswith(('INSERT', 'UPDATE', 'DELETE', 'CREATE', 'ALTER')):
            # For DML operations, we need to check if they actually succeeded
            # This is a workaround since Spark doesn't always raise exceptions for DML failures
            try:
                # Try to get some execution info
                spark.sparkContext.setLocalProperty("callSite.short", query_name)
            except:
                pass
                
        return result
        
    except (AnalysisException, ParseException) as e:
        # These are Spark SQL analysis/parse errors
        error_msg = f"SPARK_SQL_ERROR in {query_name}: {str(e)}" if query_name else f"SPARK_SQL_ERROR: {str(e)}"
        capture_error(error_msg)
        raise  # Re-raise to maintain normal behavior
    except Exception as e:
        # Other exceptions
        error_msg = f"EXECUTION_ERROR in {query_name}: {str(e)}" if query_name else f"EXECUTION_ERROR: {str(e)}"
        capture_exception(e, error_msg)
        raise

def execute_batch_operations(operations, batch_name="batch_operations", layer="generic"):
    """
    Execute multiple operations and capture individual failures
    """
    print(f"🔄 Executing {layer} batch: {batch_name} ({len(operations)} operations)")
    
    successful_ops = 0
    failed_ops = 0
    
    for i, operation in enumerate(operations, 1):
        op_name = f"{layer}_{batch_name}_op_{i}"
        
        try:
            # Execute the operation
            if callable(operation):
                operation()
            elif isinstance(operation, tuple) and len(operation) >= 2:
                # Handle (name, query, enabled) format
                query_name, query, enabled = operation[0], operation[1], operation[2] if len(operation) > 2 else True
                if enabled:
                    execute_sql_with_error_capture(query, query_name)
                else:
                    print(f"⏭️ Operation skipped (disabled): {query_name}")
                    successful_ops += 1
                    continue
            else:
                # Assume it's a Spark SQL query string
                execute_sql_with_error_capture(operation, op_name)
                
            successful_ops += 1
            print(f"✅ {layer.upper()} operation {i}/{len(operations)} completed: {op_name}")
            
        except Exception as e:
            failed_ops += 1
            # Error already captured in execute_sql_with_error_capture, just log the operation failure
            print(f"❌ {layer.upper()} operation {i}/{len(operations)} failed: {op_name}")
    
    print(f"📊 {layer.upper()} batch '{batch_name}' completed: {successful_ops} successful, {failed_ops} failed")
    
    if failed_ops > 0:
        return False
    return True

def create_monitoring_table_if_not_exists():
    """Create the monitoring table if it doesn't exist"""
    try:
#         # First create schema if it doesn't exist
        create_schema_sql = "CREATE SCHEMA IF NOT EXISTS ctrl"
        spark.sql(create_schema_sql)
        print("✅ Schema created/verified: ctlr")
        
        # Then create table
        create_table_sql = """
        CREATE TABLE IF NOT EXISTS ctrl.tbl_DWLoadLog (
            notebook_name STRING,
            layer_type STRING,
            status STRING,
            error_summary STRING,
            timestamp TIMESTAMP,
            run_id STRING
        )
        """
        spark.sql(create_table_sql)
        print("✅ Monitoring table created/verified: ctrl.tbl_DWLoadLog")
        
    except Exception as e:
        print(f"⚠️ Failed to create monitoring table: {str(e)}")
        capture_exception(e, "create_monitoring_table")

def finalise_notebook_logging():
    """Finalize logging and exit - call this at the END of your notebook"""
    print(f"🔍 Finalising {layer_type.upper()} layer notebook logging...")
    print(f"🔍 Total errors captured: {len(all_errors)}")
    print(f"🔍 All errors: {all_errors}")
    
    # Create table if it doesn't exist
    create_monitoring_table_if_not_exists()
    
    # Determine final status
    if any("CRASHED" in error for error in all_errors):
        status = "FAILED"
    elif all_errors:
        status = "COMPLETED_WITH_ERRORS"
    else:
        status = "SUCCESS"
        
    print(f"📋 Final status: {status}")
    
    # Create error summary
    error_summary = " | ".join(all_errors)[:2000] if all_errors else None
    
    # Log to monitoring table with layer information
    try:
        if error_summary:
            error_summary_escaped = error_summary.replace("'", "''")
            insert_sql = f"""
            INSERT INTO ctrl.tbl_DWLoadLog
            VALUES ('{notebook_name}', '{layer_type}', '{status}', '{error_summary_escaped}', CURRENT_TIMESTAMP, '{run_id}')
            """
        else:
            insert_sql = f"""
            INSERT INTO ctrl.tbl_DWLoadLog (notebook_name, layer_type, status, timestamp, run_id)
            VALUES ('{notebook_name}', '{layer_type}', '{status}', CURRENT_TIMESTAMP, '{run_id}')
            """
        
        spark.sql(insert_sql)
        print(f"✅ Logged {layer_type.upper()} notebook to tbl_DWLoadLog: {status}")
        
    except Exception as e:
        print(f"⚠️ Failed to write {layer_type.upper()} notebook log: {str(e)}")
        mssparkutils.notebook.exit("FAILED")
    
    # Exit for pipeline
    mssparkutils.notebook.exit(status)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"\n-=- CONFIG FOR SILVER LAYER COMPLETED -=-")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
