# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# MARKDOWN ********************

# # 🟨 GOLD LAYER CONFIGURATION

# CELL ********************

print("-=- STARTING CONFIG FOR GOLD LAYER -=-")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import notebookutils
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import col
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor as tpe
import time
import json

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Spark Configurations
spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
spark.conf.set("spark.sql.parquet.DATETIME2RebaseModeInWrite", "LEGACY")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "LEGACY")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "LEGACY")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "LEGACY")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

p_workSpace = globals().get("p_workSpace", "Fabric_SandBox")
p_accountName = globals().get("p_accountName", "onelake")
p_relativeSILVERPath = globals().get("p_relativeSILVERPath", "LH_200_Silver_Test.Lakehouse/Tables")
p_current_domain = globals().get("p_current_domain", "STATIC_GL,SAP,Bail,Essex_STORM,Athena_A4E,P_HOLDER_2")

print("✅ Parameters loaded:")
print(f"Workspace: {p_workSpace}")
print(f"Account Name: {p_accountName}")
print(f"Silver Path: {p_relativeSILVERPath}")
print(f"Domains: {p_current_domain}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# PARAMETERS CELL ********************

# Using VL 
v_workSpaceName = notebookutils.variableLibrary.get("$(/**/vl_medallion/v_workspaceName)")
v_accountName = notebookutils.variableLibrary.get("$(/**/vl_medallion/v_accountName)")
v_relativeSILVERPath = notebookutils.variableLibrary.get("$(/**/vl_medallion/v_relativeSILVERPath)")
# v_current_domain = notebookutils.variableLibrary.get("$(/**/vl_medallion/v_current_domain)")
p_current_domain = globals().get("p_current_domain", "STATIC_GL,SAP,Bail,Essex_STORM,Athena_A4E,P_HOLDER_2")


print("✅ Variable loaded:")
print(f"workSpaceName: {v_workSpaceName}")
print(f"accountName: {v_accountName}")
print(f"relativeSILVERPath: {v_relativeSILVERPath}")
# print(f"current_domain: {v_current_domain}")
print(f"current_domain: {p_current_domain}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# pr
silverPath = f"abfss://{p_workSpaceName}@{p_accountName}.dfs.fabric.microsoft.com/{p_relativeSILVERPath}"
print(f"📁 Silver Path: {silverPath}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

# vl
silverPath = f"abfss://{v_workSpaceName}@{v_accountName}.dfs.fabric.microsoft.com/{v_relativeSILVERPath}"
print(f"📁 Silver Path: {silverPath}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def createTable(createtable):
    for tableName, sql in createtable:
        if spark.catalog.tableExists(tableName):
            print(f" 🕑 Skipping .... Table {tableName} Exists Already")
        else:
            try:
                print(f"🕑 Creating Table... -=- {tableName} -=-")
                spark.sql(sql)
                print(f"✅ {tableName} -=- Created Successfully")
            except Exception as e:
                print(f"❌ Table {tableName} Creation FAILED!\n {str(e)}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def run_parallel_queries_gold(query_list, max_workers=10):
    def run_safe_query(name, sql):
        try:
            start_time = time.time()
            print(f"🏁 Starting: {name} ....")
            
            # Execute the SQL
            spark.sql(sql)
            
            # Get statistics
            stats_sql = f"""
                SELECT 
                    COUNT(*) as SuccessCount,
                    SUM(CASE WHEN OA_IS_ACTIVE = 1 AND OA_VERSION = 1 THEN 1 ELSE 0 END) as InsertedRows, 
                    SUM(CASE WHEN OA_IS_ACTIVE = 1 AND OA_VERSION > 1 THEN 1 ELSE 0 END) as UpdatedRows,
                    SUM(CASE WHEN OA_IS_ACTIVE = 1 AND OA_VERSION = 1 THEN 0 ELSE 0 END) as AffectedRows
                FROM {name}
            """
            
            stats = spark.sql(stats_sql).first()
            if stats is None:
                stats = (0, 0, 0, 0)
            
            duration = time.time() - start_time
            print(f"✅ Success: {name} ({duration:.1f}s)")
            return True, stats
        except Exception as e:
            duration = time.time() - start_time
            print(f"❌ Failed: {name} - {str(e)}")
            return False, (0, 0, 0, 0)

    # Execute with concurrent workers
    with tpe(max_workers=max_workers) as executor:
        futures = {
            executor.submit(run_safe_query, name, sql): name
            for name, sql in query_list
        }
        
        results = {
            futures[future]: future.result()
            for future in futures
        }
    
    # Print final summary
    print("\n=== LOAD RESULTS ===")
    for name, (success, stats) in results.items():
        if success:
            print(f"{name}: COMPLETED - SuccessCount: {stats[0]}, AffectedRows: {stats[1]}, UpdatedRows: {stats[2]}, InsertedRows: {stats[3]}")
        else:
            print(f"{name}: FAILED")
    print("\nALL QUERIES COMPLETED\n")
    
    return results

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def create_temp_views_by_domains(silverPath, domain):
    """Create temp views filtered by domain patterns"""
    print(f"🔄 Creating temp views for domain: {domain}")
    
    # Define domain patterns
    domain_patterns = {
        "Bail": ["tbl_bail", "bail_",  "athena_link_custody"],
        "SAP": ["sap_", "tbl_org", "tbl_staff_history", "operationalplanningcalendar_"],
        "Athena_A4E": ["tbl_", "athena_", "bail_custodyrecord"],
        "Essex_STORM": ["tbl_storm_", "tbl_incident", "tbl_personnel"],
        "Kent_STORM": ["tbl_storm_", "tbl_incident", "tbl_personnel"],
        "P_HOLDER_1": ["rprt.tbl_"],
        "P_HOLDER_2": ["rprt.tbl_"]
    }

    # Get patterns for current domain
    patterns = domain_patterns.get(domain, [])
    print(f"📊 Domain patterns: {patterns}")
    
    # Get all silver layer tables
    all_silver_tables = [files for files in notebookutils.fs.ls(silverPath)]
    
    # Filter tables based on domain patterns
    filtered_tables = []
    for file_info in all_silver_tables:
        table_name = file_info.name
        
        # Check if table matches any domain pattern
        table_matched = False
        for pattern in patterns:
            if table_name.startswith(pattern):
                filtered_tables.append(file_info.path)
                table_matched = True
                break  # No need to check other patterns once matched
        
        # Debug: Show which tables are being considered
        # if not table_matched:
        #     print(f"🔍 Skipped: {table_name} - no pattern match")
    
    print(f"📁 Found {len(filtered_tables)} tables matching domain patterns")
    
    # Create temp views for filtered tables
    tables_processed = 0
    for file_path in filtered_tables:
        tablename = file_path.split("/")[-1]
        
        try:
            df = spark.read.format("delta").load(file_path)

            if "OA_REC_PROCESSED_DATE" in df.columns:
                max_date = df.agg({"OA_REC_PROCESSED_DATE": "max"}).collect()[0][0]
                latest_df = df.filter(col("OA_REC_PROCESSED_DATE") == max_date)
                record_count = latest_df.count()
                latest_df.createOrReplaceTempView(f"temp_{tablename}")
                print(f"✅ Created: temp_{tablename} - {record_count} records (latest: {max_date})")
            else:
                df.createOrReplaceTempView(f"temp_{tablename}")
                record_count = df.count()
                print(f"✅ Created: temp_{tablename} - {record_count} records (no OA date)")
            
            tables_processed += 1
            
        except Exception as e:
            print(f"❌ Failed: {tablename} - {str(e)}")
    
    print(f"🎯 Completed: {tables_processed} temp views created for {domain}")
    return tables_processed


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# Test

# CELL ********************

create_temp_views_by_domains(silverPath, "Athena_A4E")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

def run_sql_static_statement(sqlstatement: list):
    for table_name, sql in sqlstatement:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        try:
            spark.sql(sql)
            print(f"{table_name}, Completed Successfully -=- {now}")
        except Exception as e:
            print(f"{table_name}, Failed -=- {now}")
            print(f"Error: {str(e)}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### Logging

# CELL ********************

# Config_Notebook_Logger
notebook_name = "notebookName from Parameter"
run_id = mssparkutils.env.getJobId()
all_errors = []

print(f"📝 Starting notebook logging for: {notebook_name}")
print(f"🏃 Run ID: {run_id}")

def capture_error(msg):
    """Capture error messages without stopping execution"""
    all_errors.append(msg)
    print(f"❌ CAPTURED ERROR: {msg}")
    # print(f"🔍 DEBUG: Total errors captured so far: {len(all_errors)}")

def finalise_notebook_logging():
    """Finalize logging and exit - call this at the END of your notebook"""
    # print(f"🔍 DEBUG: Starting finalise_notebook_logging()")
    # print(f"🔍 DEBUG: All errors: {all_errors}")
    
    # Determine final status
    if any("NOTEBOOK CRASHED" in error for error in all_errors):
        status = "FAILED"
    elif all_errors:
        status = "COMPLETED_WITH_ERRORS"
    else:
        status = "SUCCESS"
    
    # print(f"🔍 DEBUG: Determined status: {status}")
    
    # Create error summary
    error_summary = " | ".join(all_errors)[:2000] if all_errors else None
    # print(f"🔍 DEBUG: Error summary: {error_summary}")
    
    # Log to existing monitoring table in ctrl schema
    try:
        # print("🔍 DEBUG: Attempting to write to table...")
        
        if error_summary:
            # Escape single quotes for SQL
            error_summary_escaped = error_summary.replace("'", "''")
            insert_sql = f"""
            INSERT INTO ctrl.tbl_DWLoadLog 
            VALUES ('{notebook_name}', '{status}', '{error_summary_escaped}', CURRENT_TIMESTAMP, '{run_id}')
            """
        else:
            insert_sql = f"""
            INSERT INTO ctrl.tbl_DWLoadLog (notebook_name, status, timestamp, run_id)
            VALUES ('{notebook_name}', '{status}', CURRENT_TIMESTAMP, '{run_id}')
            """
        
        # print(f"🔍 DEBUG: SQL: {insert_sql}")
        spark.sql(insert_sql)
        print(f"✅ Logged to ctrl.tbl_DWLoadLog: {status}")
        
    except Exception as e:
        print(f"⚠️ Failed to write to ctrl.tbl_DWLoadLog: {str(e)}")
    
    # Exit for pipeline
    mssparkutils.notebook.exit(status)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print("\n✅ -=- CONFIG FOR GOLD LAYER COMPLETED -=-  ")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
