# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "42396a50-8b85-4951-9850-b36abfe2a28d",
# META       "default_lakehouse_name": "LH_300_Gold_Test",
# META       "default_lakehouse_workspace_id": "a3e4d0e6-6b32-498b-addc-1629a4b29a47",
# META       "known_lakehouses": [
# META         {
# META           "id": "42396a50-8b85-4951-9850-b36abfe2a28d"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# # **All Static Gold Layer Tables**

# CELL ********************

print("-=- LOADING STATIC TABLES -=-")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run /config_gold_layer

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


createTable([
# Create schema calc
    ("calc", """CREATE SCHEMA IF NOT EXISTS calc"""),

    ("rprt", """CREATE SCHEMA IF NOT EXISTS rprt"""),

    ("ctrl", """CREATE SCHEMA IF NOT EXISTS ctrl"""),
])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

                                                    #=========================
                                                    # CREATE CONTROL TABLE
                                                    #=========================

# change to tbl_DWLoadLog
createTable([
    # Create Logs table 
("ctrl.notebook_process_logs",
"""CREATE TABLE IF NOT EXISTS ctrl.notebook_process_logs(
    NOTEBOOK_NAME STRING,
    STATUS STRING,
    ERROR_SUMMARY STRING,
    PROCESS_TIMESTAMP TIMESTAMP,
    RUN_ID STRING
    )USING DELTA;
"""),

])


                                                    #=========================
                                                    # CREATE STATIC TABLE
                                                    #=========================

createTable([

# Create and Load Date Table
("rprt.tbl_d_date", 
"""CREATE TABLE IF NOT EXISTS rprt.tbl_d_date(
    DateID int NOT NULL
    ,Date date NOT NULL
    ,Year int NOT NULL
    ,Month int NOT NULL
    ,Day int NOT NULL
    ,Quarter int NOT NULL
    ,Week int NOT NULL
    ,QuarterName string NOT NULL
    ,MonthName string NOT NULL
    ,WeekName string NOT NULL
    ,DayName string NOT NULL
    ,YearMonth string NOT NULL
    ,YearMonthName string NOT NULL
    )USING DELTA;
"""),

# Create and Load Distance Table
("rprt.tbl_d_distance", 
"""CREATE TABLE IF NOT EXISTS rprt.tbl_d_distance(
    DistanceID int NOT NULL,
    MinDistance decimal(10,2) NOT NULL,
    MaxDistance decimal(10,2) NOT NULL,
    DistanceBucket string NOT NULL
    )USING DELTA;
"""),

# Create and Load Time Table
("rprt.tbl_d_time", 
"""CREATE TABLE IF NOT EXISTS rprt.tbl_d_time(
    SecondOfDay int NOT NULL
    ,Hour24 int 
    ,Minute int NOT NULL
    ,Second int NOT NULL
    ,TimeID int NOT NULL
    ,Hour12 int NOT NULL
    ,AmPmString string NOT NULL
    ,FullTimeString24 string NOT NULL
    ,FullTimeString12 string NOT NULL
    ,FullTime string NOT NULL
    ,Shift string NOT NULL
    ,Police_Hr int NOT NULL
    ,Time_Band string
    )USING DELTA;
"""),

])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

try:
    run_sql_static_statement([
    # Create and Load Date Table
    ("tbl_d_date", """MERGE INTO rprt.tbl_d_date AS target
    USING (
        WITH date_sequence AS (
            SELECT explode(sequence(to_date('1900-01-01'), to_date('2100-12-31'), interval 1 day)) AS Date
        )
        SELECT 
            CAST(date_format(Date, 'yyyyMMdd') AS INT) AS DateID,
            Date,
            CAST(date_format(Date, 'yyyy') AS INT) AS Year,
            CAST(date_format(Date, 'MM') AS INT) AS Month,
            CAST(date_format(Date, 'dd') AS INT) AS Day,
            CAST(ceil(CAST(date_format(Date, 'MM') AS INT) / 3) AS INT) AS Quarter,
            weekofyear(Date) AS Week,
            CONCAT('Quarter-', CAST(ceil(CAST(date_format(Date, 'MM') AS INT) / 3) AS INT)) AS QuarterName,
            date_format(Date, 'MMMM') AS MonthName,
            CONCAT('Week-', weekofyear(Date)) AS WeekName,
            date_format(Date, 'EEEE') AS DayName,
            date_format(Date, 'yyyy-MM') AS YearMonth,
            CONCAT(date_format(Date, 'yyyy'), ' - ', date_format(Date, 'MMMM')) AS YearMonthName
        FROM date_sequence
    ) AS source
    ON target.DateID = source.DateID
    WHEN NOT MATCHED THEN
        INSERT *
        """),

    # Create and Load Time Table
        ("tbl_d_time", """MERGE INTO rprt.tbl_d_time AS target
            USING(
            WITH time_sequence AS (
                SELECT explode(sequence(0, 86399)) AS SecondOfDay
            )
            SELECT 
                SecondOfDay,
                CAST(SecondOfDay / 3600 AS INT) AS Hour24,
                CAST((SecondOfDay % 3600) / 60 AS INT) AS Minute,
                CAST(SecondOfDay % 60 AS INT) AS Second,
                CAST((CAST(SecondOfDay / 3600 AS INT) * 10000 + CAST((SecondOfDay % 3600) / 60 AS INT) * 100 + CAST(SecondOfDay % 60 AS INT)) AS INT) AS TimeID,
                CAST(CAST(SecondOfDay / 3600 AS INT) % 12 AS INT) AS Hour12,
                CASE WHEN CAST(SecondOfDay / 3600 AS INT) < 12 THEN 'AM' ELSE 'PM' END AS AmPmString,

                -- FullTimeString24
                CONCAT(
                    LPAD(CAST(SecondOfDay / 3600 AS STRING), 2, '0'), ':',
                    LPAD(CAST((SecondOfDay % 3600) / 60 AS STRING), 2, '0'), ':',
                    LPAD(CAST(SecondOfDay % 60 AS STRING), 2, '0')
                ) AS FullTimeString24,

                -- FullTimeString12
                CONCAT(
                    LPAD(CAST((SecondOfDay / 3600) % 12 AS STRING), 2, '0'), ':',
                    LPAD(CAST((SecondOfDay % 3600) / 60 AS STRING), 2, '0'), ':',
                    LPAD(CAST(SecondOfDay % 60 AS STRING), 2, '0')
                ) AS FullTimeString12,

                -- FullTime as TIME
                CASE 
                    WHEN SecondOfDay IS NOT NULL THEN 
                        CONCAT(
                            LPAD(CAST(SecondOfDay / 3600 AS STRING), 2, '0'), ':',
                            LPAD(CAST((SecondOfDay % 3600) / 60 AS STRING), 2, '0'), ':',
                            LPAD(CAST(SecondOfDay % 60 AS STRING), 2, '0')
                        )
                    ELSE '00:00:00'
                END AS FullTime,

                -- Shift
                CASE 
                    WHEN CAST(SecondOfDay / 3600 AS INT) BETWEEN 6 AND 13 THEN 'EARLY'
                    WHEN CAST(SecondOfDay / 3600 AS INT) BETWEEN 14 AND 21 THEN 'LATE'
                    ELSE 'NIGHT'
                END AS Shift,

                -- Police_Hr
                CASE 
                    WHEN CAST(SecondOfDay / 3600 AS INT) > 5 THEN CAST(SecondOfDay / 3600 AS INT) - 5
                    ELSE CAST(SecondOfDay / 3600 AS INT) + 19
                END AS Police_Hr,

                -- Time_Band
                CASE
                    WHEN CAST(SecondOfDay / 3600 AS INT) BETWEEN 0 AND 2 THEN '00:00-03:00'
                    WHEN CAST(SecondOfDay / 3600 AS INT) BETWEEN 3 AND 5 THEN '03:00-06:00'
                    WHEN CAST(SecondOfDay / 3600 AS INT) BETWEEN 6 AND 8 THEN '06:00-09:00'
                    WHEN CAST(SecondOfDay / 3600 AS INT) BETWEEN 9 AND 11 THEN '09:00-12:00'
                    WHEN CAST(SecondOfDay / 3600 AS INT) BETWEEN 12 AND 14 THEN '12:00-15:00'
                    WHEN CAST(SecondOfDay / 3600 AS INT) BETWEEN 15 AND 17 THEN '15:00-18:00'
                    WHEN CAST(SecondOfDay / 3600 AS INT) BETWEEN 18 AND 20 THEN '18:00-21:00'
                    ELSE '21:00-00:00'
                END AS Time_Band
            FROM time_sequence
            )AS source
            ON target.TimeID = source.TimeID
            WHEN NOT MATCHED THEN
        INSERT *
        """),

    # Create and Load Distance Table
        ("tbl_d_distance", """MERGE INTO rprt.tbl_d_distance AS target
            USING(
            SELECT
                CAST(DistanceID AS INT) AS DistanceID,
                CAST(MinDistance AS DECIMAL(10,2)) AS MinDistance,
                CAST(MaxDistance AS DECIMAL(10,2)) AS MaxDistance,
                CAST(DistanceBucket AS STRING) AS DistanceBucket
            FROM (
                VALUES
                (1, 0, 5, '0 - 5'),
                (2, 5, 10, '5 - 10'),
                (3, 10, 15, '10 - 15'),
                (4, 15, 20, '15 - 20'),
                (5, 20, 25, '20 - 25'),
                (6, 25, 30, '25 - 30'),
                (7, 35, 70, '35 - 70')
            ) AS src(DistanceID, MinDistance, MaxDistance, DistanceBucket)
            ) AS source
            ON target.DistanceID = source.DistanceID
            WHEN NOT MATCHED THEN
        INSERT *
        """),

    ])
except Exception as e:
    capture_error(f"Create Table Cell; {str()}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### LOGGING

# CELL ********************

# finalise_notebook_logging()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print("-=- LOADING STATIC TABLES COMPLETED -=-")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
