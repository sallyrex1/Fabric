# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "6a459f05-6527-49bd-8600-74065f42a607",
# META       "default_lakehouse_name": "LH_200_Silver_Test",
# META       "default_lakehouse_workspace_id": "a3e4d0e6-6b32-498b-addc-1629a4b29a47",
# META       "known_lakehouses": [
# META         {
# META           "id": "6a459f05-6527-49bd-8600-74065f42a607"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# # **Silver Layer Static Tables**

# CELL ********************

print("-=- LOADING STATIC TABLES -=-")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./config_silver_layer

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

createTable([

# notebook_process_logs
("notebook_process_logs",
    """CREATE TABLE IF NOT EXISTS notebook_process_logs(
    		NOTEBOOK_NAME STRING,
            LAYER_TYPE STRING,
            STATUS STRING,
            ERROR_SUMMARY STRING,
            TIMESTAMP TIMESTAMP,
            RUN_ID STRING
    )USING DELTA;
"""), 
])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

createTable([

# stat_postcode_lookup
("stat_postcode_lookup",
    """CREATE TABLE IF NOT EXISTS stat_postcode_lookup(
	KEY int
	,POSTCODE string
	,LAT float
	,LONG float
    )USING DELTA;
"""), 

# stat_outcome_lookup
("stat_outcome_lookup",
    """CREATE TABLE IF NOT EXISTS stat_outcome_lookup(
	OUTCOMETYPE string
	,GROUP string
    )USING DELTA;
"""), 

# stat_Urban_Rural_Lookup
("stat_Urban_Rural_Lookup",
    """CREATE TABLE IF NOT EXISTS stat_Urban_Rural_Lookup(
	EPLPA string
	,EPBEAT string
	,PCDS string
	,RUCGROUP string
    )USING DELTA;
"""), 

# stat_harm_score_lookup
("stat_harm_score_lookup",
    """CREATE TABLE IF NOT EXISTS stat_harm_score_lookup(
	HO_CLASSIFICATION_CODE string
	,WEIGHT int
    )USING DELTA;
"""), 

# tbl_l_tagcategories
("tbl_l_tagcategories",
    """CREATE TABLE IF NOT EXISTS tbl_l_tagcategories(
	TagCode string
	,TagCategory string
    )USING DELTA;
"""), 

# tbl_l_harm_score_lookup
("tbl_l_harm_score_lookup",
    """CREATE TABLE IF NOT EXISTS tbl_l_harm_score_lookup(
	HO_Classification_Code string
	,Weight int
    )USING DELTA;
"""), 
    
])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

run_sql_static_statement([

# postcode_lookup
("stat_postcode_lookup", """INSERT OVERWRITE stat_postcode_lookup (Key, Postcode, Lat, Long)
    VALUES
    	 (1, 'CB1 6', NULL, NULL)
    	,(2, 'CB10 1', 52.021405, 0.23928925)
    	,(3, 'CB10 2', 52.02521, 0.2458786)
    	,(4, 'CB10 4', NULL, NULL)
    	,(5, 'CB10 9', 52.022948, 0.23856461)
    	,(6, 'CB11 3', 52.021636, 0.24938722)
    	,(7, 'CB11 4', 52.019607, 0.23975328)
    	,(8, 'CB21 4', 52.098354, 0.28833164)
    	,(9, 'CB6 3', 52.401896, 0.25254118)
    	,(10, 'CB9 7', 52.071041, 0.43653401)
    	,(11, 'CM0 7', 51.662523, 0.82912161)
    	,(12, 'CM0 8', 51.625499, 0.81924499)
    	,(13, 'CM1 1', 51.737213, 0.47599066)
    	,(14, 'CM1 2', 51.740885, 0.45656329)
    	,(15, 'CM1 3', 51.721731, 0.4478939)
    	,(16, 'CM1 4', 51.756136, 0.46780983)
    	,(17, 'CM1 5', NULL, NULL)
    	,(18, 'CM1 6', 51.75238, 0.48513729)
    	,(19, 'CM1 7', 51.758451, 0.47403697)
    	,(20, 'CM1 9', 51.737213, 0.47599066)
    	,(21, 'CM11 1', 51.634322, 0.42693975)
    	,(22, 'CM11 2', 51.62767, 0.41985114)
    	,(23, 'CM12 0', 51.62913, 0.41923528)
    	,(24, 'CM12 2', 51.62287, 0.41669163)
    	,(25, 'CM12 9', 51.62287, 0.41669163)
    	,(26, 'CM13 1', 51.631749, 0.33343636)
    	,(27, 'CM13 2', 51.612773, 0.31892834)
    	,(28, 'CM13 3', 51.603065, 0.29447528)
    	,(29, 'CM14 4', 51.620306, 0.30359417)
    	,(30, 'CM14 5', 51.612428, 0.31090853)
    	,(31, 'CM14 9', 51.620306, 0.30359417)
    	,(32, 'CM15 0', 51.665971, 0.26946763)
    	,(33, 'CM15 8', 51.621396, 0.30714563)
    	,(34, 'CM15 9', 51.627187, 0.31446175)
    	,(35, 'CM16 4', 51.700041, 0.11300739)
    	,(36, 'CM16 5', 51.700821, 0.11214645)
    	,(37, 'CM16 6', 51.71355, 0.15496665)
    	,(38, 'CM16 7', 51.692902, 0.11591605)
    	,(39, 'CM16 9', 51.700041, 0.11300739)
    	,(40, 'CM17 0', 51.783171, 0.13225829)
    	,(41, 'CM17 9', 51.763097, 0.12692114)
    	,(42, 'CM18 6', 51.764472, 0.10352242)
    	,(43, 'CM18 7', 51.755823, 0.11839262)
    	,(44, 'CM19 4', 51.76786, 0.090012568)
    	,(45, 'CM19 5', 51.765852, 0.068832711)
    	,(46, 'CM2 0', 51.728372, 0.46705003)
    	,(47, 'CM2 5', 51.752184, 0.51884349)
    	,(48, 'CM2 6', 51.735696, 0.49540337)
    	,(49, 'CM2 7', 51.711351, 0.50978416)
    	,(50, 'CM2 8', 51.712496, 0.46378264)
    	,(51, 'CM2 9', 51.724735, 0.46210232)
    	,(52, 'CM20 1', 51.771747, 0.093946281)
    	,(53, 'CM20 2', 51.782447, 0.11956718)
    	,(54, 'CM20 3', 51.775804, 0.11292106)
    	,(55, 'CM20 9', 51.771747, 0.093946281)
    	,(56, 'CM21 0', 51.803615, 0.13748744)
    	,(57, 'CM21 1', 51.812466, 0.15947962)
    	,(58, 'CM21 9', 51.812625, 0.14885283)
    	,(59, 'CM22 6', 51.924558, 0.24583864)
    	,(60, 'CM22 7', 51.816248, 0.20279647)
    	,(61, 'CM23 1', 51.937084, 0.15152218)
    	,(62, 'CM23 2', 51.871752, 0.16637207)
    	,(63, 'CM23 3', 51.866756, 0.16033627)
    	,(64, 'CM23 5', 51.876169, 0.17164033)
    	,(65, 'CM24 1', 51.880949, 0.21909359)
    	,(66, 'CM24 8', 51.902747, 0.1951203)
    	,(67, 'CM3 1', 51.785623, 0.46869429)
    	,(68, 'CM3 2', 51.78775, 0.58638408)
    	,(69, 'CM3 3', 51.765375, 0.55060911)
    	,(70, 'CM3 4', 51.718092, 0.56655182)
    	,(71, 'CM3 5', 51.643346, 0.61638861)
    	,(72, 'CM3 6', 51.680939, 0.76204133)
    	,(73, 'CM3 7', 51.64264, 0.60364224)
    	,(74, 'CM3 8', 51.680391, 0.56044035)
    	,(75, 'CM3 9', 51.643346, 0.61638861)
    	,(76, 'CM4 0', 51.670158, 0.38267486)
    	,(77, 'CM4 9', 51.663098, 0.37158901)
    	,(78, 'CM5 0', 51.710728, 0.24418956)
    	,(79, 'CM5 5', 51.703812, 0.24516432)
    	,(80, 'CM5 9', 51.706507, 0.24437142)
    	,(81, 'CM6 1', 51.872315, 0.36273828)
    	,(82, 'CM6 2', 51.877466, 0.36194772)
    	,(83, 'CM6 3', 51.880606, 0.40754911)
    	,(84, 'CM6 4', NULL, NULL)
    	,(85, 'CM6 9', 51.876265, 0.56645693)
    	,(86, 'CM7 0', 51.876265, 0.56645693)
    	,(87, 'CM7 1', 51.867622, 0.55534567)
    	,(88, 'CM7 2', 51.878998, 0.54250668)
    	,(89, 'CM7 3', 51.878553, 0.57824053)
    	,(90, 'CM7 4', 51.913114, 0.53765772)
    	,(91, 'CM7 5', 51.89976, 0.51544822)
    	,(92, 'CM7 6', NULL, NULL)
    	,(93, 'CM7 7', NULL, NULL)
    	,(94, 'CM7 8', NULL, NULL)
    	,(95, 'CM7 9', 51.881314, 0.55224247)
    	,(96, 'CM77 6', 51.878201, 0.50801094)
    	,(97, 'CM77 7', 51.865848, 0.52048409)
    	,(98, 'CM77 8', 51.88078, 0.58288715)
    	,(99, 'CM8 1', 51.798703, 0.63901033)
    	,(100, 'CM8 2', 51.799107, 0.64145623)
    	,(101, 'CM8 3', 51.81126, 0.65367256)
    	,(102, 'CM8 9', 51.800562, 0.64191847)
    	,(103, 'CM9 4', 51.741545, 0.69003036)
    	,(104, 'CM9 5', 51.731374, 0.68054793)
    	,(105, 'CM9 6', 51.730716, 0.67510678)
    	,(106, 'CM9 7', NULL, NULL)
    	,(107, 'CM9 8', 51.759722, 0.80457316)
    	,(108, 'CM9 9', 51.73489, 0.67742463)
    	,(109, 'CM92 1', 51.769357, 0.061253245)
    	,(110, 'CM98 1', 51.752184, 0.51884349)
    	,(111, 'CM99 1', NULL, NULL)
    	,(112, 'CM99 2', 51.737213, 0.47599066)
    	,(113, 'CO1 1', 51.898868, 0.89662288)
    	,(114, 'CO1 2', 51.885389, 0.90565301)
    	,(115, 'CO1 9', 51.889519, 0.91609393)
    	,(116, 'CO10 5', 52.031205, 0.85807699)
    	,(117, 'CO10 7', 52.056986, 0.70515462)
    	,(118, 'CO10 8', 52.087124, 0.64645304)
    	,(119, 'CO11 1', 51.945636, 1.0606826)
    	,(120, 'CO11 2', 51.942406, 1.0648864)
    	,(121, 'CO11 3', NULL, NULL)
    	,(122, 'CO11 9', 51.945231, 1.0627652)
    	,(123, 'CO12 3', 51.937681, 1.2797627)
    	,(124, 'CO12 4', 51.935288, 1.2726764)
    	,(125, 'CO12 5', 51.907528, 1.1989222)
    	,(126, 'CO12 9', 51.937681, 1.2797627)
    	,(127, 'CO13 0', 51.838174, 1.2468069)
    	,(128, 'CO13 3', 51.833539, 1.2452828)
    	,(129, 'CO13 9', 51.834542, 1.2451226)
    	,(130, 'CO14 8', 51.849347, 1.2717197)
    	,(131, 'CO15 1', 51.786503, 1.1388773)
    	,(132, 'CO15 2', 51.795577, 1.1338508)
    	,(133, 'CO15 3', 51.793288, 1.1485011)
    	,(134, 'CO15 4', 51.804051, 1.1666902)
    	,(135, 'CO15 5', 51.79483, 1.1727451)
    	,(136, 'CO15 6', 51.792865, 1.15452)
    	,(137, 'CO15 9', 51.79979, 1.1585579)
    	,(138, 'CO16 0', 51.865207, 1.1507786)
    	,(139, 'CO16 7', 51.794918, 1.1302224)
    	,(140, 'CO16 8', 51.805333, 1.1346295)
    	,(141, 'CO16 9', 51.863357, 1.0917276)
    	,(142, 'CO2 0', 51.860463, 0.90838888)
    	,(143, 'CO2 7', 51.887476, 0.89652943)
    	,(144, 'CO2 8', 51.876852, 0.9195313)
    	,(145, 'CO2 9', 51.877224, 0.87376885)
    	,(146, 'CO3 0', 51.889132, 0.84416617)
    	,(147, 'CO3 3', 51.889752, 0.89394331)
    	,(148, 'CO3 4', 51.888094, 0.86318404)
    	,(149, 'CO3 5', NULL, NULL)
    	,(150, 'CO3 8', 51.885202, 0.82809135)
    	,(151, 'CO3 9', 51.890441, 0.85321695)
    	,(152, 'CO4 0', 51.89445, 0.91780885)
    	,(153, 'CO4 1', NULL, NULL)
    	,(154, 'CO4 3', 51.882755, 0.93350201)
    	,(155, 'CO4 4', NULL, NULL)
    	,(156, 'CO4 5', 51.902086, 0.89415482)
    	,(157, 'CO4 6', 51.91219, 0.89396139)
    	,(158, 'CO4 9', 51.920303, 0.92738366)
    	,(159, 'CO5 0', 51.810128, 0.75333819)
    	,(160, 'CO5 1', 51.816996, 0.74539872)
    	,(161, 'CO5 7', 51.843328, 0.93883558)
    	,(162, 'CO5 8', 51.775238, 0.91424039)
    	,(163, 'CO5 9', 51.837362, 0.70131453)
    	,(164, 'CO6 1', 51.900327, 0.74658245)
    	,(165, 'CO6 2', 51.92048, 0.76317173)
    	,(166, 'CO6 3', 51.953089, 0.79329722)
    	,(167, 'CO6 4', 51.940001, 0.87551132)
    	,(168, 'CO6 5', 52.005034, 0.89930891)
    	,(169, 'CO7 0', 51.811528, 1.0248837)
    	,(170, 'CO7 1', 51.857347, 0.95937215)
    	,(171, 'CO7 5', 51.811528, 1.0248837)
    	,(172, 'CO7 6', 51.958624, 0.99390408)
    	,(173, 'CO7 7', 51.880433, 0.99631816)
    	,(174, 'CO7 8', 51.853509, 0.99760721)
    	,(175, 'CO7 9', 51.856205, 0.95936979)
    	,(176, 'CO8 5', 51.971171, 0.77518722)
    	,(177, 'CO9 1', 51.939977, 0.62855576)
    	,(178, 'CO9 2', 51.944701, 0.63808703)
    	,(179, 'CO9 3', 51.981478, 0.59904736)
    	,(180, 'CO9 4', 52.045573, 0.50939631)
    	,(181, 'CO9 9', 51.944667, 0.63636795)
    	,(182, 'E4 7', 51.634747, 0.006314459)
    	,(183, 'EN10 6', 51.728633, -0.025283755)
    	,(184, 'EN11 0', 51.764847, -0.007269458)
    	,(185, 'EN8 9', 51.702419, -0.033762881)
    	,(186, 'EN9 1', 51.686246, -0.013746726)
    	,(187, 'EN9 2', 51.70578, 0.05047377)
    	,(188, 'EN9 3', 51.679142, 0.005831681)
    	,(189, 'IG10 1', 51.647746, 0.055948672)
    	,(190, 'IG10 2', 51.653029, 0.075617658)
    	,(191, 'IG10 3', 51.638326, 0.060812043)
    	,(192, 'IG10 4', 51.641726, 0.034993924)
    	,(193, 'IG10 9', 51.646481, 0.086867855)
    	,(194, 'IG4 5', 51.576197, 0.057668342)
    	,(195, 'IG7 4', 51.60901, 0.11092931)
    	,(196, 'IG7 5', 51.617802, 0.057397429)
    	,(197, 'IG7 6', 51.620601, 0.074137452)
    	,(198, 'IG8 0', 51.607377, 0.023391276)
    	,(199, 'IG8 1', 51.609262, 0.022536326)
    	,(200, 'IG8 7', 51.599223, 0.036298746)
    	,(201, 'IG8 8', 51.605688, 0.050798618)
    	,(202, 'IG8 9', 51.605167, 0.025343709)
    	,(203, 'IG9 5', 51.623454, 0.044766103)
    	,(204, 'IG9 6', 51.62775, 0.048036823)
    	,(205, 'RM14 2', 51.552477, 0.24768598)
    	,(206, 'RM14 3', 51.552403, 0.24919698)
    	,(207, 'RM15 4', 51.499427, 0.26266727)
    	,(208, 'RM15 5', 51.514535, 0.28262891)
    	,(209, 'RM15 6', 51.501333, 0.29188252)
    	,(210, 'RM15 9', 51.509718, 0.28109101)
    	,(211, 'RM16 1', NULL, NULL)
    	,(212, 'RM16 2', 51.495911, 0.3319371)
    	,(213, 'RM16 3', 51.491766, 0.36468706)
    	,(214, 'RM16 4', 51.489471, 0.35046523)
    	,(215, 'RM16 5', 51.499222, 0.29543636)
    	,(216, 'RM16 6', 51.480201, 0.28991544)
    	,(217, 'RM17 5', 51.492202, 0.32036674)
    	,(218, 'RM17 6', 51.481222, 0.34115436)
    	,(219, 'RM17 9', 51.479919, 0.3207513)
    	,(220, 'RM18 7', 51.465287, 0.35141052)
    	,(221, 'RM18 8', 51.461998, 0.36425622)
    	,(222, 'RM19 1', 51.493821, 0.28420141)
    	,(223, 'RM20 1', 51.489033, 0.27556382)
    	,(224, 'RM20 2', 51.484168, 0.28204809)
    	,(225, 'RM20 3', 51.472879, 0.27846057)
    	,(226, 'RM20 4', 51.477619, 0.30283401)
    	,(227, 'RM4 1', 51.651567, 0.14446451)
    	,(228, 'SG8 8', 52.009546, -0.017646356)
    	,(229, 'SS0 0', 51.55216, 0.6777998)
    	,(230, 'SS0 7', 51.547316, 0.70314789)
    	,(231, 'SS0 8', 51.543005, 0.68920455)
    	,(232, 'SS0 9', 51.548405, 0.69998127)
    	,(233, 'SS1 1', 51.543523, 0.71237046)
    	,(234, 'SS1 2', 51.539394, 0.71359589)
    	,(235, 'SS1 3', 51.530451, 0.74119617)
    	,(236, 'SS1 9', 51.543523, 0.71237046)
    	,(237, 'SS11 7', 51.614534, 0.5230439)
    	,(238, 'SS11 8', 51.614089, 0.52408817)
    	,(239, 'SS11 9', 51.614089, 0.52408817)
    	,(240, 'SS12 0', 51.615038, 0.51756805)
    	,(241, 'SS12 9', 51.604071, 0.52574203)
    	,(242, 'SS13 1', 51.576056, 0.51993028)
    	,(243, 'SS13 2', 51.566639, 0.5098998)
    	,(244, 'SS13 3', 51.563773, 0.49880444)
    	,(245, 'SS14 0', 51.571103, 0.46003895)
    	,(246, 'SS14 1', 51.571103, 0.46003895)
    	,(247, 'SS14 2', 51.573605, 0.46209358)
    	,(248, 'SS14 3', 51.586555, 0.47197543)
    	,(249, 'SS14 9', 51.571103, 0.46003895)
    	,(250, 'SS15 4', 51.586298, 0.4317416)
    	,(251, 'SS15 5', 51.569439, 0.45020806)
    	,(252, 'SS15 6', 51.568036, 0.42288768)
    	,(253, 'SS16 4', 51.564445, 0.47260831)
    	,(254, 'SS16 5', 51.563666, 0.4647742)
    	,(255, 'SS16 6', 51.56552, 0.42194579)
    	,(256, 'SS17 0', 51.516682, 0.44083087)
    	,(257, 'SS17 1', 51.525317, 0.44806881)
    	,(258, 'SS17 7', 51.522423, 0.43244498)
    	,(259, 'SS17 8', 51.522225, 0.43069011)
    	,(260, 'SS17 9', 51.526604, 0.45962863)
    	,(261, 'SS2 4', 51.547412, 0.72349252)
    	,(262, 'SS2 5', 51.541565, 0.71810965)
    	,(263, 'SS2 6', 51.542234, 0.70981294)
    	,(264, 'SS22 7', NULL, NULL)
    	,(265, 'SS22 8', 51.55698, 0.70682309)
    	,(266, 'SS3 0', 51.553599, 0.80853362)
    	,(267, 'SS3 3', 51.529061, 0.79701555)
    	,(268, 'SS3 8', 51.539013, 0.77181003)
    	,(269, 'SS3 9', 51.529061, 0.79701555)
    	,(270, 'SS4 1', 51.58308, 0.70681542)
    	,(271, 'SS4 2', 51.582136, 0.72236436)
    	,(272, 'SS4 3', 51.598823, 0.68903621)
    	,(273, 'SS4 9', 51.582871, 0.71003664)
    	,(274, 'SS5 4', 51.602281, 0.6564715)
    	,(275, 'SS5 5', 51.60389, 0.66045053)
    	,(276, 'SS5 6', 51.607856, 0.63898786)
    	,(277, 'SS5 9', 51.602281, 0.6564715)
    	,(278, 'SS6 0', 51.584471, 0.60201788)
    	,(279, 'SS6 7', 51.582764, 0.60031796)
    	,(280, 'SS6 8', 51.59098, 0.61022993)
    	,(281, 'SS6 9', 51.590204, 0.60100286)
    	,(282, 'SS7 1', 51.562395, 0.57579454)
    	,(283, 'SS7 2', 51.553141, 0.6063313)
    	,(284, 'SS7 3', 51.565735, 0.57728207)
    	,(285, 'SS7 4', 51.57035, 0.56491545)
    	,(286, 'SS7 5', 51.56002, 0.54824637)
    	,(287, 'SS7 9', 51.568082, 0.5756831)
    	,(288, 'SS8 0', 51.51841, 0.59205108)
    	,(289, 'SS8 1', 51.52257, 0.59179725)
    	,(290, 'SS8 7', 51.52257, 0.59179725)
    	,(291, 'SS8 8', 51.523919, 0.59343091)
    	,(292, 'SS8 9', 51.523093, 0.59217292)
    	,(293, 'SS9 0', 51.548734, 0.64847433)
    	,(294, 'SS9 1', 51.542444, 0.66133491)
    	,(295, 'SS9 2', 51.548734, 0.64847433)
    	,(296, 'SS9 3', 51.549538, 0.64833349)
    	,(297, 'SS9 4', 51.555366, 0.66659065)
    	,(298, 'SS9 5', 51.572665, 0.64492968)
    	,(299, 'SS99 0', 51.531166, 0.72942942)
    	,(300, 'SS99 1', 51.542234, 0.70981294)
    	,(301, 'SS99 2', 51.55698, 0.70682309)
    	,(302, 'SS99 3', 51.55698, 0.70682309)
    	,(303, 'SS99 4', 51.543523, 0.71237046)
    	,(304, 'SS99 5', 51.55698, 0.70682309)
    	,(305, 'SS99 6', 51.543523, 0.71237046)
    	,(306, 'SS99 7', 51.539846, 0.72318485)
    	,(307, 'SS99 8', 51.55698, 0.70682309)
    	,(308, 'SS99 9', 51.531166, 0.72942942);
    """),

# outcome_lookup
("stat_outcome_lookup", """
    INSERT OVERWRITE stat_outcome_lookup (OutcomeType,Group)
    VALUES
    	 ('Adult Caution - conditional', 'Solved')
    	,('Non-HO Outcome - Other Non Crime', 'Ignore - DQ issue')
    	,('No prosecution', 'Ignore - DQ issue')
    	,('Type 10 - Formal Action Against Offender is not in the Public Interest (Police)', 'Other')
    	,('Type 11 - Prosecution Prevented-Named Suspect Identified But Is Below The Age Of Criminal Responsibility', 'Other')
    	,('Type 12 - Prosecution Prevented-Named Suspect Identified But Is Too Ill (Physical Or Mental Health) To Prosecute',	'Other')
    	,('Type 13 - Prosecution Prevented-Named Suspect Identified But Victim Or Key Witness Is Dead Or Too Ill To Give Evidence', 'Other')
    	,('Type 14 - Evidential Difficulties Victim Based- Suspect Not Identified: Crime Confirmed But The Victim Either Declines Or Unable To Support Further Police Investigation To Identify The Offender',	'Victim does not support')
    	,('Type 15 - Named Suspect Identified: Victim Supports Police Action But Evidential Difficulties Prevent Further Action',	'Other')
    	,('Type 16 - Named Suspect Identified: Evidential Difficulties Prevent Further Action: Victim Does Not Support (Or Has Withdrawn Support From) Police Action',	'Victim does not support')
    	,('Type 17 - Prosecution Time Limit Expired: Suspect Identified But Prosecution Time Limit Has Expired',	'Other')
    	,('Type 18 - Investigation Complete; No Suspect Identified. Crime Investigated As Far As Reasonably Possible-Case Closed Pending Further Investigative Opportunities Becoming Available',	'Other')
    	,('Type 1A - Charged/Summons - alternate offence. Offender has been charged under the alternate offence rule.', 'Solved')
    	,('Type 1 - Charged/Summonsed/Postal Requisition',	'Solved')
    	,('Type 20 - Further action resulting from the crime report will be undertaken by another body or agency subject to the victim (or person acting on their behalf) being made aware of the act to be taken', 'Other')
    	,('Type 21 - Further investigation resulting from crime report which could provide evidence sufficient to support formal action against the suspect is not in the public interest - police decision.',	'Other')
    	,('Type 22 - Diversionary, educational or intervention activity, resulting from the crime report, has been undertaken and it is not in the public interest to take any further action.', 'Other')
    	,('Type 2A - Caution Youth - alternate offence. Offender is a juvenile and has been given a youth caution under the alternate offences rule.',	'Solved')
    	,('Type 2 - Caution Youth', 'Solved')
    	,('Type 3A - Caution Adult - alternate offence. Offender has been given a simple caution under the alternate offences rule.',	'Solved')
    	,('Type 3 - Caution Adult', 'Solved')
    	,('Type 4 - TIC - Taken into Consideration', 'Solved')
    	,('Type 5 - Offender has died', 'Other')
    	,('Type 6 - Penalty notice for disorder', 'Solved')
    	,('Type 7 - Cannabis/Khat Warning', 'Solved')
    	,('Type 8 - Community resolution (Crime)',	'Solved')
    	,('Type 9 - Prosecution Not In the Public Interest (CPS)',	'Solved')
    	,('Type AF - Action Fraud record filed temporarily awaiting result from master AF investigation',	'Ongoing')
    	,('Non-HO Outcome - First Instance Harassment Warning Issued', 'Ignore - DQ issue')
    	,('No offence', 'Ignore - DQ issue')
    	,('Youth Conditional Caution', 'Solved');
    """),

# Urban_Rural_Lookup
("stat_Urban_Rural_Lookup", """
    INSERT OVERWRITE stat_Urban_Rural_Lookup (eplpa,epbeat,pcds,rucgroup) 
    VALUES
    	 ('North','C120A','CM1 5GR','Urban'),
    	 ('North','C120A','CM1 5GS','Urban'),
    	 ('North','C120A','CM1 5GT','Urban'),
    	 ('North','C120A','CM1 5HR','Urban'),
    	 ('North','C120A','CM1 5HT','Urban'),
    	 ('North','C120A','CM1 5PH','Urban'),
    	 ('North','C120A','CM1 5PL','Urban'),
    	 ('North','C120A','CM1 5PN','Urban'),
    	 ('North','C120A','CM1 5RA','Urban'),
    	 ('North','C120A','CM1 5RB','Urban'),
    	 ('North','C120A','CM1 5RD','Urban'),
    	 ('North','C120A','CM1 5RE','Urban'),
    	 ('North','C120A','CM1 5RF','Urban'),
    	 ('North','C120A','CM1 5RG','Urban'),
    	 ('North','C120A','CM1 5RH','Urban'),
    	 ('North','C120A','CM1 5RJ','Urban'),
    	 ('North','C120A','CM1 5RL','Urban'),
    	 ('North','C120A','CM1 5RN','Urban'),
    	 ('North','C120A','CM1 5RQ','Urban'),
    	 ('North','C120A','CM1 5RS','Urban'),
    	 ('North','C120A','CM1 5RT','Urban'),
    	 ('North','C120A','CM1 5RU','Urban'),
    	 ('North','C120A','CM1 5RX','Urban'),
    	 ('North','C120A','CM1 5RY','Urban'),
    	 ('North','C120A','CM1 5RZ','Urban'),
    	 ('North','C120A','CM1 5SA','Urban'),
    	 ('North','C120A','CM1 5SP','Urban'),
    	 ('North','C120A','CM1 5SR','Urban'),
    	 ('North','C120A','CM1 5SW','Urban'),
    	 ('North','C120A','CM1 5UF','Urban'),
    	 ('North','C120A','CM1 7FE','Urban'),
    	 ('North','C120A','CM1 7GT','Urban'),
    	 ('North','C120A','CM1 7HR','Urban'),
    	 ('North','C120A','CM1 7HT','Urban'),
    	 ('North','C120A','CM1 7HU','Urban'),
    	 ('North','C120A','CM1 7PH','Urban'),
    	 ('North','C120A','CM1 7PL','Urban'),
    	 ('North','C120A','CM1 7PN','Urban'),
    	 ('North','C120A','CM1 7QY','Urban'),
    	 ('North','C120A','CM1 7QZ','Urban'),
    	 ('North','C120A','CM1 7RA','Urban'),
    	 ('North','C120A','CM1 7RB','Urban'),
    	 ('North','C120A','CM1 7RD','Urban'),
    	 ('North','C120A','CM1 7RE','Urban'),
    	 ('North','C120A','CM1 7RF','Urban'),
    	 ('North','C120A','CM1 7RG','Urban'),
    	 ('North','C120A','CM1 7RH','Urban'),
    	 ('North','C120A','CM1 7RJ','Urban'),
    	 ('North','C120A','CM1 7RL','Urban'),
    	 ('North','C120A','CM1 7RN','Urban'),
    	 ('North','C120A','CM1 7RQ','Urban'),
    	 ('North','C120A','CM1 7RS','Urban'),
    	 ('North','C120A','CM1 7RT','Urban'),
    	 ('North','C120A','CM1 7RU','Urban'),
    	 ('North','C120A','CM1 7RX','Urban'),
    	 ('North','C120A','CM1 7RY','Urban'),
    	 ('North','C120A','CM1 7RZ','Urban'),
    	 ('North','C120A','CM1 7SA','Urban'),
    	 ('North','C120A','CM1 7SP','Urban'),
    	 ('North','C120A','CM1 7SR','Urban'),
    	 ('North','C120A','CM1 7SW','Urban'),
    	 ('North','C120A','CM1 7UF','Urban'),
    	 ('North','C120A','CM2 6AA','Urban'),
    	 ('North','C120A','CM2 6AF','Urban'),
    	 ('North','C120A','CM2 6AG','Urban'),
    	 ('North','C120A','CM2 6AH','Urban'),
    	 ('North','C120A','CM2 6AJ','Urban'),
    	 ('North','C120A','CM2 6AL','Urban'),
    	 ('North','C120A','CM2 6AN','Urban'),
    	 ('North','C120A','CM2 6AP','Urban'),
    	 ('North','C120A','CM2 6AQ','Urban'),
    	 ('North','C120A','CM2 6AR','Urban'),
    	 ('North','C120A','CM2 6AS','Urban'),
    	 ('North','C120A','CM2 6AT','Urban'),
    	 ('North','C120A','CM2 6AU','Urban'),
    	 ('North','C120A','CM2 6AW','Urban'),
    	 ('North','C120A','CM2 6AX','Urban'),
    	 ('North','C120A','CM2 6AY','Urban'),
    	 ('North','C120A','CM2 6AZ','Urban'),
    	 ('North','C120A','CM2 6BA','Urban'),
    	 ('North','C120A','CM2 6BB','Urban'),
    	 ('North','C120A','CM2 6BG','Urban'),
    	 ('North','C120A','CM2 6BJ','Urban'),
    	 ('North','C120A','CM2 6BL','Urban'),
    	 ('North','C120A','CM2 6BN','Urban'),
    	 ('North','C120A','CM2 6BP','Urban'),
    	 ('North','C120A','CM2 6BS','Urban'),
    	 ('North','C120A','CM2 6BT','Urban'),
    	 ('North','C120A','CM2 6BU','Urban'),
    	 ('North','C120A','CM2 6BW','Urban'),
    	 ('North','C120A','CM2 6BX','Urban'),
    	 ('North','C120A','CM2 6BY','Urban'),
    	 ('North','C120A','CM2 6BZ','Urban'),
    	 ('North','C120A','CM2 6DB','Urban'),
    	 ('North','C120A','CM2 6DD','Urban'),
    	 ('North','C120A','CM2 6DE','Urban'),
    	 ('North','C120A','CM2 6DF','Urban'),
    	 ('North','C120A','CM2 6DG','Urban'),
    	 ('North','C120A','CM2 6DH','Urban'),
    	 ('North','C120A','CM2 6DJ','Urban'),
    	 ('North','C120A','CM2 6DL','Urban'),
    	 ('North','C120A','CM2 6DN','Urban'),
    	 ('North','C120A','CM2 6DP','Urban'),
    	 ('North','C120A','CM2 6DQ','Urban'),
    	 ('North','C120A','CM2 6DR','Urban'),
    	 ('North','C120A','CM2 6DS','Urban'),
    	 ('North','C120A','CM2 6DT','Urban'),
    	 ('North','C120A','CM2 6DU','Urban'),
    	 ('North','C120A','CM2 6DW','Urban'),
    	 ('North','C120A','CM2 6DX','Urban'),
    	 ('North','C120A','CM2 6DY','Urban'),
    	 ('North','C120A','CM2 6DZ','Urban'),
    	 ('North','C120A','CM2 6EA','Urban'),
    	 ('North','C120A','CM2 6EB','Urban'),
    	 ('North','C120A','CM2 6ED','Urban'),
    	 ('North','C120A','CM2 6EE','Urban'),
    	 ('North','C120A','CM2 6EF','Urban'),
    	 ('North','C120A','CM2 6EG','Urban'),
    	 ('North','C120A','CM2 6EH','Urban'),
    	 ('North','C120A','CM2 6EJ','Urban'),
    	 ('North','C120A','CM2 6EL','Urban'),
    	 ('North','C120A','CM2 6EN','Urban'),
    	 ('North','C120A','CM2 6EP','Urban'),
    	 ('North','C120A','CM2 6EQ','Urban'),
    	 ('North','C120A','CM2 6ER','Urban'),
    	 ('North','C120A','CM2 6ES','Urban'),
    	 ('North','C120A','CM2 6ET','Urban'),
    	 ('North','C120A','CM2 6EU','Urban'),
    	 ('North','C120A','CM2 6EW','Urban'),
    	 ('North','C120A','CM2 6EX','Urban'),
    	 ('North','C120A','CM2 6EY','Urban'),
    	 ('North','C120A','CM2 6FJ','Urban'),
    	 ('North','C120A','CM2 6FR','Urban'),
    	 ('North','C120A','CM2 6FT','Urban'),
    	 ('North','C120A','CM2 6HA','Urban'),
    	 ('North','C120A','CM2 6HB','Urban'),
    	 ('North','C120A','CM2 6HD','Urban'),
    	 ('North','C120A','CM2 6HE','Urban'),
    	 ('North','C120A','CM2 6HG','Urban'),
    	 ('North','C120A','CM2 6HH','Urban'),
    	 ('North','C120A','CM2 6HJ','Urban'),
    	 ('North','C120A','CM2 6HL','Urban'),
    	 ('North','C120A','CM2 6HN','Urban'),
    	 ('North','C120A','CM2 6HP','Urban'),
    	 ('North','C120A','CM2 6HQ','Urban'),
    	 ('North','C120A','CM2 6HR','Urban'),
    	 ('North','C120A','CM2 6HS','Urban'),
    	 ('North','C120A','CM2 6HT','Urban'),
    	 ('North','C120A','CM2 6HW','Urban'),
    	 ('North','C120A','CM2 6JP','Urban'),
    	 ('North','C120A','CM2 6JS','Urban'),
    	 ('North','C120A','CM2 6JT','Urban'),
    	 ('North','C120A','CM2 6JU','Urban'),
    	 ('North','C120A','CM2 6LG','Urban'),
    	 ('North','C120A','CM2 6LQ','Urban'),
    	 ('North','C120A','CM2 6LW','Urban'),
    	 ('North','C120A','CM2 6ND','Urban'),
    	 ('North','C120A','CM2 6NE','Urban'),
    	 ('North','C120A','CM2 6NH','Urban'),
    	 ('North','C120A','CM2 6PQ','Urban'),
    	 ('North','C120A','CM2 6RD','Urban'),
    	 ('North','C120A','CM2 6ZN','Urban'),
    	 ('North','C121A','CM1 1AA','Urban'),
    	 ('North','C121A','CM1 1AH','Urban'),
    	 ('North','C121A','CM1 1AL','Urban'),
    	 ('North','C121A','CM1 1AN','Urban'),
    	 ('North','C121A','CM1 1AR','Urban'),
    	 ('North','C121A','CM1 1AS','Urban'),
    	 ('North','C121A','CM1 1AT','Urban'),
    	 ('North','C121A','CM1 1AY','Urban'),
    	 ('North','C121A','CM1 1AZ','Urban'),
    	 ('North','C121A','CM1 1BA','Urban'),
    	 ('North','C121A','CM1 1BD','Urban'),
    	 ('North','C121A','CM1 1BE','Urban'),
    	 ('North','C121A','CM1 1BG','Urban'),
    	 ('North','C121A','CM1 1BJ','Urban'),
    	 ('North','C121A','CM1 1BN','Urban'),
    	 ('North','C121A','CM1 1BP','Urban'),
    	 ('North','C121A','CM1 1BQ','Urban'),
    	 ('North','C121A','CM1 1BS','Urban'),
    	 ('North','C121A','CM1 1BT','Urban'),
    	 ('North','C121A','CM1 1BU','Urban'),
    	 ('North','C121A','CM1 1BX','Urban'),
    	 ('North','C121A','CM1 1BZ','Urban'),
    	 ('North','C121A','CM1 1DA','Urban'),
    	 ('North','C121A','CM1 1DD','Urban'),
    	 ('North','C121A','CM1 1DE','Urban'),
    	 ('North','C121A','CM1 1DG','Urban'),
    	 ('North','C121A','CM1 1DH','Urban'),
    	 ('North','C121A','CM1 1DN','Urban'),
    	 ('North','C121A','CM1 1DP','Urban'),
    	 ('North','C121A','CM1 1DQ','Urban'),
    	 ('North','C121A','CM1 1DR','Urban'),
    	 ('North','C121A','CM1 1DS','Urban'),
    	 ('North','C121A','CM1 1DT','Urban'),
    	 ('North','C121A','CM1 1DU','Urban'),
    	 ('North','C121A','CM1 1DW','Urban'),
    	 ('North','C121A','CM1 1DX','Urban'),
    	 ('North','C121A','CM1 1DY','Urban'),
    	 ('North','C121A','CM1 1DZ','Urban'),
    	 ('North','C121A','CM1 1EA','Urban'),
    	 ('North','C121A','CM1 1ED','Urban'),
    	 ('North','C121A','CM1 1EE','Urban'),
    	 ('North','C121A','CM1 1EF','Urban'),
    	 ('North','C121A','CM1 1EG','Urban'),
    	 ('North','C121A','CM1 1EH','Urban'),
    	 ('North','C121A','CM1 1EJ','Urban'),
    	 ('North','C121A','CM1 1EN','Urban'),
    	 ('North','C121A','CM1 1EP','Urban'),
    	 ('North','C121A','CM1 1EQ','Urban'),
    	 ('North','C121A','CM1 1ER','Urban'),
    	 ('North','C121A','CM1 1ES','Urban'),
    	 ('North','C121A','CM1 1ET','Urban'),
    	 ('North','C121A','CM1 1EU','Urban'),
    	 ('North','C121A','CM1 1EX','Urban'),
    	 ('North','C121A','CM1 1EY','Urban'),
    	 ('North','C121A','CM1 1EZ','Urban'),
    	 ('North','C121A','CM1 1FA','Urban'),
    	 ('North','C121A','CM1 1FB','Urban'),
    	 ('North','C121A','CM1 1FE','Urban'),
    	 ('North','C121A','CM1 1FG','Urban'),
    	 ('North','C121A','CM1 1FL','Urban'),
    	 ('North','C121A','CM1 1FQ','Urban'),
    	 ('North','C121A','CM1 1FU','Urban'),
    	 ('North','C121A','CM1 1FY','Urban'),
    	 ('North','C121A','CM1 1FZ','Urban'),
    	 ('North','C121A','CM1 1GA','Urban'),
    	 ('North','C121A','CM1 1GB','Urban'),
    	 ('North','C121A','CM1 1GD','Urban'),
    	 ('North','C121A','CM1 1GE','Urban'),
    	 ('North','C121A','CM1 1GF','Urban'),
    	 ('North','C121A','CM1 1GG','Urban'),
    	 ('North','C121A','CM1 1GH','Urban'),
    	 ('North','C121A','CM1 1GL','Urban'),
    	 ('North','C121A','CM1 1GP','Urban'),
    	 ('North','C121A','CM1 1GQ','Urban'),
    	 ('North','C121A','CM1 1HA','Urban'),
    	 ('North','C121A','CM1 1HB','Urban'),
    	 ('North','C121A','CM1 1HD','Urban'),
    	 ('North','C121A','CM1 1HF','Urban'),
    	 ('North','C121A','CM1 1HG','Urban'),
    	 ('North','C121A','CM1 1HJ','Urban'),
    	 ('North','C121A','CM1 1HL','Urban'),
    	 ('North','C121A','CM1 1HN','Urban'),
    	 ('North','C121A','CM1 1HP','Urban'),
    	 ('North','C121A','CM1 1HQ','Urban'),
    	 ('North','C121A','CM1 1HR','Urban'),
    	 ('North','C121A','CM1 1HS','Urban'),
    	 ('North','C121A','CM1 1HT','Urban'),
    	 ('North','C121A','CM1 1HU','Urban'),
    	 ('North','C121A','CM1 1HW','Urban'),
    	 ('North','C121A','CM1 1JB','Urban'),
    	 ('North','C121A','CM1 1JJ','Urban'),
    	 ('North','C121A','CM1 1JL','Urban'),
    	 ('North','C121A','CM1 1JN','Urban'),
    	 ('North','C121A','CM1 1JP','Urban'),
    	 ('North','C121A','CM1 1JQ','Urban'),
    	 ('North','C121A','CM1 1JR','Urban'),
    	 ('North','C121A','CM1 1JS','Urban'),
    	 ('North','C121A','CM1 1JT','Urban'),
    	 ('North','C121A','CM1 1JU','Urban'),
    	 ('North','C121A','CM1 1JW','Urban'),
    	 ('North','C121A','CM1 1JX','Urban'),
    	 ('North','C121A','CM1 1JY','Urban'),
    	 ('North','C121A','CM1 1LA','Urban'),
    	 ('North','C121A','CM1 1LD','Urban'),
    	 ('North','C121A','CM1 1LE','Urban'),
    	 ('North','C121A','CM1 1LF','Urban'),
    	 ('North','C121A','CM1 1LJ','Urban'),
    	 ('North','C121A','CM1 1LL','Urban'),
    	 ('North','C121A','CM1 1LN','Urban'),
    	 ('North','C121A','CM1 1LP','Urban'),
    	 ('North','C121A','CM1 1LQ','Urban'),
    	 ('North','C121A','CM1 1LS','Urban'),
    	 ('North','C121A','CM1 1LU','Urban'),
    	 ('North','C121A','CM1 1LW','Urban'),
    	 ('North','C121A','CM1 1LY','Urban'),
    	 ('North','C121A','CM1 1LZ','Urban'),
    	 ('North','C121A','CM1 1NA','Urban'),
    	 ('North','C121A','CM1 1NB','Urban'),
    	 ('North','C121A','CM1 1ND','Urban'),
    	 ('North','C121A','CM1 1NE','Urban'),
    	 ('North','C121A','CM1 1NF','Urban'),
    	 ('North','C121A','CM1 1NG','Urban'),
    	 ('North','C121A','CM1 1NH','Urban'),
    	 ('North','C121A','CM1 1NL','Urban'),
    	 ('North','C121A','CM1 1NP','Urban'),
    	 ('North','C121A','CM1 1NQ','Urban'),
    	 ('North','C121A','CM1 1NS','Urban'),
    	 ('North','C121A','CM1 1NT','Urban'),
    	 ('North','C121A','CM1 1NU','Urban'),
    	 ('North','C121A','CM1 1NW','Urban'),
    	 ('North','C121A','CM1 1NX','Urban'),
    	 ('North','C121A','CM1 1NY','Urban'),
    	 ('North','C121A','CM1 1NZ','Urban'),
    	 ('North','C121A','CM1 1PA','Urban'),
    	 ('North','C121A','CM1 1PB','Urban'),
    	 ('North','C121A','CM1 1PE','Urban'),
    	 ('North','C121A','CM1 1PF','Urban'),
    	 ('North','C121A','CM1 1PG','Urban');
 """),

# harm_score_lookup	
("stat_harm_score_lookup", """ INSERT OVERWRITE stat_harm_score_lookup (HO_Classification_Code, Weight)
VALUES
	 ('1', 7973)
	,('2', 4654)
	,('13', 290)
	,('14', 1056)
	,('15', 201)
	,('20', 588)
	,('21', 824)
	,('23', 1122)
	,('24', 366)
	,('26', 201)
	,('27', 4)
	,('29', 2289)
	,('31', 1850)
	,('33', 31)
	,('35', 786)
	,('36', 1217)
	,('38', 248)
	,('39', 80)
	,('40', 51)
	,('41', 49)
	,('42', 85)
	,('43', 5)
	,('44', 15)
	,('45', 33)
	,('46', 12)
	,('47', 111)
	,('48', 128)
	,('49', 37)
	,('54', 55)
	,('59', 61)
	,('60', 32)
	,('61', 146)
	,('66', 73)
	,('67', 98)
	,('69', 207)
	,('70', 1445)
	,('71', 939)
	,('73', 241)
	,('76', 817)
	,('79', 169)
	,('80', 192)
	,('81', 1288)
	,('83', 3)
	,('86', 137)
	,('95', 13)
	,('96', 248)
	,('99', 179)
	,('104', 8)
	,('106', 1069)
	,('126', 9)
	,('802', 120)
	,('814', 7)
	,('4/1', 7973)
	,('4/3', 3776)
	,('4/4', 1023)
	,('4/6', 1512)
	,('4/7', 3776)
	,('4/8', 111)
	,('4/9', 180)
	,('4/10', 7973)
	,('017  (Also 17B)', 788)
	,('105A', 14)
	,('105B', 31)
	,('10A', 617)
	,('10B', 412)
	,('10C', 52)
	,('10D', 53)
	,('11A', 139)
	,('17A', 767)
	,('17B', 862)
	,('19A', 3279)
	,('19C', 2953)
	,('19D', 3883)
	,('19E', 3225)
	,('19F', 3192)
	,('19G', 3895)
	,('19H', 2397)
	,('19J', 3279)
	,('19K', 2975)
	,('20A', 459)
	,('20B', 1212)
	,('22A', 1055)
	,('22B', 726)
	,('28A', 465)
	,('28B', 465)
	,('28C', 465)
	,('28D', 465)
	,('28E', 465)
	,('28F', 465)
	,('28G', 465)
	,('28H', 465)
	,('29A', 2289)
	,('30A', 123)
	,('30B', 123)
	,('30C', 123)
	,('30D', 123)
	,('31A', 1850)
	,('33A', 135)
	,('34A', 800)
	,('34B', 800)
	,('37/1', 128)
	,('37/2', 53)
	,('3A', 2024)
	,('3B', 275)
	,('49A', 7)
	,('53D', 266)
	,('56A', 826)
	,('56B', 187)
	,('58A', 5)
	,('58B', 5)
	,('58C', 5)
	,('58D', 5)
	,('58J', 14)
	,('5D', 2035)
	,('5E', 1447)
	,('61A', 194)
	,('62A', 363)
	,('88A', 463)
	,('88C', 1027)
	,('88D', 52)
	,('88E', 40)
	,('8L', 36)
	,('8M', 38)
	,('8', 189)
	,('8P', 313)
	,('8Q', 56)
	,('8R', 15)
	,('8S', 401)
	,('8T', 401)
	,('8U', 56)
	,('92A', 513)
	,('92C', 9)
	,('92D', 8)
	,('92E', 2)
	,('9A', 7)
	,('9B', 13)
	,('NFIB', 132);
"""),

# tbl_l_tagcategories
("tbl_l_tagcategories","""
    INSERT OVERWRITE tbl_l_tagcategories	(TagCode, TagCategory)
    VALUES
    	 ('F:DELAY', 'Delay Reason')
    	,('F:DELAYED', 'Delay Reason')
    	,('F:DISTANCE', 'Delay Reason')
    	,('F:NOUNIT', 'Delay Reason')
    	,('F:UPGRADE', 'Delay Reason');
"""),

# tbl_l_harm_score_lookup
("tbl_l_harm_score_lookup", """
    INSERT INTO tbl_l_harm_score_lookup (HO_Classification_Code, Weight)
    VALUES

    	 ('1', 7973)
    	,('2', 4654)
    	,('13', 290)
    	,('14', 1056)
    	,('15', 201)
    	,('20', 588)
    	,('21', 824)
    	,('23', 1122)
    	,('24', 366)
    	,('26', 201)
    	,('27', 4)
    	,('29', 2289)
    	,('31', 1850)
    	,('33', 31)
    	,('35', 786)
    	,('36', 1217)
    	,('38', 248)
    	,('39', 80)
    	,('40', 51)
    	,('41', 49)
    	,('42', 85)
    	,('43', 5)
    	,('44', 15)
    	,('45', 33)
    	,('46', 12)
    	,('47', 111)
    	,('48', 128)
    	,('49', 37)
    	,('54', 55)
    	,('59', 61)
    	,('60', 32)
    	,('61', 146)
    	,('66', 73)
    	,('67', 98)
    	,('69', 207)
    	,('70', 1445)
    	,('71', 939)
    	,('73', 241)
    	,('76', 817)
    	,('79', 169)
    	,('80', 192)
    	,('81', 1288)
    	,('83', 3)
    	,('86', 137)
    	,('95', 13)
    	,('96', 248)
    	,('99', 179)
    	,('104', 8)
    	,('106', 1069)
    	,('126', 9)
    	,('802', 120)
    	,('814', 7)
    	,('4/1', 7973)
    	,('4/3', 3776)
    	,('4/4', 1023)
    	,('4/6', 1512)
    	,('4/7', 3776)
    	,('4/8', 111)
    	,('4/9', 180)
    	,('4/10', 7973)
    	,('017  (Also 17B)', 788)
    	,('105A', 14)
    	,('105B', 31)
    	,('10A', 617)
    	,('10B', 412)
    	,('10C', 52)
    	,('10D', 53)
    	,('11A', 139)
    	,('17A', 767)
    	,('17B', 862)
    	,('19A', 3279)
    	,('19C', 2953)
    	,('19D', 3883)
    	,('19E', 3225)
    	,('19F', 3192)
    	,('19G', 3895)
    	,('19H', 2397)
    	,('19J', 3279)
    	,('19K', 2975)
    	,('20A', 459)
    	,('20B', 1212)
    	,('22A', 1055)
    	,('22B', 726)
    	,('28A', 465)
    	,('28B', 465)
    	,('28C', 465)
    	,('28D', 465)
    	,('28E', 465)
    	,('28F', 465)
    	,('28G', 465)
    	,('28H', 465)
    	,('29A', 2289)
    	,('30A', 123)
    	,('30B', 123)
    	,('30C', 123)
    	,('30D', 123)
    	,('31A', 1850)
    	,('33A', 135)
    	,('34A', 800)
    	,('34B', 800)
    	,('37/1', 128)
    	,('37/2', 53)
    	,('3A', 2024)
    	,('3B', 275)
    	,('49A', 7)
    	,('53D', 266)
    	,('56A', 826)
    	,('56B', 187)
    	,('58A', 5)
    	,('58B', 5)
    	,('58C', 5)
    	,('58D', 5)
    	,('58J', 14)
    	,('5D', 2035)
    	,('5E', 1447)
    	,('61A', 194)
    	,('62A', 363)
    	,('88A', 463)
    	,('88C', 1027)
    	,('88D', 52)
    	,('88E', 40)
    	,('8L', 36)
    	,('8M', 38)
    	,('8N', 189)
    	,('8P', 313)
    	,('8Q', 56)
    	,('8R', 15)
    	,('8S', 401)
    	,('8T', 401)
    	,('8U', 56)
    	,('92A', 513)
    	,('92C', 9)
    	,('92D', 8)
    	,('92E', 2)
    	,('9A', 7)
    	,('9B', 13)
    	,('NFIB', 132);
"""),


# ===========================
# t_date Table
# ===========================


# Create and Load Date Table
    ("tbl_date", """CREATE OR REPLACE TABLE tbl_date AS
        WITH date_sequence AS (
            SELECT explode(sequence(to_date('1900-01-01'), to_date('2100-12-31'), interval 1 day)) AS Date
        )
        SELECT 
            CAST(date_format(Date, 'yyyyMMdd') AS INT) AS DateID,
            Date,
            CAST(date_format(Date, 'yyyy') AS INT) AS Year,
            CAST(date_format(Date, 'MM') AS INT) AS Month,
            CAST(date_format(Date, 'dd') AS INT) AS Day,
            CAST(ceil(CAST(date_format(Date, 'MM') AS INT) / 3) AS INT) AS Quarter,
            weekofyear(Date) AS Week,
            CONCAT('Quarter-', CAST(ceil(CAST(date_format(Date, 'MM') AS INT) / 3) AS INT)) AS QuarterName,
            date_format(Date, 'MMMM') AS MonthName,
            CONCAT('Week-', weekofyear(Date)) AS WeekName,
            date_format(Date, 'EEEE') AS DayName,
            date_format(Date, 'yyyy-MM') AS YearMonth,
            CONCAT(date_format(Date, 'yyyy'), ' - ', date_format(Date, 'MMMM')) AS YearMonthName
        FROM date_sequence;
    """),

])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": true
# META }

# CELL ********************

finalise_notebook_logging()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": true
# META }

# CELL ********************

print("-=- LOADING STATIC TABLES COMPLETED -=-")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
