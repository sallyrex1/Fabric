# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "42396a50-8b85-4951-9850-b36abfe2a28d",
# META       "default_lakehouse_name": "LH_300_Gold_Test",
# META       "default_lakehouse_workspace_id": "a3e4d0e6-6b32-498b-addc-1629a4b29a47",
# META       "known_lakehouses": [
# META         {
# META           "id": "42396a50-8b85-4951-9850-b36abfe2a28d"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# # **BAIL GOLD LOAD**

# MARKDOWN ********************

# ###### CONFIG

# CELL ********************

%run /config_gold_layer

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Only activate for Testing
p_current_domain = "Bail"
print(f"✅ STARTING {p_current_domain} PROCESSING")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": true
# META }

# CELL ********************

create_temp_views_by_domains(silverPath, p_current_domain)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### CREATE TABLE

# CELL ********************

                                    # ======================
                                    #     calc TABLES
                                    # ======================

createTable([

# calc.bail_custodyrecord
("calc.bail_custodyrecord",
"""CREATE TABLE IF NOT EXISTS calc.bail_custodyrecord (
    ID INT,
    BAILSTARTDATE TIMESTAMP,
    CREATED TIMESTAMP,
    EXPIREDDATE TIMESTAMP,
    FINALISEDATE TIMESTAMP,
    REFERENCE STRING,
    RELEASEDATE TIMESTAMP,
    STATUS STRING,
    TERMINATEDDATE TIMESTAMP,
    DISTRICT_ID INT,
    OIC_ID STRING,
    SUPERVISOR_ID STRING,
    BAILTORETURNDATE DATE,
    OA_REC_PROCESSED_DATE TIMESTAMP,
    OA_REC_CREATED_DATE TIMESTAMP,
    OA_REC_END_DATE TIMESTAMP,
    OA_IS_ACTIVE INT,
    OA_VERSION INT,
    OA_RECORDID STRING
) USING DELTA;
""")

])

                                    # ======================
                                    #     rprt TABLES
                                    # ======================


createTable([
    
# rprt.tbl_d_bail_geo
("rprt.tbl_d_bail_geo",
"""CREATE TABLE IF NOT EXISTS rprt.tbl_d_bail_geo(
    D_BAIL_GEO_DISTRICT_ID INT NOT NULL
    ,LoadID INT
    ,D_BAIL_GEO_DISTRICT STRING
    ,D_BAIL_GEO_AREA_ID INT
    ,D_BAIL_GEO_AREA STRING
    ,D_BAIL_GEO_POLICE_FORCE STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_REC_CREATED_DATE TIMESTAMP
    ,OA_REC_END_DATE TIMESTAMP
    ,OA_IS_ACTIVE INT
    ,OA_VERSION INT
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# rprt.tbl_d_bail
("rprt.tbl_d_bail",
"""CREATE TABLE IF NOT EXISTS rprt.tbl_d_bail(
    D_BAIL_ID INT NOT NULL
    ,LoadID INT
    ,D_BAIL_CUSTODY_ID INT
    ,D_BAIL_TYPE STRING
    ,D_BAIL_TYPE_FULL STRING
    ,D_BAIL_CRIME_TYPE STRING
    ,D_BAIL_CREATED_ON TIMESTAMP
    ,D_BAIL_RELEASE_DATE TIMESTAMP
    ,D_BAIL_RUI_FINALISE_DATE TIMESTAMP
    ,D_BAIL_BAIL_EXPIRY_DATE TIMESTAMP
    ,D_BAIL_BAIL_DATE TIMESTAMP
    ,D_BAIL_TERMINATED_DATE TIMESTAMP
    ,D_BAIL_REVIEW_DUE_DATE TIMESTAMP
    ,D_BAIL_LIVE_OR_HISTORIC STRING
    ,D_BAIL_STAGE STRING
    ,D_BAIL_END_DATE TIMESTAMP
    ,D_BAIL_CUSTODY_REF STRING
    ,D_BAIL_BAIL_TO_RETURN_DATE TIMESTAMP
    ,D_BAIL_SUSPENSION STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_REC_CREATED_DATE TIMESTAMP
    ,OA_REC_END_DATE TIMESTAMP
    ,OA_IS_ACTIVE INT
    ,OA_VERSION INT
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# =============================== F TABLE 

# rprt.tbl_f_bail
("rprt.tbl_f_bail",
"""CREATE TABLE IF NOT EXISTS rprt.tbl_f_bail(
    FK_D_BAIL_CUSTODY_ID INT NOT NULL
    ,LoadID	INT
    ,FK_D_CREATE_DATE_ID INT
    ,FK_D_CREATE_TIME_ID INT
    ,FK_D_CUSTODY_REF STRING
    ,FK_D_BAIL_OIC_ID STRING
    ,F_BAIL_OIC_ID STRING
    ,FK_D_BAIL_GEO_DISTRICT_ID INT
    ,FK_D_BAIL_SUPERVISOR_ID STRING
    ,FK_D_BAIL_AUTHORISING_OFFICER_ID STRING
    ,F_MET_LENGTH_DAYS INT
    ,F_MET_PROXIMITY_EXPIRY INT
    ,BAIL_TYPE STRING
    ,LIVE_OR_HISTORIC STRING
    ,STAFF_MOVE_ID STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_REC_CREATED_DATE TIMESTAMP
    ,OA_REC_END_DATE TIMESTAMP
    ,OA_IS_ACTIVE INT
    ,OA_VERSION INT
    ,OA_RECORDID STRING
)USING DELTA;
"""),


# ============================= B TABLE

# rprt.tbl_b_case_custody
("rprt.tbl_b_case_custody",
"""CREATE TABLE IF NOT EXISTS rprt.tbl_b_case_custody(
    B_CASE_CUSTODY_LINK_ID	INT NOT NULL
    ,LoadID INT
    ,FK_D_CASE_ID	INT
    ,FK_F_CUSTODY_RECORD_ID	INT
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_REC_CREATED_DATE TIMESTAMP
    ,OA_REC_END_DATE TIMESTAMP
    ,OA_IS_ACTIVE INT
    ,OA_VERSION INT
    ,OA_RECORDID STRING
)USING DELTA;
"""),

])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### INGEST GOLD LAYER

# CELL ********************


                                                                                # ==================================
                                                                                # calc -TABLE LOAD 
                                                                                # ==================================

run_parallel_queries_gold([

# calc.bail_custodyrecord
("calc.bail_custodyrecord",
"""WITH version_data AS (
    SELECT ID, MAX(OA_VERSION) AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate 
    FROM calc.bail_custodyrecord 
    GROUP BY ID
),
prepared_source AS (
    SELECT s.*, 
           COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW, 
           CURRENT_TIMESTAMP() AS OA_REC_PROCESSED_DATE_NEW,
           CASE WHEN s.ID = v.ID THEN v.min_createdDate ELSE CURRENT_TIMESTAMP() END AS OA_REC_CREATED_DATE
    FROM temp_bail_custodyrecord s
    LEFT JOIN version_data v ON s.ID = v.ID
)

MERGE INTO calc.bail_custodyrecord AS t
USING prepared_source s
ON t.ID = s.ID AND t.OA_IS_ACTIVE = 1

WHEN MATCHED AND t.OA_RECORDID <> s.OA_RECORDID THEN
    UPDATE SET t.OA_IS_ACTIVE = 0, 
               t.OA_REC_END_DATE = s.OA_REC_PROCESSED_DATE_NEW, 
               t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE_NEW

WHEN NOT MATCHED THEN
    INSERT (ID, BAILSTARTDATE, CREATED, EXPIREDDATE, FINALISEDATE, REFERENCE, RELEASEDATE, STATUS, TERMINATEDDATE, DISTRICT_ID, OIC_ID, SUPERVISOR_ID, BAILTORETURNDATE, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
    VALUES (s.ID, s.BAILSTARTDATE, s.CREATED, s.EXPIREDDATE, s.FINALISEDATE, s.REFERENCE, s.RELEASEDATE, s.STATUS, s.TERMINATEDDATE, s.DISTRICT_ID, s.OIC_ID, s.SUPERVISOR_ID, s.BAILTORETURNDATE, s.OA_REC_PROCESSED_DATE_NEW, s.OA_REC_CREATED_DATE, TO_TIMESTAMP('9999-12-31'), 1, s.OA_VERSION_NEW, s.OA_RECORDID);
""")

])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#========================================
                                                                    # rprt TABLES LOAD -approx xmins
                                                                    # =======================================

run_parallel_queries_gold([
# rprt.tbl_d_bail_geo
    ("rprt.tbl_d_bail_geo",
        """WITH version_data AS(SELECT D_BAIL_GEO_DISTRICT_ID, MAX(OA_VERSION) AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate FROM rprt.tbl_d_bail_geo GROUP BY D_BAIL_GEO_DISTRICT_ID),
    
        -- Step 3: Prepare source data with versions
        prepared_source AS(
        SELECT  s.*, COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW,  CURRENT_TIMESTAMP() AS OA_REC_PROCESSED_DATE_NEW, CASE WHEN s.D_BAIL_GEO_DISTRICT_ID = v.D_BAIL_GEO_DISTRICT_ID THEN v.min_createdDate ELSE CURRENT_TIMESTAMP() END OA_REC_CREATED_DATE
        FROM temp_tbl_bail_geo s
        LEFT JOIN version_data v ON s.D_BAIL_GEO_DISTRICT_ID = v.D_BAIL_GEO_DISTRICT_ID
        WHERE s.OA_REC_PROCESSED_DATE = (SELECT MAX(OA_REC_PROCESSED_DATE) FROM temp_tbl_bail_geo) ) 
        
        MERGE INTO rprt.tbl_d_bail_geo AS t
        USING prepared_source s
        ON t.D_BAIL_GEO_DISTRICT_ID = s.D_BAIL_GEO_DISTRICT_ID AND t.OA_IS_ACTIVE = 1
    
        WHEN MATCHED AND t.OA_RECORDID <> s.OA_RECORDID THEN
            UPDATE SET t.OA_IS_ACTIVE = 0, t.OA_REC_END_DATE = OA_REC_PROCESSED_DATE_NEW, t.OA_REC_PROCESSED_DATE = OA_REC_PROCESSED_DATE_NEW
    
        WHEN NOT MATCHED THEN
        INSERT (D_BAIL_GEO_DISTRICT_ID, LoadID ,D_BAIL_GEO_DISTRICT ,D_BAIL_GEO_AREA_ID ,D_BAIL_GEO_AREA ,D_BAIL_GEO_POLICE_FORCE, 
        OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
        VALUES (s.D_BAIL_GEO_DISTRICT_ID, NULL ,s.D_BAIL_GEO_DISTRICT ,s.D_BAIL_GEO_AREA_ID ,s.D_BAIL_GEO_AREA ,s.D_BAIL_GEO_POLICE_FORCE, 
        s.OA_REC_PROCESSED_DATE_NEW, s.OA_REC_CREATED_DATE, TO_TIMESTAMP('9999-12-31'), 1,s.OA_VERSION_NEW,s.OA_RECORDID)
    """
    ),

# rprt.tbl_d_bail
    ("rprt.tbl_d_bail",
        """WITH version_data AS(SELECT D_BAIL_ID, MAX(OA_VERSION) AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate FROM rprt.tbl_d_bail GROUP BY D_BAIL_ID),
    
        -- Step 3: Prepare source data with versions
        prepared_source AS(
        SELECT  s.*, COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW,  CURRENT_TIMESTAMP() AS OA_REC_PROCESSED_DATE_NEW, CASE WHEN s.D_BAIL_ID = v.D_BAIL_ID THEN v.min_createdDate ELSE CURRENT_TIMESTAMP() END OA_REC_CREATED_DATE
        FROM temp_tbl_bail s
        LEFT JOIN version_data v ON s.D_BAIL_ID = v.D_BAIL_ID
        WHERE s.OA_REC_PROCESSED_DATE = (SELECT MAX(OA_REC_PROCESSED_DATE) FROM temp_tbl_bail) ) 
        
        MERGE INTO rprt.tbl_d_bail AS t
        USING prepared_source s
        ON t.D_BAIL_ID = s.D_BAIL_ID AND t.OA_IS_ACTIVE = 1
    
        WHEN MATCHED AND t.OA_RECORDID <> s.OA_RECORDID THEN
            UPDATE SET t.OA_IS_ACTIVE = 0, t.OA_REC_END_DATE = OA_REC_PROCESSED_DATE_NEW, t.OA_REC_PROCESSED_DATE = OA_REC_PROCESSED_DATE_NEW
    
        WHEN NOT MATCHED THEN
        INSERT (D_BAIL_ID,LoadID,D_BAIL_CUSTODY_ID,D_BAIL_TYPE,D_BAIL_TYPE_FULL,D_BAIL_CRIME_TYPE,D_BAIL_CREATED_ON,D_BAIL_RELEASE_DATE,D_BAIL_RUI_FINALISE_DATE,D_BAIL_BAIL_EXPIRY_DATE,
        D_BAIL_BAIL_DATE,D_BAIL_TERMINATED_DATE,D_BAIL_REVIEW_DUE_DATE,D_BAIL_LIVE_OR_HISTORIC,D_BAIL_STAGE,D_BAIL_END_DATE,D_BAIL_CUSTODY_REF,D_BAIL_BAIL_TO_RETURN_DATE,D_BAIL_SUSPENSION,
        OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
        VALUES (s.D_BAIL_ID,NULL,s.D_BAIL_CUSTODY_ID,s.D_BAIL_TYPE,s.D_BAIL_TYPE_FULL,s.D_BAIL_CRIME_TYPE,s.D_BAIL_CREATED_ON,s.D_BAIL_RELEASE_DATE,s.D_BAIL_RUI_FINALISE_DATE,s.D_BAIL_BAIL_EXPIRY_DATE,
        s.D_BAIL_BAIL_DATE,s.D_BAIL_TERMINATED_DATE,s.D_BAIL_REVIEW_DUE_DATE,s.D_BAIL_LIVE_OR_HISTORIC,s.D_BAIL_STAGE,s.D_BAIL_END_DATE,s.D_BAIL_CUSTODY_REF,s.D_BAIL_BAIL_TO_RETURN_DATE,s.D_BAIL_SUSPENSION,
        s.OA_REC_PROCESSED_DATE_NEW, s.OA_REC_CREATED_DATE, TO_TIMESTAMP('9999-12-31'), 1,s.OA_VERSION_NEW,s.OA_RECORDID)        
        """)
    
])

                                                                                # ==================================
                                                                                # F-TABLE 
#                                                                               # ==================================

run_parallel_queries_gold([   
# rprt.tbl_f_bail
("rprt.tbl_f_bail",
        """WITH version_data AS (
    SELECT FK_D_BAIL_CUSTODY_ID, MAX(OA_VERSION) AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate 
    FROM rprt.tbl_f_bail 
    GROUP BY FK_D_BAIL_CUSTODY_ID
),

f_bail_pre AS (
    SELECT DISTINCT
        BCRa.id AS ID,
        CASE
            WHEN BCRa.status = 'FINALISED' THEN 'Historic'
            ELSE 'Live'
        END AS LIVE_OR_HISTORIC,
        CASE
            -- Account for data excluded from dashboard
            WHEN BCRa.status = 'BAIL APPROVED' THEN 'DQ'
            WHEN BCRa.status = 'FINALISED' AND COALESCE(BCRa.bailStartDate, BCRa.releaseDate) IS NULL THEN 'DQ'
            WHEN BCRa.status = 'BAILED' AND BCRa.releaseDate IS NOT NULL AND BCRa.bailStartDate IS NULL THEN 'CPS BAIL'
            -- Data required in dashboard
            WHEN BCRa.finaliseDate <= COALESCE(BCRa.terminatedDate, '00:00:00') THEN 'BAIL'
            WHEN BCRa.finaliseDate <= COALESCE(BCRa.expiredDate, '00:00:00') THEN 'BAIL'
            WHEN BCRa.expiredDate IS NOT NULL THEN 'BAIL TO RUI'
            WHEN BCRa.terminatedDate IS NOT NULL THEN 'BAIL TO RUI'
            WHEN BCRa.bailStartDate IS NOT NULL THEN 'BAIL'
            WHEN BCRa.releaseDate IS NULL THEN 'DQ'
            ELSE 'RUI'
        END AS BAIL_TYPE
    FROM temp_bail_custodyrecord BCRa
),

-- SELECT * FROM f_bail_pre LIMIT 5;


f_bailsource AS (
    SELECT DISTINCT --BCR.*
        BCR.id AS FK_D_BAIL_CUSTODY_ID,
        COALESCE(D.DateID, -1) AS FK_D_CREATE_DATE_ID,
        COALESCE(T.TimeID, -1) AS FK_D_CREATE_TIME_ID,
        COALESCE(BCR.reference, '-1') AS FK_D_CUSTODY_REF,
        COALESCE(O.PERSONNELNUMBER, '-1') AS FK_D_BAIL_OIC_ID,
        COALESCE(UUS1.username, '-1') AS F_BAIL_OIC_ID,
        COALESCE(G.D_BAIL_GEO_DISTRICT_ID, -1) AS FK_D_BAIL_GEO_DISTRICT_ID,
        COALESCE(UUS2.username, '-1') AS FK_D_BAIL_SUPERVISOR_ID,
        COALESCE(UUS3.username, '-1') AS FK_D_BAIL_AUTHORISING_OFFICER_ID,
        CASE
            WHEN fbp.LIVE_OR_HISTORIC = 'Live' AND fbp.BAIL_TYPE = 'BAIL' THEN
                DATEDIFF(CURRENT_DATE(), BCR.bailStartDate)
            WHEN fbp.LIVE_OR_HISTORIC = 'Live' AND fbp.BAIL_TYPE = 'BAIL TO RUI' THEN
                DATEDIFF(CURRENT_DATE(), BCR.bailStartDate)
            WHEN fbp.LIVE_OR_HISTORIC = 'Live' AND fbp.BAIL_TYPE = 'RUI' THEN
                DATEDIFF(CURRENT_DATE(), BCR.releaseDate)
            WHEN fbp.LIVE_OR_HISTORIC = 'Historic' AND fbp.BAIL_TYPE = 'BAIL' THEN
                DATEDIFF(
                    COALESCE(
                        BCR.finaliseDate,
                        BCR.expiredDate,
                        BCR.terminatedDate,
                        BCR.releaseDate
                    ),
                    BCR.bailStartDate
                )
            WHEN fbp.LIVE_OR_HISTORIC = 'Historic' AND fbp.BAIL_TYPE = 'BAIL TO RUI' THEN
                DATEDIFF(
                    COALESCE(
                        BCR.finaliseDate,
                        BCR.expiredDate,
                        BCR.terminatedDate
                    ),
                    BCR.bailStartDate
                )
            WHEN fbp.LIVE_OR_HISTORIC = 'Historic' AND fbp.BAIL_TYPE = 'RUI' THEN
                DATEDIFF(BCR.finaliseDate, BCR.releaseDate)
        END AS F_MET_LENGTH_DAYS,
        CASE
            WHEN fbp.LIVE_OR_HISTORIC = 'Live' AND fbp.BAIL_TYPE = 'BAIL' THEN 
                28 - DATEDIFF(CURRENT_DATE(), BCR.bailStartDate)
            WHEN fbp.LIVE_OR_HISTORIC = 'Live' AND fbp.BAIL_TYPE = 'RUI' THEN
                CASE  
                    WHEN MONTHS_BETWEEN(CURRENT_DATE(), BCR.releaseDate) <= 3 THEN 
                        90 - DATEDIFF(CURRENT_DATE(), BCR.releaseDate)
                    ELSE 
                        182 - DATEDIFF(CURRENT_DATE(), BCR.releaseDate)
                END
            WHEN fbp.LIVE_OR_HISTORIC = 'Live' AND fbp.BAIL_TYPE = 'BAIL TO RUI' THEN
                DATEDIFF(CURRENT_DATE(), COALESCE(BCR.expiredDate, BCR.terminatedDate))
            ELSE NULL
        END AS F_MET_PROXIMITY_EXPIRY,
        CASE WHEN fbp.BAIL_TYPE = 'BAIL TO RUI' THEN 'RUI' ELSE fbp.BAIL_TYPE END AS BAIL_TYPE,
        fbp.LIVE_OR_HISTORIC,
        sh.STAFF_MOVE_ID AS STAFF_MOVE_ID,
        ROW_NUMBER() OVER(PARTITION BY BCR.id ORDER BY T.TimeID DESC) AS f_bail_duplicate,
        COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW,
        CURRENT_TIMESTAMP() AS OA_REC_PROCESSED_DATE_NEW,
        BCR.OA_REC_PROCESSED_DATE,
        CASE 
            WHEN BCR.id = v.FK_D_BAIL_CUSTODY_ID THEN v.min_createdDate 
            ELSE CURRENT_TIMESTAMP() 
        END AS OA_REC_CREATED_DATE,
        BCR.OA_RECORDID
    FROM temp_bail_custodyrecord BCR
    INNER JOIN f_bail_pre fbp ON BCR.id = fbp.ID
    LEFT JOIN version_data v ON BCR.id = v.FK_D_BAIL_CUSTODY_ID
    LEFT JOIN (
        SELECT 
            CUSTODY_ID, 
            officerApproving_id, 
            ROW_NUMBER() OVER (PARTITION BY BRI_ID ORDER BY CUSTODY_ID DESC) as ROW_NO
        FROM temp_bail_bailRequestInternal 
    ) BRI ON BCR.ID = BRI.CUSTODY_ID AND BRI.ROW_NO = 1
    LEFT JOIN temp_bail_UTIL_USER_SNAPSHOT UUS1 ON BCR.oic_id = UUS1.id
    LEFT JOIN temp_bail_UTIL_USER_SNAPSHOT UUS2 ON BCR.supervisor_id = UUS2.id
    LEFT JOIN temp_bail_UTIL_USER_SNAPSHOT UUS3 ON BRI.officerApproving_id = UUS3.id
    LEFT JOIN rprt.tbl_d_date D ON CAST(BCR.CREATED AS DATE) = D.Date
    LEFT JOIN rprt.tbl_d_time T ON CAST(BCR.CREATED AS STRING) = CAST(T.FullTimeString24 AS STRING)
    LEFT JOIN rprt.tbl_d_org O ON O.PERSONNELNUMBER = UUS1.username
    LEFT JOIN rprt.tbl_d_bail_geo G ON BCR.district_id = G.D_BAIL_GEO_DISTRICT_ID 
    LEFT JOIN rprt.tbl_d_staff_history sh 
        ON O.PERSONNELNUMBER = sh.PERSONNELNUMBER 
        AND CAST(BCR.CREATED AS DATE) BETWEEN sh.StartDate AND sh.EndDate
    WHERE fbp.BAIL_TYPE NOT IN ('DQ', 'CPS BAIL')
        AND BCR.id IS NOT NULL
        AND BCR.id != '0'
)

-- SELECT * FROM f_bailsource LIMIT 10;

,finalsource AS (
    SELECT
        FK_D_BAIL_CUSTODY_ID,
        FK_D_CREATE_DATE_ID,
        FK_D_CREATE_TIME_ID,
        FK_D_CUSTODY_REF,
        FK_D_BAIL_OIC_ID,
        F_BAIL_OIC_ID,
        FK_D_BAIL_GEO_DISTRICT_ID,
        FK_D_BAIL_SUPERVISOR_ID,
        FK_D_BAIL_AUTHORISING_OFFICER_ID,
        F_MET_LENGTH_DAYS,
        F_MET_PROXIMITY_EXPIRY,
        BAIL_TYPE,
        LIVE_OR_HISTORIC,
        STAFF_MOVE_ID,
        OA_VERSION_NEW,
        OA_REC_PROCESSED_DATE_NEW,
        OA_REC_CREATED_DATE,
        OA_RECORDID
    FROM f_bailsource
    WHERE f_bail_duplicate = 1
)
-- SELECT * FROM finalsource LIMIT 10;

MERGE INTO rprt.tbl_f_bail AS t
USING finalsource AS s
ON t.FK_D_BAIL_CUSTODY_ID = s.FK_D_BAIL_CUSTODY_ID AND t.OA_IS_ACTIVE = 1

WHEN MATCHED AND t.OA_RECORDID <> s.OA_RECORDID THEN
    UPDATE SET 
        t.OA_IS_ACTIVE = 0, 
        t.OA_REC_END_DATE = s.OA_REC_PROCESSED_DATE_NEW, 
        t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE_NEW

WHEN NOT MATCHED THEN
    INSERT (
        FK_D_BAIL_CUSTODY_ID, LoadID, FK_D_CREATE_DATE_ID, FK_D_CREATE_TIME_ID, 
        FK_D_CUSTODY_REF, FK_D_BAIL_OIC_ID, F_BAIL_OIC_ID, 
        FK_D_BAIL_GEO_DISTRICT_ID, FK_D_BAIL_SUPERVISOR_ID, FK_D_BAIL_AUTHORISING_OFFICER_ID, 
        F_MET_LENGTH_DAYS, F_MET_PROXIMITY_EXPIRY, BAIL_TYPE, LIVE_OR_HISTORIC, STAFF_MOVE_ID,
        OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID
    )
    VALUES (
        s.FK_D_BAIL_CUSTODY_ID, NULL, s.FK_D_CREATE_DATE_ID, s.FK_D_CREATE_TIME_ID, 
        s.FK_D_CUSTODY_REF, s.FK_D_BAIL_OIC_ID, s.F_BAIL_OIC_ID, 
        s.FK_D_BAIL_GEO_DISTRICT_ID, s.FK_D_BAIL_SUPERVISOR_ID, s.FK_D_BAIL_AUTHORISING_OFFICER_ID, 
        s.F_MET_LENGTH_DAYS, s.F_MET_PROXIMITY_EXPIRY, s.BAIL_TYPE, s.LIVE_OR_HISTORIC, s.STAFF_MOVE_ID, 
        s.OA_REC_PROCESSED_DATE_NEW, s.OA_REC_CREATED_DATE, TIMESTAMP('9999-12-31 23:59:59'), 1, s.OA_VERSION_NEW, s.OA_RECORDID
    )

        """),
])


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### LOGGING

# CELL ********************

# finalise_notebook_logging()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### TEST

# CELL ********************

# MAGIC %%sql
# MAGIC WITH version_data AS (
# MAGIC     SELECT 
# MAGIC         FK_D_BAIL_CUSTODY_ID, 
# MAGIC         MAX(OA_VERSION) AS max_version, 
# MAGIC         MIN(OA_REC_CREATED_DATE) AS min_createdDate 
# MAGIC     FROM rprt.tbl_f_bail 
# MAGIC     GROUP BY FK_D_BAIL_CUSTODY_ID
# MAGIC ),
# MAGIC 
# MAGIC f_bail_pre AS (
# MAGIC     SELECT DISTINCT
# MAGIC         BCRa.id AS ID,
# MAGIC         CASE
# MAGIC             WHEN BCRa.status = 'FINALISED' THEN 'Historic'
# MAGIC             ELSE 'Live'
# MAGIC         END AS LIVE_OR_HISTORIC,
# MAGIC         CASE
# MAGIC             -- Account for data excluded from dashboard
# MAGIC             WHEN BCRa.status = 'BAIL APPROVED' THEN 'DQ'
# MAGIC             WHEN BCRa.status = 'FINALISED' AND COALESCE(BCRa.bailStartDate, BCRa.releaseDate) IS NULL THEN 'DQ'
# MAGIC             WHEN BCRa.status = 'BAILED' AND BCRa.releaseDate IS NOT NULL AND BCRa.bailStartDate IS NULL THEN 'CPS BAIL'
# MAGIC             -- Data required in dashboard
# MAGIC             WHEN BCRa.finaliseDate <= COALESCE(BCRa.terminatedDate, '00:00:00') THEN 'BAIL'
# MAGIC             WHEN BCRa.finaliseDate <= COALESCE(BCRa.expiredDate, '00:00:00') THEN 'BAIL'
# MAGIC             WHEN BCRa.expiredDate IS NOT NULL THEN 'BAIL TO RUI'
# MAGIC             WHEN BCRa.terminatedDate IS NOT NULL THEN 'BAIL TO RUI'
# MAGIC             WHEN BCRa.bailStartDate IS NOT NULL THEN 'BAIL'
# MAGIC             WHEN BCRa.releaseDate IS NULL THEN 'DQ'
# MAGIC             ELSE 'RUI'
# MAGIC         END AS BAIL_TYPE
# MAGIC     FROM temp_bail_custodyrecord BCRa
# MAGIC ),
# MAGIC 
# MAGIC -- SELECT * FROM f_bail_pre LIMIT 5;
# MAGIC 
# MAGIC 
# MAGIC f_bailsource AS (
# MAGIC     SELECT DISTINCT --BCR.*
# MAGIC         BCR.id AS FK_D_BAIL_CUSTODY_ID,
# MAGIC         COALESCE(D.DateID, -1) AS FK_D_CREATE_DATE_ID,
# MAGIC         COALESCE(T.TimeID, -1) AS FK_D_CREATE_TIME_ID,
# MAGIC         COALESCE(BCR.reference, '-1') AS FK_D_CUSTODY_REF,
# MAGIC         COALESCE(O.PERSONNELNUMBER, '-1') AS FK_D_BAIL_OIC_ID,
# MAGIC         COALESCE(UUS1.username, '-1') AS F_BAIL_OIC_ID,
# MAGIC         COALESCE(G.D_BAIL_GEO_DISTRICT_ID, -1) AS FK_D_BAIL_GEO_DISTRICT_ID,
# MAGIC         COALESCE(UUS2.username, '-1') AS FK_D_BAIL_SUPERVISOR_ID,
# MAGIC         COALESCE(UUS3.username, '-1') AS FK_D_BAIL_AUTHORISING_OFFICER_ID,
# MAGIC         CASE
# MAGIC             WHEN fbp.LIVE_OR_HISTORIC = 'Live' AND fbp.BAIL_TYPE = 'BAIL' THEN
# MAGIC                 DATEDIFF(CURRENT_DATE(), BCR.bailStartDate)
# MAGIC             WHEN fbp.LIVE_OR_HISTORIC = 'Live' AND fbp.BAIL_TYPE = 'BAIL TO RUI' THEN
# MAGIC                 DATEDIFF(CURRENT_DATE(), BCR.bailStartDate)
# MAGIC             WHEN fbp.LIVE_OR_HISTORIC = 'Live' AND fbp.BAIL_TYPE = 'RUI' THEN
# MAGIC                 DATEDIFF(CURRENT_DATE(), BCR.releaseDate)
# MAGIC             WHEN fbp.LIVE_OR_HISTORIC = 'Historic' AND fbp.BAIL_TYPE = 'BAIL' THEN
# MAGIC                 DATEDIFF(
# MAGIC                     COALESCE(
# MAGIC                         BCR.finaliseDate,
# MAGIC                         BCR.expiredDate,
# MAGIC                         BCR.terminatedDate,
# MAGIC                         BCR.releaseDate
# MAGIC                     ),
# MAGIC                     BCR.bailStartDate
# MAGIC                 )
# MAGIC             WHEN fbp.LIVE_OR_HISTORIC = 'Historic' AND fbp.BAIL_TYPE = 'BAIL TO RUI' THEN
# MAGIC                 DATEDIFF(
# MAGIC                     COALESCE(
# MAGIC                         BCR.finaliseDate,
# MAGIC                         BCR.expiredDate,
# MAGIC                         BCR.terminatedDate
# MAGIC                     ),
# MAGIC                     BCR.bailStartDate
# MAGIC                 )
# MAGIC             WHEN fbp.LIVE_OR_HISTORIC = 'Historic' AND fbp.BAIL_TYPE = 'RUI' THEN
# MAGIC                 DATEDIFF(BCR.finaliseDate, BCR.releaseDate)
# MAGIC         END AS F_MET_LENGTH_DAYS,
# MAGIC         CASE
# MAGIC             WHEN fbp.LIVE_OR_HISTORIC = 'Live' AND fbp.BAIL_TYPE = 'BAIL' THEN 
# MAGIC                 28 - DATEDIFF(CURRENT_DATE(), BCR.bailStartDate)
# MAGIC             WHEN fbp.LIVE_OR_HISTORIC = 'Live' AND fbp.BAIL_TYPE = 'RUI' THEN
# MAGIC                 CASE  
# MAGIC                     WHEN MONTHS_BETWEEN(CURRENT_DATE(), BCR.releaseDate) <= 3 THEN 
# MAGIC                         90 - DATEDIFF(CURRENT_DATE(), BCR.releaseDate)
# MAGIC                     ELSE 
# MAGIC                         182 - DATEDIFF(CURRENT_DATE(), BCR.releaseDate)
# MAGIC                 END
# MAGIC             WHEN fbp.LIVE_OR_HISTORIC = 'Live' AND fbp.BAIL_TYPE = 'BAIL TO RUI' THEN
# MAGIC                 DATEDIFF(CURRENT_DATE(), COALESCE(BCR.expiredDate, BCR.terminatedDate))
# MAGIC             ELSE NULL
# MAGIC         END AS F_MET_PROXIMITY_EXPIRY,
# MAGIC         CASE WHEN fbp.BAIL_TYPE = 'BAIL TO RUI' THEN 'RUI' ELSE fbp.BAIL_TYPE END AS BAIL_TYPE,
# MAGIC         fbp.LIVE_OR_HISTORIC,
# MAGIC         sh.STAFFMOVEID AS STAFF_MOVE_ID,
# MAGIC         ROW_NUMBER() OVER(PARTITION BY BCR.id ORDER BY T.TimeID DESC) AS f_bail_duplicate,
# MAGIC         COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW,
# MAGIC         CURRENT_TIMESTAMP() AS OA_REC_PROCESSED_DATE_NEW,
# MAGIC         BCR.OA_REC_PROCESSED_DATE,
# MAGIC         CASE 
# MAGIC             WHEN BCR.id = v.FK_D_BAIL_CUSTODY_ID THEN v.min_createdDate 
# MAGIC             ELSE CURRENT_TIMESTAMP() 
# MAGIC         END AS OA_REC_CREATED_DATE,
# MAGIC         BCR.OA_RECORDID
# MAGIC     FROM temp_bail_custodyrecord BCR
# MAGIC     INNER JOIN f_bail_pre fbp ON BCR.id = fbp.ID
# MAGIC     LEFT JOIN version_data v ON BCR.id = v.FK_D_BAIL_CUSTODY_ID
# MAGIC     LEFT JOIN (
# MAGIC         SELECT 
# MAGIC             CUSTODY_ID, 
# MAGIC             officerApproving_id, 
# MAGIC             ROW_NUMBER() OVER (PARTITION BY BRI_ID ORDER BY CUSTODY_ID DESC) as ROW_NO
# MAGIC         FROM temp_bail_bailRequestInternal 
# MAGIC     ) BRI ON BCR.ID = BRI.CUSTODY_ID AND BRI.ROW_NO = 1
# MAGIC     LEFT JOIN temp_bail_UTIL_USER_SNAPSHOT UUS1 ON BCR.oic_id = UUS1.id
# MAGIC     LEFT JOIN temp_bail_UTIL_USER_SNAPSHOT UUS2 ON BCR.supervisor_id = UUS2.id
# MAGIC     LEFT JOIN temp_bail_UTIL_USER_SNAPSHOT UUS3 ON BRI.officerApproving_id = UUS3.id
# MAGIC     LEFT JOIN rprt.tbl_d_date D ON CAST(BCR.CREATED AS DATE) = D.Date
# MAGIC     LEFT JOIN rprt.tbl_d_time T ON CAST(BCR.CREATED AS STRING) = CAST(T.FullTimeString24 AS STRING)
# MAGIC     LEFT JOIN rprt.tbl_d_org O ON O.PERSONNELNUMBER = UUS1.username
# MAGIC     LEFT JOIN rprt.tbl_d_bail_geo G ON BCR.district_id = G.D_BAIL_GEO_DISTRICT_ID 
# MAGIC     LEFT JOIN rprt.tbl_d_staff_history sh 
# MAGIC         ON O.PERSONNELNUMBER = sh.PERSONNELNUMBER 
# MAGIC         AND CAST(BCR.CREATED AS DATE) BETWEEN sh.StartDate AND sh.EndDate
# MAGIC     WHERE fbp.BAIL_TYPE NOT IN ('DQ', 'CPS BAIL')
# MAGIC         AND BCR.id IS NOT NULL
# MAGIC         AND BCR.id != '0'
# MAGIC )
# MAGIC 
# MAGIC -- SELECT * FROM f_bailsource LIMIT 10;
# MAGIC 
# MAGIC ,finalsource AS (
# MAGIC     SELECT
# MAGIC         FK_D_BAIL_CUSTODY_ID,
# MAGIC         FK_D_CREATE_DATE_ID,
# MAGIC         FK_D_CREATE_TIME_ID,
# MAGIC         FK_D_CUSTODY_REF,
# MAGIC         FK_D_BAIL_OIC_ID,
# MAGIC         F_BAIL_OIC_ID,
# MAGIC         FK_D_BAIL_GEO_DISTRICT_ID,
# MAGIC         FK_D_BAIL_SUPERVISOR_ID,
# MAGIC         FK_D_BAIL_AUTHORISING_OFFICER_ID,
# MAGIC         F_MET_LENGTH_DAYS,
# MAGIC         F_MET_PROXIMITY_EXPIRY,
# MAGIC         BAIL_TYPE,
# MAGIC         LIVE_OR_HISTORIC,
# MAGIC         STAFF_MOVE_ID,
# MAGIC         OA_VERSION_NEW,
# MAGIC         OA_REC_PROCESSED_DATE_NEW,
# MAGIC         OA_REC_CREATED_DATE,
# MAGIC         OA_RECORDID
# MAGIC     FROM f_bailsource
# MAGIC     WHERE f_bail_duplicate = 1
# MAGIC )
# MAGIC -- SELECT * FROM finalsource LIMIT 10;
# MAGIC 
# MAGIC MERGE INTO rprt.tbl_f_bail AS t
# MAGIC USING finalsource AS s
# MAGIC ON t.FK_D_BAIL_CUSTODY_ID = s.FK_D_BAIL_CUSTODY_ID AND t.OA_IS_ACTIVE = 1
# MAGIC 
# MAGIC WHEN MATCHED AND t.OA_RECORDID <> s.OA_RECORDID THEN
# MAGIC     UPDATE SET 
# MAGIC         t.OA_IS_ACTIVE = 0, 
# MAGIC         t.OA_REC_END_DATE = s.OA_REC_PROCESSED_DATE_NEW, 
# MAGIC         t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE_NEW
# MAGIC 
# MAGIC WHEN NOT MATCHED THEN
# MAGIC     INSERT (
# MAGIC         FK_D_BAIL_CUSTODY_ID, LoadID, FK_D_CREATE_DATE_ID, FK_D_CREATE_TIME_ID, 
# MAGIC         FK_D_CUSTODY_REF, FK_D_BAIL_OIC_ID, F_BAIL_OIC_ID, 
# MAGIC         FK_D_BAIL_GEO_DISTRICT_ID, FK_D_BAIL_SUPERVISOR_ID, FK_D_BAIL_AUTHORISING_OFFICER_ID, 
# MAGIC         F_MET_LENGTH_DAYS, F_MET_PROXIMITY_EXPIRY, BAIL_TYPE, LIVE_OR_HISTORIC, STAFF_MOVE_ID,
# MAGIC         OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID
# MAGIC     )
# MAGIC     VALUES (
# MAGIC         s.FK_D_BAIL_CUSTODY_ID, NULL, s.FK_D_CREATE_DATE_ID, s.FK_D_CREATE_TIME_ID, 
# MAGIC         s.FK_D_CUSTODY_REF, s.FK_D_BAIL_OIC_ID, s.F_BAIL_OIC_ID, 
# MAGIC         s.FK_D_BAIL_GEO_DISTRICT_ID, s.FK_D_BAIL_SUPERVISOR_ID, s.FK_D_BAIL_AUTHORISING_OFFICER_ID, 
# MAGIC         s.F_MET_LENGTH_DAYS, s.F_MET_PROXIMITY_EXPIRY, s.BAIL_TYPE, s.LIVE_OR_HISTORIC, s.STAFF_MOVE_ID, 
# MAGIC         s.OA_REC_PROCESSED_DATE_NEW, s.OA_REC_CREATED_DATE, TIMESTAMP('9999-12-31 23:59:59'), 1, s.OA_VERSION_NEW, s.OA_RECORDID
# MAGIC     )
# MAGIC  

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC select distinct  D_BAIL_CRIME_TYPE
# MAGIC -- delete 
# MAGIC from rprt.tbl_d_bail;
# MAGIC 


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC WITH version_data AS(SELECT D_BAIL_ID, MAX(OA_VERSION) AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate FROM rprt.tbl_d_bail GROUP BY D_BAIL_ID),
# MAGIC     
# MAGIC         -- Step 3: Prepare source data with versions
# MAGIC         prepared_source AS(
# MAGIC         SELECT  s.*, COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW,  CURRENT_TIMESTAMP() AS OA_REC_PROCESSED_DATE_NEW, CASE WHEN s.D_BAIL_ID = v.D_BAIL_ID THEN v.min_createdDate ELSE CURRENT_TIMESTAMP() END OA_REC_CREATED_DATE
# MAGIC         FROM temp_tbl_bail s
# MAGIC         LEFT JOIN version_data v ON s.D_BAIL_ID = v.D_BAIL_ID
# MAGIC         WHERE s.OA_REC_PROCESSED_DATE = (SELECT MAX(OA_REC_PROCESSED_DATE) FROM temp_tbl_bail) 
# MAGIC         )
# MAGIC 
# MAGIC         -- select * from  prepared_source where D_BAIL_CRIME_TYPE is not null;
# MAGIC         
# MAGIC      
# MAGIC         MERGE INTO rprt.tbl_d_bail AS t
# MAGIC         USING prepared_source s
# MAGIC         ON t.D_BAIL_ID = s.D_BAIL_ID AND t.OA_IS_ACTIVE = 1
# MAGIC     
# MAGIC         WHEN MATCHED AND t.OA_RECORDID <> s.OA_RECORDID THEN
# MAGIC             UPDATE SET t.OA_IS_ACTIVE = 0, t.OA_REC_END_DATE = OA_REC_PROCESSED_DATE_NEW, t.OA_REC_PROCESSED_DATE = OA_REC_PROCESSED_DATE_NEW
# MAGIC     
# MAGIC         WHEN NOT MATCHED THEN
# MAGIC         INSERT (D_BAIL_ID,D_BAIL_CUSTODY_ID,D_BAIL_TYPE,D_BAIL_TYPE_FULL,D_BAIL_CRIME_TYPE,D_BAIL_CREATED_ON,D_BAIL_RELEASE_DATE,D_BAIL_RUI_FINALISE_DATE,D_BAIL_BAIL_EXPIRY_DATE,
# MAGIC         D_BAIL_BAIL_DATE,D_BAIL_TERMINATED_DATE,D_BAIL_REVIEW_DUE_DATE,D_BAIL_LIVE_OR_HISTORIC,D_BAIL_STAGE,D_BAIL_END_DATE,D_BAIL_CUSTODY_REF,D_BAIL_BAIL_TO_RETURN_DATE,D_BAIL_SUSPENSION,
# MAGIC         OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
# MAGIC         VALUES (s.D_BAIL_ID,s.D_BAIL_CUSTODY_ID,s.D_BAIL_TYPE,s.D_BAIL_TYPE_FULL,s.D_BAIL_CRIME_TYPE,s.D_BAIL_CREATED_ON,s.D_BAIL_RELEASE_DATE,s.D_BAIL_RUI_FINALISE_DATE,s.D_BAIL_BAIL_EXPIRY_DATE,
# MAGIC         s.D_BAIL_BAIL_DATE,s.D_BAIL_TERMINATED_DATE,s.D_BAIL_REVIEW_DUE_DATE,s.D_BAIL_LIVE_OR_HISTORIC,s.D_BAIL_STAGE,s.D_BAIL_END_DATE,s.D_BAIL_CUSTODY_REF,s.D_BAIL_BAIL_TO_RETURN_DATE,s.D_BAIL_SUSPENSION,
# MAGIC         s.OA_REC_PROCESSED_DATE_NEW, s.OA_REC_CREATED_DATE, TO_TIMESTAMP('9999-12-31'), 1,s.OA_VERSION_NEW,s.OA_RECORDID)  


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

finalise_notebook_logging()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
