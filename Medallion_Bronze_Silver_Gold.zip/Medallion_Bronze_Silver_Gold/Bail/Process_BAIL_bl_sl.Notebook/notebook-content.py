# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "6a459f05-6527-49bd-8600-74065f42a607",
# META       "default_lakehouse_name": "LH_200_Silver_Test",
# META       "default_lakehouse_workspace_id": "a3e4d0e6-6b32-498b-addc-1629a4b29a47",
# META       "known_lakehouses": [
# META         {
# META           "id": "6a459f05-6527-49bd-8600-74065f42a607"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# # **BAIL SILVER LOAD**

# MARKDOWN ********************

# ###### CONFIG

# CELL ********************

# get domain from pipeline
current_domain = ["Bail"]

try:
    current_domain - mssparkutils.notebook.getArgument("current_domain")
except:
    pass

print(f"STARTING {current_domain} PROCESSING")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./config_silver_layer

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

create_temp_views_by_domain(db_bronzeFile_Paths, current_domain)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### CREATE TABLE

# CELL ********************


bail_tables = createTable([

# bail_UTIL_DISTRICT
("bail_UTIL_DISTRICT",
"""CREATE TABLE IF NOT EXISTS bail_UTIL_DISTRICT(
    BAIL_UTIL_DISTRICT_ID INT
    ,DISTRICT STRING
    ,AREA_ID INT
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# bail_UTIL_AREA
("bail_UTIL_AREA",
"""CREATE TABLE IF NOT EXISTS bail_UTIL_AREA(
    BAIL_UTIL_AREA_ID INT
    ,POLICE_FORCE STRING
    ,AREA STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# bail_custodyrecord
("bail_custodyrecord",
"""CREATE TABLE IF NOT EXISTS bail_custodyrecord(
    ID	INT
    ,BAILSTARTDATE	TIMESTAMP
    ,CREATED	TIMESTAMP
    ,EXPIREDDATE	TIMESTAMP
    ,FINALISEDATE	TIMESTAMP
    ,REFERENCE	STRING
    ,RELEASEDATE	TIMESTAMP
    ,STATUS	STRING
    ,TERMINATEDDATE	TIMESTAMP
    ,DISTRICT_ID	INT
    ,OIC_ID	STRING
    ,SUPERVISOR_ID	STRING
    ,BAILTORETURNDATE	DATE
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
    )USING DELTA;
"""),

# bail_UTIL_USER_SNAPSHOT
("bail_UTIL_USER_SNAPSHOT",
"""CREATE TABLE IF NOT EXISTS bail_UTIL_USER_SNAPSHOT(
	ID INT
	,USERNAME STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
	,OA_RECORDID STRING
)USING DELTA;
"""),

# bail_bailRequestInternal
("bail_bailRequestInternal",
"""CREATE TABLE IF NOT EXISTS bail_bailRequestInternal(
	 BRI_ID INT 
	,OFFICERAPPROVING_ID STRING
	,CUSTODY_ID INT
	,ROW_NO INT
	,OA_REC_PROCESSED_DATE TIMESTAMP
	,OA_RECORDID STRING
)USING DELTA;
"""),

# bail_review
("bail_review",
"""CREATE TABLE IF NOT EXISTS bail_review(
	 BAIL_REVIEW_ID	INT
	,ID	STRING
	,REVIEWEDON	TIMESTAMP
	,CUSTODY_ID	INT
	,ROW_NO	INT
	,OA_REC_PROCESSED_DATE TIMESTAMP
	,OA_RECORDID STRING
)USING DELTA;
"""),

# bail_BailSuspension
("bail_BailSuspension",
 """CREATE TABLE IF NOT EXISTS bail_BailSuspension(
   ID INT
  ,RESUMEDATE	DATE
  ,SUSPENDDATE	DATE
  ,RESUMEDBY_ID	INT
  ,SUSPENDEDBY_ID	INT
  ,CUSTODY_ID	INT
  ,OA_REC_PROCESSED_DATE TIMESTAMP
  ,OA_RECORDID STRING
  )USING DELTA;
 """),

# tbl_bail_geo
("tbl_bail_geo",
"""CREATE TABLE IF NOT EXISTS tbl_bail_geo(
    D_BAIL_GEO_DISTRICT_ID INT
    ,D_BAIL_GEO_DISTRICT STRING
    ,D_BAIL_GEO_AREA_ID INT
    ,D_BAIL_GEO_AREA STRING
    ,D_BAIL_GEO_POLICE_FORCE STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# tbl_bail  -- Lewis to confirm if the trade offs for ,D_BAIL_CRIME_TYPE is acceptable. Aside that work done.
("tbl_bail",
"""CREATE TABLE IF NOT EXISTS tbl_bail(
    D_BAIL_ID INT
    ,D_BAIL_CUSTODY_ID INT
    ,D_BAIL_TYPE STRING
    ,D_BAIL_TYPE_FULL STRING
    ,D_BAIL_CRIME_TYPE STRING
    ,D_BAIL_CREATED_ON TIMESTAMP
    ,D_BAIL_RELEASE_DATE TIMESTAMP
    ,D_BAIL_RUI_FINALISE_DATE TIMESTAMP
    ,D_BAIL_BAIL_EXPIRY_DATE TIMESTAMP
    ,D_BAIL_BAIL_DATE TIMESTAMP
    ,D_BAIL_TERMINATED_DATE TIMESTAMP
    ,D_BAIL_REVIEW_DUE_DATE TIMESTAMP
    ,D_BAIL_LIVE_OR_HISTORIC STRING
    ,D_BAIL_STAGE STRING
    ,D_BAIL_END_DATE TIMESTAMP
    ,D_BAIL_CUSTODY_REF STRING
    ,D_BAIL_BAIL_TO_RETURN_DATE TIMESTAMP
    ,D_BAIL_SUSPENSION STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_RECORDID STRING
)USING DELTA;
""")
])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### INGEST SILVER LAYER

# CELL ********************

                                                                    #========================================
                                                                    # BAIL TABLES LOAD  -approx 50sec
                                                                    # =======================================
bail_load = run_parallel_queries_silver([

# bail_UTIL_DISTRICT
('bail_UTIL_DISTRICT', """INSERT OVERWRITE bail_UTIL_DISTRICT(BAIL_UTIL_DISTRICT_ID, DISTRICT, AREA_ID, OA_REC_PROCESSED_DATE, OA_RECORDID)
    WITH bailUTILDISTRICT AS (
        SELECT DISTINCT
        TRY_CAST(id AS INT) AS bail_util_district_id
        ,TRY_CAST(district AS STRING) AS district
        ,TRY_CAST(area_id AS INT) AS area_id
		,ROW_NUMBER() OVER (PARTITION BY ID ORDER BY area_id DESC) AS bailUTILDISTRICT_duplicate
		,SHA2(CONCAT_WS('|', COALESCE(TRY_CAST(BAIL_UTIL_DISTRICT_ID AS STRING), ''), COALESCE(DISTRICT, ''), COALESCE(TRY_CAST(AREA_ID AS STRING), '')), 256) AS OA_RECORDID
        FROM  temp_UTIL_DISTRICT
        WHERE id IS NOT NULL
    )
    SELECT BAIL_UTIL_DISTRICT_ID, DISTRICT, AREA_ID, COALESCE(NULL, CURRENT_TIMESTAMP()), OA_RECORDID FROM bailUTILDISTRICT WHERE bailUTILDISTRICT_duplicate =1
    """, True),

# bail_UTIL_AREA
('bail_UTIL_AREA', """INSERT OVERWRITE bail_UTIL_AREA(BAIL_UTIL_AREA_ID, POLICE_FORCE, AREA, OA_REC_PROCESSED_DATE, OA_RECORDID)
    WITH bailUTILAREAS AS (
        SELECT DISTINCT
        TRY_CAST(id           AS INT) AS bail_util_area_id
        ,TRY_CAST(police_force AS STRING) AS police_force
        ,TRY_CAST(area		   AS STRING) AS area
        ,ROW_NUMBER() OVER (PARTITION BY ID ORDER BY area DESC) AS bailUTILAREA_duplicate
		,SHA2(CONCAT_WS('|', COALESCE(TRY_CAST(BAIL_UTIL_AREA_ID AS STRING), ''), COALESCE(POLICE_FORCE, ''), COALESCE(AREA, '')), 256) AS OA_RECORDID
        FROM
        temp_UTIL_AREA 
        WHERE id IS NOT NULL
    )
    SELECT BAIL_UTIL_AREA_ID, POLICE_FORCE, AREA, COALESCE(NULL, CURRENT_TIMESTAMP()), OA_RECORDID FROM bailUTILAREAS WHERE bailUTILAREA_duplicate = 1
	""", True),

# bail_custodyRecord
("bail_custodyRecord", """INSERT OVERWRITE bail_custodyRecord(id ,bailStartDate ,created ,expiredDate ,finaliseDate ,reference ,releaseDate ,status 
,terminatedDate ,district_id ,oic_id ,supervisor_id ,bailToReturnDate,OA_REC_PROCESSED_DATE,OA_RECORDID)
WITH custodyRecord AS(SELECT DISTINCT
	   TRY_CAST(id AS INT) AS id
      ,TRY_CAST(LEFT(bailStartDate,19) AS timestamp) AS bailStartDate
      ,TRY_CAST(LEFT(created,19) AS timestamp) AS created
      ,TRY_CAST(LEFT(expiredDate,19) AS timestamp) AS expiredDate
      ,TRY_CAST(LEFT(finaliseDate,19) AS timestamp) AS finaliseDate
      ,TRY_CAST(reference AS VARCHAR(20)) AS reference
      ,TRY_CAST(LEFT(releaseDate,19) AS timestamp) AS releaseDate
      ,TRY_CAST(status AS VARCHAR(20)) AS status
      ,TRY_CAST(LEFT(terminatedDate,19) AS timestamp) AS terminatedDate
	  ,TRY_CAST(district_id AS INT) AS district_id
	  ,TRY_CAST(RIGHT('00000000' + TRY_CAST(oic_id AS VARCHAR(15)), 8) AS VARCHAR(15)) AS oic_id
	  ,TRY_CAST(RIGHT('00000000' + TRY_CAST(supervisor_id AS VARCHAR(15)), 8) AS VARCHAR(15)) AS supervisor_id
	  ,TRY_CAST(bailToReturnDate AS DATE) AS bailToReturnDate
	  ,ROW_NUMBER() OVER(PARTITION BY id ORDER BY created) AS custodyRecord_duplicate 
	  ,SHA2(CONCAT_WS('|',COALESCE(TRY_CAST(id AS INT), ''), COALESCE(created, ''), COALESCE(reference, ''), COALESCE(status, '')
	  , COALESCE(district_id, ''), COALESCE(oic_id, ''), COALESCE(supervisor_id, '')),256) AS OA_RECORDID
FROM temp_custodyRecord
WHERE id IS NOT NULL
AND force = 'ESSEX')
SELECT id ,bailStartDate ,created ,expiredDate ,finaliseDate ,reference ,releaseDate ,status ,terminatedDate ,district_id ,oic_id ,supervisor_id ,bailToReturnDate, COALESCE(NULL, CURRENT_TIMESTAMP()),OA_RECORDID FROM custodyRecord WHERE custodyRecord_duplicate =1
""", True),

#bail_UTIL_USER_SNAPSHOT
("bail_UTIL_USER_SNAPSHOT","""INSERT OVERWRITE bail_UTIL_USER_SNAPSHOT(ID,USERNAME,OA_REC_PROCESSED_DATE ,OA_RECORDID)
WITH userSnapshot AS(
	SELECT DISTINCT
	    ID
	   ,USERNAME
     ,SHA2(CONCAT_WS('|', COALESCE(TRY_CAST(ID AS STRING),''), COALESCE(USERNAME,'')),256) AS OA_RECORDID 
	   FROM temp_UTIL_USER_SNAPSHOT 
       WHERE ID IS NOT NULL)
SELECT ID ,USERNAME ,COALESCE(NULL, CURRENT_TIMESTAMP()) ,OA_RECORDID FROM userSnapshot 
""", True),

# bail_bailRequestInternal 
("bail_bailRequestInternal","""INSERT OVERWRITE bail_bailRequestInternal(BRI_ID, officerApproving_id, custody_id, ROW_NO ,OA_REC_PROCESSED_DATE ,OA_RECORDID)
WITH bailRequestInternal AS(SELECT DISTINCT
	   TRY_CAST(id AS INT) AS BRI_ID
	  ,TRY_CAST(RIGHT('00000000' + TRY_CAST(officerApproving_id AS VARCHAR(15)), 8) AS VARCHAR(15)) AS officerApproving_id
	  ,TRY_CAST(custody_id AS INT) AS custody_id
	  ,ROW_NUMBER() OVER (PARTITION BY CUSTODY_ID ORDER BY DECISIONDATE DESC) AS ROW_NO
	  ,SHA2(CONCAT_WS('|', COALESCE(TRY_CAST(id AS STRING), ''), COALESCE(TRY_CAST(officerApproving_id AS STRING),''), COALESCE(TRY_CAST(custody_id AS STRING), '')),256) AS OA_RECORDID
FROM temp_bailRequestInternal
WHERE id IS NOT NULL)
SELECT BRI_ID, OFFICERAPPROVING_ID, CUSTODY_ID, ROW_NO, COALESCE(NULL, CURRENT_TIMESTAMP()) ,OA_RECORDID FROM bailRequestInternal
""", True),

#bail_review
("bail_review","""INSERT OVERWRITE bail_review(BAIL_REVIEW_ID, ID ,REVIEWEDON ,CUSTODY_ID ,ROW_NO ,OA_REC_PROCESSED_DATE ,OA_RECORDID)
WITH bailreview AS(
	SELECT DISTINCT
	TRY_CAST(id AS INT) AS BAIL_REVIEW_ID
    ,ID
	,TRY_CAST(LEFT(reviewedOn,19) AS timestamp) AS REVIEWEDON
	,TRY_CAST(custody_id AS INT) AS CUSTODY_ID
	,ROW_NUMBER() OVER (PARTITION BY CUSTODY_ID ORDER BY reviewedOn DESC) AS ROW_NO
	,SHA2(CONCAT_WS('|',COALESCE(ID, ''), COALESCE(reviewedOn, ''),COALESCE(custody_id, '')),256) AS OA_RECORDID
FROM temp_review
WHERE id IS NOT NULL)
SELECT BAIL_REVIEW_ID, ID ,REVIEWEDON ,CUSTODY_ID ,ROW_NO, COALESCE(NULL, CURRENT_TIMESTAMP()) ,OA_RECORDID FROM bailreview
""", True),

# bail_BailSuspension
("bail_BailSuspension", """INSERT OVERWRITE bail_BailSuspension(ID, RESUMEDATE ,SUSPENDDATE ,RESUMEDBY_ID ,SUSPENDEDBY_ID ,CUSTODY_ID ,OA_REC_PROCESSED_DATE ,
OA_RECORDID)
WITH BailSuspension AS (SELECT DISTINCT
	   TRY_CAST(id AS INT) AS id
	  ,TRY_CAST(resumeDate AS date) AS resumeDate
      ,TRY_CAST(suspendDate AS date) AS suspendDate
      ,TRY_CAST(resumedBy_id AS int) AS resumedBy_id
      ,TRY_CAST(suspendedBy_id AS int) AS suspendedBy_id
      ,TRY_CAST(custody_id AS int) AS custody_id
	  ,SHA2(CONCAT_WS('|', COALESCE(TRY_CAST(ID AS STRING), ''),COALESCE(resumeDate, ''),COALESCE(suspendDate, ''),COALESCE(resumedBy_id, ''),COALESCE(suspendedBy_id, ''),COALESCE(custody_id, '')),256) AS OA_RECORDID
FROM temp_BailSuspension
WHERE ID IS NOT NULL)
SELECT ID, RESUMEDATE ,SUSPENDDATE ,RESUMEDBY_ID ,SUSPENDEDBY_ID ,CUSTODY_ID ,COALESCE(NULL, CURRENT_TIMESTAMP()) ,OA_RECORDID FROM BailSuspension
""", True)

])
                                                                    
                                                                    #========================================
                                                                    # TBL TABLES LOAD  -approx 30sec
                                                                    # =======================================


bail_load_tbl = run_parallel_queries_silver([
# tbl_bail_geo
('tbl_bail_geo', """INSERT OVERWRITE tbl_bail_geo(D_BAIL_GEO_DISTRICT_ID, D_BAIL_GEO_DISTRICT, D_BAIL_GEO_AREA_ID, D_BAIL_GEO_AREA, D_BAIL_GEO_POLICE_FORCE, 
OA_REC_PROCESSED_DATE, OA_RECORDID)
    WITH dbailgeo AS (
        SELECT
        UD.bail_util_district_id AS D_BAIL_GEO_DISTRICT_ID
        ,UD.district AS D_BAIL_GEO_DISTRICT
        ,UD.area_id AS	D_BAIL_GEO_AREA_ID
        ,UA.area AS D_BAIL_GEO_AREA
        ,UA.police_force AS D_BAIL_GEO_POLICE_FORCE
		,ROW_NUMBER() OVER (PARTITION BY bail_util_district_id ORDER BY area_id DESC) AS dbailgeo_duplicate
        ,SHA2(CONCAT_WS('|', COALESCE(TRY_CAST(D_BAIL_GEO_DISTRICT_ID AS STRING), ''), COALESCE(D_BAIL_GEO_DISTRICT, ''), COALESCE(TRY_CAST(D_BAIL_GEO_AREA_ID AS STRING), ''), 
        COALESCE(D_BAIL_GEO_AREA, ''), COALESCE(D_BAIL_GEO_POLICE_FORCE, '')), 256) AS OA_RECORDID
        FROM bail_UTIL_DISTRICT UD
        LEFT JOIN bail_UTIL_AREA UA ON UD.AREA_ID = UA.bail_util_area_id
    )
    SELECT D_BAIL_GEO_DISTRICT_ID, D_BAIL_GEO_DISTRICT, D_BAIL_GEO_AREA_ID, D_BAIL_GEO_AREA, D_BAIL_GEO_POLICE_FORCE, COALESCE(NULL, CURRENT_TIMESTAMP()), OA_RECORDID FROM dbailgeo WHERE dbailgeo_duplicate = 1
	""", True),


# # tbl_bail  (This will can not run here, I has to be done after Athena is completed else it will fail)
# ('tbl_bail', """INSERT OVERWRITE tbl_bail(D_BAIL_ID, D_BAIL_CUSTODY_ID, D_BAIL_TYPE, D_BAIL_TYPE_FULL, D_BAIL_CRIME_TYPE, D_BAIL_CREATED_ON, D_BAIL_RELEASE_DATE, 
# D_BAIL_RUI_FINALISE_DATE, D_BAIL_BAIL_EXPIRY_DATE, 
# D_BAIL_BAIL_DATE, D_BAIL_TERMINATED_DATE, D_BAIL_REVIEW_DUE_DATE, D_BAIL_LIVE_OR_HISTORIC, D_BAIL_STAGE, D_BAIL_END_DATE, D_BAIL_CUSTODY_REF, D_BAIL_BAIL_TO_RETURN_DATE, D_BAIL_SUSPENSION, OA_REC_PROCESSED_DATE, OA_RECORDID)
#         WITH BAIL_RECORDS AS (
#         SELECT DISTINCT 

#         CR.ID AS D_BAIL_ID, 
#             CR.ID AS D_BAIL_CUSTODY_ID, 
#             CR.reference AS D_BAIL_CUSTODY_REF,

#             -- Bail Type Logic
#         CASE
#             WHEN CR.status = 'BAIL APPROVED' THEN 'DQ'
#             WHEN CR.status = 'FINALISED' AND COALESCE(CR.bailStartDate, CR.releaseDate) IS NULL THEN 'DQ'
#             WHEN CR.status = 'BAILED' AND CR.releaseDate IS NOT NULL AND CR.bailStartDate IS NULL THEN 'CPS BAIL'
#             WHEN CR.finaliseDate <= COALESCE(CR.terminatedDate, '00:00:00') THEN 'BAIL'
#             WHEN CR.finaliseDate <= COALESCE(CR.expiredDate, '00:00:00') THEN 'BAIL'
#             WHEN CR.expiredDate IS NOT NULL THEN 'RUI'
#             WHEN CR.terminatedDate IS NOT NULL THEN 'RUI'
#             WHEN CR.bailStartDate IS NOT NULL THEN 'BAIL'
#             WHEN CR.releaseDate IS NULL THEN 'DQ'
#             ELSE 'RUI'
#             END AS D_BAIL_TYPE,

#             -- Full Bail Type Logic                                                                             -- This is more of a duplications so I can we take out?
#         CASE
#             WHEN CR.status = 'BAIL APPROVED' THEN 'DQ'
#             WHEN CR.status = 'FINALISED' AND COALESCE(CR.bailStartDate, CR.releaseDate) IS NULL THEN 'DQ'
#             WHEN CR.status = 'BAILED' AND CR.releaseDate IS NOT NULL AND CR.bailStartDate IS NULL THEN 'CPS BAIL'
#             WHEN CR.finaliseDate <= COALESCE(CR.terminatedDate, '00:00:00') THEN 'BAIL'
#             WHEN CR.finaliseDate <= COALESCE(CR.expiredDate, '00:00:00') THEN 'BAIL'
#             WHEN CR.expiredDate IS NOT NULL THEN 'BAIL TO RUI'
#             WHEN CR.terminatedDate IS NOT NULL THEN 'BAIL TO RUI'
#             WHEN CR.bailStartDate IS NOT NULL THEN 'BAIL'
#             WHEN CR.releaseDate IS NULL THEN 'DQ'
#             ELSE 'RUI'
#             END AS D_BAIL_TYPE_FULL,

#             -- Additional Fields
#             ARA.ACPO_GROUPING_GCV AS D_BAIL_CRIME_TYPE,
#             CR.created AS D_BAIL_CREATED_ON,
#             CR.releaseDate AS D_BAIL_RELEASE_DATE,
#             CR.finaliseDate AS D_BAIL_RUI_FINALISE_DATE,
#             CR.expiredDate AS D_BAIL_BAIL_EXPIRY_DATE,
#             CR.bailStartDate AS D_BAIL_BAIL_DATE,
#             CR.terminatedDate AS D_BAIL_TERMINATED_DATE,
#             LEAST( COALESCE(CR.terminatedDate, '9999-12-31'), COALESCE(CR.finaliseDate, '9999-12-31'), COALESCE(CR.expiredDate, '9999-12-31'), COALESCE(CR.releaseDate, '9999-12-31')
#             ) AS D_BAIL_END_DATE,
#             BR.reviewedOn AS D_BAIL_REVIEW_DUE_DATE,

#         CASE
#             WHEN CR.status = 'FINALISED' THEN 'Historic'
#             ELSE 'Live'
#             END AS D_BAIL_LIVE_OR_HISTORIC,
#             CR.status AS D_BAIL_STAGE,
#             APR.update_date_time,
#             CR.bailToReturnDate AS D_BAIL_BAIL_TO_RETURN_DATE,
#         CASE
#           WHEN SUSP.id IS NOT NULL THEN 'Y'
#           ELSE 'N'
#           END AS D_BAIL_SUSPENSION,
#                 ROW_NUMBER() OVER (PARTITION BY CR.id ORDER BY APR.update_date_time DESC) AS RN,                   ------  Thisbreak the code so I took it off?.

#                 -- ROW_NUMBER() OVER (PARTITION BY CR.id ORDER BY CR.reference DESC) AS RN,                   ------  Thisbreak the code so I took it off?.

#                 SHA2(CONCAT_WS('|', COALESCE(TRY_CAST(CR.ID AS STRING), ''), 
#                 -- COALESCE(TRY_CAST(CR.ID AS STRING), ''), 
#                 COALESCE(D_BAIL_TYPE, ''), COALESCE(D_BAIL_TYPE_FULL, ''), 
#                 -- COALESCE(D_BAIL_CRIME_TYPE, ''), 
#                 COALESCE(CR.CREATED, ''), COALESCE(CR.RELEASEDATE, ''), COALESCE(CR.FINALISEDATE, ''), COALESCE(CR.EXPIREDDATE, ''), COALESCE(CR.BAILSTARTDATE, ''), COALESCE(CR.TERMINATEDDATE, ''), 
#                 COALESCE(BR.REVIEWEDON, ''), COALESCE(CR.STATUS, ''), COALESCE(CR.TERMINATEDDATE, ''), COALESCE(CR.REFERENCE, ''), COALESCE(CR.BAILTORETURNDATE, '')
#                 -- , COALESCE(D_BAIL_SUSPENSION, '')
#                 ), 256) AS OA_RECORDID


#        FROM bail_custodyRecord CR
# 		    LEFT JOIN bail_review BR ON CR.id = BR.custody_id AND BR.ROW_NO = 1 --Take record with most recent bail review date
#             LEFT JOIN bail_BailSuspension SUSP	ON (CR.id = SUSP.id)
# 		    LEFT JOIN athena_custody_record ACR ON CR.reference = ACR.CUSTODY_REFERENCE_NUMBER
# 		    LEFT JOIN  athena_link_bail AL	ON (ACR.ATHENA_CUSTODY_ID = AL.FROM_OBJECT_KEY AND AL.TO_OBJECT_TYPE = 'POLE_ARREST')
# 		    LEFT JOIN athena_arrest_initial_reason AIR	ON AL.TO_OBJECT_KEY = AIR.POLE_ARREST_ID
# 		    LEFT JOIN athena_pole_arrest APR ON AL.TO_OBJECT_KEY = APR.POLE_ARREST_ID
# 		    LEFT JOIN athena_reason_for_arrest ARA ON (AIR.ARREST_REASON = ARA.ID AND APR.MAIN_ARREST_FLAG = 'T')	--Only take the main reason for arrest	
# ) 

#     SELECT DISTINCT D_BAIL_ID, D_BAIL_CUSTODY_ID, D_BAIL_TYPE, D_BAIL_TYPE_FULL, D_BAIL_CRIME_TYPE, D_BAIL_CREATED_ON, D_BAIL_RELEASE_DATE, D_BAIL_RUI_FINALISE_DATE, D_BAIL_BAIL_EXPIRY_DATE, D_BAIL_BAIL_DATE, 
#         D_BAIL_TERMINATED_DATE, D_BAIL_REVIEW_DUE_DATE, D_BAIL_LIVE_OR_HISTORIC, D_BAIL_STAGE, 
#         D_BAIL_END_DATE, D_BAIL_CUSTODY_REF, D_BAIL_BAIL_TO_RETURN_DATE,D_BAIL_SUSPENSION, COALESCE(NULL, CURRENT_TIMESTAMP()), OA_RECORDID
#         FROM BAIL_RECORDS 
#         WHERE RN = 1           --This bit can't work because I update_date_time is the killer
#     """, True)

])


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### LOGGING

# CELL ********************

finalise_notebook_logging()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": true
# META }

# MARKDOWN ********************

# ###### TEST

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC INSERT OVERWRITE tbl_bail(D_BAIL_ID, D_BAIL_CUSTODY_ID, D_BAIL_TYPE, D_BAIL_TYPE_FULL, D_BAIL_CRIME_TYPE, D_BAIL_CREATED_ON, D_BAIL_RELEASE_DATE, 
# MAGIC D_BAIL_RUI_FINALISE_DATE, D_BAIL_BAIL_EXPIRY_DATE, 
# MAGIC D_BAIL_BAIL_DATE, D_BAIL_TERMINATED_DATE, D_BAIL_REVIEW_DUE_DATE, D_BAIL_LIVE_OR_HISTORIC, D_BAIL_STAGE, D_BAIL_END_DATE, D_BAIL_CUSTODY_REF, D_BAIL_BAIL_TO_RETURN_DATE, D_BAIL_SUSPENSION, OA_REC_PROCESSED_DATE, OA_RECORDID)
# MAGIC         WITH BAIL_RECORDS AS (
# MAGIC         SELECT DISTINCT 
# MAGIC 
# MAGIC         CR.ID AS D_BAIL_ID, 
# MAGIC             CR.ID AS D_BAIL_CUSTODY_ID, 
# MAGIC             CR.reference AS D_BAIL_CUSTODY_REF,
# MAGIC 
# MAGIC             -- Bail Type Logic
# MAGIC         CASE
# MAGIC             WHEN CR.status = 'BAIL APPROVED' THEN 'DQ'
# MAGIC             WHEN CR.status = 'FINALISED' AND COALESCE(CR.bailStartDate, CR.releaseDate) IS NULL THEN 'DQ'
# MAGIC             WHEN CR.status = 'BAILED' AND CR.releaseDate IS NOT NULL AND CR.bailStartDate IS NULL THEN 'CPS BAIL'
# MAGIC             WHEN CR.finaliseDate <= COALESCE(CR.terminatedDate, '00:00:00') THEN 'BAIL'
# MAGIC             WHEN CR.finaliseDate <= COALESCE(CR.expiredDate, '00:00:00') THEN 'BAIL'
# MAGIC             WHEN CR.expiredDate IS NOT NULL THEN 'RUI'
# MAGIC             WHEN CR.terminatedDate IS NOT NULL THEN 'RUI'
# MAGIC             WHEN CR.bailStartDate IS NOT NULL THEN 'BAIL'
# MAGIC             WHEN CR.releaseDate IS NULL THEN 'DQ'
# MAGIC             ELSE 'RUI'
# MAGIC             END AS D_BAIL_TYPE,
# MAGIC 
# MAGIC             -- Full Bail Type Logic                                                                             -- This is more of a duplications so I can we take out?
# MAGIC         CASE
# MAGIC             WHEN CR.status = 'BAIL APPROVED' THEN 'DQ'
# MAGIC             WHEN CR.status = 'FINALISED' AND COALESCE(CR.bailStartDate, CR.releaseDate) IS NULL THEN 'DQ'
# MAGIC             WHEN CR.status = 'BAILED' AND CR.releaseDate IS NOT NULL AND CR.bailStartDate IS NULL THEN 'CPS BAIL'
# MAGIC             WHEN CR.finaliseDate <= COALESCE(CR.terminatedDate, '00:00:00') THEN 'BAIL'
# MAGIC             WHEN CR.finaliseDate <= COALESCE(CR.expiredDate, '00:00:00') THEN 'BAIL'
# MAGIC             WHEN CR.expiredDate IS NOT NULL THEN 'BAIL TO RUI'
# MAGIC             WHEN CR.terminatedDate IS NOT NULL THEN 'BAIL TO RUI'
# MAGIC             WHEN CR.bailStartDate IS NOT NULL THEN 'BAIL'
# MAGIC             WHEN CR.releaseDate IS NULL THEN 'DQ'
# MAGIC             ELSE 'RUI'
# MAGIC             END AS D_BAIL_TYPE_FULL,
# MAGIC 
# MAGIC             -- Additional Fields
# MAGIC             ARA.ACPO_GROUPING_GCV AS D_BAIL_CRIME_TYPE,
# MAGIC             CR.created AS D_BAIL_CREATED_ON,
# MAGIC             CR.releaseDate AS D_BAIL_RELEASE_DATE,
# MAGIC             CR.finaliseDate AS D_BAIL_RUI_FINALISE_DATE,
# MAGIC             CR.expiredDate AS D_BAIL_BAIL_EXPIRY_DATE,
# MAGIC             CR.bailStartDate AS D_BAIL_BAIL_DATE,
# MAGIC             CR.terminatedDate AS D_BAIL_TERMINATED_DATE,
# MAGIC             LEAST( COALESCE(CR.terminatedDate, '9999-12-31'), COALESCE(CR.finaliseDate, '9999-12-31'), COALESCE(CR.expiredDate, '9999-12-31'), COALESCE(CR.releaseDate, '9999-12-31')
# MAGIC             ) AS D_BAIL_END_DATE,
# MAGIC             BR.reviewedOn AS D_BAIL_REVIEW_DUE_DATE,
# MAGIC 
# MAGIC         CASE
# MAGIC             WHEN CR.status = 'FINALISED' THEN 'Historic'
# MAGIC             ELSE 'Live'
# MAGIC             END AS D_BAIL_LIVE_OR_HISTORIC,
# MAGIC             CR.status AS D_BAIL_STAGE,
# MAGIC             APR.update_date_time,
# MAGIC             CR.bailToReturnDate AS D_BAIL_BAIL_TO_RETURN_DATE,
# MAGIC         CASE
# MAGIC           WHEN SUSP.id IS NOT NULL THEN 'Y'
# MAGIC           ELSE 'N'
# MAGIC           END AS D_BAIL_SUSPENSION,
# MAGIC                 -- ROW_NUMBER() OVER (PARTITION BY CR.id ORDER BY APR.update_date_time DESC) AS RN,                   ------  Thisbreak the code so I took it off?.
# MAGIC 
# MAGIC                 ROW_NUMBER() OVER (PARTITION BY CR.id ORDER BY CR.reference DESC) AS RN,                   ------  Thisbreak the code so I took it off?.
# MAGIC 
# MAGIC                 SHA2(CONCAT_WS('|', COALESCE(TRY_CAST(CR.ID AS STRING), ''), 
# MAGIC                 -- COALESCE(TRY_CAST(CR.ID AS STRING), ''), 
# MAGIC                 COALESCE(D_BAIL_TYPE, ''), COALESCE(D_BAIL_TYPE_FULL, ''), 
# MAGIC                 -- COALESCE(D_BAIL_CRIME_TYPE, ''), 
# MAGIC                 COALESCE(CR.CREATED, ''), COALESCE(CR.RELEASEDATE, ''), COALESCE(CR.FINALISEDATE, ''), COALESCE(CR.EXPIREDDATE, ''), COALESCE(CR.BAILSTARTDATE, ''), COALESCE(CR.TERMINATEDDATE, ''), 
# MAGIC                 COALESCE(BR.REVIEWEDON, ''), COALESCE(CR.STATUS, ''), COALESCE(CR.TERMINATEDDATE, ''), COALESCE(CR.REFERENCE, ''), COALESCE(CR.BAILTORETURNDATE, '')
# MAGIC                 -- , COALESCE(D_BAIL_SUSPENSION, '')
# MAGIC                 ), 256) AS OA_RECORDID
# MAGIC 
# MAGIC 
# MAGIC        FROM bail_custodyRecord CR
# MAGIC 		    LEFT JOIN bail_review BR ON CR.id = BR.custody_id AND BR.ROW_NO = 1 --Take record with most recent bail review date
# MAGIC             LEFT JOIN bail_BailSuspension SUSP	ON (CR.id = SUSP.id)
# MAGIC 		    LEFT JOIN athena_custody_record ACR ON CR.reference = ACR.CUSTODY_REFERENCE_NUMBER
# MAGIC 		    LEFT JOIN  athena_link_bail AL	ON (ACR.ATHENA_CUSTODY_ID = AL.FROM_OBJECT_KEY AND AL.TO_OBJECT_TYPE = 'POLE_ARREST')
# MAGIC 		    LEFT JOIN athena_arrest_initial_reason AIR	ON AL.TO_OBJECT_KEY = AIR.POLE_ARREST_ID
# MAGIC 		    LEFT JOIN athena_pole_arrest APR ON AL.TO_OBJECT_KEY = APR.POLE_ARREST_ID
# MAGIC 		    LEFT JOIN athena_reason_for_arrest ARA ON (AIR.ARREST_REASON = ARA.ID AND APR.MAIN_ARREST_FLAG = 'T')	--Only take the main reason for arrest	
# MAGIC ) 
# MAGIC 
# MAGIC     SELECT DISTINCT D_BAIL_ID, D_BAIL_CUSTODY_ID, D_BAIL_TYPE, D_BAIL_TYPE_FULL, D_BAIL_CRIME_TYPE = NULL, D_BAIL_CREATED_ON, D_BAIL_RELEASE_DATE, D_BAIL_RUI_FINALISE_DATE, D_BAIL_BAIL_EXPIRY_DATE, D_BAIL_BAIL_DATE, 
# MAGIC         D_BAIL_TERMINATED_DATE, D_BAIL_REVIEW_DUE_DATE, D_BAIL_LIVE_OR_HISTORIC, D_BAIL_STAGE, 
# MAGIC         D_BAIL_END_DATE, D_BAIL_CUSTODY_REF, D_BAIL_BAIL_TO_RETURN_DATE,D_BAIL_SUSPENSION, COALESCE(NULL, CURRENT_TIMESTAMP()), OA_RECORDID
# MAGIC         FROM BAIL_RECORDS 
# MAGIC         -- WHERE RN = 1           --This bit can't work because I update_date_time is the killer
# MAGIC     	

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC INSERT OVERWRITE tbl_bail(D_BAIL_ID, D_BAIL_CUSTODY_ID, D_BAIL_TYPE, D_BAIL_TYPE_FULL, D_BAIL_CRIME_TYPE, D_BAIL_CREATED_ON, D_BAIL_RELEASE_DATE, 
# MAGIC D_BAIL_RUI_FINALISE_DATE, D_BAIL_BAIL_EXPIRY_DATE, 
# MAGIC D_BAIL_BAIL_DATE, D_BAIL_TERMINATED_DATE, D_BAIL_REVIEW_DUE_DATE, D_BAIL_LIVE_OR_HISTORIC, D_BAIL_STAGE, D_BAIL_END_DATE, D_BAIL_CUSTODY_REF, D_BAIL_BAIL_TO_RETURN_DATE, D_BAIL_SUSPENSION, OA_REC_PROCESSED_DATE, OA_RECORDID)
# MAGIC         WITH BAIL_RECORDS AS (
# MAGIC         SELECT DISTINCT 
# MAGIC 
# MAGIC         CR.ID AS D_BAIL_ID, 
# MAGIC             CR.ID AS D_BAIL_CUSTODY_ID, 
# MAGIC             CR.reference AS D_BAIL_CUSTODY_REF,
# MAGIC 
# MAGIC             -- Bail Type Logic
# MAGIC         CASE
# MAGIC             WHEN CR.status = 'BAIL APPROVED' THEN 'DQ'
# MAGIC             WHEN CR.status = 'FINALISED' AND COALESCE(CR.bailStartDate, CR.releaseDate) IS NULL THEN 'DQ'
# MAGIC             WHEN CR.status = 'BAILED' AND CR.releaseDate IS NOT NULL AND CR.bailStartDate IS NULL THEN 'CPS BAIL'
# MAGIC             WHEN CR.finaliseDate <= COALESCE(CR.terminatedDate, '00:00:00') THEN 'BAIL'
# MAGIC             WHEN CR.finaliseDate <= COALESCE(CR.expiredDate, '00:00:00') THEN 'BAIL'
# MAGIC             WHEN CR.expiredDate IS NOT NULL THEN 'RUI'
# MAGIC             WHEN CR.terminatedDate IS NOT NULL THEN 'RUI'
# MAGIC             WHEN CR.bailStartDate IS NOT NULL THEN 'BAIL'
# MAGIC             WHEN CR.releaseDate IS NULL THEN 'DQ'
# MAGIC             ELSE 'RUI'
# MAGIC             END AS D_BAIL_TYPE,
# MAGIC 
# MAGIC             -- Full Bail Type Logic                                                                             -- This is more of a duplications so I can we take out?
# MAGIC         CASE
# MAGIC             WHEN CR.status = 'BAIL APPROVED' THEN 'DQ'
# MAGIC             WHEN CR.status = 'FINALISED' AND COALESCE(CR.bailStartDate, CR.releaseDate) IS NULL THEN 'DQ'
# MAGIC             WHEN CR.status = 'BAILED' AND CR.releaseDate IS NOT NULL AND CR.bailStartDate IS NULL THEN 'CPS BAIL'
# MAGIC             WHEN CR.finaliseDate <= COALESCE(CR.terminatedDate, '00:00:00') THEN 'BAIL'
# MAGIC             WHEN CR.finaliseDate <= COALESCE(CR.expiredDate, '00:00:00') THEN 'BAIL'
# MAGIC             WHEN CR.expiredDate IS NOT NULL THEN 'BAIL TO RUI'
# MAGIC             WHEN CR.terminatedDate IS NOT NULL THEN 'BAIL TO RUI'
# MAGIC             WHEN CR.bailStartDate IS NOT NULL THEN 'BAIL'
# MAGIC             WHEN CR.releaseDate IS NULL THEN 'DQ'
# MAGIC             ELSE 'RUI'
# MAGIC             END AS D_BAIL_TYPE_FULL,
# MAGIC 
# MAGIC             -- Additional Fields
# MAGIC             ARA.ACPO_GROUPING_GCV AS D_BAIL_CRIME_TYPE,
# MAGIC             CR.created AS D_BAIL_CREATED_ON,
# MAGIC             CR.releaseDate AS D_BAIL_RELEASE_DATE,
# MAGIC             CR.finaliseDate AS D_BAIL_RUI_FINALISE_DATE,
# MAGIC             CR.expiredDate AS D_BAIL_BAIL_EXPIRY_DATE,
# MAGIC             CR.bailStartDate AS D_BAIL_BAIL_DATE,
# MAGIC             CR.terminatedDate AS D_BAIL_TERMINATED_DATE,
# MAGIC             LEAST( COALESCE(CR.terminatedDate, '9999-12-31'), COALESCE(CR.finaliseDate, '9999-12-31'), COALESCE(CR.expiredDate, '9999-12-31'), COALESCE(CR.releaseDate, '9999-12-31')
# MAGIC             ) AS D_BAIL_END_DATE,
# MAGIC             BR.reviewedOn AS D_BAIL_REVIEW_DUE_DATE,
# MAGIC 
# MAGIC         CASE
# MAGIC             WHEN CR.status = 'FINALISED' THEN 'Historic'
# MAGIC             ELSE 'Live'
# MAGIC             END AS D_BAIL_LIVE_OR_HISTORIC,
# MAGIC             CR.status AS D_BAIL_STAGE,
# MAGIC             APR.update_date_time,
# MAGIC             CR.bailToReturnDate AS D_BAIL_BAIL_TO_RETURN_DATE,
# MAGIC         CASE
# MAGIC           WHEN SUSP.id IS NOT NULL THEN 'Y'
# MAGIC           ELSE 'N'
# MAGIC           END AS D_BAIL_SUSPENSION,
# MAGIC                 ROW_NUMBER() OVER (PARTITION BY CR.id ORDER BY APR.update_date_time DESC) AS RN,                   ------  Thisbreak the code so I took it off?.
# MAGIC 
# MAGIC                 -- ROW_NUMBER() OVER (PARTITION BY CR.id ORDER BY CR.reference DESC) AS RN,                   ------  Thisbreak the code so I took it off?.
# MAGIC 
# MAGIC                 SHA2(CONCAT_WS('|', COALESCE(TRY_CAST(CR.ID AS STRING), ''), 
# MAGIC                 -- COALESCE(TRY_CAST(CR.ID AS STRING), ''), 
# MAGIC                 COALESCE(D_BAIL_TYPE, ''), COALESCE(D_BAIL_TYPE_FULL, ''), 
# MAGIC                 -- COALESCE(D_BAIL_CRIME_TYPE, ''), 
# MAGIC                 COALESCE(CR.CREATED, ''), COALESCE(CR.RELEASEDATE, ''), COALESCE(CR.FINALISEDATE, ''), COALESCE(CR.EXPIREDDATE, ''), COALESCE(CR.BAILSTARTDATE, ''), COALESCE(CR.TERMINATEDDATE, ''), 
# MAGIC                 COALESCE(BR.REVIEWEDON, ''), COALESCE(CR.STATUS, ''), COALESCE(CR.TERMINATEDDATE, ''), COALESCE(CR.REFERENCE, ''), COALESCE(CR.BAILTORETURNDATE, '')
# MAGIC                 -- , COALESCE(D_BAIL_SUSPENSION, '')
# MAGIC                 ), 256) AS OA_RECORDID
# MAGIC 
# MAGIC 
# MAGIC        FROM bail_custodyRecord CR
# MAGIC 		    LEFT JOIN bail_review BR ON CR.id = BR.custody_id AND BR.ROW_NO = 1 --Take record with most recent bail review date
# MAGIC             LEFT JOIN bail_BailSuspension SUSP	ON (CR.id = SUSP.id)
# MAGIC 		    LEFT JOIN athena_custody_record ACR ON CR.reference = ACR.CUSTODY_REFERENCE_NUMBER
# MAGIC 		    LEFT JOIN  athena_link_bail AL	ON (ACR.ATHENA_CUSTODY_ID = AL.FROM_OBJECT_KEY AND AL.TO_OBJECT_TYPE = 'POLE_ARREST')
# MAGIC 		    LEFT JOIN athena_arrest_initial_reason AIR	ON AL.TO_OBJECT_KEY = AIR.POLE_ARREST_ID
# MAGIC 		    LEFT JOIN athena_pole_arrest APR ON AL.TO_OBJECT_KEY = APR.POLE_ARREST_ID
# MAGIC 		    LEFT JOIN athena_reason_for_arrest ARA ON (AIR.ARREST_REASON = ARA.ID AND APR.MAIN_ARREST_FLAG = 'T')	--Only take the main reason for arrest	
# MAGIC ) 
# MAGIC 
# MAGIC     SELECT DISTINCT D_BAIL_ID, D_BAIL_CUSTODY_ID, D_BAIL_TYPE, D_BAIL_TYPE_FULL, D_BAIL_CRIME_TYPE, D_BAIL_CREATED_ON, D_BAIL_RELEASE_DATE, D_BAIL_RUI_FINALISE_DATE, D_BAIL_BAIL_EXPIRY_DATE, D_BAIL_BAIL_DATE, 
# MAGIC         D_BAIL_TERMINATED_DATE, D_BAIL_REVIEW_DUE_DATE, D_BAIL_LIVE_OR_HISTORIC, D_BAIL_STAGE, 
# MAGIC         D_BAIL_END_DATE, D_BAIL_CUSTODY_REF, D_BAIL_BAIL_TO_RETURN_DATE,D_BAIL_SUSPENSION, COALESCE(NULL, CURRENT_TIMESTAMP()), OA_RECORDID
# MAGIC         FROM BAIL_RECORDS 
# MAGIC         WHERE RN = 1           --This bit can't work because I update_date_time is the killer
# MAGIC 
# MAGIC 
# MAGIC 
# MAGIC     	

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }
