-- Fabric notebook source

-- METADATA ********************

-- META {
-- META   "kernel_info": {
-- META     "name": "sqldatawarehouse"
-- META   },
-- META   "dependencies": {
-- META     "warehouse": {
-- META       "default_warehouse": "65b85860-6e65-95e7-4399-e89ee955f64e",
-- META       "known_warehouses": [
-- META         {
-- META           "id": "65b85860-6e65-95e7-4399-e89ee955f64e",
-- META           "type": "Datawarehouse"
-- META         }
-- META       ]
-- META     }
-- META   }
-- META }

-- MARKDOWN ********************

-- ## **WH CALC TABLES INGEST**

-- MARKDOWN ********************

-- ###### SAP CALC LAKEHOUSE TO WARHOUSE

-- CELL ********************

/* ============================================================
 Run-wide variables for this cell
 ============================================================ */
DECLARE @wh_db NVARCHAR(255) = N'WH_400_Gold_Test';
DECLARE @lh_db NVARCHAR(255) = N'LH_300_Gold_Test';
DECLARE @source NVARCHAR(50) = N'SAP';
-- One FolderDateTime (yyyyMMddHHmmss) shared by all MERGEs in this cell
DECLARE @runFolder VARCHAR(14) =
 CONVERT(VARCHAR(8), SYSDATETIME(), 112) + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), ':', '');

/* ==================================================================
 MERGE #1: calc.sap_pa2003 SOURCE = 'SAP'
 ================================================================== */
DECLARE @table_name_calc_sap_pa2003 NVARCHAR(255) = N'calc.sap_pa2003';
DECLARE @rows_affected_calc_sap_pa2003 INT = 0;
DECLARE @run_id_calc_sap_pa2003 NVARCHAR(1000);
DECLARE @err_msg_calc_sap_pa2003 NVARCHAR(MAX);
DECLARE @err_details_calc_sap_pa2003 NVARCHAR(MAX);
DECLARE @sql_log_success_calc_sap_pa2003 NVARCHAR(MAX);
DECLARE @sql_log_error_calc_sap_pa2003 NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_calc_sap_pa2003 NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.calc.sap_pa2003 AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.calc.sap_pa2003 AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.PERSONNEL_NUMBER = s.PERSONNEL_NUMBER,
 t.SUBS_START_DATE = s.SUBS_START_DATE,
 t.SUBS_END_DATE = s.SUBS_END_DATE,
 t.CHANGED_ON = s.CHANGED_ON,
 t.SUBSTITUTION_TYPE = s.SUBSTITUTION_TYPE,
 t.WORK_BRK_SCHED = s.WORK_BRK_SCHED,
 t.PUBLIC_HOL_CAL = s.PUBLIC_HOL_CAL,
 t.WORK_SCHED_RULE = s.WORK_SCHED_RULE,
 t.DAILY_WORK_SCHED = s.DAILY_WORK_SCHED,
 t.DAY_TYPE = s.DAY_TYPE,
 t.POSITION = s.POSITION,
 t.CHANGED_BY = s.CHANGED_BY,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (PERSONNEL_NUMBER, SUBS_START_DATE, SUBS_END_DATE, CHANGED_ON, SUBSTITUTION_TYPE, WORK_BRK_SCHED, PUBLIC_HOL_CAL, WORK_SCHED_RULE, DAILY_WORK_SCHED, DAY_TYPE, POSITION, CHANGED_BY, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.PERSONNEL_NUMBER, s.SUBS_START_DATE, s.SUBS_END_DATE, s.CHANGED_ON, s.SUBSTITUTION_TYPE, s.WORK_BRK_SCHED, s.PUBLIC_HOL_CAL, s.WORK_SCHED_RULE, s.DAILY_WORK_SCHED, s.DAY_TYPE, s.POSITION, s.CHANGED_BY, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_calc_sap_pa2003, N'@rows INT OUTPUT', @rows_affected_calc_sap_pa2003 OUTPUT;
 SET @run_id_calc_sap_pa2003 = @table_name_calc_sap_pa2003 + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_calc_sap_pa2003 + N': ' + CAST(@rows_affected_calc_sap_pa2003 AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_calc_sap_pa2003 + N')';
 SET @sql_log_success_calc_sap_pa2003 =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_calc_sap_pa2003,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_calc_sap_pa2003,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_calc_sap_pa2003,
 @rows = @rows_affected_calc_sap_pa2003,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_calc_sap_pa2003 = N'calc.sap_pa2003' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_calc_sap_pa2003 = ERROR_MESSAGE();
 SET @err_details_calc_sap_pa2003 =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'calc.sap_pa2003' + N' \n Message=' + @err_msg_calc_sap_pa2003 + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.calc.sap_pa2003 AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.calc.sap_pa2003 AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n calc.sap_pa2003: ' + @err_msg_calc_sap_pa2003 + N' (run_id=' + @run_id_calc_sap_pa2003 + N')';
 SET @sql_log_error_calc_sap_pa2003 =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_calc_sap_pa2003,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'calc.sap_pa2003',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_calc_sap_pa2003,
 @runid = @run_id_calc_sap_pa2003,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ============================================================ 
 Final consolidated grid for this cell (no table variables)
 ============================================================ */
DECLARE @sql_show NVARCHAR(MAX) =
 N'SELECT
 STATUS AS Status,
 NOTEBOOK_NAME AS TableName,
 ROWS_AFFECTED AS RowsAffected,
 RUN_ID AS RunId
 FROM ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 WHERE FolderDateTime = @f
 ORDER BY TableName;';
EXEC sp_executesql
 @sql_show,
 N'@f varchar(14)',
 @f = @runFolder;

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- MARKDOWN ********************

-- ###### STORM CALC LAKEHOUSE TO WARHOUSE

-- CELL ********************

/* ============================================================
 Run-wide variables for this cell
 ============================================================ */
DECLARE @wh_db NVARCHAR(255) = N'WH_400_Gold_Test';
DECLARE @lh_db NVARCHAR(255) = N'LH_300_Gold_Test';
DECLARE @source NVARCHAR(50) = N'Storm';
-- One FolderDateTime (yyyyMMddHHmmss) shared by all MERGEs in this cell
DECLARE @runFolder VARCHAR(14) =
 CONVERT(VARCHAR(8), SYSDATETIME(), 112) + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), ':', '');

/* ==================================================================
 MERGE #1: calc.tbl_storm_priority SOURCE = 'Storm'
 ================================================================== */
DECLARE @table_name_calc_tbl_storm_priority NVARCHAR(255) = N'calc.tbl_storm_priority';
DECLARE @rows_affected_calc_tbl_storm_priority INT = 0;
DECLARE @run_id_calc_tbl_storm_priority NVARCHAR(1000);
DECLARE @err_msg_calc_tbl_storm_priority NVARCHAR(MAX);
DECLARE @err_details_calc_tbl_storm_priority NVARCHAR(MAX);
DECLARE @sql_log_success_calc_tbl_storm_priority NVARCHAR(MAX);
DECLARE @sql_log_error_calc_tbl_storm_priority NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_calc_tbl_storm_priority NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.calc.tbl_storm_priority AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.calc.tbl_storm_priority AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.PriorityID = s.PriorityID,
 t.Priority = s.Priority,
 t.TargetReponseTime = s.TargetReponseTime,
 t.TargetAllocationTime = s.TargetAllocationTime,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (PriorityID, Priority, TargetReponseTime, TargetAllocationTime, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.PriorityID, s.Priority, s.TargetReponseTime, s.TargetAllocationTime, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';

 EXEC sp_executesql @sql_calc_tbl_storm_priority, N'@rows INT OUTPUT', @rows_affected_calc_tbl_storm_priority OUTPUT;
 SET @run_id_calc_tbl_storm_priority = @table_name_calc_tbl_storm_priority + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_calc_tbl_storm_priority + N': ' + CAST(@rows_affected_calc_tbl_storm_priority AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_calc_tbl_storm_priority + N')';
 SET @sql_log_success_calc_tbl_storm_priority =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_calc_tbl_storm_priority,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_calc_tbl_storm_priority,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_calc_tbl_storm_priority,
 @rows = @rows_affected_calc_tbl_storm_priority,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_calc_tbl_storm_priority = N'calc.tbl_storm_priority' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_calc_tbl_storm_priority = ERROR_MESSAGE();
 SET @err_details_calc_tbl_storm_priority =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'calc.tbl_storm_priority' + N' \n Message=' + @err_msg_calc_tbl_storm_priority + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.calc.tbl_storm_priority AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.calc.tbl_storm_priority AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n calc.tbl_storm_priority: ' + @err_msg_calc_tbl_storm_priority + N' (run_id=' + @run_id_calc_tbl_storm_priority + N')';
 SET @sql_log_error_calc_tbl_storm_priority =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_calc_tbl_storm_priority,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'calc.tbl_storm_priority',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_calc_tbl_storm_priority,
 @runid = @run_id_calc_tbl_storm_priority,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ============================================================ 
 Final consolidated grid for this cell (no table variables)
 ============================================================ */
DECLARE @sql_show NVARCHAR(MAX) =
 N'SELECT
 STATUS AS Status,
 NOTEBOOK_NAME AS TableName,
 ROWS_AFFECTED AS RowsAffected,
 RUN_ID AS RunId
 FROM ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 WHERE FolderDateTime = @f
 ORDER BY TableName;';
EXEC sp_executesql
 @sql_show,
 N'@f varchar(14)',
 @f = @runFolder;

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- MARKDOWN ********************

-- ###### BAIL CALC LAKEHOUSE TO WARHOUSE

-- CELL ********************

/* ============================================================
 Run-wide variables for this cell
 ============================================================ */
DECLARE @wh_db NVARCHAR(255) = N'WH_400_Gold_Test';
DECLARE @lh_db NVARCHAR(255) = N'LH_300_Gold_Test';
DECLARE @source NVARCHAR(50) = N'Bail';
-- One FolderDateTime (yyyyMMddHHmmss) shared by all MERGEs in this cell
DECLARE @runFolder VARCHAR(14) =
 CONVERT(VARCHAR(8), SYSDATETIME(), 112) + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), ':', '');

/* ==================================================================
 MERGE #1: calc.bail_custodyrecord SOURCE = 'Bail'
 ================================================================== */
DECLARE @table_name_calc_bail_custodyrecord NVARCHAR(255) = N'calc.bail_custodyrecord';
DECLARE @rows_affected_calc_bail_custodyrecord INT = 0;
DECLARE @run_id_calc_bail_custodyrecord NVARCHAR(1000);
DECLARE @err_msg_calc_bail_custodyrecord NVARCHAR(MAX);
DECLARE @err_details_calc_bail_custodyrecord NVARCHAR(MAX);
DECLARE @sql_log_success_calc_bail_custodyrecord NVARCHAR(MAX);
DECLARE @sql_log_error_calc_bail_custodyrecord NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_calc_bail_custodyrecord NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.calc.bail_custodyrecord AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.calc.bail_custodyrecord AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.ID = s.ID,
 t.BAILSTARTDATE = s.BAILSTARTDATE,
 t.CREATED = s.CREATED,
 t.EXPIREDDATE = s.EXPIREDDATE,
 t.FINALISEDATE = s.FINALISEDATE,
 t.REFERENCE = s.REFERENCE,
 t.RELEASEDATE = s.RELEASEDATE,
 t.STATUS = s.STATUS,
 t.TERMINATEDDATE = s.TERMINATEDDATE,
 t.DISTRICT_ID = s.DISTRICT_ID,
 t.OIC_ID = s.OIC_ID,
 t.SUPERVISOR_ID = s.SUPERVISOR_ID,
 t.BAILTORETURNDATE = s.BAILTORETURNDATE,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (ID, BAILSTARTDATE, CREATED, EXPIREDDATE, FINALISEDATE, REFERENCE, RELEASEDATE, STATUS, TERMINATEDDATE, DISTRICT_ID, OIC_ID, SUPERVISOR_ID, BAILTORETURNDATE, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.ID, s.BAILSTARTDATE, s.CREATED, s.EXPIREDDATE, s.FINALISEDATE, s.REFERENCE, s.RELEASEDATE, s.STATUS, s.TERMINATEDDATE, s.DISTRICT_ID, s.OIC_ID, s.SUPERVISOR_ID, s.BAILTORETURNDATE, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_calc_bail_custodyrecord, N'@rows INT OUTPUT', @rows_affected_calc_bail_custodyrecord OUTPUT;
 SET @run_id_calc_bail_custodyrecord = @table_name_calc_bail_custodyrecord + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_calc_bail_custodyrecord + N': ' + CAST(@rows_affected_calc_bail_custodyrecord AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_calc_bail_custodyrecord + N')';
 SET @sql_log_success_calc_bail_custodyrecord =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_calc_bail_custodyrecord,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_calc_bail_custodyrecord,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_calc_bail_custodyrecord,
 @rows = @rows_affected_calc_bail_custodyrecord,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_calc_bail_custodyrecord = N'calc.bail_custodyrecord' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_calc_bail_custodyrecord = ERROR_MESSAGE();
 SET @err_details_calc_bail_custodyrecord =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'calc.bail_custodyrecord' + N' \n Message=' + @err_msg_calc_bail_custodyrecord + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.calc.bail_custodyrecord AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.calc.bail_custodyrecord AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n calc.bail_custodyrecord: ' + @err_msg_calc_bail_custodyrecord + N' (run_id=' + @run_id_calc_bail_custodyrecord + N')';
 SET @sql_log_error_calc_bail_custodyrecord =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_calc_bail_custodyrecord,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'calc.bail_custodyrecord',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_calc_bail_custodyrecord,
 @runid = @run_id_calc_bail_custodyrecord,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ============================================================ 
 Final consolidated grid for this cell (no table variables)
 ============================================================ */
DECLARE @sql_show NVARCHAR(MAX) =
 N'SELECT
 STATUS AS Status,
 NOTEBOOK_NAME AS TableName,
 ROWS_AFFECTED AS RowsAffected,
 RUN_ID AS RunId
 FROM ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 WHERE FolderDateTime = @f
 ORDER BY TableName;';
EXEC sp_executesql
 @sql_show,
 N'@f varchar(14)',
 @f = @runFolder;

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- MARKDOWN ********************

-- ###### ATHEN CALC LAKEHOUSE TO WARHOUSE

-- CELL ********************

/* ============================================================
 Run-wide variables for this cell
 ============================================================ */
DECLARE @wh_db NVARCHAR(255) = N'WH_400_Gold_Test';
DECLARE @lh_db NVARCHAR(255) = N'LH_300_Gold_Test';
DECLARE @source NVARCHAR(50) = N'Athena';
-- One FolderDateTime (yyyyMMddHHmmss) shared by all MERGEs in this cell
DECLARE @runFolder VARCHAR(14) =
 CONVERT(VARCHAR(8), SYSDATETIME(), 112) + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), ':', '');

/* ==================================================================
 MERGE #1: calc.athena_reason_for_arrest SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_calc_athena_reason_for_arrest NVARCHAR(255) = N'calc.athena_reason_for_arrest';
DECLARE @rows_affected_calc_athena_reason_for_arrest INT = 0;
DECLARE @run_id_calc_athena_reason_for_arrest NVARCHAR(1000);
DECLARE @err_msg_calc_athena_reason_for_arrest NVARCHAR(MAX);
DECLARE @err_details_calc_athena_reason_for_arrest NVARCHAR(MAX);
DECLARE @sql_log_success_calc_athena_reason_for_arrest NVARCHAR(MAX);
DECLARE @sql_log_error_calc_athena_reason_for_arrest NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_calc_athena_reason_for_arrest NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.calc.athena_reason_for_arrest AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.calc.athena_reason_for_arrest AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.ID = s.ID,
 t.ACPO_GROUPING_GCV = s.ACPO_GROUPING_GCV,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (ID, ACPO_GROUPING_GCV, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.ID, s.ACPO_GROUPING_GCV, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_calc_athena_reason_for_arrest, N'@rows INT OUTPUT', @rows_affected_calc_athena_reason_for_arrest OUTPUT;
 SET @run_id_calc_athena_reason_for_arrest = @table_name_calc_athena_reason_for_arrest + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_calc_athena_reason_for_arrest + N': ' + CAST(@rows_affected_calc_athena_reason_for_arrest AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_calc_athena_reason_for_arrest + N')';
 SET @sql_log_success_calc_athena_reason_for_arrest =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_calc_athena_reason_for_arrest,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_calc_athena_reason_for_arrest,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_calc_athena_reason_for_arrest,
 @rows = @rows_affected_calc_athena_reason_for_arrest,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_calc_athena_reason_for_arrest = N'calc.athena_reason_for_arrest' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_calc_athena_reason_for_arrest = ERROR_MESSAGE();
 SET @err_details_calc_athena_reason_for_arrest =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'calc.athena_reason_for_arrest' + N' \n Message=' + @err_msg_calc_athena_reason_for_arrest + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.calc.athena_reason_for_arrest AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.calc.athena_reason_for_arrest AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n calc.athena_reason_for_arrest: ' + @err_msg_calc_athena_reason_for_arrest + N' (run_id=' + @run_id_calc_athena_reason_for_arrest + N')';
 SET @sql_log_error_calc_athena_reason_for_arrest =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_calc_athena_reason_for_arrest,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'calc.athena_reason_for_arrest',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_calc_athena_reason_for_arrest,
 @runid = @run_id_calc_athena_reason_for_arrest,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #2: calc.athena_person SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_calc_athena_person NVARCHAR(255) = N'calc.athena_person';
DECLARE @rows_affected_calc_athena_person INT = 0;
DECLARE @run_id_calc_athena_person NVARCHAR(1000);
DECLARE @err_msg_calc_athena_person NVARCHAR(MAX);
DECLARE @err_details_calc_athena_person NVARCHAR(MAX);
DECLARE @sql_log_success_calc_athena_person NVARCHAR(MAX);
DECLARE @sql_log_error_calc_athena_person NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_calc_athena_person NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.calc.athena_person AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.calc.athena_person AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.PERSON_ID = s.PERSON_ID,
 t.ITERATION_GROUP_REF = s.ITERATION_GROUP_REF,
 t.GENDER_GCV = s.GENDER_GCV,
 t.DOB = s.DOB,
 t.ETHNICITY_SELF_GCV = s.ETHNICITY_SELF_GCV,
 t.PNC_ID = s.PNC_ID,
 t.DEAD = s.DEAD,
 t.DATE_OF_DEATH = s.DATE_OF_DEATH,
 t.COUNTRY_OF_BIRTH = s.COUNTRY_OF_BIRTH,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (PERSON_ID, ITERATION_GROUP_REF, GENDER_GCV, DOB, ETHNICITY_SELF_GCV, PNC_ID, DEAD, DATE_OF_DEATH, COUNTRY_OF_BIRTH, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.PERSON_ID, s.ITERATION_GROUP_REF, s.GENDER_GCV, s.DOB, s.ETHNICITY_SELF_GCV, s.PNC_ID, s.DEAD, s.DATE_OF_DEATH, s.COUNTRY_OF_BIRTH, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_calc_athena_person, N'@rows INT OUTPUT', @rows_affected_calc_athena_person OUTPUT;
 SET @run_id_calc_athena_person = @table_name_calc_athena_person + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_calc_athena_person + N': ' + CAST(@rows_affected_calc_athena_person AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_calc_athena_person + N')';
 SET @sql_log_success_calc_athena_person =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_calc_athena_person,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_calc_athena_person,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_calc_athena_person,
 @rows = @rows_affected_calc_athena_person,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_calc_athena_person = N'calc.athena_person' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_calc_athena_person = ERROR_MESSAGE();
 SET @err_details_calc_athena_person =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'calc.athena_person' + N' \n Message=' + @err_msg_calc_athena_person + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.calc.athena_person AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.calc.athena_person AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n calc.athena_person: ' + @err_msg_calc_athena_person + N' (run_id=' + @run_id_calc_athena_person + N')';
 SET @sql_log_error_calc_athena_person =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_calc_athena_person,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'calc.athena_person',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_calc_athena_person,
 @runid = @run_id_calc_athena_person,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #3: calc.athena_gem_task_history SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_calc_athena_gem_task_history NVARCHAR(255) = N'calc.athena_gem_task_history';
DECLARE @rows_affected_calc_athena_gem_task_history INT = 0;
DECLARE @run_id_calc_athena_gem_task_history NVARCHAR(1000);
DECLARE @err_msg_calc_athena_gem_task_history NVARCHAR(MAX);
DECLARE @err_details_calc_athena_gem_task_history NVARCHAR(MAX);
DECLARE @sql_log_success_calc_athena_gem_task_history NVARCHAR(MAX);
DECLARE @sql_log_error_calc_athena_gem_task_history NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_calc_athena_gem_task_history NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.calc.athena_gem_task_history AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.calc.athena_gem_task_history AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.OBJECT_REF = s.OBJECT_REF,
 t.PARENT_OBJECT_TYPE = s.PARENT_OBJECT_TYPE,
 t.PARENT_OBJECT_REF = s.PARENT_OBJECT_REF,
 t.TASK_NAME = s.TASK_NAME,
 t.PERFORMED_DATE_TIME = s.PERFORMED_DATE_TIME,
 t.ALLOCATED_PERFORMED_DATE_TIME = s.ALLOCATED_PERFORMED_DATE_TIME,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (OBJECT_REF, PARENT_OBJECT_TYPE, PARENT_OBJECT_REF, TASK_NAME, PERFORMED_DATE_TIME, ALLOCATED_PERFORMED_DATE_TIME, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.OBJECT_REF, s.PARENT_OBJECT_TYPE, s.PARENT_OBJECT_REF, s.TASK_NAME, s.PERFORMED_DATE_TIME, s.ALLOCATED_PERFORMED_DATE_TIME, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_calc_athena_gem_task_history, N'@rows INT OUTPUT', @rows_affected_calc_athena_gem_task_history OUTPUT;
 SET @run_id_calc_athena_gem_task_history = @table_name_calc_athena_gem_task_history + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_calc_athena_gem_task_history + N': ' + CAST(@rows_affected_calc_athena_gem_task_history AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_calc_athena_gem_task_history + N')';
 SET @sql_log_success_calc_athena_gem_task_history =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_calc_athena_gem_task_history,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_calc_athena_gem_task_history,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_calc_athena_gem_task_history,
 @rows = @rows_affected_calc_athena_gem_task_history,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_calc_athena_gem_task_history = N'calc.athena_gem_task_history' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_calc_athena_gem_task_history = ERROR_MESSAGE();
 SET @err_details_calc_athena_gem_task_history =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'calc.athena_gem_task_history' + N' \n Message=' + @err_msg_calc_athena_gem_task_history + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.calc.athena_gem_task_history AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.calc.athena_gem_task_history AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n calc.athena_gem_task_history: ' + @err_msg_calc_athena_gem_task_history + N' (run_id=' + @run_id_calc_athena_gem_task_history + N')';
 SET @sql_log_error_calc_athena_gem_task_history =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_calc_athena_gem_task_history,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'calc.athena_gem_task_history',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_calc_athena_gem_task_history,
 @runid = @run_id_calc_athena_gem_task_history,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #4: calc.athena_crime_asb_keyword SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_calc_athena_crime_asb_keyword NVARCHAR(255) = N'calc.athena_crime_asb_keyword';
DECLARE @rows_affected_calc_athena_crime_asb_keyword INT = 0;
DECLARE @run_id_calc_athena_crime_asb_keyword NVARCHAR(1000);
DECLARE @err_msg_calc_athena_crime_asb_keyword NVARCHAR(MAX);
DECLARE @err_details_calc_athena_crime_asb_keyword NVARCHAR(MAX);
DECLARE @sql_log_success_calc_athena_crime_asb_keyword NVARCHAR(MAX);
DECLARE @sql_log_error_calc_athena_crime_asb_keyword NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_calc_athena_crime_asb_keyword NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.calc.athena_crime_asb_keyword AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.calc.athena_crime_asb_keyword AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.ASB_KEYWORD_ID = s.ASB_KEYWORD_ID,
 t.CRIME_ID = s.CRIME_ID,
 t.ASB_KEYWORD = s.ASB_KEYWORD,
 t.ASB_KEYWORD_GCV = s.ASB_KEYWORD_GCV,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (ASB_KEYWORD_ID, CRIME_ID, ASB_KEYWORD, ASB_KEYWORD_GCV, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.ASB_KEYWORD_ID, s.CRIME_ID, s.ASB_KEYWORD, s.ASB_KEYWORD_GCV, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_calc_athena_crime_asb_keyword, N'@rows INT OUTPUT', @rows_affected_calc_athena_crime_asb_keyword OUTPUT;
 SET @run_id_calc_athena_crime_asb_keyword = @table_name_calc_athena_crime_asb_keyword + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_calc_athena_crime_asb_keyword + N': ' + CAST(@rows_affected_calc_athena_crime_asb_keyword AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_calc_athena_crime_asb_keyword + N')';
 SET @sql_log_success_calc_athena_crime_asb_keyword =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_calc_athena_crime_asb_keyword,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_calc_athena_crime_asb_keyword,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_calc_athena_crime_asb_keyword,
 @rows = @rows_affected_calc_athena_crime_asb_keyword,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_calc_athena_crime_asb_keyword = N'calc.athena_crime_asb_keyword' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_calc_athena_crime_asb_keyword = ERROR_MESSAGE();
 SET @err_details_calc_athena_crime_asb_keyword =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'calc.athena_crime_asb_keyword' + N' \n Message=' + @err_msg_calc_athena_crime_asb_keyword + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.calc.athena_crime_asb_keyword AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.calc.athena_crime_asb_keyword AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n calc.athena_crime_asb_keyword: ' + @err_msg_calc_athena_crime_asb_keyword + N' (run_id=' + @run_id_calc_athena_crime_asb_keyword + N')';
 SET @sql_log_error_calc_athena_crime_asb_keyword =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_calc_athena_crime_asb_keyword,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'calc.athena_crime_asb_keyword',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_calc_athena_crime_asb_keyword,
 @runid = @run_id_calc_athena_crime_asb_keyword,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ============================================================ 
 Final consolidated grid for this cell (no table variables)
 ============================================================ */
DECLARE @sql_show NVARCHAR(MAX) =
 N'SELECT
 STATUS AS Status,
 NOTEBOOK_NAME AS TableName,
 ROWS_AFFECTED AS RowsAffected,
 RUN_ID AS RunId
 FROM ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 WHERE FolderDateTime = @f
 ORDER BY TableName;';
EXEC sp_executesql
 @sql_show,
 N'@f varchar(14)',
 @f = @runFolder;

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- MARKDOWN ********************

-- ###### **TEST**

-- CELL ********************

SELECT * FROM
-- DELETE
[WH_400_Gold_Test].[ctrl].[tbl_DWLoadLog]
WHERE 1=1
AND Successful = 0
-- AND NOTEBOOK_NAME = 'calc.tbl_storm_priority'
ORDER BY 9 DESC

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse",
-- META   "frozen": false,
-- META   "editable": true
-- META }

-- MARKDOWN ********************

-- ### TEST

-- CELL ********************


-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- CELL ********************


-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }
