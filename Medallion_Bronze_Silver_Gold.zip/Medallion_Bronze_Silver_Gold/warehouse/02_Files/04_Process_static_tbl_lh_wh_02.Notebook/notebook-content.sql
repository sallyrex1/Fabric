-- Fabric notebook source

-- METADATA ********************

-- META {
-- META   "kernel_info": {
-- META     "name": "sqldatawarehouse"
-- META   },
-- META   "dependencies": {
-- META     "warehouse": {
-- META       "default_warehouse": "65b85860-6e65-95e7-4399-e89ee955f64e",
-- META       "known_warehouses": [
-- META         {
-- META           "id": "65b85860-6e65-95e7-4399-e89ee955f64e",
-- META           "type": "Datawarehouse"
-- META         }
-- META       ]
-- META     }
-- META   }
-- META }

-- MARKDOWN ********************

-- ## **WH STATIC TABLES INGEST**

-- MARKDOWN ********************

-- ###### STATIC TABLES **(Time/Date/Distance)** LAKEHOUSE TO WARHOUSE

-- CELL ********************

/* ============================================================
 Run-wide variables for this cell
 ============================================================ */
DECLARE @wh_db NVARCHAR(255) = N'WH_400_Gold_Test';
DECLARE @lh_db NVARCHAR(255) = N'LH_300_Gold_Test';
DECLARE @source NVARCHAR(50) = N'Athena';
-- One FolderDateTime (yyyyMMddHHmmss) shared by all MERGEs in this cell
DECLARE @runFolder VARCHAR(14) =
 CONVERT(VARCHAR(8), SYSDATETIME(), 112) + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), ':', '');

/* ==================================================================
 MERGE #1: rprt.tbl_d_date SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_date NVARCHAR(255) = N'rprt.tbl_d_date';
DECLARE @rows_affected_rprt_tbl_d_date INT = 0;
DECLARE @run_id_rprt_tbl_d_date NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_date NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_date NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_date NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_date NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_date NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_date AS t
 USING ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_date AS s
 ON t.DateID = s.DateID
 WHEN MATCHED THEN
 UPDATE SET
 t.Date = s.Date,
 t.Year = s.Year,
 t.Month = s.Month,
 t.Day = s.Day,
 t.Quarter = s.Quarter,
 t.Week = s.Week,
 t.QuarterName = s.QuarterName,
 t.MonthName = s.MonthName,
 t.WeekName = s.WeekName,
 t.DayName = s.DayName,
 t.YearMonth = s.YearMonth,
 t.YearMonthName = s.YearMonthName
 WHEN NOT MATCHED THEN
 INSERT (DateID, Date, Year, Month, Day, Quarter, Week, QuarterName, MonthName, WeekName, DayName, YearMonth, YearMonthName)
 VALUES (s.DateID, s.Date, s.Year, s.Month, s.Day, s.Quarter, s.Week, s.QuarterName, s.MonthName, s.WeekName, s.DayName, s.YearMonth, s.YearMonthName);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_date, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_date OUTPUT;
 SET @run_id_rprt_tbl_d_date = @table_name_rprt_tbl_d_date + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_date + N': ' + CAST(@rows_affected_rprt_tbl_d_date AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_date + N')';
 SET @sql_log_success_rprt_tbl_d_date =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_date,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_date,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_date,
 @rows = @rows_affected_rprt_tbl_d_date,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_date = N'rprt.tbl_d_date' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_date = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_date =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_date' + N' \n Message=' + @err_msg_rprt_tbl_d_date + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_date AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_date AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_date: ' + @err_msg_rprt_tbl_d_date + N' (run_id=' + @run_id_rprt_tbl_d_date + N')';
 SET @sql_log_error_rprt_tbl_d_date =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_date,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_date',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_date,
 @runid = @run_id_rprt_tbl_d_date,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #2: rprt.tbl_d_distance SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_distance NVARCHAR(255) = N'rprt.tbl_d_distance';
DECLARE @rows_affected_rprt_tbl_d_distance INT = 0;
DECLARE @run_id_rprt_tbl_d_distance NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_distance NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_distance NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_distance NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_distance NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_distance NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_distance AS t
 USING ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_distance AS s
 ON t.DistanceID = s.DistanceID
 WHEN MATCHED THEN
 UPDATE SET
 t.DistanceBucket = s.DistanceBucket
 WHEN NOT MATCHED THEN
 INSERT (DistanceID, MinDistance, MaxDistance, DistanceBucket)
 VALUES (s.DistanceID, MinDistance, MaxDistance, s.DistanceBucket);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';

EXEC sp_executesql @sql_rprt_tbl_d_distance, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_distance OUTPUT;
 SET @run_id_rprt_tbl_d_distance = @table_name_rprt_tbl_d_distance + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_distance + N': ' + CAST(@rows_affected_rprt_tbl_d_distance AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_distance + N')';
 SET @sql_log_success_rprt_tbl_d_distance =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_distance,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_distance,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_distance,
 @rows = @rows_affected_rprt_tbl_d_distance,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_distance = N'rprt.tbl_d_distance' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_distance = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_distance =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_distance' + N' \n Message=' + @err_msg_rprt_tbl_d_distance + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_distance AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_distance AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_distance: ' + @err_msg_rprt_tbl_d_distance + N' (run_id=' + @run_id_rprt_tbl_d_distance + N')';
 SET @sql_log_error_rprt_tbl_d_distance =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_distance,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_distance',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_distance,
 @runid = @run_id_rprt_tbl_d_distance,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #3: rprt.tbl_d_time SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_time NVARCHAR(255) = N'rprt.tbl_d_time';
DECLARE @rows_affected_rprt_tbl_d_time INT = 0;
DECLARE @run_id_rprt_tbl_d_time NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_time NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_time NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_time NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_time NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_time NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_time AS t
 USING ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_time AS s
 ON t.SecondOfDay = s.SecondOfDay
 WHEN MATCHED THEN
 UPDATE SET
 t.Hour24 = s.Hour24,
 t.Minute = s.Minute,
 t.Second = s.Second,
 t.TimeID = s.TimeID,
 t.Hour12 = s.Hour12,
 t.AmPmString = s.AmPmString,
 t.FullTimeString24 = s.FullTimeString24,
 t.FullTimeString12 = s.FullTimeString12,
 t.FullTime = s.FullTime,
 t.Shift = s.Shift,
 t.Police_Hr = s.Police_Hr,
 t.Time_Band = s.Time_Band
 WHEN NOT MATCHED THEN
 INSERT (SecondOfDay, Hour24, Minute, Second, TimeID, Hour12, AmPmString, FullTimeString24, FullTimeString12, FullTime, Shift, Police_Hr, Time_Band)
 VALUES (s.SecondOfDay, s.Hour24, s.Minute, s.Second, s.TimeID, s.Hour12, s.AmPmString, s.FullTimeString24, s.FullTimeString12, s.FullTime, s.Shift, s.Police_Hr, s.Time_Band);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_time, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_time OUTPUT;
 SET @run_id_rprt_tbl_d_time = @table_name_rprt_tbl_d_time + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_time + N': ' + CAST(@rows_affected_rprt_tbl_d_time AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_time + N')';
 SET @sql_log_success_rprt_tbl_d_time =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_time,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_time,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_time,
 @rows = @rows_affected_rprt_tbl_d_time,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_time = N'rprt.tbl_d_time' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_time = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_time =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_time' + N' \n Message=' + @err_msg_rprt_tbl_d_time + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_time AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_time AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_time: ' + @err_msg_rprt_tbl_d_time + N' (run_id=' + @run_id_rprt_tbl_d_time + N')';
 SET @sql_log_error_rprt_tbl_d_time =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_time,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_time',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_time,
 @runid = @run_id_rprt_tbl_d_time,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ============================================================ 
 Final consolidated grid for this cell (no table variables)
 ============================================================ */
DECLARE @sql_show NVARCHAR(MAX) =
 N'SELECT
 STATUS AS Status,
 NOTEBOOK_NAME AS TableName,
 ROWS_AFFECTED AS RowsAffected,
 RUN_ID AS RunId
 FROM ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 WHERE FolderDateTime = @f
 ORDER BY TableName;';
EXEC sp_executesql
 @sql_show,
 N'@f varchar(14)',
 @f = @runFolder;

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- MARKDOWN ********************

-- ###### **TEST**

-- CELL ********************

SELECT * FROM
-- DELETE
[WH_400_Gold_Test].[ctrl].[tbl_DWLoadLog]

WHERE 1=1 
AND NOTEBOOK_NAME in ('rprt.tbl_d_date', 'rprt.tbl_d_distance', 'rprt.tbl_d_time')
AND Successful = 0
ORDER BY 9 DESC

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse",
-- META   "frozen": false,
-- META   "editable": true
-- META }
