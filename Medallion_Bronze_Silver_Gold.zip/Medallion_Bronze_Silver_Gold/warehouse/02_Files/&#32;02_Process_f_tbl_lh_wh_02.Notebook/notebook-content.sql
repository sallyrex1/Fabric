-- Fabric notebook source

-- METADATA ********************

-- META {
-- META   "kernel_info": {
-- META     "name": "sqldatawarehouse"
-- META   },
-- META   "dependencies": {
-- META     "warehouse": {
-- META       "default_warehouse": "65b85860-6e65-95e7-4399-e89ee955f64e",
-- META       "known_warehouses": [
-- META         {
-- META           "id": "65b85860-6e65-95e7-4399-e89ee955f64e",
-- META           "type": "Datawarehouse"
-- META         }
-- META       ]
-- META     }
-- META   }
-- META }

-- MARKDOWN ********************

-- ## **WH F TABLES INGEST**

-- MARKDOWN ********************

-- ###### SAP F LAKEHOUSE TO WARHOUSE

-- CELL ********************

/* ============================================================
 Run-wide variables for this cell
 ============================================================ */
DECLARE @wh_db NVARCHAR(255) = N'WH_400_Gold_Test';
DECLARE @lh_db NVARCHAR(255) = N'LH_300_Gold_Test';
DECLARE @source NVARCHAR(50) = N'SAP';
-- One FolderDateTime (yyyyMMddHHmmss) shared by all MERGEs in this cell
DECLARE @runFolder VARCHAR(14) =
 CONVERT(VARCHAR(8), SYSDATETIME(), 112) + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), ':', '');

/* ==================================================================
 MERGE #1: rprt.tbl_f_operational_planning SOURCE = 'SAP'
 ================================================================== */
DECLARE @table_name_rprt_tbl_f_operational_planning NVARCHAR(255) = N'rprt.tbl_f_operational_planning';
DECLARE @rows_affected_rprt_tbl_f_operational_planning INT = 0;
DECLARE @run_id_rprt_tbl_f_operational_planning NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_f_operational_planning NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_f_operational_planning NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_f_operational_planning NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_f_operational_planning NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_f_operational_planning NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_f_operational_planning AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_f_operational_planning AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.OPCId = s.OPCId,
 t.Start_Date = s.Start_Date,
 t.End_Date = s.End_Date,
 t.Duration = s.Duration,
 t.Demand_Type = s.Demand_Type,
 t.Operation = s.Operation,
 t.Description = s.Description,
 t.Sensitive = s.Sensitive,
 t.Code = s.Code,
 t.Status = s.Status,
 t.Colour = s.Colour,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (OPCId, Start_Date, End_Date, Duration, Demand_Type, Operation, Description, Sensitive, Code, Status, Colour, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.OPCId, s.Start_Date, s.End_Date, s.Duration, s.Demand_Type, s.Operation, s.Description, s.Sensitive, s.Code, s.Status, s.Colour, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_f_operational_planning, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_f_operational_planning OUTPUT;
 SET @run_id_rprt_tbl_f_operational_planning = @table_name_rprt_tbl_f_operational_planning + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_f_operational_planning + N': ' + CAST(@rows_affected_rprt_tbl_f_operational_planning AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_f_operational_planning + N')';
 SET @sql_log_success_rprt_tbl_f_operational_planning =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_f_operational_planning,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_f_operational_planning,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_f_operational_planning,
 @rows = @rows_affected_rprt_tbl_f_operational_planning,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_f_operational_planning = N'rprt.tbl_f_operational_planning' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_f_operational_planning = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_f_operational_planning =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_f_operational_planning' + N' \n Message=' + @err_msg_rprt_tbl_f_operational_planning + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_f_operational_planning AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_f_operational_planning AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_f_operational_planning: ' + @err_msg_rprt_tbl_f_operational_planning + N' (run_id=' + @run_id_rprt_tbl_f_operational_planning + N')';
 SET @sql_log_error_rprt_tbl_f_operational_planning =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_f_operational_planning,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_f_operational_planning',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_f_operational_planning,
 @runid = @run_id_rprt_tbl_f_operational_planning,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #2: rprt.tbl_f_staffing_report SOURCE = 'SAP'
 ================================================================== */
DECLARE @table_name_rprt_tbl_f_staffing_report NVARCHAR(255) = N'rprt.tbl_f_staffing_report';
DECLARE @rows_affected_rprt_tbl_f_staffing_report INT = 0;
DECLARE @run_id_rprt_tbl_f_staffing_report NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_f_staffing_report NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_f_staffing_report NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_f_staffing_report NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_f_staffing_report NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_f_staffing_report NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_f_staffing_report AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_f_staffing_report AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.Date = s.Date,
 t.PersonnelNumber = s.PersonnelNumber,
 t.Name = s.Name,
 t.Personnel = s.Personnel,
 t.Command = s.Command,
 t.Department = s.Department,
 t.Location = s.Location,
 t.Unit = s.Unit,
 t.Section = s.Section,
 t.Role = s.Role,
 t.TSA = s.TSA,
 t.Rank = s.Rank,
 t.Group_Rank = s.Group_Rank,
 t.Planned_Shift_Detail = s.Planned_Shift_Detail,
 t.Actual_Shift_Detail = s.Actual_Shift_Detail,
 t.Shift_Type = s.Shift_Type,
 t.FTE = s.FTE,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (Date, PersonnelNumber, Name, Personnel, Command, Department, Location, Unit, Section, Role, TSA, Rank, Group_Rank, Planned_Shift_Detail, Actual_Shift_Detail, Shift_Type, FTE, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.Date, s.PersonnelNumber, s.Name, s.Personnel, s.Command, s.Department, s.Location, s.Unit, s.Section, s.Role, s.TSA, s.Rank, s.Group_Rank, s.Planned_Shift_Detail, s.Actual_Shift_Detail, s.Shift_Type, s.FTE, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_f_staffing_report, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_f_staffing_report OUTPUT;
 SET @run_id_rprt_tbl_f_staffing_report = @table_name_rprt_tbl_f_staffing_report + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_f_staffing_report + N': ' + CAST(@rows_affected_rprt_tbl_f_staffing_report AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_f_staffing_report + N')';
 SET @sql_log_success_rprt_tbl_f_staffing_report =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_f_staffing_report,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_f_staffing_report,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_f_staffing_report,
 @rows = @rows_affected_rprt_tbl_f_staffing_report,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_f_staffing_report = N'rprt.tbl_f_staffing_report' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_f_staffing_report = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_f_staffing_report =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_f_staffing_report' + N' \n Message=' + @err_msg_rprt_tbl_f_staffing_report + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_f_staffing_report AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_f_staffing_report AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_f_staffing_report: ' + @err_msg_rprt_tbl_f_staffing_report + N' (run_id=' + @run_id_rprt_tbl_f_staffing_report + N')';
 SET @sql_log_error_rprt_tbl_f_staffing_report =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_f_staffing_report,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_f_staffing_report',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_f_staffing_report,
 @runid = @run_id_rprt_tbl_f_staffing_report,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ============================================================ 
 Final consolidated grid for this cell (no table variables)
 ============================================================ */
DECLARE @sql_show NVARCHAR(MAX) =
 N'SELECT
 STATUS AS Status,
 NOTEBOOK_NAME AS TableName,
 ROWS_AFFECTED AS RowsAffected,
 RUN_ID AS RunId
 FROM ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 WHERE FolderDateTime = @f
 ORDER BY TableName;';
EXEC sp_executesql
 @sql_show,
 N'@f varchar(14)',
 @f = @runFolder;

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse",
-- META   "frozen": false,
-- META   "editable": true
-- META }

-- MARKDOWN ********************

-- ###### STORM F LAKEHOUSE TO WARHOUSE

-- CELL ********************

/* ============================================================
 Run-wide variables for this cell
 ============================================================ */
DECLARE @wh_db NVARCHAR(255) = N'WH_400_Gold_Test';
DECLARE @lh_db NVARCHAR(255) = N'LH_300_Gold_Test';
DECLARE @source NVARCHAR(50) = N'Storm';
-- One FolderDateTime (yyyyMMddHHmmss) shared by all MERGEs in this cell
DECLARE @runFolder VARCHAR(14) =
 CONVERT(VARCHAR(8), SYSDATETIME(), 112) + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), ':', '');


/* ==================================================================
 MERGE #2: rprt.tbl_f_incident SOURCE = 'Storm'
 ================================================================== */
DECLARE @table_name_rprt_tbl_f_incident NVARCHAR(255) = N'rprt.tbl_f_incident';
DECLARE @rows_affected_rprt_tbl_f_incident INT = 0;
DECLARE @run_id_rprt_tbl_f_incident NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_f_incident NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_f_incident NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_f_incident NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_f_incident NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_f_incident NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_f_incident AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_f_incident AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.IncidentNaturalID = s.IncidentNaturalID,
 t.LoadID = s.LoadID,
 t.DateAllocated = s.DateAllocated,
 t.TimeAllocated = s.TimeAllocated,
 t.DateAssigned = s.DateAssigned,
 t.TimeAssigned = s.TimeAssigned,
 t.DateArrived = s.DateArrived,
 t.TimeArrived = s.TimeArrived,
 t.TransferDate = s.TransferDate,
 t.TransferTime = s.TransferTime,
 t.DispatchedLevel = s.DispatchedLevel,
 t.ComplAddInfo = s.ComplAddInfo,
 t.FinalServCode = s.FinalServCode,
 t.Origin = s.Origin,
 t.Description = s.Description,
 t.FirstUnitArrived = s.FirstUnitArrived,
 t.FirstUnitDispatched = s.FirstUnitDispatched,
 t.FK_IncidentID = s.FK_IncidentID,
 t.FK_GeoID = s.FK_GeoID,
 t.FK_LocationID = s.FK_LocationID,
 t.FK_OfficerID = s.FK_OfficerID,
 t.FK_DispatcherID = s.FK_DispatcherID,
 t.FK_CallerTakerID = s.FK_CallerTakerID,
 t.FK_DistanceID = s.FK_DistanceID,
 t.FK_PriorityID = s.FK_PriorityID,
 t.FK_InitialServiceCodeID = s.FK_InitialServiceCodeID,
 t.SupervisorPIN = s.SupervisorPIN,
 t.DisposedURN = s.DisposedURN,
 t.ModifiedLocation = s.ModifiedLocation,
 t.ModifiedServCode = s.ModifiedServCode,
 t.HandlingUnit = s.HandlingUnit,
 t.MinDiff_SavedtoTransfer = s.MinDiff_SavedtoTransfer,
 t.MinDiff_SavedtoArrived = s.MinDiff_SavedtoArrived,
 t.MinDiff_TransfertoAllocation = s.MinDiff_TransfertoAllocation,
 t.MinDiff_AllocatedtoArrived = s.MinDiff_AllocatedtoArrived,
 t.MinDiff_SavedtoDispatched = s.MinDiff_SavedtoDispatched,
 t.TravelTimeAvailable = s.TravelTimeAvailable,
 t.DistanceTravelled = s.DistanceTravelled,
 t.MissedResponseFlag = s.MissedResponseFlag,
 t.MissedAllocationFlag = s.MissedAllocationFlag,
 t.FK_DateSavedActualID = s.FK_DateSavedActualID,
 t.FK_DateSavedPoliceID = s.FK_DateSavedPoliceID,
 t.FK_TimeSavedID = s.FK_TimeSavedID,
 t.AvailableUnitsDPA = s.AvailableUnitsDPA,
 t.AvailableUnitsLPA = s.AvailableUnitsLPA,
 t.HandlerEmployeeNo = s.HandlerEmployeeNo,
 t.Handler_Staff_Move_ID = s.Handler_Staff_Move_ID,
 t.Dispatcher_Staff_Move_ID = s.Dispatcher_Staff_Move_ID,
 t.DispatcherEmployeeNo = s.DispatcherEmployeeNo,
 t.Original_Priority = s.Original_Priority,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (IncidentNaturalID, LoadID, DateAllocated, TimeAllocated, DateAssigned, TimeAssigned, DateArrived, TimeArrived, TransferDate, TransferTime, DispatchedLevel, ComplAddInfo, FinalServCode, Origin, Description, FirstUnitArrived, FirstUnitDispatched, FK_IncidentID, FK_GeoID, FK_LocationID, FK_OfficerID, FK_DispatcherID, FK_CallerTakerID, FK_DistanceID, FK_PriorityID, FK_InitialServiceCodeID, SupervisorPIN, DisposedURN, ModifiedLocation, ModifiedServCode, HandlingUnit, MinDiff_SavedtoTransfer, MinDiff_SavedtoArrived, MinDiff_TransfertoAllocation, MinDiff_AllocatedtoArrived, MinDiff_SavedtoDispatched, TravelTimeAvailable, DistanceTravelled, MissedResponseFlag, MissedAllocationFlag, FK_DateSavedActualID, FK_DateSavedPoliceID, FK_TimeSavedID, AvailableUnitsDPA, AvailableUnitsLPA, HandlerEmployeeNo, Handler_Staff_Move_ID, Dispatcher_Staff_Move_ID, DispatcherEmployeeNo, Original_Priority, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.IncidentNaturalID, s.LoadID, s.DateAllocated, s.TimeAllocated, s.DateAssigned, s.TimeAssigned, s.DateArrived, s.TimeArrived, s.TransferDate, s.TransferTime, s.DispatchedLevel, s.ComplAddInfo, s.FinalServCode, s.Origin, s.Description, s.FirstUnitArrived, s.FirstUnitDispatched, s.FK_IncidentID, s.FK_GeoID, s.FK_LocationID, s.FK_OfficerID, s.FK_DispatcherID, s.FK_CallerTakerID, s.FK_DistanceID, s.FK_PriorityID, s.FK_InitialServiceCodeID, s.SupervisorPIN, s.DisposedURN, s.ModifiedLocation, s.ModifiedServCode, s.HandlingUnit, s.MinDiff_SavedtoTransfer, s.MinDiff_SavedtoArrived, s.MinDiff_TransfertoAllocation, s.MinDiff_AllocatedtoArrived, s.MinDiff_SavedtoDispatched, s.TravelTimeAvailable, s.DistanceTravelled, s.MissedResponseFlag, s.MissedAllocationFlag, s.FK_DateSavedActualID, s.FK_DateSavedPoliceID, s.FK_TimeSavedID, s.AvailableUnitsDPA, s.AvailableUnitsLPA, s.HandlerEmployeeNo, s.Handler_Staff_Move_ID, s.Dispatcher_Staff_Move_ID, s.DispatcherEmployeeNo, s.Original_Priority, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_f_incident, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_f_incident OUTPUT;
 SET @run_id_rprt_tbl_f_incident = @table_name_rprt_tbl_f_incident + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_f_incident + N': ' + CAST(@rows_affected_rprt_tbl_f_incident AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_f_incident + N')';
 SET @sql_log_success_rprt_tbl_f_incident =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_f_incident,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_f_incident,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_f_incident,
 @rows = @rows_affected_rprt_tbl_f_incident,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_f_incident = N'rprt.tbl_f_incident' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_f_incident = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_f_incident =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_f_incident' + N' \n Message=' + @err_msg_rprt_tbl_f_incident + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_f_incident AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_f_incident AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_f_incident: ' + @err_msg_rprt_tbl_f_incident + N' (run_id=' + @run_id_rprt_tbl_f_incident + N')';
 SET @sql_log_error_rprt_tbl_f_incident =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_f_incident,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_f_incident',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_f_incident,
 @runid = @run_id_rprt_tbl_f_incident,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #1: rprt.tbl_f_IncidentOfficerResponse SOURCE = 'Storm'
 ================================================================== */
DECLARE @table_name_rprt_tbl_f_incidentofficerresponse NVARCHAR(255) = N'rprt.tbl_f_IncidentOfficerResponse';
DECLARE @rows_affected_rprt_tbl_f_incidentofficerresponse INT = 0;
DECLARE @run_id_rprt_tbl_f_incidentofficerresponse NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_f_incidentofficerresponse NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_f_incidentofficerresponse NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_f_incidentofficerresponse NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_f_incidentofficerresponse NVARCHAR(MAX);

BEGIN TRY
  DECLARE @sql_rprt_tbl_f_incidentofficerresponse NVARCHAR(MAX) = N'
BEGIN TRY
  SET NOCOUNT ON;
  ;WITH s_src AS (
     SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_f_incidentofficerresponse AS s
  ),
  s_dedup AS (
     SELECT s_src.*,
            ROW_NUMBER() OVER (
              PARTITION BY s_src.OA_RECORDID
              ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
            ) AS rn
     FROM s_src
  )
  MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_f_IncidentOfficerResponse AS t
  USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
  ON t.OA_RECORDID = s.OA_RECORDID
  WHEN MATCHED THEN
    UPDATE SET
    t.PK_IncidentOfficerResponse = s.PK_IncidentOfficerResponse,
    t.IncidentNaturalID = s.IncidentNaturalID,
    t.UnitNo = s.UnitNo,
    t.PersonnelID = s.PersonnelID,
    t.LoadID = s.LoadID,
    t.UnitType = s.UnitType,
    t.ArrivalOrder = s.ArrivalOrder,
    t.FirstArrived = s.FirstArrived,
    t.MaxArrivalOrder = s.MaxArrivalOrder,
    t.MinProximityToShiftHandover = s.MinProximityToShiftHandover,
    t.NonResponseUnitFlag = s.NonResponseUnitFlag,
    t.DateTransfer = s.DateTransfer,
    t.TimeTransfer = s.TimeTransfer,
    t.DateAllocated = s.DateAllocated,
    t.TimeAllocated = s.TimeAllocated,
    t.DateArrived = s.DateArrived,
    t.TimeArrived = s.TimeArrived,
    t.MinDiffSavedtoTransfer = s.MinDiffSavedtoTransfer,
    t.MinDiffSavedtoAllocated = s.MinDiffSavedtoAllocated,
    t.MinDiffSavedtoArrived = s.MinDiffSavedtoArrived,
    t.MinDiffTransfertoAllocated = s.MinDiffTransfertoAllocated,
    t.MinDiffTransfertoArrived = s.MinDiffTransfertoArrived,
    t.MinDiffAllocatedtoTarget = s.MinDiffAllocatedtoTarget,
    t.MissedResponseFlag = s.MissedResponseFlag,
    t.MissedAllocationFlag = s.MissedAllocationFlag,
    t.PriorityID = s.PriorityID,
    t.DistancedTravelled = s.DistancedTravelled,
    t.First_Lat = s.First_Lat,
    t.First_Long = s.First_Long,
    t.Last_Lat = s.Last_Lat,
    t.Last_Long = s.Last_Long,
    t.FK_IncidentID = s.FK_IncidentID,
    t.FK_DateSavedActualID = s.FK_DateSavedActualID,
    t.FK_DateSavedPoliceID = s.FK_DateSavedPoliceID,
    t.FK_TimeSavedID = s.FK_TimeSavedID,
    t.FK_GeoID = s.FK_GeoID,
    t.FK_LocationID = s.FK_LocationID,
    t.FK_CallerTakerID = s.FK_CallerTakerID,
    t.FK_DispatcherID = s.FK_DispatcherID,
    t.FK_InitialServiceCodeID = s.FK_InitialServiceCodeID,
    t.FK_PriorityID = s.FK_PriorityID,
    t.FK_OfficerID = s.FK_OfficerID,
    t.FK_DistanceID = s.FK_DistanceID,
    t.AllocationOrder = s.AllocationOrder,
    t.maxallocationorder = s.maxallocationorder,
    t.FirstAllocated = s.FirstAllocated,
    t.FinalServCode = s.FinalServCode,
    t.OfficerEmployeeNo = s.OfficerEmployeeNo,
    t.Off_Staff_Move_ID = s.Off_Staff_Move_ID,
    t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
    t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
    t.OA_REC_END_DATE = s.OA_REC_END_DATE,
    t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
    t.OA_VERSION = s.OA_VERSION
  WHEN NOT MATCHED THEN
    INSERT (PK_IncidentOfficerResponse, IncidentNaturalID, UnitNo, PersonnelID, LoadID, UnitType, ArrivalOrder, FirstArrived, MaxArrivalOrder, MinProximityToShiftHandover, NonResponseUnitFlag, DateTransfer, TimeTransfer, DateAllocated, TimeAllocated, DateArrived, TimeArrived, MinDiffSavedtoTransfer, MinDiffSavedtoAllocated, MinDiffSavedtoArrived, MinDiffTransfertoAllocated, MinDiffTransfertoArrived, MinDiffAllocatedtoTarget, MissedResponseFlag, MissedAllocationFlag, PriorityID, DistancedTravelled, First_Lat, First_Long, Last_Lat, Last_Long, FK_IncidentID, FK_DateSavedActualID, FK_DateSavedPoliceID, FK_TimeSavedID, FK_GeoID, FK_LocationID, FK_CallerTakerID, FK_DispatcherID, FK_InitialServiceCodeID, FK_PriorityID, FK_OfficerID, FK_DistanceID, AllocationOrder, maxallocationorder, FirstAllocated, FinalServCode, OfficerEmployeeNo, Off_Staff_Move_ID, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
    VALUES (s.PK_IncidentOfficerResponse, s.IncidentNaturalID, s.UnitNo, s.PersonnelID, s.LoadID, s.UnitType, s.ArrivalOrder, s.FirstArrived, s.MaxArrivalOrder, s.MinProximityToShiftHandover, s.NonResponseUnitFlag, s.DateTransfer, s.TimeTransfer, s.DateAllocated, s.TimeAllocated, s.DateArrived, s.TimeArrived, s.MinDiffSavedtoTransfer, s.MinDiffSavedtoAllocated, s.MinDiffSavedtoArrived, s.MinDiffTransfertoAllocated, s.MinDiffTransfertoArrived, s.MinDiffAllocatedtoTarget, s.MissedResponseFlag, s.MissedAllocationFlag, s.PriorityID, s.DistancedTravelled, s.First_Lat, s.First_Long, s.Last_Lat, s.Last_Long, s.FK_IncidentID, s.FK_DateSavedActualID, s.FK_DateSavedPoliceID, s.FK_TimeSavedID, s.FK_GeoID, s.FK_LocationID, s.FK_CallerTakerID, s.FK_DispatcherID, s.FK_InitialServiceCodeID, s.FK_PriorityID, s.FK_OfficerID, s.FK_DistanceID, s.AllocationOrder, s.maxallocationorder, s.FirstAllocated, s.FinalServCode, s.OfficerEmployeeNo, s.Off_Staff_Move_ID, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
  SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
  DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
  THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_f_incidentofficerresponse, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_f_incidentofficerresponse OUTPUT;
 SET @run_id_rprt_tbl_f_incidentofficerresponse = @table_name_rprt_tbl_f_incidentofficerresponse + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_f_incidentofficerresponse + N': ' + CAST(@rows_affected_rprt_tbl_f_incidentofficerresponse AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_f_incidentofficerresponse + N')';
 SET @sql_log_success_rprt_tbl_f_incidentofficerresponse =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_f_incidentofficerresponse,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_f_incidentofficerresponse,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_f_incidentofficerresponse,
 @rows = @rows_affected_rprt_tbl_f_incidentofficerresponse,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_f_incidentofficerresponse = N'rprt.tbl_f_IncidentOfficerResponse' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_f_incidentofficerresponse = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_f_incidentofficerresponse =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_f_IncidentOfficerResponse' + N' \n Message=' + @err_msg_rprt_tbl_f_incidentofficerresponse + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_f_IncidentOfficerResponse AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_f_IncidentOfficerResponse AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_f_IncidentOfficerResponse: ' + @err_msg_rprt_tbl_f_incidentofficerresponse + N' (run_id=' + @run_id_rprt_tbl_f_incidentofficerresponse + N')';
 SET @sql_log_error_rprt_tbl_f_incidentofficerresponse =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_f_incidentofficerresponse,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_f_IncidentOfficerResponse',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_f_incidentofficerresponse,
 @runid = @run_id_rprt_tbl_f_incidentofficerresponse,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;


/* ============================================================ 
 Final consolidated grid for this cell (no table variables)
 ============================================================ */
DECLARE @sql_show NVARCHAR(MAX) =
 N'SELECT
 STATUS AS Status,
 NOTEBOOK_NAME AS TableName,
 ROWS_AFFECTED AS RowsAffected,
 RUN_ID AS RunId
 FROM ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 WHERE FolderDateTime = @f
 ORDER BY TableName;';
EXEC sp_executesql
 @sql_show,
 N'@f varchar(14)',
 @f = @runFolder;

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse",
-- META   "frozen": false,
-- META   "editable": true
-- META }

-- MARKDOWN ********************

-- ###### BAIL F LAKEHOUSE TO WARHOUSE

-- CELL ********************

/* ============================================================
 Run-wide variables for this cell
 ============================================================ */
DECLARE @wh_db NVARCHAR(255) = N'WH_400_Gold_Test';
DECLARE @lh_db NVARCHAR(255) = N'LH_300_Gold_Test';
DECLARE @source NVARCHAR(50) = N'Bail';
-- One FolderDateTime (yyyyMMddHHmmss) shared by all MERGEs in this cell
DECLARE @runFolder VARCHAR(14) =
 CONVERT(VARCHAR(8), SYSDATETIME(), 112) + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), ':', '');

/* ==================================================================
 MERGE #1: rprt.tbl_f_bail SOURCE = 'Bail'
 ================================================================== */
DECLARE @table_name_rprt_tbl_f_bail NVARCHAR(255) = N'rprt.tbl_f_bail';
DECLARE @rows_affected_rprt_tbl_f_bail INT = 0;
DECLARE @run_id_rprt_tbl_f_bail NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_f_bail NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_f_bail NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_f_bail NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_f_bail NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_f_bail NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_f_bail AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_f_bail AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.FK_D_BAIL_CUSTODY_ID = s.FK_D_BAIL_CUSTODY_ID,
 t.LoadID = s.LoadID,
 t.FK_D_CREATE_DATE_ID = s.FK_D_CREATE_DATE_ID,
 t.FK_D_CREATE_TIME_ID = s.FK_D_CREATE_TIME_ID,
 t.FK_D_CUSTODY_REF = s.FK_D_CUSTODY_REF,
 t.FK_D_BAIL_OIC_ID = s.FK_D_BAIL_OIC_ID,
 t.F_BAIL_OIC_ID = s.F_BAIL_OIC_ID,
 t.FK_D_BAIL_GEO_DISTRICT_ID = s.FK_D_BAIL_GEO_DISTRICT_ID,
 t.FK_D_BAIL_SUPERVISOR_ID = s.FK_D_BAIL_SUPERVISOR_ID,
 t.FK_D_BAIL_AUTHORISING_OFFICER_ID = s.FK_D_BAIL_AUTHORISING_OFFICER_ID,
 t.F_MET_LENGTH_DAYS = s.F_MET_LENGTH_DAYS,
 t.F_MET_PROXIMITY_EXPIRY = s.F_MET_PROXIMITY_EXPIRY,
 t.BAIL_TYPE = s.BAIL_TYPE,
 t.LIVE_OR_HISTORIC = s.LIVE_OR_HISTORIC,
 t.STAFF_MOVE_ID = s.STAFF_MOVE_ID,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (FK_D_BAIL_CUSTODY_ID, LoadID, FK_D_CREATE_DATE_ID, FK_D_CREATE_TIME_ID, FK_D_CUSTODY_REF, FK_D_BAIL_OIC_ID, F_BAIL_OIC_ID, FK_D_BAIL_GEO_DISTRICT_ID, FK_D_BAIL_SUPERVISOR_ID, FK_D_BAIL_AUTHORISING_OFFICER_ID, F_MET_LENGTH_DAYS, F_MET_PROXIMITY_EXPIRY, BAIL_TYPE, LIVE_OR_HISTORIC, STAFF_MOVE_ID, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.FK_D_BAIL_CUSTODY_ID, s.LoadID, s.FK_D_CREATE_DATE_ID, s.FK_D_CREATE_TIME_ID, s.FK_D_CUSTODY_REF, s.FK_D_BAIL_OIC_ID, s.F_BAIL_OIC_ID, s.FK_D_BAIL_GEO_DISTRICT_ID, s.FK_D_BAIL_SUPERVISOR_ID, s.FK_D_BAIL_AUTHORISING_OFFICER_ID, s.F_MET_LENGTH_DAYS, s.F_MET_PROXIMITY_EXPIRY, s.BAIL_TYPE, s.LIVE_OR_HISTORIC, s.STAFF_MOVE_ID, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_f_bail, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_f_bail OUTPUT;
 SET @run_id_rprt_tbl_f_bail = @table_name_rprt_tbl_f_bail + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_f_bail + N': ' + CAST(@rows_affected_rprt_tbl_f_bail AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_f_bail + N')';
 SET @sql_log_success_rprt_tbl_f_bail =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_f_bail,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_f_bail,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_f_bail,
 @rows = @rows_affected_rprt_tbl_f_bail,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_f_bail = N'rprt.tbl_f_bail' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_f_bail = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_f_bail =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_f_bail' + N' \n Message=' + @err_msg_rprt_tbl_f_bail + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_f_bail AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_f_bail AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_f_bail: ' + @err_msg_rprt_tbl_f_bail + N' (run_id=' + @run_id_rprt_tbl_f_bail + N')';
 SET @sql_log_error_rprt_tbl_f_bail =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_f_bail,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_f_bail',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_f_bail,
 @runid = @run_id_rprt_tbl_f_bail,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ============================================================ 
 Final consolidated grid for this cell (no table variables)
 ============================================================ */
DECLARE @sql_show NVARCHAR(MAX) =
 N'SELECT
 STATUS AS Status,
 NOTEBOOK_NAME AS TableName,
 ROWS_AFFECTED AS RowsAffected,
 RUN_ID AS RunId
 FROM ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 WHERE FolderDateTime = @f
 ORDER BY TableName;';
EXEC sp_executesql
 @sql_show,
 N'@f varchar(14)',
 @f = @runFolder;

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse",
-- META   "frozen": false,
-- META   "editable": true
-- META }

-- MARKDOWN ********************

-- ###### ATHENA F LAKEHOUSE TO WARHOUSE

-- CELL ********************

/* ============================================================
 Run-wide variables for this cell
 ============================================================ */
DECLARE @wh_db NVARCHAR(255) = N'WH_400_Gold_Test';
DECLARE @lh_db NVARCHAR(255) = N'LH_300_Gold_Test';
DECLARE @source NVARCHAR(50) = N'Athena';
-- One FolderDateTime (yyyyMMddHHmmss) shared by all MERGEs in this cell
DECLARE @runFolder VARCHAR(14) =
 CONVERT(VARCHAR(8), SYSDATETIME(), 112) + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), ':', '');

/* ==================================================================
 MERGE #1: rprt.tbl_f_crime SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_f_crime NVARCHAR(255) = N'rprt.tbl_f_crime';
DECLARE @rows_affected_rprt_tbl_f_crime INT = 0;
DECLARE @run_id_rprt_tbl_f_crime NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_f_crime NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_f_crime NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_f_crime NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_f_crime NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_f_crime NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_f_crime AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_f_crime AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET

 t.F_CRIME_ID = s.F_CRIME_ID,
--  t.LoadID = s.LoadID,
 t.FK_D_CRIME_ID = s.FK_D_CRIME_ID,
 t.FK_CRIME_INCIDENT_CREATED_DATE_ID = s.FK_CRIME_INCIDENT_CREATED_DATE_ID,
 t.FK_CRIME_INCIDENT_CREATED_TIME_ID = s.FK_CRIME_INCIDENT_CREATED_TIME_ID,
 t.FK_CRIME_INCIDENT_FROM_DATE_ID = s.FK_CRIME_INCIDENT_FROM_DATE_ID,
 t.FK_CRIME_INCIDENT_FROM_TIME_ID = s.FK_CRIME_INCIDENT_FROM_TIME_ID,
 t.FK_D_CRIME_INCIDENT_ID = s.FK_D_CRIME_INCIDENT_ID,
 t.HAS_VICTIM = s.HAS_VICTIM,
 t.HAS_SUSPECT = s.HAS_SUSPECT,
 t.FK_F_CRIME_URN = s.FK_F_CRIME_URN,
 t.FK_F_CRIME_DISPOSAL_DATE_ID = s.FK_F_CRIME_DISPOSAL_DATE_ID,
 t.FK_D_ATHENA_GEO_ID = s.FK_D_ATHENA_GEO_ID,
 t.FK_IncidentNaturalID = s.FK_IncidentNaturalID,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION

 WHEN NOT MATCHED THEN
 INSERT (F_CRIME_ID, LoadID, FK_D_CRIME_ID, FK_CRIME_INCIDENT_CREATED_DATE_ID, FK_CRIME_INCIDENT_CREATED_TIME_ID, FK_CRIME_INCIDENT_FROM_DATE_ID, FK_CRIME_INCIDENT_FROM_TIME_ID, FK_D_CRIME_INCIDENT_ID, HAS_VICTIM, HAS_SUSPECT, FK_F_CRIME_URN, FK_F_CRIME_DISPOSAL_DATE_ID, FK_D_ATHENA_GEO_ID, FK_IncidentNaturalID, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.F_CRIME_ID, s.LoadID, s.FK_D_CRIME_ID, s.FK_CRIME_INCIDENT_CREATED_DATE_ID, s.FK_CRIME_INCIDENT_CREATED_TIME_ID, s.FK_CRIME_INCIDENT_FROM_DATE_ID, s.FK_CRIME_INCIDENT_FROM_TIME_ID, s.FK_D_CRIME_INCIDENT_ID, s.HAS_VICTIM, s.HAS_SUSPECT, s.FK_F_CRIME_URN, s.FK_F_CRIME_DISPOSAL_DATE_ID, s.FK_D_ATHENA_GEO_ID, s.FK_IncidentNaturalID, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_f_crime, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_f_crime OUTPUT;
 SET @run_id_rprt_tbl_f_crime = @table_name_rprt_tbl_f_crime + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_f_crime + N': ' + CAST(@rows_affected_rprt_tbl_f_crime AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_f_crime + N')';
 SET @sql_log_success_rprt_tbl_f_crime =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_f_crime,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_f_crime,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_f_crime,
 @rows = @rows_affected_rprt_tbl_f_crime,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_f_crime = N'rprt.tbl_f_crime' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_f_crime = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_f_crime =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_f_crime' + N' \n Message=' + @err_msg_rprt_tbl_f_crime + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_f_crime AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_f_crime AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_f_crime: ' + @err_msg_rprt_tbl_f_crime + N' (run_id=' + @run_id_rprt_tbl_f_crime + N')';
 SET @sql_log_error_rprt_tbl_f_crime =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_f_crime,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_f_crime',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_f_crime,
 @runid = @run_id_rprt_tbl_f_crime,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #2: rprt.tbl_f_vcc SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_f_vcc NVARCHAR(255) = N'rprt.tbl_f_vcc';
DECLARE @rows_affected_rprt_tbl_f_vcc INT = 0;
DECLARE @run_id_rprt_tbl_f_vcc NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_f_vcc NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_f_vcc NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_f_vcc NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_f_vcc NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_f_vcc NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_f_vcc AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_f_vcc AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.F_VCC_ID = s.F_VCC_ID,
 t.LoadID = s.LoadID,
 t.FK_D_VCC_ID = s.FK_D_VCC_ID,
 t.FK_D_CRIME_ID = s.FK_D_CRIME_ID,
 t.FK_D_ORG_OFFICER_ID = s.FK_D_ORG_OFFICER_ID,
 t.FK_D_INC_CREATION_DATE_ID = s.FK_D_INC_CREATION_DATE_ID,
 t.FK_D_INC_CREATION_TIME_ID = s.FK_D_INC_CREATION_TIME_ID,
 t.FK_D_ATHENA_GEO_ID = s.FK_D_ATHENA_GEO_ID,
 t.F_MET_OVERDUE_VCC = s.F_MET_OVERDUE_VCC,
 t.F_MET_OVERDUE_DAYS = s.F_MET_OVERDUE_DAYS,
 t.F_MET_UPDATE_FREQUENCY = s.F_MET_UPDATE_FREQUENCY,
 t.F_MET_UPCOMING_FLAG = s.F_MET_UPCOMING_FLAG,
 t.F_MET_RISK_OVERDUE = s.F_MET_RISK_OVERDUE,
 t.F_MET_NUMBER_CASES_ASSIGNED_TO_OFFICER = s.F_MET_NUMBER_CASES_ASSIGNED_TO_OFFICER,
 t.F_MET_CONTACT_MISSED_FLAG = s.F_MET_CONTACT_MISSED_FLAG,
 t.F_MET_CONTACT_MISSED_COUNT = s.F_MET_CONTACT_MISSED_COUNT,
 t.F_MET_OPT_OUT = s.F_MET_OPT_OUT,
 t.F_LIVE_HISTORIC = s.F_LIVE_HISTORIC,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (F_VCC_ID, LoadID, FK_D_VCC_ID, FK_D_CRIME_ID, FK_D_ORG_OFFICER_ID, FK_D_INC_CREATION_DATE_ID, FK_D_INC_CREATION_TIME_ID, FK_D_ATHENA_GEO_ID, F_MET_OVERDUE_VCC, F_MET_OVERDUE_DAYS, F_MET_UPDATE_FREQUENCY, F_MET_UPCOMING_FLAG, F_MET_RISK_OVERDUE, F_MET_NUMBER_CASES_ASSIGNED_TO_OFFICER, F_MET_CONTACT_MISSED_FLAG, F_MET_CONTACT_MISSED_COUNT, F_MET_OPT_OUT, F_LIVE_HISTORIC, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.F_VCC_ID, s.LoadID, s.FK_D_VCC_ID, s.FK_D_CRIME_ID, s.FK_D_ORG_OFFICER_ID, s.FK_D_INC_CREATION_DATE_ID, s.FK_D_INC_CREATION_TIME_ID, s.FK_D_ATHENA_GEO_ID, s.F_MET_OVERDUE_VCC, s.F_MET_OVERDUE_DAYS, s.F_MET_UPDATE_FREQUENCY, s.F_MET_UPCOMING_FLAG, s.F_MET_RISK_OVERDUE, s.F_MET_NUMBER_CASES_ASSIGNED_TO_OFFICER, s.F_MET_CONTACT_MISSED_FLAG, s.F_MET_CONTACT_MISSED_COUNT, s.F_MET_OPT_OUT, s.F_LIVE_HISTORIC, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_f_vcc, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_f_vcc OUTPUT;
 SET @run_id_rprt_tbl_f_vcc = @table_name_rprt_tbl_f_vcc + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_f_vcc + N': ' + CAST(@rows_affected_rprt_tbl_f_vcc AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_f_vcc + N')';
 SET @sql_log_success_rprt_tbl_f_vcc =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_f_vcc,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_f_vcc,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_f_vcc,
 @rows = @rows_affected_rprt_tbl_f_vcc,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_f_vcc = N'rprt.tbl_f_vcc' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_f_vcc = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_f_vcc =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_f_vcc' + N' \n Message=' + @err_msg_rprt_tbl_f_vcc + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_f_vcc AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_f_vcc AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_f_vcc: ' + @err_msg_rprt_tbl_f_vcc + N' (run_id=' + @run_id_rprt_tbl_f_vcc + N')';
 SET @sql_log_error_rprt_tbl_f_vcc =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_f_vcc,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_f_vcc',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_f_vcc,
 @runid = @run_id_rprt_tbl_f_vcc,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #3: rprt.tbl_f_workload SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_f_workload NVARCHAR(255) = N'rprt.tbl_f_workload';
DECLARE @rows_affected_rprt_tbl_f_workload INT = 0;
DECLARE @run_id_rprt_tbl_f_workload NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_f_workload NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_f_workload NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_f_workload NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_f_workload NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_f_workload NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_f_workload AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_f_workload AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.FK_WORKLOAD_ID = s.FK_WORKLOAD_ID,
 t.FK_D_CASE_ID = s.FK_D_CASE_ID,
 t.FK_D_CRIME_ID = s.FK_D_CRIME_ID,
 t.F_WORKLOAD_TYPE = s.F_WORKLOAD_TYPE,
 t.F_OFFENCE_TYPE = s.F_OFFENCE_TYPE,
 t.F_CRIME_CATEGORY = s.F_CRIME_CATEGORY,
 t.F_OUTCOME = s.F_OUTCOME,
 t.F_HAS_CASE = s.F_HAS_CASE,
 t.F_HAS_CRIME = s.F_HAS_CRIME,
 t.F_HAS_SUSPECT = s.F_HAS_SUSPECT,
 t.F_HAS_VICTIM = s.F_HAS_VICTIM,
 t.F_MET_RISK_LEVEL = s.F_MET_RISK_LEVEL,
 t.F_PROCESSED = s.F_PROCESSED,
 t.F_HARM_SCORE = s.F_HARM_SCORE,
 t.LoadID = s.LoadID,
 t.FK_CREATED_DATE_ID = s.FK_CREATED_DATE_ID,
 t.F_LENGTH = s.F_LENGTH,
 t.F_DETAILS = s.F_DETAILS,
 t.F_HIGH_HARM = s.F_HIGH_HARM,
 t.F_OUTCOME_SOLVED_UNSOLVED = s.F_OUTCOME_SOLVED_UNSOLVED,
 t.F_OUTCOME_DETAILS = s.F_OUTCOME_DETAILS,
 t.FK_D_PERSONNELID = s.FK_D_PERSONNELID,
 t.F_PERSONNEL_ATHENA_EMPLOYEE_ITERATION_ID = s.F_PERSONNEL_ATHENA_EMPLOYEE_ITERATION_ID,
 t.F_PERSONNEL_EMPLOYEE_NO = s.F_PERSONNEL_EMPLOYEE_NO,
 t.F_END_DATE = s.F_END_DATE,
 t.F_CASE_REF = s.F_CASE_REF,
 t.F_CRIME_REF = s.F_CRIME_REF,
 t.F_VALID_RECORD = s.F_VALID_RECORD,
 t.F_SUSPECT_STATUS = s.F_SUSPECT_STATUS,
 t.F_VICTIM_VULNERABLE = s.F_VICTIM_VULNERABLE,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (FK_WORKLOAD_ID, FK_D_CASE_ID, FK_D_CRIME_ID, F_WORKLOAD_TYPE, F_OFFENCE_TYPE, F_CRIME_CATEGORY, F_OUTCOME, F_HAS_CASE, F_HAS_CRIME, F_HAS_SUSPECT, F_HAS_VICTIM, F_MET_RISK_LEVEL, F_PROCESSED, F_HARM_SCORE, LoadID, FK_CREATED_DATE_ID, F_LENGTH, F_DETAILS, F_HIGH_HARM, F_OUTCOME_SOLVED_UNSOLVED, F_OUTCOME_DETAILS, FK_D_PERSONNELID, F_PERSONNEL_ATHENA_EMPLOYEE_ITERATION_ID, F_PERSONNEL_EMPLOYEE_NO, F_END_DATE, F_CASE_REF, F_CRIME_REF, F_VALID_RECORD, F_SUSPECT_STATUS, F_VICTIM_VULNERABLE, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.FK_WORKLOAD_ID, s.FK_D_CASE_ID, s.FK_D_CRIME_ID, s.F_WORKLOAD_TYPE, s.F_OFFENCE_TYPE, s.F_CRIME_CATEGORY, s.F_OUTCOME, s.F_HAS_CASE, s.F_HAS_CRIME, s.F_HAS_SUSPECT, s.F_HAS_VICTIM, s.F_MET_RISK_LEVEL, s.F_PROCESSED, s.F_HARM_SCORE, s.LoadID, s.FK_CREATED_DATE_ID, s.F_LENGTH, s.F_DETAILS, s.F_HIGH_HARM, s.F_OUTCOME_SOLVED_UNSOLVED, s.F_OUTCOME_DETAILS, s.FK_D_PERSONNELID, s.F_PERSONNEL_ATHENA_EMPLOYEE_ITERATION_ID, s.F_PERSONNEL_EMPLOYEE_NO, s.F_END_DATE, s.F_CASE_REF, s.F_CRIME_REF, s.F_VALID_RECORD, s.F_SUSPECT_STATUS, s.F_VICTIM_VULNERABLE, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_f_workload, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_f_workload OUTPUT;
 SET @run_id_rprt_tbl_f_workload = @table_name_rprt_tbl_f_workload + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_f_workload + N': ' + CAST(@rows_affected_rprt_tbl_f_workload AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_f_workload + N')';
 SET @sql_log_success_rprt_tbl_f_workload =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_f_workload,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_f_workload,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_f_workload,
 @rows = @rows_affected_rprt_tbl_f_workload,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_f_workload = N'rprt.tbl_f_workload' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_f_workload = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_f_workload =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_f_workload' + N' \n Message=' + @err_msg_rprt_tbl_f_workload + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_f_workload AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_f_workload AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_f_workload: ' + @err_msg_rprt_tbl_f_workload + N' (run_id=' + @run_id_rprt_tbl_f_workload + N')';
 SET @sql_log_error_rprt_tbl_f_workload =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_f_workload,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_f_workload',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_f_workload,
 @runid = @run_id_rprt_tbl_f_workload,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #4: rprt.tbl_f_custody_record SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_f_custody_record NVARCHAR(255) = N'rprt.tbl_f_custody_record';
DECLARE @rows_affected_rprt_tbl_f_custody_record INT = 0;
DECLARE @run_id_rprt_tbl_f_custody_record NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_f_custody_record NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_f_custody_record NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_f_custody_record NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_f_custody_record NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_f_custody_record NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_f_custody_record AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_f_custody_record AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.F_CUSTODY_RECORD_ID = s.F_CUSTODY_RECORD_ID,
 t.LoadID = s.LoadID,
 t.F_CUSTODY_REFERENCE_NUMBER = s.F_CUSTODY_REFERENCE_NUMBER,
 t.F_CUSTODY_TYPE = s.F_CUSTODY_TYPE,
 t.F_CUSTODY_ORIGINAL_TYPE = s.F_CUSTODY_ORIGINAL_TYPE,
 t.F_CUSTODY_CURRENT_STATUS = s.F_CUSTODY_CURRENT_STATUS,
 t.F_CUSTODY_FORCE_ID = s.F_CUSTODY_FORCE_ID,
 t.F_CUSTODY_ATTENDANCE_REASON = s.F_CUSTODY_ATTENDANCE_REASON,
 t.F_CUSTODY_MULTIPLE_ARRESTS = s.F_CUSTODY_MULTIPLE_ARRESTS,
 t.F_CUSTODY_RELEVANT_TIME = s.F_CUSTODY_RELEVANT_TIME,
 t.F_CUSTODY_CLOCK_START_DATE_TIME = s.F_CUSTODY_CLOCK_START_DATE_TIME,
 t.F_CUSTODY_CLOCK_STOP_DATE_TIME = s.F_CUSTODY_CLOCK_STOP_DATE_TIME,
 t.F_CUSTODY_TOTAL_TIME_IN_CUSTODY_MINS = s.F_CUSTODY_TOTAL_TIME_IN_CUSTODY_MINS,
 t.F_CUSTODY_TOTAL_TIME_AUTH_MINS = s.F_CUSTODY_TOTAL_TIME_AUTH_MINS,
 t.F_CUSTODY_SCHEDULED_RELEASE_DATE_TIME = s.F_CUSTODY_SCHEDULED_RELEASE_DATE_TIME,
 t.F_CUSTODY_OFFICER_ID = s.F_CUSTODY_OFFICER_ID,
 t.F_CUSTODY_DUI_OR_FTP = s.F_CUSTODY_DUI_OR_FTP,
 t.F_CUSTODY_MAIN_ARREST_DATE_TIME = s.F_CUSTODY_MAIN_ARREST_DATE_TIME,
 t.F_CUSTODY_PERSON_ID = s.F_CUSTODY_PERSON_ID,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (F_CUSTODY_RECORD_ID, LoadID, F_CUSTODY_REFERENCE_NUMBER, F_CUSTODY_TYPE, F_CUSTODY_ORIGINAL_TYPE, F_CUSTODY_CURRENT_STATUS, F_CUSTODY_FORCE_ID, F_CUSTODY_ATTENDANCE_REASON, F_CUSTODY_MULTIPLE_ARRESTS, F_CUSTODY_RELEVANT_TIME, F_CUSTODY_CLOCK_START_DATE_TIME, F_CUSTODY_CLOCK_STOP_DATE_TIME, F_CUSTODY_TOTAL_TIME_IN_CUSTODY_MINS, F_CUSTODY_TOTAL_TIME_AUTH_MINS, F_CUSTODY_SCHEDULED_RELEASE_DATE_TIME, F_CUSTODY_OFFICER_ID, F_CUSTODY_DUI_OR_FTP, F_CUSTODY_MAIN_ARREST_DATE_TIME, F_CUSTODY_PERSON_ID, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.F_CUSTODY_RECORD_ID, s.LoadID, s.F_CUSTODY_REFERENCE_NUMBER, s.F_CUSTODY_TYPE, s.F_CUSTODY_ORIGINAL_TYPE, s.F_CUSTODY_CURRENT_STATUS, s.F_CUSTODY_FORCE_ID, s.F_CUSTODY_ATTENDANCE_REASON, s.F_CUSTODY_MULTIPLE_ARRESTS, s.F_CUSTODY_RELEVANT_TIME, s.F_CUSTODY_CLOCK_START_DATE_TIME, s.F_CUSTODY_CLOCK_STOP_DATE_TIME, s.F_CUSTODY_TOTAL_TIME_IN_CUSTODY_MINS, s.F_CUSTODY_TOTAL_TIME_AUTH_MINS, s.F_CUSTODY_SCHEDULED_RELEASE_DATE_TIME, s.F_CUSTODY_OFFICER_ID, s.F_CUSTODY_DUI_OR_FTP, s.F_CUSTODY_MAIN_ARREST_DATE_TIME, s.F_CUSTODY_PERSON_ID, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_f_custody_record, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_f_custody_record OUTPUT;
 SET @run_id_rprt_tbl_f_custody_record = @table_name_rprt_tbl_f_custody_record + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_f_custody_record + N': ' + CAST(@rows_affected_rprt_tbl_f_custody_record AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_f_custody_record + N')';
 SET @sql_log_success_rprt_tbl_f_custody_record =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_f_custody_record,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_f_custody_record,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_f_custody_record,
 @rows = @rows_affected_rprt_tbl_f_custody_record,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_f_custody_record = N'rprt.tbl_f_custody_record' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_f_custody_record = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_f_custody_record =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_f_custody_record' + N' \n Message=' + @err_msg_rprt_tbl_f_custody_record + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_f_custody_record AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_f_custody_record AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_f_custody_record: ' + @err_msg_rprt_tbl_f_custody_record + N' (run_id=' + @run_id_rprt_tbl_f_custody_record + N')';
 SET @sql_log_error_rprt_tbl_f_custody_record =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_f_custody_record,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_f_custody_record',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_f_custody_record,
 @runid = @run_id_rprt_tbl_f_custody_record,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ============================================================ 
 Final consolidated grid for this cell (no table variables)
 ============================================================ */
DECLARE @sql_show NVARCHAR(MAX) =
 N'SELECT
 STATUS AS Status,
 NOTEBOOK_NAME AS TableName,
 ROWS_AFFECTED AS RowsAffected,
 RUN_ID AS RunId
 FROM ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 WHERE FolderDateTime = @f
 ORDER BY TableName;';
EXEC sp_executesql
 @sql_show,
 N'@f varchar(14)',
 @f = @runFolder;

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse",
-- META   "frozen": false,
-- META   "editable": true
-- META }

-- MARKDOWN ********************

-- ###### **TEST**

-- CELL ********************

SELECT * FROM
-- DELETE
[WH_400_Gold_Test].[ctrl].[tbl_DWLoadLog]
WHERE NOTEBOOK_NAME LIKE 'rprt.tbl_f_%'
ORDER BY 9 DESC

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse",
-- META   "frozen": false,
-- META   "editable": true
-- META }

-- MARKDOWN ********************

-- ###### **Test**
