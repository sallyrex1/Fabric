-- Fabric notebook source

-- METADATA ********************

-- META {
-- META   "kernel_info": {
-- META     "name": "sqldatawarehouse"
-- META   },
-- META   "dependencies": {
-- META     "warehouse": {
-- META       "default_warehouse": "65b85860-6e65-95e7-4399-e89ee955f64e",
-- META       "known_warehouses": [
-- META         {
-- META           "id": "65b85860-6e65-95e7-4399-e89ee955f64e",
-- META           "type": "Datawarehouse"
-- META         }
-- META       ]
-- META     }
-- META   }
-- META }

-- MARKDOWN ********************

-- ## **WH B TABLES INGEST**

-- MARKDOWN ********************

-- ###### SAP B LAKEHOUSE TO WARHOUSE

-- CELL ********************

-- N/A

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- MARKDOWN ********************

-- ###### STORM B LAKEHOUSE TO WARHOUSE

-- CELL ********************

-- N/A

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- MARKDOWN ********************

-- ###### BAIL B LAKEHOUSE TO WARHOUSE

-- CELL ********************

/* ============================================================
 Run-wide variables for this cell
 ============================================================ */
DECLARE @wh_db NVARCHAR(255) = N'WH_400_Gold_Test';
DECLARE @lh_db NVARCHAR(255) = N'LH_300_Gold_Test';
DECLARE @source NVARCHAR(50) = N'Bail';
-- One FolderDateTime (yyyyMMddHHmmss) shared by all MERGEs in this cell
DECLARE @runFolder VARCHAR(14) =
 CONVERT(VARCHAR(8), SYSDATETIME(), 112) + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), ':', '');

/* ==================================================================
 MERGE #1: rprt.tbl_b_case_custody SOURCE = 'Bail'
 ================================================================== */
DECLARE @table_name_rprt_tbl_b_case_custody NVARCHAR(255) = N'rprt.tbl_b_case_custody';
DECLARE @rows_affected_rprt_tbl_b_case_custody INT = 0;
DECLARE @run_id_rprt_tbl_b_case_custody NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_b_case_custody NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_b_case_custody NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_b_case_custody NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_b_case_custody NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_b_case_custody NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_b_case_custody AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_b_case_custody AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.B_CASE_CUSTODY_LINK_ID = s.B_CASE_CUSTODY_LINK_ID,
 t.LoadID = s.LoadID,
 t.FK_D_CASE_ID = s.FK_D_CASE_ID,
 t.FK_F_CUSTODY_RECORD_ID = s.FK_F_CUSTODY_RECORD_ID,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (B_CASE_CUSTODY_LINK_ID, LoadID, FK_D_CASE_ID, FK_F_CUSTODY_RECORD_ID, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.B_CASE_CUSTODY_LINK_ID, s.LoadID, s.FK_D_CASE_ID, s.FK_F_CUSTODY_RECORD_ID, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_b_case_custody, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_b_case_custody OUTPUT;
 SET @run_id_rprt_tbl_b_case_custody = @table_name_rprt_tbl_b_case_custody + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_b_case_custody + N': ' + CAST(@rows_affected_rprt_tbl_b_case_custody AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_b_case_custody + N')';
 SET @sql_log_success_rprt_tbl_b_case_custody =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_b_case_custody,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_b_case_custody,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_b_case_custody,
 @rows = @rows_affected_rprt_tbl_b_case_custody,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_b_case_custody = N'rprt.tbl_b_case_custody' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_b_case_custody = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_b_case_custody =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_b_case_custody' + N' \n Message=' + @err_msg_rprt_tbl_b_case_custody + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_b_case_custody AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_b_case_custody AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_b_case_custody: ' + @err_msg_rprt_tbl_b_case_custody + N' (run_id=' + @run_id_rprt_tbl_b_case_custody + N')';
 SET @sql_log_error_rprt_tbl_b_case_custody =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_b_case_custody,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_b_case_custody',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_b_case_custody,
 @runid = @run_id_rprt_tbl_b_case_custody,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ============================================================ 
 Final consolidated grid for this cell (no table variables)
 ============================================================ */
DECLARE @sql_show NVARCHAR(MAX) =
 N'SELECT
 STATUS AS Status,
 NOTEBOOK_NAME AS TableName,
 ROWS_AFFECTED AS RowsAffected,
 RUN_ID AS RunId
 FROM ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 WHERE FolderDateTime = @f
 ORDER BY TableName;';
EXEC sp_executesql
 @sql_show,
 N'@f varchar(14)',
 @f = @runFolder;

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- MARKDOWN ********************

-- ###### ATHENA B LAKEHOUSE TO WARHOUSE

-- CELL ********************

/* ============================================================
 Run-wide variables for this cell
 ============================================================ */
DECLARE @wh_db NVARCHAR(255) = N'WH_400_Gold_Test';
DECLARE @lh_db NVARCHAR(255) = N'LH_300_Gold_Test';
DECLARE @source NVARCHAR(50) = N'Athena';
-- One FolderDateTime (yyyyMMddHHmmss) shared by all MERGEs in this cell
DECLARE @runFolder VARCHAR(14) =
 CONVERT(VARCHAR(8), SYSDATETIME(), 112) + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), ':', '');

/* ==================================================================
 MERGE #1: rprt.tbl_b_bailtoathena SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_b_bailtoathena NVARCHAR(255) = N'rprt.tbl_b_bailtoathena';
DECLARE @rows_affected_rprt_tbl_b_bailtoathena INT = 0;
DECLARE @run_id_rprt_tbl_b_bailtoathena NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_b_bailtoathena NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_b_bailtoathena NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_b_bailtoathena NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_b_bailtoathena NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_b_bailtoathena NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_b_bailtoathena AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_b_bailtoathena AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.ID = s.ID,
 t.LoadID = s.LoadID,
 t.D_BAIL_ID = s.D_BAIL_ID,
 t.D_ATHENA_BAIL_ID = s.D_ATHENA_BAIL_ID,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (ID, LoadID, D_BAIL_ID, D_ATHENA_BAIL_ID, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.ID, s.LoadID, s.D_BAIL_ID, s.D_ATHENA_BAIL_ID, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_b_bailtoathena, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_b_bailtoathena OUTPUT;
 SET @run_id_rprt_tbl_b_bailtoathena = @table_name_rprt_tbl_b_bailtoathena + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_b_bailtoathena + N': ' + CAST(@rows_affected_rprt_tbl_b_bailtoathena AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_b_bailtoathena + N')';
 SET @sql_log_success_rprt_tbl_b_bailtoathena =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_b_bailtoathena,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_b_bailtoathena,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_b_bailtoathena,
 @rows = @rows_affected_rprt_tbl_b_bailtoathena,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_b_bailtoathena = N'rprt.tbl_b_bailtoathena' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_b_bailtoathena = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_b_bailtoathena =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_b_bailtoathena' + N' \n Message=' + @err_msg_rprt_tbl_b_bailtoathena + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_b_bailtoathena AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_b_bailtoathena AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_b_bailtoathena: ' + @err_msg_rprt_tbl_b_bailtoathena + N' (run_id=' + @run_id_rprt_tbl_b_bailtoathena + N')';
 SET @sql_log_error_rprt_tbl_b_bailtoathena =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_b_bailtoathena,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_b_bailtoathena',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_b_bailtoathena,
 @runid = @run_id_rprt_tbl_b_bailtoathena,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #2: rprt.tbl_b_crime_custody SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_b_crime_custody NVARCHAR(255) = N'rprt.tbl_b_crime_custody';
DECLARE @rows_affected_rprt_tbl_b_crime_custody INT = 0;
DECLARE @run_id_rprt_tbl_b_crime_custody NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_b_crime_custody NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_b_crime_custody NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_b_crime_custody NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_b_crime_custody NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_b_crime_custody NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_b_crime_custody AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_b_crime_custody AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.B_CRIME_CUSTODY_LINK_ID = s.B_CRIME_CUSTODY_LINK_ID,
 t.LoadID = s.LoadID,
 t.FK_D_CRIME_ID = s.FK_D_CRIME_ID,
 t.FK_F_CUSTODY_RECORD_ID = s.FK_F_CUSTODY_RECORD_ID,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (B_CRIME_CUSTODY_LINK_ID, LoadID, FK_D_CRIME_ID, FK_F_CUSTODY_RECORD_ID, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.B_CRIME_CUSTODY_LINK_ID, s.LoadID, s.FK_D_CRIME_ID, s.FK_F_CUSTODY_RECORD_ID, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_b_crime_custody, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_b_crime_custody OUTPUT;
 SET @run_id_rprt_tbl_b_crime_custody = @table_name_rprt_tbl_b_crime_custody + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_b_crime_custody + N': ' + CAST(@rows_affected_rprt_tbl_b_crime_custody AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_b_crime_custody + N')';
 SET @sql_log_success_rprt_tbl_b_crime_custody =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_b_crime_custody,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_b_crime_custody,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_b_crime_custody,
 @rows = @rows_affected_rprt_tbl_b_crime_custody,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_b_crime_custody = N'rprt.tbl_b_crime_custody' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_b_crime_custody = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_b_crime_custody =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_b_crime_custody' + N' \n Message=' + @err_msg_rprt_tbl_b_crime_custody + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_b_crime_custody AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_b_crime_custody AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_b_crime_custody: ' + @err_msg_rprt_tbl_b_crime_custody + N' (run_id=' + @run_id_rprt_tbl_b_crime_custody + N')';
 SET @sql_log_error_rprt_tbl_b_crime_custody =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_b_crime_custody,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_b_crime_custody',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_b_crime_custody,
 @runid = @run_id_rprt_tbl_b_crime_custody,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #3: rprt.tbl_b_crime_person_info SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_b_crime_person_info NVARCHAR(255) = N'rprt.tbl_b_crime_person_info';
DECLARE @rows_affected_rprt_tbl_b_crime_person_info INT = 0;
DECLARE @run_id_rprt_tbl_b_crime_person_info NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_b_crime_person_info NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_b_crime_person_info NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_b_crime_person_info NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_b_crime_person_info NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_b_crime_person_info NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_b_crime_person_info AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_b_crime_person_info AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.B_CRIME_PERSON_ID = s.B_CRIME_PERSON_ID,
 t.LoadID = s.LoadID,
 t.FK_D_PERSON_ID = s.FK_D_PERSON_ID,
 t.FK_F_CRIME_ID = s.FK_F_CRIME_ID,
 t.B_VICTIM_VULNERABLE = s.B_VICTIM_VULNERABLE,
 t.B_REPEATED_VICTIM = s.B_REPEATED_VICTIM,
 t.B_CRIME_PERSON_STATUS = s.B_CRIME_PERSON_STATUS,
 t.FK_F_VCC_ID = s.FK_F_VCC_ID,
 t.B_PERSON_AGE = s.B_PERSON_AGE,
 t.B_PERSON_AGE_BAND = s.B_PERSON_AGE_BAND,
 t.B_SUSPECT_STATUS = s.B_SUSPECT_STATUS,
 t.FK_D_CRIME_ID = s.FK_D_CRIME_ID,
 t.B_SUSPECT_SUB_STATUS = s.B_SUSPECT_SUB_STATUS,
 t.B_VICTIM_SUSPECT_RELATIONSHIP = s.B_VICTIM_SUSPECT_RELATIONSHIP,
 t.B_CPI_DATE_LINKED_TO_CRIME = s.B_CPI_DATE_LINKED_TO_CRIME,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (B_CRIME_PERSON_ID, LoadID, FK_D_PERSON_ID, FK_F_CRIME_ID, B_VICTIM_VULNERABLE, B_REPEATED_VICTIM, B_CRIME_PERSON_STATUS, FK_F_VCC_ID, B_PERSON_AGE, B_PERSON_AGE_BAND, B_SUSPECT_STATUS, FK_D_CRIME_ID, B_SUSPECT_SUB_STATUS, B_VICTIM_SUSPECT_RELATIONSHIP, B_CPI_DATE_LINKED_TO_CRIME, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.B_CRIME_PERSON_ID, s.LoadID, s.FK_D_PERSON_ID, s.FK_F_CRIME_ID, s.B_VICTIM_VULNERABLE, s.B_REPEATED_VICTIM, s.B_CRIME_PERSON_STATUS, s.FK_F_VCC_ID, s.B_PERSON_AGE, s.B_PERSON_AGE_BAND, s.B_SUSPECT_STATUS, s.FK_D_CRIME_ID, s.B_SUSPECT_SUB_STATUS, s.B_VICTIM_SUSPECT_RELATIONSHIP, s.B_CPI_DATE_LINKED_TO_CRIME, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_b_crime_person_info, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_b_crime_person_info OUTPUT;
 SET @run_id_rprt_tbl_b_crime_person_info = @table_name_rprt_tbl_b_crime_person_info + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_b_crime_person_info + N': ' + CAST(@rows_affected_rprt_tbl_b_crime_person_info AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_b_crime_person_info + N')';
 SET @sql_log_success_rprt_tbl_b_crime_person_info =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_b_crime_person_info,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_b_crime_person_info,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_b_crime_person_info,
 @rows = @rows_affected_rprt_tbl_b_crime_person_info,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_b_crime_person_info = N'rprt.tbl_b_crime_person_info' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_b_crime_person_info = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_b_crime_person_info =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_b_crime_person_info' + N' \n Message=' + @err_msg_rprt_tbl_b_crime_person_info + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_b_crime_person_info AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_b_crime_person_info AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_b_crime_person_info: ' + @err_msg_rprt_tbl_b_crime_person_info + N' (run_id=' + @run_id_rprt_tbl_b_crime_person_info + N')';
 SET @sql_log_error_rprt_tbl_b_crime_person_info =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_b_crime_person_info,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_b_crime_person_info',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_b_crime_person_info,
 @runid = @run_id_rprt_tbl_b_crime_person_info,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #4: rprt.tbl_b_custody_arrest SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_b_custody_arrest NVARCHAR(255) = N'rprt.tbl_b_custody_arrest';
DECLARE @rows_affected_rprt_tbl_b_custody_arrest INT = 0;
DECLARE @run_id_rprt_tbl_b_custody_arrest NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_b_custody_arrest NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_b_custody_arrest NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_b_custody_arrest NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_b_custody_arrest NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_b_custody_arrest NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_b_custody_arrest AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_b_custody_arrest AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.B_CUSTODY_ARREST_LINK_ID = s.B_CUSTODY_ARREST_LINK_ID,
 t.LoadID = s.LoadID,
 t.FK_D_ARREST_ID = s.FK_D_ARREST_ID,
 t.FK_F_CUSTODY_RECORD_ID = s.FK_F_CUSTODY_RECORD_ID,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (B_CUSTODY_ARREST_LINK_ID, LoadID, FK_D_ARREST_ID, FK_F_CUSTODY_RECORD_ID, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.B_CUSTODY_ARREST_LINK_ID, s.LoadID, s.FK_D_ARREST_ID, s.FK_F_CUSTODY_RECORD_ID, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_b_custody_arrest, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_b_custody_arrest OUTPUT;
 SET @run_id_rprt_tbl_b_custody_arrest = @table_name_rprt_tbl_b_custody_arrest + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_b_custody_arrest + N': ' + CAST(@rows_affected_rprt_tbl_b_custody_arrest AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_b_custody_arrest + N')';
 SET @sql_log_success_rprt_tbl_b_custody_arrest =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_b_custody_arrest,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_b_custody_arrest,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_b_custody_arrest,
 @rows = @rows_affected_rprt_tbl_b_custody_arrest,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_b_custody_arrest = N'rprt.tbl_b_custody_arrest' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_b_custody_arrest = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_b_custody_arrest =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_b_custody_arrest' + N' \n Message=' + @err_msg_rprt_tbl_b_custody_arrest + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_b_custody_arrest AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_b_custody_arrest AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_b_custody_arrest: ' + @err_msg_rprt_tbl_b_custody_arrest + N' (run_id=' + @run_id_rprt_tbl_b_custody_arrest + N')';
 SET @sql_log_error_rprt_tbl_b_custody_arrest =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_b_custody_arrest,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_b_custody_arrest',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_b_custody_arrest,
 @runid = @run_id_rprt_tbl_b_custody_arrest,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #5: rprt.tbl_b_custody_offence SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_b_custody_offence NVARCHAR(255) = N'rprt.tbl_b_custody_offence';
DECLARE @rows_affected_rprt_tbl_b_custody_offence INT = 0;
DECLARE @run_id_rprt_tbl_b_custody_offence NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_b_custody_offence NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_b_custody_offence NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_b_custody_offence NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_b_custody_offence NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_b_custody_offence NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_b_custody_offence AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_b_custody_offence AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.B_CUSTODY_OFFENCE_LINK_ID = s.B_CUSTODY_OFFENCE_LINK_ID,
 t.LoadID = s.LoadID,
 t.FK_D_CUSTODY_OFFENCE_ID = s.FK_D_CUSTODY_OFFENCE_ID,
 t.FK_F_CUSTODY_RECORD_ID = s.FK_F_CUSTODY_RECORD_ID,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (B_CUSTODY_OFFENCE_LINK_ID, LoadID, FK_D_CUSTODY_OFFENCE_ID, FK_F_CUSTODY_RECORD_ID, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.B_CUSTODY_OFFENCE_LINK_ID, s.LoadID, s.FK_D_CUSTODY_OFFENCE_ID, s.FK_F_CUSTODY_RECORD_ID, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_b_custody_offence, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_b_custody_offence OUTPUT;
 SET @run_id_rprt_tbl_b_custody_offence = @table_name_rprt_tbl_b_custody_offence + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_b_custody_offence + N': ' + CAST(@rows_affected_rprt_tbl_b_custody_offence AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_b_custody_offence + N')';
 SET @sql_log_success_rprt_tbl_b_custody_offence =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_b_custody_offence,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_b_custody_offence,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_b_custody_offence,
 @rows = @rows_affected_rprt_tbl_b_custody_offence,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_b_custody_offence = N'rprt.tbl_b_custody_offence' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_b_custody_offence = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_b_custody_offence =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_b_custody_offence' + N' \n Message=' + @err_msg_rprt_tbl_b_custody_offence + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_b_custody_offence AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_b_custody_offence AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_b_custody_offence: ' + @err_msg_rprt_tbl_b_custody_offence + N' (run_id=' + @run_id_rprt_tbl_b_custody_offence + N')';
 SET @sql_log_error_rprt_tbl_b_custody_offence =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_b_custody_offence,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_b_custody_offence',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_b_custody_offence,
 @runid = @run_id_rprt_tbl_b_custody_offence,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #6: rprt.tbl_b_custody_subfacility SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_b_custody_subfacility NVARCHAR(255) = N'rprt.tbl_b_custody_subfacility';
DECLARE @rows_affected_rprt_tbl_b_custody_subfacility INT = 0;
DECLARE @run_id_rprt_tbl_b_custody_subfacility NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_b_custody_subfacility NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_b_custody_subfacility NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_b_custody_subfacility NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_b_custody_subfacility NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_b_custody_subfacility NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_b_custody_subfacility AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_b_custody_subfacility AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.B_CUSTODY_SUBFACILITY_ID = s.B_CUSTODY_SUBFACILITY_ID,
 t.LoadID = s.LoadID,
 t.FK_F_CUSTODY_RECORD_ID = s.FK_F_CUSTODY_RECORD_ID,
 t.FK_D_SUBFACILITY_ID = s.FK_D_SUBFACILITY_ID,
 t.B_OCCUPANCY_FROM_DATE = s.B_OCCUPANCY_FROM_DATE,
 t.B_OCCUPANCY_TO_DATE = s.B_OCCUPANCY_TO_DATE,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (B_CUSTODY_SUBFACILITY_ID, LoadID, FK_F_CUSTODY_RECORD_ID, FK_D_SUBFACILITY_ID, B_OCCUPANCY_FROM_DATE, B_OCCUPANCY_TO_DATE, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.B_CUSTODY_SUBFACILITY_ID, s.LoadID, s.FK_F_CUSTODY_RECORD_ID, s.FK_D_SUBFACILITY_ID, s.B_OCCUPANCY_FROM_DATE, s.B_OCCUPANCY_TO_DATE, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_b_custody_subfacility, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_b_custody_subfacility OUTPUT;
 SET @run_id_rprt_tbl_b_custody_subfacility = @table_name_rprt_tbl_b_custody_subfacility + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_b_custody_subfacility + N': ' + CAST(@rows_affected_rprt_tbl_b_custody_subfacility AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_b_custody_subfacility + N')';
 SET @sql_log_success_rprt_tbl_b_custody_subfacility =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_b_custody_subfacility,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_b_custody_subfacility,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_b_custody_subfacility,
 @rows = @rows_affected_rprt_tbl_b_custody_subfacility,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_b_custody_subfacility = N'rprt.tbl_b_custody_subfacility' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_b_custody_subfacility = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_b_custody_subfacility =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_b_custody_subfacility' + N' \n Message=' + @err_msg_rprt_tbl_b_custody_subfacility + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_b_custody_subfacility AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_b_custody_subfacility AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_b_custody_subfacility: ' + @err_msg_rprt_tbl_b_custody_subfacility + N' (run_id=' + @run_id_rprt_tbl_b_custody_subfacility + N')';
 SET @sql_log_error_rprt_tbl_b_custody_subfacility =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_b_custody_subfacility,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_b_custody_subfacility',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_b_custody_subfacility,
 @runid = @run_id_rprt_tbl_b_custody_subfacility,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ============================================================ 
 Final consolidated grid for this cell (no table variables)
 ============================================================ */
DECLARE @sql_show NVARCHAR(MAX) =
 N'SELECT
 STATUS AS Status,
 NOTEBOOK_NAME AS TableName,
 ROWS_AFFECTED AS RowsAffected,
 RUN_ID AS RunId
 FROM ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 WHERE FolderDateTime = @f
 ORDER BY TableName;';
EXEC sp_executesql
 @sql_show,
 N'@f varchar(14)',
 @f = @runFolder;

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- MARKDOWN ********************

-- ###### **TEST**

-- CELL ********************

SELECT * FROM
-- DELETE
[WH_400_Gold_Test].[ctrl].[tbl_DWLoadLog]
WHERE NOTEBOOK_NAME LIKE 'rprt.tbl_b_%'
ORDER BY 9 DESC

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- CELL ********************


-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- CELL ********************


-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }
