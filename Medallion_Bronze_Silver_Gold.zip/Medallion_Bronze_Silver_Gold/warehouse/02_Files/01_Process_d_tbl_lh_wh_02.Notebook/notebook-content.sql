-- Fabric notebook source

-- METADATA ********************

-- META {
-- META   "kernel_info": {
-- META     "name": "sqldatawarehouse"
-- META   },
-- META   "dependencies": {
-- META     "warehouse": {
-- META       "default_warehouse": "65b85860-6e65-95e7-4399-e89ee955f64e",
-- META       "known_warehouses": [
-- META         {
-- META           "id": "65b85860-6e65-95e7-4399-e89ee955f64e",
-- META           "type": "Datawarehouse"
-- META         }
-- META       ]
-- META     }
-- META   }
-- META }

-- MARKDOWN ********************

-- ## **WH D TABLES INGEST**

-- MARKDOWN ********************

-- ###### SAP F LAKEHOUSE TO WARHOUSE

-- CELL ********************

/* ============================================================
 Run-wide variables for this cell
 ============================================================ */
DECLARE @wh_db NVARCHAR(255) = N'WH_400_Gold_Test';
DECLARE @lh_db NVARCHAR(255) = N'LH_300_Gold_Test';
DECLARE @source NVARCHAR(50) = N'SAP';
-- One FolderDateTime (yyyyMMddHHmmss) shared by all MERGEs in this cell
DECLARE @runFolder VARCHAR(14) =
 CONVERT(VARCHAR(8), SYSDATETIME(), 112) + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), ':', '');

/* ==================================================================
 MERGE #1: rprt.tbl_d_staff_history SOURCE = 'SAP'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_staff_history NVARCHAR(255) = N'rprt.tbl_d_staff_history';
DECLARE @rows_affected_rprt_tbl_d_staff_history INT = 0;
DECLARE @run_id_rprt_tbl_d_staff_history NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_staff_history NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_staff_history NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_staff_history NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_staff_history NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_staff_history NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_staff_history AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_staff_history AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.PersonnelNumber = s.PersonnelNumber,
 t.StartDate = s.StartDate,
 t.EndDate = s.EndDate,
 t.FullName = s.FullName,
 t.Role = s.Role,
 t.RoleID = s.RoleID,
 t.Section = s.Section,
 t.SectionID = s.SectionID,
 t.Unit = s.Unit,
 t.UnitID = s.UnitID,
 t.Location = s.Location,
 t.LocationID = s.LocationID,
 t.Department = s.Department,
 t.DepartmentID = s.DepartmentID,
 t.Command = s.Command,
 t.CommandID = s.CommandID,
 t.Directorate = s.Directorate,
 t.DirectorateID = s.DirectorateID,
 t.Force = s.Force,
 t.ForceID = s.ForceID,
 t.STAFF_MOVE_ID = s.STAFF_MOVE_ID,
 t.[Current] = s.[Current],
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (PersonnelNumber, StartDate, EndDate, FullName, Role, RoleID, Section, SectionID, Unit, UnitID, Location, LocationID, Department, DepartmentID, Command, CommandID, Directorate, DirectorateID, Force, ForceID, STAFF_MOVE_ID, [Current], OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.PersonnelNumber, s.StartDate, s.EndDate, s.FullName, s.Role, s.RoleID, s.Section, s.SectionID, s.Unit, s.UnitID, s.Location, s.LocationID, s.Department, s.DepartmentID, s.Command, s.CommandID, s.Directorate, s.DirectorateID, s.Force, s.ForceID, s.STAFF_MOVE_ID, s.[Current], s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_staff_history, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_staff_history OUTPUT;
 SET @run_id_rprt_tbl_d_staff_history = @table_name_rprt_tbl_d_staff_history + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_staff_history + N': ' + CAST(@rows_affected_rprt_tbl_d_staff_history AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_staff_history + N')';
 SET @sql_log_success_rprt_tbl_d_staff_history =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_staff_history,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_staff_history,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_staff_history,
 @rows = @rows_affected_rprt_tbl_d_staff_history,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_staff_history = N'rprt.tbl_d_staff_history' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_staff_history = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_staff_history =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_staff_history' + N' \n Message=' + @err_msg_rprt_tbl_d_staff_history + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_staff_history AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_staff_history AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_staff_history: ' + @err_msg_rprt_tbl_d_staff_history + N' (run_id=' + @run_id_rprt_tbl_d_staff_history + N')';
 SET @sql_log_error_rprt_tbl_d_staff_history =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_staff_history,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_staff_history',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_staff_history,
 @runid = @run_id_rprt_tbl_d_staff_history,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #2: rprt.tbl_d_org SOURCE = 'SAP'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_org NVARCHAR(255) = N'rprt.tbl_d_org';
DECLARE @rows_affected_rprt_tbl_d_org INT = 0;
DECLARE @run_id_rprt_tbl_d_org NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_org NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_org NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_org NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_org NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_org NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_org AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_org AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.OrgID = s.OrgID,
 t.LoadID = s.LoadID,
 t.PersonnelNumber = s.PersonnelNumber,
 t.StartDate = s.StartDate,
 t.EndDate = s.EndDate,
 t.FullName = s.FullName,
 t.Section = s.Section,
 t.SectionID = s.SectionID,
 t.Unit = s.Unit,
 t.UnitID = s.UnitID,
 t.Location = s.Location,
 t.LocationID = s.LocationID,
 t.Department = s.Department,
 t.DepartmentID = s.DepartmentID,
 t.Command = s.Command,
 t.CommandID = s.CommandID,
 t.Directorate = s.Directorate,
 t.DirectorateID = s.DirectorateID,
 t.Force = s.Force,
 t.ForceID = s.ForceID,
 t.STAFF_MOVE_ID = s.STAFF_MOVE_ID,
 t.[Current] = s.[Current],
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (OrgID, LoadID, PersonnelNumber, StartDate, EndDate, FullName, Section, SectionID, Unit, UnitID, Location, LocationID, Department, DepartmentID, Command, CommandID, Directorate, DirectorateID, Force, ForceID, STAFF_MOVE_ID, [Current], OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.OrgID, s.LoadID, s.PersonnelNumber, s.StartDate, s.EndDate, s.FullName, s.Section, s.SectionID, s.Unit, s.UnitID, s.Location, s.LocationID, s.Department, s.DepartmentID, s.Command, s.CommandID, s.Directorate, s.DirectorateID, s.Force, s.ForceID, s.STAFF_MOVE_ID, s.[Current], s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_org, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_org OUTPUT;
 SET @run_id_rprt_tbl_d_org = @table_name_rprt_tbl_d_org + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_org + N': ' + CAST(@rows_affected_rprt_tbl_d_org AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_org + N')';
 SET @sql_log_success_rprt_tbl_d_org =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_org,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_org,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_org,
 @rows = @rows_affected_rprt_tbl_d_org,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_org = N'rprt.tbl_d_org' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_org = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_org =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_org' + N' \n Message=' + @err_msg_rprt_tbl_d_org + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_org AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_org AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_org: ' + @err_msg_rprt_tbl_d_org + N' (run_id=' + @run_id_rprt_tbl_d_org + N')';
 SET @sql_log_error_rprt_tbl_d_org =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_org,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_org',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_org,
 @runid = @run_id_rprt_tbl_d_org,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ============================================================ 
 Final consolidated grid for this cell (no table variables)
 ============================================================ */
DECLARE @sql_show NVARCHAR(MAX) =
 N'SELECT
 STATUS AS Status,
 NOTEBOOK_NAME AS TableName,
 ROWS_AFFECTED AS RowsAffected,
 RUN_ID AS RunId
 FROM ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 WHERE FolderDateTime = @f
 ORDER BY TableName;';
EXEC sp_executesql
 @sql_show,
 N'@f varchar(14)',
 @f = @runFolder;

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }

-- MARKDOWN ********************

-- ###### STORM D LAKEHOUSE TO WARHOUSE

-- CELL ********************

-- Approx 15 mins
/* ============================================================
 Run-wide variables for this cell
 ============================================================ */
DECLARE @wh_db NVARCHAR(255) = N'WH_400_Gold_Test';
DECLARE @lh_db NVARCHAR(255) = N'LH_300_Gold_Test';
DECLARE @source NVARCHAR(50) = N'Storm';
-- One FolderDateTime (yyyyMMddHHmmss) shared by all MERGEs in this cell
DECLARE @runFolder VARCHAR(14) =
 CONVERT(VARCHAR(8), SYSDATETIME(), 112) + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), ':', '');

/* ==================================================================
 MERGE #1: rprt.tbl_d_servicecode SOURCE = 'Storm'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_servicecode NVARCHAR(255) = N'rprt.tbl_d_servicecode';
DECLARE @rows_affected_rprt_tbl_d_servicecode INT = 0;
DECLARE @run_id_rprt_tbl_d_servicecode NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_servicecode NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_servicecode NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_servicecode NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_servicecode NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_servicecode NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_servicecode AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_servicecode AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.ServiceCodeNaturalID = s.ServiceCodeNaturalID,
 t.LoadID = s.LoadID,
 t.ServiceCode = s.ServiceCode,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (ServiceCodeNaturalID, LoadID, ServiceCode, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.ServiceCodeNaturalID, s.LoadID, s.ServiceCode, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_servicecode, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_servicecode OUTPUT;
 SET @run_id_rprt_tbl_d_servicecode = @table_name_rprt_tbl_d_servicecode + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_servicecode + N': ' + CAST(@rows_affected_rprt_tbl_d_servicecode AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_servicecode + N')';
 SET @sql_log_success_rprt_tbl_d_servicecode =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_servicecode,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_servicecode,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_servicecode,
 @rows = @rows_affected_rprt_tbl_d_servicecode,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_servicecode = N'rprt.tbl_d_servicecode' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_servicecode = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_servicecode =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_servicecode' + N' \n Message=' + @err_msg_rprt_tbl_d_servicecode + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_servicecode AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_servicecode AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_servicecode: ' + @err_msg_rprt_tbl_d_servicecode + N' (run_id=' + @run_id_rprt_tbl_d_servicecode + N')';
 SET @sql_log_error_rprt_tbl_d_servicecode =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_servicecode,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_servicecode',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_servicecode,
 @runid = @run_id_rprt_tbl_d_servicecode,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #2: rprt.tbl_d_priority SOURCE = 'Storm'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_priority NVARCHAR(255) = N'rprt.tbl_d_priority';
DECLARE @rows_affected_rprt_tbl_d_priority INT = 0;
DECLARE @run_id_rprt_tbl_d_priority NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_priority NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_priority NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_priority NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_priority NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_priority NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_priority AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_priority AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.PriorityID = s.PriorityID,
 t.LoadID = s.LoadID,
 t.Priority = s.Priority,
 t.TargetReponseTime = s.TargetReponseTime,
 t.TargetAllocationTime = s.TargetAllocationTime,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (PriorityID, LoadID, Priority, TargetReponseTime, TargetAllocationTime, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.PriorityID, s.LoadID, s.Priority, s.TargetReponseTime, s.TargetAllocationTime, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_priority, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_priority OUTPUT;
 SET @run_id_rprt_tbl_d_priority = @table_name_rprt_tbl_d_priority + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_priority + N': ' + CAST(@rows_affected_rprt_tbl_d_priority AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_priority + N')';
 SET @sql_log_success_rprt_tbl_d_priority =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_priority,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_priority,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_priority,
 @rows = @rows_affected_rprt_tbl_d_priority,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_priority = N'rprt.tbl_d_priority' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_priority = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_priority =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_priority' + N' \n Message=' + @err_msg_rprt_tbl_d_priority + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_priority AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_priority AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_priority: ' + @err_msg_rprt_tbl_d_priority + N' (run_id=' + @run_id_rprt_tbl_d_priority + N')';
 SET @sql_log_error_rprt_tbl_d_priority =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_priority,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_priority',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_priority,
 @runid = @run_id_rprt_tbl_d_priority,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #3: rprt.tbl_d_storm_isr SOURCE = 'Storm'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_storm_isr NVARCHAR(255) = N'rprt.tbl_d_storm_isr';
DECLARE @rows_affected_rprt_tbl_d_storm_isr INT = 0;
DECLARE @run_id_rprt_tbl_d_storm_isr NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_storm_isr NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_storm_isr NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_storm_isr NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_storm_isr NVARCHAR(MAX);

BEGIN TRY
  DECLARE @sql_rprt_tbl_d_storm_isr NVARCHAR(MAX) = N'
BEGIN TRY
  SET NOCOUNT ON;
  ;WITH s_src AS (
     SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_storm_isr AS s
  ),
  s_dedup AS (
     SELECT s_src.*,
            ROW_NUMBER() OVER (
              PARTITION BY s_src.OA_RECORDID
              ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
            ) AS rn
     FROM s_src
  )
  MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_storm_isr AS t
  USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
  ON t.OA_RECORDID = s.OA_RECORDID
  WHEN MATCHED THEN
    UPDATE SET
    t.ISR_NO = s.ISR_NO,
    t.DISPATCH_LEVEL = s.DISPATCH_LEVEL,
    t.LOC_ID = s.LOC_ID,
    t.LOC_NAME = s.LOC_NAME,
    t.LOC_TYPE = s.LOC_TYPE,
    t.LEVEL1 = s.LEVEL1,
    t.LEVEL2 = s.LEVEL2,
    t.LEVEL3 = s.LEVEL3,
    t.LEVEL4 = s.LEVEL4,
    t.LEVEL5 = s.LEVEL5,
    t.FINAL_SERV_CODE = s.FINAL_SERV_CODE,
    t.INITIAL_SERV_CODE = s.INITIAL_SERV_CODE,
    t.P_ORIGIN = s.P_ORIGIN,
    t.PRIORITY = s.PRIORITY,
    t.HANDLING_UNIT = s.HANDLING_UNIT,
    t.DP_ID = s.DP_ID,
    t.DP_BADGE_NO = s.DP_BADGE_NO,
    t.SUPER_ID = s.SUPER_ID,
    t.SUPER_BADGE_NO = s.SUPER_BADGE_NO,
    t.OFF_ID1 = s.OFF_ID1,
    t.OFF_ID2 = s.OFF_ID2,
    t.OFF_BADGE_NO1 = s.OFF_BADGE_NO1,
    t.OFF_BADGE_NO2 = s.OFF_BADGE_NO2,
    t.S_STATUS = s.S_STATUS,
    t.S_STATUS_NOTE = s.S_STATUS_NOTE,
    t.LONGITUDE = s.LONGITUDE,
    t.LATITUDE = s.LATITUDE,
    t.PERSON = s.PERSON,
    t.LOG = s.LOG,
    t.MOD_LOC = s.MOD_LOC,
    t.MOD_SERV_CODE = s.MOD_SERV_CODE,
    t.MOD_PRIORITY = s.MOD_PRIORITY,
    t.CREA_LOGINNAME = s.CREA_LOGINNAME,
    t.CREA_PERSONNEL_ID = s.CREA_PERSONNEL_ID,
    t.MOD_DATE = s.MOD_DATE,
    t.MOD_TIME = s.MOD_TIME,
    t.OIC_BADGE_NO = s.OIC_BADGE_NO,
    t.OIC_ID = s.OIC_ID,
    t.ORIGINAL_PRIORITY = s.ORIGINAL_PRIORITY,
    t.STATUS1_DATE = s.STATUS1_DATE,
    t.STATUS1_TIME = s.STATUS1_TIME,
    t.STATUS2_DATE = s.STATUS2_DATE,
    t.STATUS2_TIME = s.STATUS2_TIME,
    t.STATUS3_DATE = s.STATUS3_DATE,
    t.STATUS3_TIME = s.STATUS3_TIME,
    t.STATUS4_DATE = s.STATUS4_DATE,
    t.STATUS4_TIME = s.STATUS4_TIME,
    t.STATUS5_DATE = s.STATUS5_DATE,
    t.STATUS5_TIME = s.STATUS5_TIME,
    t.STATUS6_DATE = s.STATUS6_DATE,
    t.STATUS6_TIME = s.STATUS6_TIME,
    t.source_table = s.source_table,
    t.CRITICALITY = s.CRITICALITY,
    t.DISPOSE_CODE1 = s.DISPOSE_CODE1,
    t.VSS = s.VSS,
    t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
    t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
    t.OA_REC_END_DATE = s.OA_REC_END_DATE,
    t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
    t.OA_VERSION = s.OA_VERSION
  WHEN NOT MATCHED THEN
    INSERT (ISR_NO, DISPATCH_LEVEL, LOC_ID, LOC_NAME, LOC_TYPE, LEVEL1, LEVEL2, LEVEL3, LEVEL4, LEVEL5, FINAL_SERV_CODE, INITIAL_SERV_CODE, P_ORIGIN, PRIORITY, HANDLING_UNIT, DP_ID, DP_BADGE_NO, SUPER_ID, SUPER_BADGE_NO, OFF_ID1, OFF_ID2, OFF_BADGE_NO1, OFF_BADGE_NO2, S_STATUS, S_STATUS_NOTE, LONGITUDE, LATITUDE, PERSON, LOG, MOD_LOC, MOD_SERV_CODE, MOD_PRIORITY, CREA_LOGINNAME, CREA_PERSONNEL_ID, MOD_DATE, MOD_TIME, OIC_BADGE_NO, OIC_ID, ORIGINAL_PRIORITY, STATUS1_DATE, STATUS1_TIME, STATUS2_DATE, STATUS2_TIME, STATUS3_DATE, STATUS3_TIME, STATUS4_DATE, STATUS4_TIME, STATUS5_DATE, STATUS5_TIME, STATUS6_DATE, STATUS6_TIME, source_table, CRITICALITY, DISPOSE_CODE1, VSS, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
    VALUES (s.ISR_NO, s.DISPATCH_LEVEL, s.LOC_ID, s.LOC_NAME, s.LOC_TYPE, s.LEVEL1, s.LEVEL2, s.LEVEL3, s.LEVEL4, s.LEVEL5, s.FINAL_SERV_CODE, s.INITIAL_SERV_CODE, s.P_ORIGIN, s.PRIORITY, s.HANDLING_UNIT, s.DP_ID, s.DP_BADGE_NO, s.SUPER_ID, s.SUPER_BADGE_NO, s.OFF_ID1, s.OFF_ID2, s.OFF_BADGE_NO1, s.OFF_BADGE_NO2, s.S_STATUS, s.S_STATUS_NOTE, s.LONGITUDE, s.LATITUDE, s.PERSON, s.LOG, s.MOD_LOC, s.MOD_SERV_CODE, s.MOD_PRIORITY, s.CREA_LOGINNAME, s.CREA_PERSONNEL_ID, s.MOD_DATE, s.MOD_TIME, s.OIC_BADGE_NO, s.OIC_ID, s.ORIGINAL_PRIORITY, s.STATUS1_DATE, s.STATUS1_TIME, s.STATUS2_DATE, s.STATUS2_TIME, s.STATUS3_DATE, s.STATUS3_TIME, s.STATUS4_DATE, s.STATUS4_TIME, s.STATUS5_DATE, s.STATUS5_TIME, s.STATUS6_DATE, s.STATUS6_TIME, s.source_table, s.CRITICALITY, s.DISPOSE_CODE1, s.VSS, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
  SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
  DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
  THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_storm_isr, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_storm_isr OUTPUT;
 SET @run_id_rprt_tbl_d_storm_isr = @table_name_rprt_tbl_d_storm_isr + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_storm_isr + N': ' + CAST(@rows_affected_rprt_tbl_d_storm_isr AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_storm_isr + N')';
 SET @sql_log_success_rprt_tbl_d_storm_isr =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_storm_isr,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_storm_isr,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_storm_isr,
 @rows = @rows_affected_rprt_tbl_d_storm_isr,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_storm_isr = N'rprt.tbl_d_storm_isr' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_storm_isr = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_storm_isr =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_storm_isr' + N' \n Message=' + @err_msg_rprt_tbl_d_storm_isr + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_storm_isr AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_storm_isr AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_storm_isr: ' + @err_msg_rprt_tbl_d_storm_isr + N' (run_id=' + @run_id_rprt_tbl_d_storm_isr + N')';
 SET @sql_log_error_rprt_tbl_d_storm_isr =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_storm_isr,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_storm_isr',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_storm_isr,
 @runid = @run_id_rprt_tbl_d_storm_isr,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #4: rprt.tbl_d_location SOURCE = 'Storm'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_location NVARCHAR(255) = N'rprt.tbl_d_location';
DECLARE @rows_affected_rprt_tbl_d_location INT = 0;
DECLARE @run_id_rprt_tbl_d_location NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_location NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_location NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_location NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_location NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_location NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_location AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_location AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.LocationID = s.LocationID,
 t.LoadID = s.LoadID,
 t.LocationSegment = s.LocationSegment,
 t.DistrictName = s.DistrictName,
 t.City = s.City,
 t.LocationName = s.LocationName,
 t.LocationEnvironment = s.LocationEnvironment,
 t.PostCode = s.PostCode,
 t.Latitude = s.Latitude,
 t.Longitude = s.Longitude,
 t.DateMod = s.DateMod,
 t.TimeMod = s.TimeMod,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (LocationID, LoadID, LocationSegment, DistrictName, City, LocationName, LocationEnvironment, PostCode, Latitude, Longitude, DateMod, TimeMod, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.LocationID, s.LoadID, s.LocationSegment, s.DistrictName, s.City, s.LocationName, s.LocationEnvironment, s.PostCode, s.Latitude, s.Longitude, s.DateMod, s.TimeMod, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_location, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_location OUTPUT;
 SET @run_id_rprt_tbl_d_location = @table_name_rprt_tbl_d_location + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_location + N': ' + CAST(@rows_affected_rprt_tbl_d_location AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_location + N')';
 SET @sql_log_success_rprt_tbl_d_location =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_location,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_location,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_location,
 @rows = @rows_affected_rprt_tbl_d_location,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_location = N'rprt.tbl_d_location' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_location = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_location =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_location' + N' \n Message=' + @err_msg_rprt_tbl_d_location + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_location AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_location AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_location: ' + @err_msg_rprt_tbl_d_location + N' (run_id=' + @run_id_rprt_tbl_d_location + N')';
 SET @sql_log_error_rprt_tbl_d_location =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_location,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_location',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_location,
 @runid = @run_id_rprt_tbl_d_location,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #5: rprt.tbl_d_personnel SOURCE = 'Storm'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_personnel NVARCHAR(255) = N'rprt.tbl_d_personnel';
DECLARE @rows_affected_rprt_tbl_d_personnel INT = 0;
DECLARE @run_id_rprt_tbl_d_personnel NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_personnel NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_personnel NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_personnel NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_personnel NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_personnel NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_personnel AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_personnel AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.PersonnelID = s.PersonnelID,
 t.LoadID = s.LoadID,
 t.AgencyCode = s.AgencyCode,
 t.EmployeeNo = s.EmployeeNo,
 t.BadgeNo = s.BadgeNo,
 t.FamilyName = s.FamilyName,
 t.FirstName = s.FirstName,
 t.Rank = s.Rank,
 t.Department = s.Department,
 t.TeamSchedule = s.TeamSchedule,
 t.SecurityGroup = s.SecurityGroup,
 t.Active = s.Active,
 t.CalltakerExperience = s.CalltakerExperience,
 t.DispatcherExperience = s.DispatcherExperience,
 t.MD5Concat = s.MD5Concat,
 t.DateStart = s.DateStart,
 t.DateEnd = s.DateEnd,
 t.CurrentFlag = s.CurrentFlag,
 t.In_Storm = s.In_Storm,
 t.Storm_PersonnelID = s.Storm_PersonnelID,
 t.In_Athena = s.In_Athena,
 t.Athena_Employee_ID = s.Athena_Employee_ID,
 t.Athena_Employee_Iteration_ID = s.Athena_Employee_Iteration_ID,
 t.Athena_Employee_Rank_GCV = s.Athena_Employee_Rank_GCV,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (PersonnelID, LoadID, AgencyCode, EmployeeNo, BadgeNo, FamilyName, FirstName, Rank, Department, TeamSchedule, SecurityGroup, Active, CalltakerExperience, DispatcherExperience, MD5Concat, DateStart, DateEnd, CurrentFlag, In_Storm, Storm_PersonnelID, In_Athena, Athena_Employee_ID, Athena_Employee_Iteration_ID, Athena_Employee_Rank_GCV, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.PersonnelID, s.LoadID, s.AgencyCode, s.EmployeeNo, s.BadgeNo, s.FamilyName, s.FirstName, s.Rank, s.Department, s.TeamSchedule, s.SecurityGroup, s.Active, s.CalltakerExperience, s.DispatcherExperience, s.MD5Concat, s.DateStart, s.DateEnd, s.CurrentFlag, s.In_Storm, s.Storm_PersonnelID, s.In_Athena, s.Athena_Employee_ID, s.Athena_Employee_Iteration_ID, s.Athena_Employee_Rank_GCV, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_personnel, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_personnel OUTPUT;
 SET @run_id_rprt_tbl_d_personnel = @table_name_rprt_tbl_d_personnel + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_personnel + N': ' + CAST(@rows_affected_rprt_tbl_d_personnel AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_personnel + N')';
 SET @sql_log_success_rprt_tbl_d_personnel =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_personnel,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_personnel,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_personnel,
 @rows = @rows_affected_rprt_tbl_d_personnel,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_personnel = N'rprt.tbl_d_personnel' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_personnel = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_personnel =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_personnel' + N' \n Message=' + @err_msg_rprt_tbl_d_personnel + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_personnel AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_personnel AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_personnel: ' + @err_msg_rprt_tbl_d_personnel + N' (run_id=' + @run_id_rprt_tbl_d_personnel + N')';
 SET @sql_log_error_rprt_tbl_d_personnel =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_personnel,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_personnel',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_personnel,
 @runid = @run_id_rprt_tbl_d_personnel,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #6: rprt.tbl_d_geo SOURCE = 'Storm'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_geo NVARCHAR(255) = N'rprt.tbl_d_geo';
DECLARE @rows_affected_rprt_tbl_d_geo INT = 0;
DECLARE @run_id_rprt_tbl_d_geo NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_geo NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_geo NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_geo NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_geo NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_geo NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_geo AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_geo AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.GeoNaturalID = s.GeoNaturalID,
 t.LoadID = s.LoadID,
 t.LPACode = s.LPACode,
 t.LPADescription = s.LPADescription,
 t.DPACode = s.DPACode,
 t.DPADescription = s.DPADescription,
 t.DivisionCode = s.DivisionCode,
 t.DivisionDescription = s.DivisionDescription,
 t.DistrictCode = s.DistrictCode,
 t.DistrictDescription = s.DistrictDescription,
 t.NeighbourhoodCode = s.NeighbourhoodCode,
 t.NeighbourhoodDescription = s.NeighbourhoodDescription,
 t.NeighbourhoodID = s.NeighbourhoodID,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (GeoNaturalID, LoadID, LPACode, LPADescription, DPACode, DPADescription, DivisionCode, DivisionDescription, DistrictCode, DistrictDescription, NeighbourhoodCode, NeighbourhoodDescription, NeighbourhoodID, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.GeoNaturalID, s.LoadID, s.LPACode, s.LPADescription, s.DPACode, s.DPADescription, s.DivisionCode, s.DivisionDescription, s.DistrictCode, s.DistrictDescription, s.NeighbourhoodCode, s.NeighbourhoodDescription, s.NeighbourhoodID, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_geo, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_geo OUTPUT;
 SET @run_id_rprt_tbl_d_geo = @table_name_rprt_tbl_d_geo + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_geo + N': ' + CAST(@rows_affected_rprt_tbl_d_geo AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_geo + N')';
 SET @sql_log_success_rprt_tbl_d_geo =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_geo,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_geo,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_geo,
 @rows = @rows_affected_rprt_tbl_d_geo,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_geo = N'rprt.tbl_d_geo' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_geo = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_geo =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_geo' + N' \n Message=' + @err_msg_rprt_tbl_d_geo + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_geo AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_geo AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_geo: ' + @err_msg_rprt_tbl_d_geo + N' (run_id=' + @run_id_rprt_tbl_d_geo + N')';
 SET @sql_log_error_rprt_tbl_d_geo =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_geo,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_geo',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_geo,
 @runid = @run_id_rprt_tbl_d_geo,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #7: rprt.tbl_d_unit_activity SOURCE = 'Storm'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_unit_activity NVARCHAR(255) = N'rprt.tbl_d_unit_activity';
DECLARE @rows_affected_rprt_tbl_d_unit_activity INT = 0;
DECLARE @run_id_rprt_tbl_d_unit_activity NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_unit_activity NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_unit_activity NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_unit_activity NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_unit_activity NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_unit_activity NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_unit_activity AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_unit_activity AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.ISR_NUMBER = s.ISR_NUMBER,
 t.UNIT = s.UNIT,
 t.P_UNIT_TYPE1 = s.P_UNIT_TYPE1,
 t.PLAN_NUMBER = s.PLAN_NUMBER,
 t.UA_DATE = s.UA_DATE,
 t.UA_TIME = s.UA_TIME,
 t.SEQ_NO = s.SEQ_NO,
 t.OFFICER_PERS_ID1 = s.OFFICER_PERS_ID1,
 t.OFFICER_PERS_ID2 = s.OFFICER_PERS_ID2,
 t.OFFICER_PERS_ID3 = s.OFFICER_PERS_ID3,
 t.OFFICER_PERS_ID4 = s.OFFICER_PERS_ID4,
 t.OFFICER_PERS_ID5 = s.OFFICER_PERS_ID5,
 t.OFFICER_PERS_ID6 = s.OFFICER_PERS_ID6,
 t.OFFICER_PERS_ID7 = s.OFFICER_PERS_ID7,
 t.OFFICER_PERS_ID8 = s.OFFICER_PERS_ID8,
 t.OFFICER_PERS_ID9 = s.OFFICER_PERS_ID9,
 t.OFFICER_PERS_ID10 = s.OFFICER_PERS_ID10,
 t.OFFICER_PERS_ID11 = s.OFFICER_PERS_ID11,
 t.OFFICER_PERS_ID12 = s.OFFICER_PERS_ID12,
 t.RIDERS = s.RIDERS,
 t.PRIORITY = s.PRIORITY,
 t.S_STATUS = s.S_STATUS,
 t.S_FUNCTION = s.S_FUNCTION,
 t.DISPATCH_LEVEL = s.DISPATCH_LEVEL,
 t.LONGITUDE = s.LONGITUDE,
 t.LATITUDE = s.LATITUDE,
 t.MOD_DATE = s.MOD_DATE,
 t.MOD_TIME = s.MOD_TIME,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (ISR_NUMBER, UNIT, P_UNIT_TYPE1, PLAN_NUMBER, UA_DATE, UA_TIME, SEQ_NO, OFFICER_PERS_ID1, OFFICER_PERS_ID2, OFFICER_PERS_ID3, OFFICER_PERS_ID4, OFFICER_PERS_ID5, OFFICER_PERS_ID6, OFFICER_PERS_ID7, OFFICER_PERS_ID8, OFFICER_PERS_ID9, OFFICER_PERS_ID10, OFFICER_PERS_ID11, OFFICER_PERS_ID12, RIDERS, PRIORITY, S_STATUS, S_FUNCTION, DISPATCH_LEVEL, LONGITUDE, LATITUDE, MOD_DATE, MOD_TIME, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.ISR_NUMBER, s.UNIT, s.P_UNIT_TYPE1, s.PLAN_NUMBER, s.UA_DATE, s.UA_TIME, s.SEQ_NO, s.OFFICER_PERS_ID1, s.OFFICER_PERS_ID2, s.OFFICER_PERS_ID3, s.OFFICER_PERS_ID4, s.OFFICER_PERS_ID5, s.OFFICER_PERS_ID6, s.OFFICER_PERS_ID7, s.OFFICER_PERS_ID8, s.OFFICER_PERS_ID9, s.OFFICER_PERS_ID10, s.OFFICER_PERS_ID11, s.OFFICER_PERS_ID12, s.RIDERS, s.PRIORITY, s.S_STATUS, s.S_FUNCTION, s.DISPATCH_LEVEL, s.LONGITUDE, s.LATITUDE, s.MOD_DATE, s.MOD_TIME, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_unit_activity, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_unit_activity OUTPUT;
 SET @run_id_rprt_tbl_d_unit_activity = @table_name_rprt_tbl_d_unit_activity + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_unit_activity + N': ' + CAST(@rows_affected_rprt_tbl_d_unit_activity AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_unit_activity + N')';
 SET @sql_log_success_rprt_tbl_d_unit_activity =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_unit_activity,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_unit_activity,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_unit_activity,
 @rows = @rows_affected_rprt_tbl_d_unit_activity,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_unit_activity = N'rprt.tbl_d_unit_activity' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_unit_activity = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_unit_activity =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_unit_activity' + N' \n Message=' + @err_msg_rprt_tbl_d_unit_activity + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_unit_activity AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_unit_activity AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_unit_activity: ' + @err_msg_rprt_tbl_d_unit_activity + N' (run_id=' + @run_id_rprt_tbl_d_unit_activity + N')';
 SET @sql_log_error_rprt_tbl_d_unit_activity =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_unit_activity,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_unit_activity',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_unit_activity,
 @runid = @run_id_rprt_tbl_d_unit_activity,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #8: rprt.tbl_d_storm_isr_timestamps SOURCE = 'Storm'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_storm_isr_timestamps NVARCHAR(255) = N'rprt.tbl_d_storm_isr_timestamps';
DECLARE @rows_affected_rprt_tbl_d_storm_isr_timestamps INT = 0;
DECLARE @run_id_rprt_tbl_d_storm_isr_timestamps NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_storm_isr_timestamps NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_storm_isr_timestamps NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_storm_isr_timestamps NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_storm_isr_timestamps NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_storm_isr_timestamps NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_storm_isr_timestamps AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_storm_isr_timestamps AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.ISR_NO = s.ISR_NO,
 t.MOD_DATE = s.MOD_DATE,
 t.MOD_TIME = s.MOD_TIME,
 t.TIMESTAMP7 = s.TIMESTAMP7,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (ISR_NO, MOD_DATE, MOD_TIME, TIMESTAMP7, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.ISR_NO, s.MOD_DATE, s.MOD_TIME, s.TIMESTAMP7, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_storm_isr_timestamps, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_storm_isr_timestamps OUTPUT;
 SET @run_id_rprt_tbl_d_storm_isr_timestamps = @table_name_rprt_tbl_d_storm_isr_timestamps + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_storm_isr_timestamps + N': ' + CAST(@rows_affected_rprt_tbl_d_storm_isr_timestamps AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_storm_isr_timestamps + N')';
 SET @sql_log_success_rprt_tbl_d_storm_isr_timestamps =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_storm_isr_timestamps,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_storm_isr_timestamps,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_storm_isr_timestamps,
 @rows = @rows_affected_rprt_tbl_d_storm_isr_timestamps,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_storm_isr_timestamps = N'rprt.tbl_d_storm_isr_timestamps' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_storm_isr_timestamps = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_storm_isr_timestamps =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_storm_isr_timestamps' + N' \n Message=' + @err_msg_rprt_tbl_d_storm_isr_timestamps + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_storm_isr_timestamps AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_storm_isr_timestamps AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_storm_isr_timestamps: ' + @err_msg_rprt_tbl_d_storm_isr_timestamps + N' (run_id=' + @run_id_rprt_tbl_d_storm_isr_timestamps + N')';
 SET @sql_log_error_rprt_tbl_d_storm_isr_timestamps =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_storm_isr_timestamps,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_storm_isr_timestamps',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_storm_isr_timestamps,
 @runid = @run_id_rprt_tbl_d_storm_isr_timestamps,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #9: rprt.tbl_d_incident SOURCE = 'Storm'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_incident NVARCHAR(255) = N'rprt.tbl_d_incident';
DECLARE @rows_affected_rprt_tbl_d_incident INT = 0;
DECLARE @run_id_rprt_tbl_d_incident NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_incident NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_incident NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_incident NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_incident NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_incident NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_incident AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_incident AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.IncidentNaturalID = s.IncidentNaturalID,
 t.LoadID = s.LoadID,
 t.DateSaved = s.DateSaved,
 t.TimeSaved = s.TimeSaved,
 t.DateTimeSaved = s.DateTimeSaved,
 t.HandlingUnit = s.HandlingUnit,
 t.CriticalityCode = s.CriticalityCode,
 t.StatusCode = s.StatusCode,
 t.IncidentTagCode = s.IncidentTagCode,
 t.DispatchLevel = s.DispatchLevel,
 t.FinalDisposeCode = s.FinalDisposeCode,
 t.AvailableUnitsDPA = s.AvailableUnitsDPA,
 t.AvailableUnitsLPA = s.AvailableUnitsLPA,
 t.FK_DateSavedID = s.FK_DateSavedID,
 t.FK_DateSavedPoliceID = s.FK_DateSavedPoliceID,
 t.FK_TimeSavedID = s.FK_TimeSavedID,
 t.FK_GeoID = s.FK_GeoID,
 t.FK_LocationID = s.FK_LocationID,
 t.FK_DispatcherID = s.FK_DispatcherID,
 t.FK_CallerTakerID = s.FK_CallerTakerID,
 t.FK_InitialServiceCodeID = s.FK_InitialServiceCodeID,
 t.FK_PriorityID = s.FK_PriorityID,
 t.FinalServCode = s.FinalServCode,
 t.VSS = s.VSS,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (IncidentNaturalID, LoadID, DateSaved, TimeSaved, DateTimeSaved, HandlingUnit, CriticalityCode, StatusCode, IncidentTagCode, DispatchLevel, FinalDisposeCode, AvailableUnitsDPA, AvailableUnitsLPA, FK_DateSavedID, FK_DateSavedPoliceID, FK_TimeSavedID, FK_GeoID, FK_LocationID, FK_DispatcherID, FK_CallerTakerID, FK_InitialServiceCodeID, FK_PriorityID, FinalServCode, VSS, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.IncidentNaturalID, s.LoadID, s.DateSaved, s.TimeSaved, s.DateTimeSaved, s.HandlingUnit, s.CriticalityCode, s.StatusCode, s.IncidentTagCode, s.DispatchLevel, s.FinalDisposeCode, s.AvailableUnitsDPA, s.AvailableUnitsLPA, s.FK_DateSavedID, s.FK_DateSavedPoliceID, s.FK_TimeSavedID, s.FK_GeoID, s.FK_LocationID, s.FK_DispatcherID, s.FK_CallerTakerID, s.FK_InitialServiceCodeID, s.FK_PriorityID, s.FinalServCode, s.VSS, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_incident, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_incident OUTPUT;
 SET @run_id_rprt_tbl_d_incident = @table_name_rprt_tbl_d_incident + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_incident + N': ' + CAST(@rows_affected_rprt_tbl_d_incident AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_incident + N')';
 SET @sql_log_success_rprt_tbl_d_incident =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_incident,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_incident,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_incident,
 @rows = @rows_affected_rprt_tbl_d_incident,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_incident = N'rprt.tbl_d_incident' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_incident = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_incident =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_incident' + N' \n Message=' + @err_msg_rprt_tbl_d_incident + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_incident AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_incident AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_incident: ' + @err_msg_rprt_tbl_d_incident + N' (run_id=' + @run_id_rprt_tbl_d_incident + N')';
 SET @sql_log_error_rprt_tbl_d_incident =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_incident,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_incident',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_incident,
 @runid = @run_id_rprt_tbl_d_incident,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;


/* ============================================================ 
 Final consolidated grid for this cell (no table variables)
 ============================================================ */
DECLARE @sql_show NVARCHAR(MAX) =
 N'SELECT
 STATUS AS Status,
 NOTEBOOK_NAME AS TableName,
 ROWS_AFFECTED AS RowsAffected,
 RUN_ID AS RunId
 FROM ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 WHERE FolderDateTime = @f
 ORDER BY TableName;';
EXEC sp_executesql
 @sql_show,
 N'@f varchar(14)', 
 @f = @runFolder;

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse",
-- META   "frozen": false,
-- META   "editable": true
-- META }

-- MARKDOWN ********************

-- ###### BAIL D LAKEHOUSE TO WARHOUSE

-- CELL ********************

/* ============================================================
 Run-wide variables for this cell
 ============================================================ */
DECLARE @wh_db NVARCHAR(255) = N'WH_400_Gold_Test';
DECLARE @lh_db NVARCHAR(255) = N'LH_300_Gold_Test';
DECLARE @source NVARCHAR(50) = N'Bail';
-- One FolderDateTime (yyyyMMddHHmmss) shared by all MERGEs in this cell
DECLARE @runFolder VARCHAR(14) =
 CONVERT(VARCHAR(8), SYSDATETIME(), 112) + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), ':', '');

/* ==================================================================
 MERGE #1: rprt.tbl_d_bail_geo SOURCE = 'Bail'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_bail_geo NVARCHAR(255) = N'rprt.tbl_d_bail_geo';
DECLARE @rows_affected_rprt_tbl_d_bail_geo INT = 0;
DECLARE @run_id_rprt_tbl_d_bail_geo NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_bail_geo NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_bail_geo NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_bail_geo NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_bail_geo NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_bail_geo NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_bail_geo AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_bail_geo AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.D_BAIL_GEO_DISTRICT_ID = s.D_BAIL_GEO_DISTRICT_ID,
 t.LoadID = s.LoadID,
 t.D_BAIL_GEO_DISTRICT = s.D_BAIL_GEO_DISTRICT,
 t.D_BAIL_GEO_AREA_ID = s.D_BAIL_GEO_AREA_ID,
 t.D_BAIL_GEO_AREA = s.D_BAIL_GEO_AREA,
 t.D_BAIL_GEO_POLICE_FORCE = s.D_BAIL_GEO_POLICE_FORCE,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (D_BAIL_GEO_DISTRICT_ID, LoadID, D_BAIL_GEO_DISTRICT, D_BAIL_GEO_AREA_ID, D_BAIL_GEO_AREA, D_BAIL_GEO_POLICE_FORCE, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.D_BAIL_GEO_DISTRICT_ID, s.LoadID, s.D_BAIL_GEO_DISTRICT, s.D_BAIL_GEO_AREA_ID, s.D_BAIL_GEO_AREA, s.D_BAIL_GEO_POLICE_FORCE, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_bail_geo, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_bail_geo OUTPUT;
 SET @run_id_rprt_tbl_d_bail_geo = @table_name_rprt_tbl_d_bail_geo + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_bail_geo + N': ' + CAST(@rows_affected_rprt_tbl_d_bail_geo AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_bail_geo + N')';
 SET @sql_log_success_rprt_tbl_d_bail_geo =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_bail_geo,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_bail_geo,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_bail_geo,
 @rows = @rows_affected_rprt_tbl_d_bail_geo,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_bail_geo = N'rprt.tbl_d_bail_geo' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_bail_geo = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_bail_geo =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_bail_geo' + N' \n Message=' + @err_msg_rprt_tbl_d_bail_geo + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_bail_geo AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_bail_geo AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_bail_geo: ' + @err_msg_rprt_tbl_d_bail_geo + N' (run_id=' + @run_id_rprt_tbl_d_bail_geo + N')';
 SET @sql_log_error_rprt_tbl_d_bail_geo =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_bail_geo,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_bail_geo',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_bail_geo,
 @runid = @run_id_rprt_tbl_d_bail_geo,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #2: rprt.tbl_d_bail SOURCE = 'Bail'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_bail NVARCHAR(255) = N'rprt.tbl_d_bail';
DECLARE @rows_affected_rprt_tbl_d_bail INT = 0;
DECLARE @run_id_rprt_tbl_d_bail NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_bail NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_bail NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_bail NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_bail NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_bail NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_bail AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_bail AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.D_BAIL_ID = s.D_BAIL_ID,
 t.LoadID = s.LoadID,
 t.D_BAIL_CUSTODY_ID = s.D_BAIL_CUSTODY_ID,
 t.D_BAIL_TYPE = s.D_BAIL_TYPE,
 t.D_BAIL_TYPE_FULL = s.D_BAIL_TYPE_FULL,
 t.D_BAIL_CRIME_TYPE = s.D_BAIL_CRIME_TYPE,
 t.D_BAIL_CREATED_ON = s.D_BAIL_CREATED_ON,
 t.D_BAIL_RELEASE_DATE = s.D_BAIL_RELEASE_DATE,
 t.D_BAIL_RUI_FINALISE_DATE = s.D_BAIL_RUI_FINALISE_DATE,
 t.D_BAIL_BAIL_EXPIRY_DATE = s.D_BAIL_BAIL_EXPIRY_DATE,
 t.D_BAIL_BAIL_DATE = s.D_BAIL_BAIL_DATE,
 t.D_BAIL_TERMINATED_DATE = s.D_BAIL_TERMINATED_DATE,
 t.D_BAIL_REVIEW_DUE_DATE = s.D_BAIL_REVIEW_DUE_DATE,
 t.D_BAIL_LIVE_OR_HISTORIC = s.D_BAIL_LIVE_OR_HISTORIC,
 t.D_BAIL_STAGE = s.D_BAIL_STAGE,
 t.D_BAIL_END_DATE = s.D_BAIL_END_DATE,
 t.D_BAIL_CUSTODY_REF = s.D_BAIL_CUSTODY_REF,
 t.D_BAIL_BAIL_TO_RETURN_DATE = s.D_BAIL_BAIL_TO_RETURN_DATE,
 t.D_BAIL_SUSPENSION = s.D_BAIL_SUSPENSION,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (D_BAIL_ID, LoadID, D_BAIL_CUSTODY_ID, D_BAIL_TYPE, D_BAIL_TYPE_FULL, D_BAIL_CRIME_TYPE, D_BAIL_CREATED_ON, D_BAIL_RELEASE_DATE, D_BAIL_RUI_FINALISE_DATE, D_BAIL_BAIL_EXPIRY_DATE, D_BAIL_BAIL_DATE, D_BAIL_TERMINATED_DATE, D_BAIL_REVIEW_DUE_DATE, D_BAIL_LIVE_OR_HISTORIC, D_BAIL_STAGE, D_BAIL_END_DATE, D_BAIL_CUSTODY_REF, D_BAIL_BAIL_TO_RETURN_DATE, D_BAIL_SUSPENSION, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.D_BAIL_ID, s.LoadID, s.D_BAIL_CUSTODY_ID, s.D_BAIL_TYPE, s.D_BAIL_TYPE_FULL, s.D_BAIL_CRIME_TYPE, s.D_BAIL_CREATED_ON, s.D_BAIL_RELEASE_DATE, s.D_BAIL_RUI_FINALISE_DATE, s.D_BAIL_BAIL_EXPIRY_DATE, s.D_BAIL_BAIL_DATE, s.D_BAIL_TERMINATED_DATE, s.D_BAIL_REVIEW_DUE_DATE, s.D_BAIL_LIVE_OR_HISTORIC, s.D_BAIL_STAGE, s.D_BAIL_END_DATE, s.D_BAIL_CUSTODY_REF, s.D_BAIL_BAIL_TO_RETURN_DATE, s.D_BAIL_SUSPENSION, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_bail, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_bail OUTPUT;
 SET @run_id_rprt_tbl_d_bail = @table_name_rprt_tbl_d_bail + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_bail + N': ' + CAST(@rows_affected_rprt_tbl_d_bail AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_bail + N')';
 SET @sql_log_success_rprt_tbl_d_bail =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_bail,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_bail,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_bail,
 @rows = @rows_affected_rprt_tbl_d_bail,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_bail = N'rprt.tbl_d_bail' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_bail = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_bail =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_bail' + N' \n Message=' + @err_msg_rprt_tbl_d_bail + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_bail AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_bail AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_bail: ' + @err_msg_rprt_tbl_d_bail + N' (run_id=' + @run_id_rprt_tbl_d_bail + N')';
 SET @sql_log_error_rprt_tbl_d_bail =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_bail,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_bail',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_bail,
 @runid = @run_id_rprt_tbl_d_bail,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ============================================================ 
 Final consolidated grid for this cell (no table variables)
 ============================================================ */
DECLARE @sql_show NVARCHAR(MAX) =
 N'SELECT
 STATUS AS Status,
 NOTEBOOK_NAME AS TableName,
 ROWS_AFFECTED AS RowsAffected,
 RUN_ID AS RunId
 FROM ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 WHERE FolderDateTime = @f
 ORDER BY TableName;';
EXEC sp_executesql
 @sql_show,
 N'@f varchar(14)',
 @f = @runFolder;

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse",
-- META   "frozen": false,
-- META   "editable": true
-- META }

-- MARKDOWN ********************

-- ###### ATHENA D LAKEHOUSE TO WARHOUSE

-- CELL ********************

/* ============================================================
 Run-wide variables for this cell
 ============================================================ */
DECLARE @wh_db NVARCHAR(255) = N'WH_400_Gold_Test';
DECLARE @lh_db NVARCHAR(255) = N'LH_300_Gold_Test';
DECLARE @source NVARCHAR(50) = N'Athena';
-- One FolderDateTime (yyyyMMddHHmmss) shared by all MERGEs in this cell
DECLARE @runFolder VARCHAR(14) =
 CONVERT(VARCHAR(8), SYSDATETIME(), 112) + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), ':', '');

/* ==================================================================
 MERGE #1: rprt.tbl_d_arrest_crimetype SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_arrest_crimetype NVARCHAR(255) = N'rprt.tbl_d_arrest_crimetype';
DECLARE @rows_affected_rprt_tbl_d_arrest_crimetype INT = 0;
DECLARE @run_id_rprt_tbl_d_arrest_crimetype NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_arrest_crimetype NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_arrest_crimetype NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_arrest_crimetype NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_arrest_crimetype NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_arrest_crimetype NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_arrest_crimetype AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_arrest_crimetype AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.CUSTODY_REFERENCE_NUMBER = s.CUSTODY_REFERENCE_NUMBER,
 t.ACPO_GROUPING_GCV = s.ACPO_GROUPING_GCV,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (CUSTODY_REFERENCE_NUMBER, ACPO_GROUPING_GCV, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.CUSTODY_REFERENCE_NUMBER, s.ACPO_GROUPING_GCV, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_arrest_crimetype, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_arrest_crimetype OUTPUT;
 SET @run_id_rprt_tbl_d_arrest_crimetype = @table_name_rprt_tbl_d_arrest_crimetype + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_arrest_crimetype + N': ' + CAST(@rows_affected_rprt_tbl_d_arrest_crimetype AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_arrest_crimetype + N')';
 SET @sql_log_success_rprt_tbl_d_arrest_crimetype =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_arrest_crimetype,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_arrest_crimetype,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_arrest_crimetype,
 @rows = @rows_affected_rprt_tbl_d_arrest_crimetype,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_arrest_crimetype = N'rprt.tbl_d_arrest_crimetype' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_arrest_crimetype = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_arrest_crimetype =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_arrest_crimetype' + N' \n Message=' + @err_msg_rprt_tbl_d_arrest_crimetype + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_arrest_crimetype AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_arrest_crimetype AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_arrest_crimetype: ' + @err_msg_rprt_tbl_d_arrest_crimetype + N' (run_id=' + @run_id_rprt_tbl_d_arrest_crimetype + N')';
 SET @sql_log_error_rprt_tbl_d_arrest_crimetype =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_arrest_crimetype,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_arrest_crimetype',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_arrest_crimetype,
 @runid = @run_id_rprt_tbl_d_arrest_crimetype,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #2: rprt.tbl_d_athena_custody SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_athena_custody NVARCHAR(255) = N'rprt.tbl_d_athena_custody';
DECLARE @rows_affected_rprt_tbl_d_athena_custody INT = 0;
DECLARE @run_id_rprt_tbl_d_athena_custody NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_athena_custody NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_athena_custody NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_athena_custody NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_athena_custody NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_athena_custody NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_athena_custody AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_athena_custody AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.D_ATHENA_BAIL_ID = s.D_ATHENA_BAIL_ID,
 t.LoadID = s.LoadID,
 t.D_CUSTODY_REFERENCE = s.D_CUSTODY_REFERENCE,
 t.D_ATHENA_CUSTODY_STATUS = s.D_ATHENA_CUSTODY_STATUS,
 t.D_ATHENA_BAIL_RESULT = s.D_ATHENA_BAIL_RESULT,
 t.D_CREATE_DATE_TIME = s.D_CREATE_DATE_TIME,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (D_ATHENA_BAIL_ID, LoadID, D_CUSTODY_REFERENCE, D_ATHENA_CUSTODY_STATUS, D_ATHENA_BAIL_RESULT, D_CREATE_DATE_TIME, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.D_ATHENA_BAIL_ID, s.LoadID, s.D_CUSTODY_REFERENCE, s.D_ATHENA_CUSTODY_STATUS, s.D_ATHENA_BAIL_RESULT, s.D_CREATE_DATE_TIME, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_athena_custody, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_athena_custody OUTPUT;
 SET @run_id_rprt_tbl_d_athena_custody = @table_name_rprt_tbl_d_athena_custody + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_athena_custody + N': ' + CAST(@rows_affected_rprt_tbl_d_athena_custody AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_athena_custody + N')';
 SET @sql_log_success_rprt_tbl_d_athena_custody =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_athena_custody,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_athena_custody,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_athena_custody,
 @rows = @rows_affected_rprt_tbl_d_athena_custody,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_athena_custody = N'rprt.tbl_d_athena_custody' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_athena_custody = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_athena_custody =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_athena_custody' + N' \n Message=' + @err_msg_rprt_tbl_d_athena_custody + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_athena_custody AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_athena_custody AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_athena_custody: ' + @err_msg_rprt_tbl_d_athena_custody + N' (run_id=' + @run_id_rprt_tbl_d_athena_custody + N')';
 SET @sql_log_error_rprt_tbl_d_athena_custody =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_athena_custody,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_athena_custody',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_athena_custody,
 @runid = @run_id_rprt_tbl_d_athena_custody,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #3: rprt.tbl_d_crime SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_crime NVARCHAR(255) = N'rprt.tbl_d_crime';
DECLARE @rows_affected_rprt_tbl_d_crime INT = 0;
DECLARE @run_id_rprt_tbl_d_crime NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_crime NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_crime NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_crime NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_crime NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_crime NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_crime AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_crime AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.D_CRIME_ID = s.D_CRIME_ID,
 t.LoadID = s.LoadID,
 t.D_INCIDENT_ID = s.D_INCIDENT_ID,
 t.D_CRIME_INCIDENT_CREATED_TIME = s.D_CRIME_INCIDENT_CREATED_TIME,
 t.D_CRIME_INCIDENT_CREATED_DATE = s.D_CRIME_INCIDENT_CREATED_DATE,
 t.D_CRIME_INCIDENT_LOCATION = s.D_CRIME_INCIDENT_LOCATION,
 t.D_CRIME_RESTRICTED_FLAG = s.D_CRIME_RESTRICTED_FLAG,
 t.D_CRIME_TYPE = s.D_CRIME_TYPE,
 t.D_FRAUD_TYPE = s.D_FRAUD_TYPE,
 t.D_CRIME_LATITUDE = s.D_CRIME_LATITUDE,
 t.D_CRIME_LONGITUDE = s.D_CRIME_LONGITUDE,
 t.D_CRIME_INCIDENT_POSTCODE = s.D_CRIME_INCIDENT_POSTCODE,
 t.D_CRIME_INVESTIGATION_END_DATE = s.D_CRIME_INVESTIGATION_END_DATE,
 t.D_INVESTIGATION_CURRENT_STATUS = s.D_INVESTIGATION_CURRENT_STATUS,
 t.D_INVESTIGATION_PROCESSED = s.D_INVESTIGATION_PROCESSED,
 t.D_INVESTIGATION_RESTRICTED = s.D_INVESTIGATION_RESTRICTED,
 t.D_INVESTIGATION_OUTCOME = s.D_INVESTIGATION_OUTCOME,
 t.D_INVESTIGATION_OUTCOME_DETAILS = s.D_INVESTIGATION_OUTCOME_DETAILS,
 t.D_INVESTIGATION_HARM_SCORE = s.D_INVESTIGATION_HARM_SCORE,
 t.D_INVESTIGATION_CRIME_CATEGORY = s.D_INVESTIGATION_CRIME_CATEGORY,
 t.D_INVESTIGATION_HAS_SUSPECT = s.D_INVESTIGATION_HAS_SUSPECT,
 t.D_INVESTIGATION_HAS_VICTIM = s.D_INVESTIGATION_HAS_VICTIM,
 t.D_INVESTIGTATION_LENGTH = s.D_INVESTIGTATION_LENGTH,
 t.D_INVESTIGATION_RISK_LEVEL = s.D_INVESTIGATION_RISK_LEVEL,
 t.D_INVESTIGATION_HIGH_HARM = s.D_INVESTIGATION_HIGH_HARM,
 t.D_INVESTIGATION_OUTCOME_SOLVED_UNSOLVED = s.D_INVESTIGATION_OUTCOME_SOLVED_UNSOLVED,
 t.D_INVESTIGATION_OFFICER_IN_CASE = s.D_INVESTIGATION_OFFICER_IN_CASE,
 t.D_INVESTIGATION_PERSONNEL_EMPLOYEE_NO = s.D_INVESTIGATION_PERSONNEL_EMPLOYEE_NO,
 t.FK_D_OFFICER_IN_CASE = s.FK_D_OFFICER_IN_CASE,
 t.D_CRIME_NO_OFFENCE_TYPE = s.D_CRIME_NO_OFFENCE_TYPE,
 t.D_CRIME_HATE = s.D_CRIME_HATE,
 t.D_CRIME_DA = s.D_CRIME_DA,
 t.D_CRIME_KNIFE = s.D_CRIME_KNIFE,
 t.D_CRIME_FORCE = s.D_CRIME_FORCE,
 t.D_CRIME_DA_INITIAL_RISK = s.D_CRIME_DA_INITIAL_RISK,
 t.D_CRIME_DA_LATEST_RISK = s.D_CRIME_DA_LATEST_RISK,
 t.D_CRIME_ASB_INITIAL_RISK = s.D_CRIME_ASB_INITIAL_RISK,
 t.D_CRIME_ASB_LATEST_RISK = s.D_CRIME_ASB_LATEST_RISK,
 t.D_CRIME_VAWG_FLAG = s.D_CRIME_VAWG_FLAG,
 t.D_CRIME_CSG_FLAG = s.D_CRIME_CSG_FLAG,
 t.D_CRIME_CSG_MAIN_CATEGORY = s.D_CRIME_CSG_MAIN_CATEGORY,
 t.D_CRIME_CSG_WITH_EXPLOITATION = s.D_CRIME_CSG_WITH_EXPLOITATION,
 t.D_CRIME_OIC_UNIT = s.D_CRIME_OIC_UNIT,
 t.D_CRIME_DOG_THEFT = s.D_CRIME_DOG_THEFT,
 t.D_CRIME_HAS_VOL_ATTENDANCE = s.D_CRIME_HAS_VOL_ATTENDANCE,
 t.D_CRIME_NUM_DETENTION = s.D_CRIME_NUM_DETENTION,
 t.D_CRIME_NUM_VOL_ATTENDANCE = s.D_CRIME_NUM_VOL_ATTENDANCE,
 t.D_CRIME_BUSINESS_CRIME = s.D_CRIME_BUSINESS_CRIME,
 t.D_CRIME_1ST_OFFICER_ALLOCATED = s.D_CRIME_1ST_OFFICER_ALLOCATED,
 t.D_CRIME_HOW_REPORTED = s.D_CRIME_HOW_REPORTED,
 t.D_CRIME_CHILD_INITIAL_RISK = s.D_CRIME_CHILD_INITIAL_RISK,
 t.D_CRIME_CHILD_LATEST_RISK = s.D_CRIME_CHILD_LATEST_RISK,
 t.D_CRIME_HATE_INITIAL_RISK = s.D_CRIME_HATE_INITIAL_RISK,
 t.D_CRIME_HATE_LATEST_RISK = s.D_CRIME_HATE_LATEST_RISK,
 t.D_CRIME_NFRC_REF = s.D_CRIME_NFRC_REF,
 t.D_CRIME_ARREST_REASON = s.D_CRIME_ARREST_REASON,
 t.D_CRIME_TIME_TO_ALLOCATE_HOURS = s.D_CRIME_TIME_TO_ALLOCATE_HOURS,
 t.D_CRIME_TIME_TO_ALLOCATE = s.D_CRIME_TIME_TO_ALLOCATE,
 t.D_CRIME_RESOLUTION_CENTRE_TO_ACTION_HOURS = s.D_CRIME_RESOLUTION_CENTRE_TO_ACTION_HOURS,
 t.D_CRIME_RESOLUTION_CENTRE_TO_ACTION = s.D_CRIME_RESOLUTION_CENTRE_TO_ACTION,
 t.D_CRIME_REPORT_DATE = s.D_CRIME_REPORT_DATE,
 t.D_CRIME_REPORT_TIME = s.D_CRIME_REPORT_TIME,
 t.D_CRIME_REPORTED_TO_CREATED_HOURS = s.D_CRIME_REPORTED_TO_CREATED_HOURS,
 t.D_CRIME_REPORTED_TO_CREATED = s.D_CRIME_REPORTED_TO_CREATED,
 t.D_CRIME_CREATED_TO_ALLOCATED_HOURS = s.D_CRIME_CREATED_TO_ALLOCATED_HOURS,
 t.D_CRIME_CREATED_TO_ALLOCATED = s.D_CRIME_CREATED_TO_ALLOCATED,
 t.D_RESOLUTION_CENTRE_TO_ACTION = s.D_RESOLUTION_CENTRE_TO_ACTION,
 t.D_CRIME_RESOLUTION_CENTRE_ALLOCATION = s.D_CRIME_RESOLUTION_CENTRE_ALLOCATION,
 t.D_CRIME_LAST_OFFICER_ALLOCATED = s.D_CRIME_LAST_OFFICER_ALLOCATED,
 t.D_STAFF_MOVE_ID = s.D_STAFF_MOVE_ID,
 t.D_INVESTIGATION_1ST_PERSONNEL_EMPLOYEE_NO = s.D_INVESTIGATION_1ST_PERSONNEL_EMPLOYEE_NO,
 t.D_DISPOSAL_STAFF_MOVE_ID = s.D_DISPOSAL_STAFF_MOVE_ID,
 t.D_1ST_OFFICER_STAFF_MOVE_ID = s.D_1ST_OFFICER_STAFF_MOVE_ID,
 t.D_CRIME_INITIAL_MO = s.D_CRIME_INITIAL_MO,
 t.D_CRIME_DETAILED_MO = s.D_CRIME_DETAILED_MO,
 t.D_CRIME_GPS_THEFT_IND = s.D_CRIME_GPS_THEFT_IND,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (D_CRIME_ID, LoadID, D_INCIDENT_ID, D_CRIME_INCIDENT_CREATED_TIME, D_CRIME_INCIDENT_CREATED_DATE, D_CRIME_INCIDENT_LOCATION, D_CRIME_RESTRICTED_FLAG, D_CRIME_TYPE, D_FRAUD_TYPE, D_CRIME_LATITUDE, D_CRIME_LONGITUDE, D_CRIME_INCIDENT_POSTCODE, D_CRIME_INVESTIGATION_END_DATE, D_INVESTIGATION_CURRENT_STATUS, D_INVESTIGATION_PROCESSED, D_INVESTIGATION_RESTRICTED, D_INVESTIGATION_OUTCOME, D_INVESTIGATION_OUTCOME_DETAILS, D_INVESTIGATION_HARM_SCORE, D_INVESTIGATION_CRIME_CATEGORY, D_INVESTIGATION_HAS_SUSPECT, D_INVESTIGATION_HAS_VICTIM, D_INVESTIGTATION_LENGTH, D_INVESTIGATION_RISK_LEVEL, D_INVESTIGATION_HIGH_HARM, D_INVESTIGATION_OUTCOME_SOLVED_UNSOLVED, D_INVESTIGATION_OFFICER_IN_CASE, D_INVESTIGATION_PERSONNEL_EMPLOYEE_NO, FK_D_OFFICER_IN_CASE, D_CRIME_NO_OFFENCE_TYPE, D_CRIME_HATE, D_CRIME_DA, D_CRIME_KNIFE, D_CRIME_FORCE, D_CRIME_DA_INITIAL_RISK, D_CRIME_DA_LATEST_RISK, D_CRIME_ASB_INITIAL_RISK, D_CRIME_ASB_LATEST_RISK, D_CRIME_VAWG_FLAG, D_CRIME_CSG_FLAG, D_CRIME_CSG_MAIN_CATEGORY, D_CRIME_CSG_WITH_EXPLOITATION, D_CRIME_OIC_UNIT, D_CRIME_DOG_THEFT, D_CRIME_HAS_VOL_ATTENDANCE, D_CRIME_NUM_DETENTION, D_CRIME_NUM_VOL_ATTENDANCE, D_CRIME_BUSINESS_CRIME, D_CRIME_1ST_OFFICER_ALLOCATED, D_CRIME_HOW_REPORTED, D_CRIME_CHILD_INITIAL_RISK, D_CRIME_CHILD_LATEST_RISK, D_CRIME_HATE_INITIAL_RISK, D_CRIME_HATE_LATEST_RISK, D_CRIME_NFRC_REF, D_CRIME_ARREST_REASON, D_CRIME_TIME_TO_ALLOCATE_HOURS, D_CRIME_TIME_TO_ALLOCATE, D_CRIME_RESOLUTION_CENTRE_TO_ACTION_HOURS, D_CRIME_RESOLUTION_CENTRE_TO_ACTION, D_CRIME_REPORT_DATE, D_CRIME_REPORT_TIME, D_CRIME_REPORTED_TO_CREATED_HOURS, D_CRIME_REPORTED_TO_CREATED, D_CRIME_CREATED_TO_ALLOCATED_HOURS, D_CRIME_CREATED_TO_ALLOCATED, D_RESOLUTION_CENTRE_TO_ACTION, D_CRIME_RESOLUTION_CENTRE_ALLOCATION, D_CRIME_LAST_OFFICER_ALLOCATED, D_STAFF_MOVE_ID, D_INVESTIGATION_1ST_PERSONNEL_EMPLOYEE_NO, D_DISPOSAL_STAFF_MOVE_ID, D_1ST_OFFICER_STAFF_MOVE_ID, D_CRIME_INITIAL_MO, D_CRIME_DETAILED_MO, D_CRIME_GPS_THEFT_IND, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.D_CRIME_ID, s.LoadID, s.D_INCIDENT_ID, s.D_CRIME_INCIDENT_CREATED_TIME, s.D_CRIME_INCIDENT_CREATED_DATE, s.D_CRIME_INCIDENT_LOCATION, s.D_CRIME_RESTRICTED_FLAG, s.D_CRIME_TYPE, s.D_FRAUD_TYPE, s.D_CRIME_LATITUDE, s.D_CRIME_LONGITUDE, s.D_CRIME_INCIDENT_POSTCODE, s.D_CRIME_INVESTIGATION_END_DATE, s.D_INVESTIGATION_CURRENT_STATUS, s.D_INVESTIGATION_PROCESSED, s.D_INVESTIGATION_RESTRICTED, s.D_INVESTIGATION_OUTCOME, s.D_INVESTIGATION_OUTCOME_DETAILS, s.D_INVESTIGATION_HARM_SCORE, s.D_INVESTIGATION_CRIME_CATEGORY, s.D_INVESTIGATION_HAS_SUSPECT, s.D_INVESTIGATION_HAS_VICTIM, s.D_INVESTIGTATION_LENGTH, s.D_INVESTIGATION_RISK_LEVEL, s.D_INVESTIGATION_HIGH_HARM, s.D_INVESTIGATION_OUTCOME_SOLVED_UNSOLVED, s.D_INVESTIGATION_OFFICER_IN_CASE, s.D_INVESTIGATION_PERSONNEL_EMPLOYEE_NO, s.FK_D_OFFICER_IN_CASE, s.D_CRIME_NO_OFFENCE_TYPE, s.D_CRIME_HATE, s.D_CRIME_DA, s.D_CRIME_KNIFE, s.D_CRIME_FORCE, s.D_CRIME_DA_INITIAL_RISK, s.D_CRIME_DA_LATEST_RISK, s.D_CRIME_ASB_INITIAL_RISK, s.D_CRIME_ASB_LATEST_RISK, s.D_CRIME_VAWG_FLAG, s.D_CRIME_CSG_FLAG, s.D_CRIME_CSG_MAIN_CATEGORY, s.D_CRIME_CSG_WITH_EXPLOITATION, s.D_CRIME_OIC_UNIT, s.D_CRIME_DOG_THEFT, s.D_CRIME_HAS_VOL_ATTENDANCE, s.D_CRIME_NUM_DETENTION, s.D_CRIME_NUM_VOL_ATTENDANCE, s.D_CRIME_BUSINESS_CRIME, s.D_CRIME_1ST_OFFICER_ALLOCATED, s.D_CRIME_HOW_REPORTED, s.D_CRIME_CHILD_INITIAL_RISK, s.D_CRIME_CHILD_LATEST_RISK, s.D_CRIME_HATE_INITIAL_RISK, s.D_CRIME_HATE_LATEST_RISK, s.D_CRIME_NFRC_REF, s.D_CRIME_ARREST_REASON, s.D_CRIME_TIME_TO_ALLOCATE_HOURS, s.D_CRIME_TIME_TO_ALLOCATE, s.D_CRIME_RESOLUTION_CENTRE_TO_ACTION_HOURS, s.D_CRIME_RESOLUTION_CENTRE_TO_ACTION, s.D_CRIME_REPORT_DATE, s.D_CRIME_REPORT_TIME, s.D_CRIME_REPORTED_TO_CREATED_HOURS, s.D_CRIME_REPORTED_TO_CREATED, s.D_CRIME_CREATED_TO_ALLOCATED_HOURS, s.D_CRIME_CREATED_TO_ALLOCATED, s.D_RESOLUTION_CENTRE_TO_ACTION, s.D_CRIME_RESOLUTION_CENTRE_ALLOCATION, s.D_CRIME_LAST_OFFICER_ALLOCATED, s.D_STAFF_MOVE_ID, s.D_INVESTIGATION_1ST_PERSONNEL_EMPLOYEE_NO, s.D_DISPOSAL_STAFF_MOVE_ID, s.D_1ST_OFFICER_STAFF_MOVE_ID, s.D_CRIME_INITIAL_MO, s.D_CRIME_DETAILED_MO, s.D_CRIME_GPS_THEFT_IND, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_crime, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_crime OUTPUT;
 SET @run_id_rprt_tbl_d_crime = @table_name_rprt_tbl_d_crime + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_crime + N': ' + CAST(@rows_affected_rprt_tbl_d_crime AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_crime + N')';
 SET @sql_log_success_rprt_tbl_d_crime =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_crime,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_crime,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_crime,
 @rows = @rows_affected_rprt_tbl_d_crime,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_crime = N'rprt.tbl_d_crime' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_crime = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_crime =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_crime' + N' \n Message=' + @err_msg_rprt_tbl_d_crime + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_crime AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_crime AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_crime: ' + @err_msg_rprt_tbl_d_crime + N' (run_id=' + @run_id_rprt_tbl_d_crime + N')';
 SET @sql_log_error_rprt_tbl_d_crime =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_crime,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_crime',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_crime,
 @runid = @run_id_rprt_tbl_d_crime,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #4: rprt.tbl_d_athena_geo SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_athena_geo NVARCHAR(255) = N'rprt.tbl_d_athena_geo';
DECLARE @rows_affected_rprt_tbl_d_athena_geo INT = 0;
DECLARE @run_id_rprt_tbl_d_athena_geo NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_athena_geo NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_athena_geo NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_athena_geo NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_athena_geo NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_athena_geo NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_athena_geo AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_athena_geo AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.D_ATHENA_GEO_ID = s.D_ATHENA_GEO_ID,
 t.LoadID = s.LoadID,
 t.D_ATHENA_GEO_CODE = s.D_ATHENA_GEO_CODE,
 t.D_ATHENA_GEO_POSTCODE = s.D_ATHENA_GEO_POSTCODE,
 t.D_ATHENA_GEO_DISTRICT = s.D_ATHENA_GEO_DISTRICT,
 t.D_ATHENA_GEO_SECTOR = s.D_ATHENA_GEO_SECTOR,
 t.D_ATHENA_LAT = s.D_ATHENA_LAT,
 t.D_ATHENA_LONG = s.D_ATHENA_LONG,
 t.D_ATHENA_GEO_LOCATION_ID = s.D_ATHENA_GEO_LOCATION_ID,
 t.D_ATHENA_GEO_FORCE = s.D_ATHENA_GEO_FORCE,
 t.D_ATHENA_GEO_BEAT_CODE = s.D_ATHENA_GEO_BEAT_CODE,
 t.D_ATHENA_GEO_BEAT_CODE_DESC = s.D_ATHENA_GEO_BEAT_CODE_DESC,
 t.D_ATHENA_GEO_LOC_TYPE = s.D_ATHENA_GEO_LOC_TYPE,
 t.D_ATHENA_GEO_URBAN_RURAL = s.D_ATHENA_GEO_URBAN_RURAL,
 t.D_ATHENA_GEO_PREMISES_TYPE = s.D_ATHENA_GEO_PREMISES_TYPE,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (D_ATHENA_GEO_ID, LoadID, D_ATHENA_GEO_CODE, D_ATHENA_GEO_POSTCODE, D_ATHENA_GEO_DISTRICT, D_ATHENA_GEO_SECTOR, D_ATHENA_LAT, D_ATHENA_LONG, D_ATHENA_GEO_LOCATION_ID, D_ATHENA_GEO_FORCE, D_ATHENA_GEO_BEAT_CODE, D_ATHENA_GEO_BEAT_CODE_DESC, D_ATHENA_GEO_LOC_TYPE, D_ATHENA_GEO_URBAN_RURAL, D_ATHENA_GEO_PREMISES_TYPE, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.D_ATHENA_GEO_ID, s.LoadID, s.D_ATHENA_GEO_CODE, s.D_ATHENA_GEO_POSTCODE, s.D_ATHENA_GEO_DISTRICT, s.D_ATHENA_GEO_SECTOR, s.D_ATHENA_LAT, s.D_ATHENA_LONG, s.D_ATHENA_GEO_LOCATION_ID, s.D_ATHENA_GEO_FORCE, s.D_ATHENA_GEO_BEAT_CODE, s.D_ATHENA_GEO_BEAT_CODE_DESC, s.D_ATHENA_GEO_LOC_TYPE, s.D_ATHENA_GEO_URBAN_RURAL, s.D_ATHENA_GEO_PREMISES_TYPE, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_athena_geo, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_athena_geo OUTPUT;
 SET @run_id_rprt_tbl_d_athena_geo = @table_name_rprt_tbl_d_athena_geo + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_athena_geo + N': ' + CAST(@rows_affected_rprt_tbl_d_athena_geo AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_athena_geo + N')';
 SET @sql_log_success_rprt_tbl_d_athena_geo =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_athena_geo,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_athena_geo,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_athena_geo,
 @rows = @rows_affected_rprt_tbl_d_athena_geo,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_athena_geo = N'rprt.tbl_d_athena_geo' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_athena_geo = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_athena_geo =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_athena_geo' + N' \n Message=' + @err_msg_rprt_tbl_d_athena_geo + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_athena_geo AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_athena_geo AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_athena_geo: ' + @err_msg_rprt_tbl_d_athena_geo + N' (run_id=' + @run_id_rprt_tbl_d_athena_geo + N')';
 SET @sql_log_error_rprt_tbl_d_athena_geo =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_athena_geo,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_athena_geo',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_athena_geo,
 @runid = @run_id_rprt_tbl_d_athena_geo,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;


/* ==================================================================
 MERGE #5: rprt.tbl_d_crime_DA_RiskAssessment SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_crime_da_riskassessment NVARCHAR(255) = N'rprt.tbl_d_crime_DA_RiskAssessment';
DECLARE @rows_affected_rprt_tbl_d_crime_da_riskassessment INT = 0;
DECLARE @run_id_rprt_tbl_d_crime_da_riskassessment NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_crime_da_riskassessment NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_crime_da_riskassessment NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_crime_da_riskassessment NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_crime_da_riskassessment NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_crime_da_riskassessment NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_crime_da_riskassessment AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_crime_DA_RiskAssessment AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.D_CRIME_DA_RiskAssessment_ID = s.D_CRIME_DA_RiskAssessment_ID,
 t.LoadId = s.LoadId,
 t.FK_D_CRIME_ID = s.FK_D_CRIME_ID,
 t.D_RISK_ASSESSMENT_NAME = s.D_RISK_ASSESSMENT_NAME,
 t.D_RISK_RATING = s.D_RISK_RATING,
 t.D_RA_COMPLETED_DATE = s.D_RA_COMPLETED_DATE,
 t.D_RA_QA_DATE = s.D_RA_QA_DATE,
 t.D_RA_IS_INITIAL_ASSESSMENT = s.D_RA_IS_INITIAL_ASSESSMENT,
 t.D_RA_IS_REVIEW = s.D_RA_IS_REVIEW,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (D_CRIME_DA_RiskAssessment_ID, LoadId, FK_D_CRIME_ID, D_RISK_ASSESSMENT_NAME, D_RISK_RATING, D_RA_COMPLETED_DATE, D_RA_QA_DATE, D_RA_IS_INITIAL_ASSESSMENT, D_RA_IS_REVIEW, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.D_CRIME_DA_RiskAssessment_ID, s.LoadId, s.FK_D_CRIME_ID, s.D_RISK_ASSESSMENT_NAME, s.D_RISK_RATING, s.D_RA_COMPLETED_DATE, s.D_RA_QA_DATE, s.D_RA_IS_INITIAL_ASSESSMENT, s.D_RA_IS_REVIEW, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_crime_da_riskassessment, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_crime_da_riskassessment OUTPUT;
 SET @run_id_rprt_tbl_d_crime_da_riskassessment = @table_name_rprt_tbl_d_crime_da_riskassessment + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_crime_da_riskassessment + N': ' + CAST(@rows_affected_rprt_tbl_d_crime_da_riskassessment AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_crime_da_riskassessment + N')';
 SET @sql_log_success_rprt_tbl_d_crime_da_riskassessment =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_crime_da_riskassessment,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_crime_da_riskassessment,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_crime_da_riskassessment,
 @rows = @rows_affected_rprt_tbl_d_crime_da_riskassessment,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_crime_da_riskassessment = N'rprt.tbl_d_crime_DA_RiskAssessment' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_crime_da_riskassessment = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_crime_da_riskassessment =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_crime_DA_RiskAssessment' + N' \n Message=' + @err_msg_rprt_tbl_d_crime_da_riskassessment + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_crime_DA_RiskAssessment AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_crime_DA_RiskAssessment AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_crime_DA_RiskAssessment: ' + @err_msg_rprt_tbl_d_crime_da_riskassessment + N' (run_id=' + @run_id_rprt_tbl_d_crime_da_riskassessment + N')';
 SET @sql_log_error_rprt_tbl_d_crime_da_riskassessment =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_crime_da_riskassessment,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_crime_DA_RiskAssessment',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_crime_da_riskassessment,
 @runid = @run_id_rprt_tbl_d_crime_da_riskassessment,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #2: rprt.tbl_d_crime_property SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_crime_property NVARCHAR(255) = N'rprt.tbl_d_crime_property';
DECLARE @rows_affected_rprt_tbl_d_crime_property INT = 0;
DECLARE @run_id_rprt_tbl_d_crime_property NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_crime_property NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_crime_property NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_crime_property NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_crime_property NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_crime_property NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_crime_property AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_crime_property AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.D_CRIME_PROPERTY_LINK_ID = s.D_CRIME_PROPERTY_LINK_ID,
 t.LoadID = s.LoadID,
 t.D_CRIME_PROPERTY_ID = s.D_CRIME_PROPERTY_ID,
 t.FK_D_CRIME_ID = s.FK_D_CRIME_ID,
 t.D_CRIME_PROPERTY_TYPE_1 = s.D_CRIME_PROPERTY_TYPE_1,
 t.D_CRIME_PROPERTY_TYPE_2 = s.D_CRIME_PROPERTY_TYPE_2,
 t.D_CRIME_PROPERTY_TYPE_3 = s.D_CRIME_PROPERTY_TYPE_3,
 t.D_CRIME_PROPERTY_STATUS = s.D_CRIME_PROPERTY_STATUS,
 t.PROPERTY_MODEL = s.PROPERTY_MODEL,
 t.PROPERTY_DESCRIPTION = s.PROPERTY_DESCRIPTION,
 t.PROPERTY_QUANTITY = s.PROPERTY_QUANTITY,
 t.D_CRIME_PROPERTY_IS_RECOVERED = s.D_CRIME_PROPERTY_IS_RECOVERED,
 t.D_CRIME_PROPERTY_RECOVERED_DATE = s.D_CRIME_PROPERTY_RECOVERED_DATE,
 t.PROPERTY_VALUE_RECOVERED = s.PROPERTY_VALUE_RECOVERED,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (D_CRIME_PROPERTY_LINK_ID, LoadID, D_CRIME_PROPERTY_ID, FK_D_CRIME_ID, D_CRIME_PROPERTY_TYPE_1, D_CRIME_PROPERTY_TYPE_2, D_CRIME_PROPERTY_TYPE_3, D_CRIME_PROPERTY_STATUS, PROPERTY_MODEL, PROPERTY_DESCRIPTION, PROPERTY_QUANTITY, D_CRIME_PROPERTY_IS_RECOVERED, D_CRIME_PROPERTY_RECOVERED_DATE, PROPERTY_VALUE_RECOVERED, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.D_CRIME_PROPERTY_LINK_ID, s.LoadID, s.D_CRIME_PROPERTY_ID, s.FK_D_CRIME_ID, s.D_CRIME_PROPERTY_TYPE_1, s.D_CRIME_PROPERTY_TYPE_2, s.D_CRIME_PROPERTY_TYPE_3, s.D_CRIME_PROPERTY_STATUS, s.PROPERTY_MODEL, s.PROPERTY_DESCRIPTION, s.PROPERTY_QUANTITY, s.D_CRIME_PROPERTY_IS_RECOVERED, s.D_CRIME_PROPERTY_RECOVERED_DATE, s.PROPERTY_VALUE_RECOVERED, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_crime_property, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_crime_property OUTPUT;
 SET @run_id_rprt_tbl_d_crime_property = @table_name_rprt_tbl_d_crime_property + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_crime_property + N': ' + CAST(@rows_affected_rprt_tbl_d_crime_property AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_crime_property + N')';
 SET @sql_log_success_rprt_tbl_d_crime_property =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_crime_property,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_crime_property,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_crime_property,
 @rows = @rows_affected_rprt_tbl_d_crime_property,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_crime_property = N'rprt.tbl_d_crime_property' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_crime_property = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_crime_property =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_crime_property' + N' \n Message=' + @err_msg_rprt_tbl_d_crime_property + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_crime_property AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_crime_property AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_crime_property: ' + @err_msg_rprt_tbl_d_crime_property + N' (run_id=' + @run_id_rprt_tbl_d_crime_property + N')';
 SET @sql_log_error_rprt_tbl_d_crime_property =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_crime_property,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_crime_property',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_crime_property,
 @runid = @run_id_rprt_tbl_d_crime_property,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #7: rprt.tbl_d_custody_arrest SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_custody_arrest NVARCHAR(255) = N'rprt.tbl_d_custody_arrest';
DECLARE @rows_affected_rprt_tbl_d_custody_arrest INT = 0;
DECLARE @run_id_rprt_tbl_d_custody_arrest NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_custody_arrest NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_custody_arrest NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_custody_arrest NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_custody_arrest NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_custody_arrest NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_custody_arrest AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_custody_arrest AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.D_ARREST_ID = s.D_ARREST_ID,
 t.LoadID = s.LoadID,
 t.D_ARREST_OWNING_FORCE = s.D_ARREST_OWNING_FORCE,
 t.D_ARREST_ARREST_LOCATION = s.D_ARREST_ARREST_LOCATION,
 t.D_ARREST_DATE_TIME = s.D_ARREST_DATE_TIME,
 t.D_ARREST_MAIN_ARREST_FLAG = s.D_ARREST_MAIN_ARREST_FLAG,
 t.D_ARREST_CUSTODY_TYPE = s.D_ARREST_CUSTODY_TYPE,
 t.D_ARREST_STREET_BAIL_GRANTED = s.D_ARREST_STREET_BAIL_GRANTED,
 t.D_ARREST_ARRESTING_FORCE = s.D_ARREST_ARRESTING_FORCE,
 t.D_ARREST_ARRESTING_OFFICER_ID = s.D_ARREST_ARRESTING_OFFICER_ID,
 t.D_ARREST_DOMESTIC_VIOLENCE_RELATED = s.D_ARREST_DOMESTIC_VIOLENCE_RELATED,
 t.D_ARREST_OFFICER_IN_CASE = s.D_ARREST_OFFICER_IN_CASE,
 t.D_ARREST_REASON = s.D_ARREST_REASON,
 t.D_STAFF_MOVE_ID = s.D_STAFF_MOVE_ID,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (D_ARREST_ID, LoadID, D_ARREST_OWNING_FORCE, D_ARREST_ARREST_LOCATION, D_ARREST_DATE_TIME, D_ARREST_MAIN_ARREST_FLAG, D_ARREST_CUSTODY_TYPE, D_ARREST_STREET_BAIL_GRANTED, D_ARREST_ARRESTING_FORCE, D_ARREST_ARRESTING_OFFICER_ID, D_ARREST_DOMESTIC_VIOLENCE_RELATED, D_ARREST_OFFICER_IN_CASE, D_ARREST_REASON, D_STAFF_MOVE_ID, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.D_ARREST_ID, s.LoadID, s.D_ARREST_OWNING_FORCE, s.D_ARREST_ARREST_LOCATION, s.D_ARREST_DATE_TIME, s.D_ARREST_MAIN_ARREST_FLAG, s.D_ARREST_CUSTODY_TYPE, s.D_ARREST_STREET_BAIL_GRANTED, s.D_ARREST_ARRESTING_FORCE, s.D_ARREST_ARRESTING_OFFICER_ID, s.D_ARREST_DOMESTIC_VIOLENCE_RELATED, s.D_ARREST_OFFICER_IN_CASE, s.D_ARREST_REASON, s.D_STAFF_MOVE_ID, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_custody_arrest, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_custody_arrest OUTPUT;
 SET @run_id_rprt_tbl_d_custody_arrest = @table_name_rprt_tbl_d_custody_arrest + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_custody_arrest + N': ' + CAST(@rows_affected_rprt_tbl_d_custody_arrest AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_custody_arrest + N')';
 SET @sql_log_success_rprt_tbl_d_custody_arrest =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_custody_arrest,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_custody_arrest,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_custody_arrest,
 @rows = @rows_affected_rprt_tbl_d_custody_arrest,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_custody_arrest = N'rprt.tbl_d_custody_arrest' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_custody_arrest = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_custody_arrest =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_custody_arrest' + N' \n Message=' + @err_msg_rprt_tbl_d_custody_arrest + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_custody_arrest AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_custody_arrest AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_custody_arrest: ' + @err_msg_rprt_tbl_d_custody_arrest + N' (run_id=' + @run_id_rprt_tbl_d_custody_arrest + N')';
 SET @sql_log_error_rprt_tbl_d_custody_arrest =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_custody_arrest,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_custody_arrest',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_custody_arrest,
 @runid = @run_id_rprt_tbl_d_custody_arrest,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #8: rprt.tbl_d_custody_facility SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_custody_facility NVARCHAR(255) = N'rprt.tbl_d_custody_facility';
DECLARE @rows_affected_rprt_tbl_d_custody_facility INT = 0;
DECLARE @run_id_rprt_tbl_d_custody_facility NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_custody_facility NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_custody_facility NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_custody_facility NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_custody_facility NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_custody_facility NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_custody_facility AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_custody_facility AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.D_CUSTODY_FACILITY_ID = s.D_CUSTODY_FACILITY_ID,
 t.LoadID = s.LoadID,
 t.D_CUSTODY_FACILITY_FORCE = s.D_CUSTODY_FACILITY_FORCE,
 t.D_CUSTODY_FACILITY_REFERENCE = s.D_CUSTODY_FACILITY_REFERENCE,
 t.D_CUSTODY_FACILITY_NAME = s.D_CUSTODY_FACILITY_NAME,
 t.D_CUSTODY_FACILITY_POSTCODE = s.D_CUSTODY_FACILITY_POSTCODE,
 t.D_CUSTODY_FACILITY_SECTOR_CODE = s.D_CUSTODY_FACILITY_SECTOR_CODE,
 t.D_CUSTODY_FACILITY_STATION_CODE = s.D_CUSTODY_FACILITY_STATION_CODE,
 t.D_CUSTODY_FACILITY_STATION_CODE_DESC = s.D_CUSTODY_FACILITY_STATION_CODE_DESC,
 t.D_CUSTODY_FACILITY_STATUS = s.D_CUSTODY_FACILITY_STATUS,
 t.D_CUSTODY_FACILITY_COURT_ID = s.D_CUSTODY_FACILITY_COURT_ID,
 t.D_CUSTODY_FACILITY_UNIT_CODE = s.D_CUSTODY_FACILITY_UNIT_CODE,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (D_CUSTODY_FACILITY_ID, LoadID, D_CUSTODY_FACILITY_FORCE, D_CUSTODY_FACILITY_REFERENCE, D_CUSTODY_FACILITY_NAME, D_CUSTODY_FACILITY_POSTCODE, D_CUSTODY_FACILITY_SECTOR_CODE, D_CUSTODY_FACILITY_STATION_CODE, D_CUSTODY_FACILITY_STATION_CODE_DESC, D_CUSTODY_FACILITY_STATUS, D_CUSTODY_FACILITY_COURT_ID, D_CUSTODY_FACILITY_UNIT_CODE, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.D_CUSTODY_FACILITY_ID, s.LoadID, s.D_CUSTODY_FACILITY_FORCE, s.D_CUSTODY_FACILITY_REFERENCE, s.D_CUSTODY_FACILITY_NAME, s.D_CUSTODY_FACILITY_POSTCODE, s.D_CUSTODY_FACILITY_SECTOR_CODE, s.D_CUSTODY_FACILITY_STATION_CODE, s.D_CUSTODY_FACILITY_STATION_CODE_DESC, s.D_CUSTODY_FACILITY_STATUS, s.D_CUSTODY_FACILITY_COURT_ID, s.D_CUSTODY_FACILITY_UNIT_CODE, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_custody_facility, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_custody_facility OUTPUT;
 SET @run_id_rprt_tbl_d_custody_facility = @table_name_rprt_tbl_d_custody_facility + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_custody_facility + N': ' + CAST(@rows_affected_rprt_tbl_d_custody_facility AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_custody_facility + N')';
 SET @sql_log_success_rprt_tbl_d_custody_facility =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_custody_facility,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_custody_facility,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_custody_facility,
 @rows = @rows_affected_rprt_tbl_d_custody_facility,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_custody_facility = N'rprt.tbl_d_custody_facility' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_custody_facility = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_custody_facility =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_custody_facility' + N' \n Message=' + @err_msg_rprt_tbl_d_custody_facility + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_custody_facility AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_custody_facility AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_custody_facility: ' + @err_msg_rprt_tbl_d_custody_facility + N' (run_id=' + @run_id_rprt_tbl_d_custody_facility + N')';
 SET @sql_log_error_rprt_tbl_d_custody_facility =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_custody_facility,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_custody_facility',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_custody_facility,
 @runid = @run_id_rprt_tbl_d_custody_facility,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #9: rprt.tbl_d_custody_subfacility SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_custody_subfacility NVARCHAR(255) = N'rprt.tbl_d_custody_subfacility';
DECLARE @rows_affected_rprt_tbl_d_custody_subfacility INT = 0;
DECLARE @run_id_rprt_tbl_d_custody_subfacility NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_custody_subfacility NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_custody_subfacility NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_custody_subfacility NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_custody_subfacility NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_custody_subfacility NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_custody_subfacility AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_custody_subfacility AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.D_SUBFACILITY_ID = s.D_SUBFACILITY_ID,
 t.LoadID = s.LoadID,
 t.D_SUBFACILITY_REFERENCE = s.D_SUBFACILITY_REFERENCE,
 t.FK_D_CUSTODY_FACILITY_ID = s.FK_D_CUSTODY_FACILITY_ID,
 t.D_SUBFACILITY_FORCE_ID = s.D_SUBFACILITY_FORCE_ID,
 t.D_SUBFACILITY_TYPE = s.D_SUBFACILITY_TYPE,
 t.D_SUBFACILITY_SUMMARY = s.D_SUBFACILITY_SUMMARY,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (D_SUBFACILITY_ID, LoadID, D_SUBFACILITY_REFERENCE, FK_D_CUSTODY_FACILITY_ID, D_SUBFACILITY_FORCE_ID, D_SUBFACILITY_TYPE, D_SUBFACILITY_SUMMARY, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.D_SUBFACILITY_ID, s.LoadID, s.D_SUBFACILITY_REFERENCE, s.FK_D_CUSTODY_FACILITY_ID, s.D_SUBFACILITY_FORCE_ID, s.D_SUBFACILITY_TYPE, s.D_SUBFACILITY_SUMMARY, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_custody_subfacility, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_custody_subfacility OUTPUT;
 SET @run_id_rprt_tbl_d_custody_subfacility = @table_name_rprt_tbl_d_custody_subfacility + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_custody_subfacility + N': ' + CAST(@rows_affected_rprt_tbl_d_custody_subfacility AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_custody_subfacility + N')';
 SET @sql_log_success_rprt_tbl_d_custody_subfacility =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_custody_subfacility,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_custody_subfacility,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_custody_subfacility,
 @rows = @rows_affected_rprt_tbl_d_custody_subfacility,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_custody_subfacility = N'rprt.tbl_d_custody_subfacility' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_custody_subfacility = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_custody_subfacility =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_custody_subfacility' + N' \n Message=' + @err_msg_rprt_tbl_d_custody_subfacility + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_custody_subfacility AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_custody_subfacility AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_custody_subfacility: ' + @err_msg_rprt_tbl_d_custody_subfacility + N' (run_id=' + @run_id_rprt_tbl_d_custody_subfacility + N')';
 SET @sql_log_error_rprt_tbl_d_custody_subfacility =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_custody_subfacility,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_custody_subfacility',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_custody_subfacility,
 @runid = @run_id_rprt_tbl_d_custody_subfacility,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #10: rprt.tbl_d_custody_offence SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_custody_offence NVARCHAR(255) = N'rprt.tbl_d_custody_offence';
DECLARE @rows_affected_rprt_tbl_d_custody_offence INT = 0;
DECLARE @run_id_rprt_tbl_d_custody_offence NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_custody_offence NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_custody_offence NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_custody_offence NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_custody_offence NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_custody_offence NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_custody_offence AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_custody_offence AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.D_CUSTODY_OFFENCE_ID = s.D_CUSTODY_OFFENCE_ID,
 t.LoadID = s.LoadID,
 t.D_CUSTODY_OWNING_FORCE = s.D_CUSTODY_OWNING_FORCE,
 t.D_CUSTODY_OFFENCE_SEQUENCE_NUMBER = s.D_CUSTODY_OFFENCE_SEQUENCE_NUMBER,
 t.D_CUSTODY_OFFENCE_CCCJS_CODE = s.D_CUSTODY_OFFENCE_CCCJS_CODE,
 t.FK_D_CRIME_ID = s.FK_D_CRIME_ID,
 t.FK_D_CASE_ID = s.FK_D_CASE_ID,
 t.D_CUSTODY_OFFENCE_ACT_SECTION = s.D_CUSTODY_OFFENCE_ACT_SECTION,
 t.D_CUSTODY_OFFENCE_OFFENCE_SHORT_TITLE = s.D_CUSTODY_OFFENCE_OFFENCE_SHORT_TITLE,
 t.D_CUSTODY_OFFENCE_CHARGE_WORDING = s.D_CUSTODY_OFFENCE_CHARGE_WORDING,
 t.D_CUSTODY_OFFENCE_COMMITTED_ON_OR_FROM_DATE_TIME = s.D_CUSTODY_OFFENCE_COMMITTED_ON_OR_FROM_DATE_TIME,
 t.D_CUSTODY_OFFENCE_LOCATION_POSTCODE = s.D_CUSTODY_OFFENCE_LOCATION_POSTCODE,
 t.D_CUSTODY_OFFENCE_LOCATION_FORCE_CODE = s.D_CUSTODY_OFFENCE_LOCATION_FORCE_CODE,
 t.D_CUSTODY_COMMITTED_ON_BAIL = s.D_CUSTODY_COMMITTED_ON_BAIL,
 t.D_CUSTODY_CURRENT_OFFENCE_STATUS = s.D_CUSTODY_CURRENT_OFFENCE_STATUS,
 t.D_CUSTODY_GROUP_ITERATION_GROUP_REF = s.D_CUSTODY_GROUP_ITERATION_GROUP_REF,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (D_CUSTODY_OFFENCE_ID, LoadID, D_CUSTODY_OWNING_FORCE, D_CUSTODY_OFFENCE_SEQUENCE_NUMBER, D_CUSTODY_OFFENCE_CCCJS_CODE, FK_D_CRIME_ID, FK_D_CASE_ID, D_CUSTODY_OFFENCE_ACT_SECTION, D_CUSTODY_OFFENCE_OFFENCE_SHORT_TITLE, D_CUSTODY_OFFENCE_CHARGE_WORDING, D_CUSTODY_OFFENCE_COMMITTED_ON_OR_FROM_DATE_TIME, D_CUSTODY_OFFENCE_LOCATION_POSTCODE, D_CUSTODY_OFFENCE_LOCATION_FORCE_CODE, D_CUSTODY_COMMITTED_ON_BAIL, D_CUSTODY_CURRENT_OFFENCE_STATUS, D_CUSTODY_GROUP_ITERATION_GROUP_REF, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.D_CUSTODY_OFFENCE_ID, s.LoadID, s.D_CUSTODY_OWNING_FORCE, s.D_CUSTODY_OFFENCE_SEQUENCE_NUMBER, s.D_CUSTODY_OFFENCE_CCCJS_CODE, s.FK_D_CRIME_ID, s.FK_D_CASE_ID, s.D_CUSTODY_OFFENCE_ACT_SECTION, s.D_CUSTODY_OFFENCE_OFFENCE_SHORT_TITLE, s.D_CUSTODY_OFFENCE_CHARGE_WORDING, s.D_CUSTODY_OFFENCE_COMMITTED_ON_OR_FROM_DATE_TIME, s.D_CUSTODY_OFFENCE_LOCATION_POSTCODE, s.D_CUSTODY_OFFENCE_LOCATION_FORCE_CODE, s.D_CUSTODY_COMMITTED_ON_BAIL, s.D_CUSTODY_CURRENT_OFFENCE_STATUS, s.D_CUSTODY_GROUP_ITERATION_GROUP_REF, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_custody_offence, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_custody_offence OUTPUT;
 SET @run_id_rprt_tbl_d_custody_offence = @table_name_rprt_tbl_d_custody_offence + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_custody_offence + N': ' + CAST(@rows_affected_rprt_tbl_d_custody_offence AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_custody_offence + N')';
 SET @sql_log_success_rprt_tbl_d_custody_offence =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_custody_offence,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_custody_offence,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_custody_offence,
 @rows = @rows_affected_rprt_tbl_d_custody_offence,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_custody_offence = N'rprt.tbl_d_custody_offence' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_custody_offence = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_custody_offence =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_custody_offence' + N' \n Message=' + @err_msg_rprt_tbl_d_custody_offence + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_custody_offence AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_custody_offence AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_custody_offence: ' + @err_msg_rprt_tbl_d_custody_offence + N' (run_id=' + @run_id_rprt_tbl_d_custody_offence + N')';
 SET @sql_log_error_rprt_tbl_d_custody_offence =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_custody_offence,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_custody_offence',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_custody_offence,
 @runid = @run_id_rprt_tbl_d_custody_offence,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #11: rprt.tbl_d_detainee_person SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_detainee_person NVARCHAR(255) = N'rprt.tbl_d_detainee_person';
DECLARE @rows_affected_rprt_tbl_d_detainee_person INT = 0;
DECLARE @run_id_rprt_tbl_d_detainee_person NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_detainee_person NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_detainee_person NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_detainee_person NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_detainee_person NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_detainee_person NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_detainee_person AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_detainee_person AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.D_DETAINEE_PERSON_ID = s.D_DETAINEE_PERSON_ID,
 t.D_DETAINEE_PERSON_CREATE_DATE_TIME = s.D_DETAINEE_PERSON_CREATE_DATE_TIME,
 t.D_DETAINEE_PERSON_CREATE_STAFF_OBJECT_REF = s.D_DETAINEE_PERSON_CREATE_STAFF_OBJECT_REF,
 t.D_DETAINEE_PERSON_ITERATION_GROUP_REF = s.D_DETAINEE_PERSON_ITERATION_GROUP_REF,
 t.D_DETAINEE_PERSON_GENDER_GCV = s.D_DETAINEE_PERSON_GENDER_GCV,
 t.D_DETAINEE_PERSON_PNC_ID = s.D_DETAINEE_PERSON_PNC_ID,
 t.D_DETAINEE_PERSON_CRO_ID = s.D_DETAINEE_PERSON_CRO_ID,
 t.FK_F_CUSTODY_RECORD_ID = s.FK_F_CUSTODY_RECORD_ID,
 t.FK_D_ARREST_ID = s.FK_D_ARREST_ID,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (D_DETAINEE_PERSON_ID, D_DETAINEE_PERSON_CREATE_DATE_TIME, D_DETAINEE_PERSON_CREATE_STAFF_OBJECT_REF, D_DETAINEE_PERSON_ITERATION_GROUP_REF, D_DETAINEE_PERSON_GENDER_GCV, D_DETAINEE_PERSON_PNC_ID, D_DETAINEE_PERSON_CRO_ID, FK_F_CUSTODY_RECORD_ID, FK_D_ARREST_ID, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.D_DETAINEE_PERSON_ID, s.D_DETAINEE_PERSON_CREATE_DATE_TIME, s.D_DETAINEE_PERSON_CREATE_STAFF_OBJECT_REF, s.D_DETAINEE_PERSON_ITERATION_GROUP_REF, s.D_DETAINEE_PERSON_GENDER_GCV, s.D_DETAINEE_PERSON_PNC_ID, s.D_DETAINEE_PERSON_CRO_ID, s.FK_F_CUSTODY_RECORD_ID, s.FK_D_ARREST_ID, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_detainee_person, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_detainee_person OUTPUT;
 SET @run_id_rprt_tbl_d_detainee_person = @table_name_rprt_tbl_d_detainee_person + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_detainee_person + N': ' + CAST(@rows_affected_rprt_tbl_d_detainee_person AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_detainee_person + N')';
 SET @sql_log_success_rprt_tbl_d_detainee_person =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_detainee_person,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_detainee_person,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_detainee_person,
 @rows = @rows_affected_rprt_tbl_d_detainee_person,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_detainee_person = N'rprt.tbl_d_detainee_person' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_detainee_person = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_detainee_person =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_detainee_person' + N' \n Message=' + @err_msg_rprt_tbl_d_detainee_person + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_detainee_person AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_detainee_person AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_detainee_person: ' + @err_msg_rprt_tbl_d_detainee_person + N' (run_id=' + @run_id_rprt_tbl_d_detainee_person + N')';
 SET @sql_log_error_rprt_tbl_d_detainee_person =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_detainee_person,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_detainee_person',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_detainee_person,
 @runid = @run_id_rprt_tbl_d_detainee_person,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;



/* ==================================================================
 MERGE #12: rprt.tbl_d_intel_reports SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_intel_reports NVARCHAR(255) = N'rprt.tbl_d_intel_reports';
DECLARE @rows_affected_rprt_tbl_d_intel_reports INT = 0;
DECLARE @run_id_rprt_tbl_d_intel_reports NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_intel_reports NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_intel_reports NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_intel_reports NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_intel_reports NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_intel_reports NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_intel_reports AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_intel_reports AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.D_OBJECT_REF = s.D_OBJECT_REF,
 t.FK_D_CRIME_INCIDENT_ID = s.FK_D_CRIME_INCIDENT_ID,
 t.D_STATUS_GCV = s.D_STATUS_GCV,
 t.D_CREATE_DATE_TIME = s.D_CREATE_DATE_TIME,
 t.D_CREATE_STAFF_OBJECT_REF = s.D_CREATE_STAFF_OBJECT_REF,
 t.D_DATE_SUBMITTED = s.D_DATE_SUBMITTED,
 t.D_TIME_SUBMITTED = s.D_TIME_SUBMITTED,
 t.D_SUBMITTING_OFFICER = s.D_SUBMITTING_OFFICER,
 t.D_TITLE = s.D_TITLE,
 t.D_GPMS_CLASSIFICATION = s.D_GPMS_CLASSIFICATION,
 t.D_MOPI_GROUP_GCV = s.D_MOPI_GROUP_GCV,
 t.D_MOPI_RETENTION_DATE = s.D_MOPI_RETENTION_DATE,
 t.D_FORCE_GCV = s.D_FORCE_GCV,
 t.D_BCU_GCV = s.D_BCU_GCV,
 t.D_STATION_CODE_GCV = s.D_STATION_CODE_GCV,
 t.D_BEAT_CODE_GCV = s.D_BEAT_CODE_GCV,
 t.D_GPMS_MARKING = s.D_GPMS_MARKING,
 t.D_PRIORITY_GCV = s.D_PRIORITY_GCV,
 t.D_NIM_LEVEL_GCV = s.D_NIM_LEVEL_GCV,
 t.D_INFO_TYPE = s.D_INFO_TYPE,
 t.D_INFO_TYPE_GCV = s.D_INFO_TYPE_GCV,
 t.D_SUBMITTING_OFFICER_EMPLOYEE_NO = s.D_SUBMITTING_OFFICER_EMPLOYEE_NO,
 t.D_STAFF_MOVE_ID = s.D_STAFF_MOVE_ID,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (D_OBJECT_REF, FK_D_CRIME_INCIDENT_ID, D_STATUS_GCV, D_CREATE_DATE_TIME, D_CREATE_STAFF_OBJECT_REF, D_DATE_SUBMITTED, D_TIME_SUBMITTED, D_SUBMITTING_OFFICER, D_TITLE, D_GPMS_CLASSIFICATION, D_MOPI_GROUP_GCV, D_MOPI_RETENTION_DATE, D_FORCE_GCV, D_BCU_GCV, D_STATION_CODE_GCV, D_BEAT_CODE_GCV, D_GPMS_MARKING, D_PRIORITY_GCV, D_NIM_LEVEL_GCV, D_INFO_TYPE, D_INFO_TYPE_GCV, D_SUBMITTING_OFFICER_EMPLOYEE_NO, D_STAFF_MOVE_ID, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.D_OBJECT_REF, s.FK_D_CRIME_INCIDENT_ID, s.D_STATUS_GCV, s.D_CREATE_DATE_TIME, s.D_CREATE_STAFF_OBJECT_REF, s.D_DATE_SUBMITTED, s.D_TIME_SUBMITTED, s.D_SUBMITTING_OFFICER, s.D_TITLE, s.D_GPMS_CLASSIFICATION, s.D_MOPI_GROUP_GCV, s.D_MOPI_RETENTION_DATE, s.D_FORCE_GCV, s.D_BCU_GCV, s.D_STATION_CODE_GCV, s.D_BEAT_CODE_GCV, s.D_GPMS_MARKING, s.D_PRIORITY_GCV, s.D_NIM_LEVEL_GCV, s.D_INFO_TYPE, s.D_INFO_TYPE_GCV, s.D_SUBMITTING_OFFICER_EMPLOYEE_NO, s.D_STAFF_MOVE_ID, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_intel_reports, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_intel_reports OUTPUT;
 SET @run_id_rprt_tbl_d_intel_reports = @table_name_rprt_tbl_d_intel_reports + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_intel_reports + N': ' + CAST(@rows_affected_rprt_tbl_d_intel_reports AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_intel_reports + N')';
 SET @sql_log_success_rprt_tbl_d_intel_reports =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_intel_reports,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_intel_reports,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_intel_reports,
 @rows = @rows_affected_rprt_tbl_d_intel_reports,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_intel_reports = N'rprt.tbl_d_intel_reports' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_intel_reports = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_intel_reports =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_intel_reports' + N' \n Message=' + @err_msg_rprt_tbl_d_intel_reports + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_intel_reports AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_intel_reports AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_intel_reports: ' + @err_msg_rprt_tbl_d_intel_reports + N' (run_id=' + @run_id_rprt_tbl_d_intel_reports + N')';
 SET @sql_log_error_rprt_tbl_d_intel_reports =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_intel_reports,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_intel_reports',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_intel_reports,
 @runid = @run_id_rprt_tbl_d_intel_reports,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #13: rprt.tbl_d_inv_classification SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_inv_classification NVARCHAR(255) = N'rprt.tbl_d_inv_classification';
DECLARE @rows_affected_rprt_tbl_d_inv_classification INT = 0;
DECLARE @run_id_rprt_tbl_d_inv_classification NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_inv_classification NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_inv_classification NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_inv_classification NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_inv_classification NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_inv_classification NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_inv_classification AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_inv_classification AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.URN = s.URN,
 t.FULL_OFFENCE_TITLE = s.FULL_OFFENCE_TITLE,
 t.GROUP_GCV = s.GROUP_GCV,
 t.SUB_GROUP_GCV = s.SUB_GROUP_GCV,
 t.SUB_SUB_GROUP_GCV = s.SUB_SUB_GROUP_GCV,
 t.CLASSIFICATION_CODE = s.CLASSIFICATION_CODE,
 t.HOME_OFFICE_CLASSIFICATION = s.HOME_OFFICE_CLASSIFICATION,
 t.HMIC_CRIME_TREE_LEVEL_2_GCV = s.HMIC_CRIME_TREE_LEVEL_2_GCV,
 t.HMIC_CRIME_TREE_LEVEL_3_GCV = s.HMIC_CRIME_TREE_LEVEL_3_GCV,
 t.NOTIFIABLE = s.NOTIFIABLE,
 t.CHANGE_FLAG = s.CHANGE_FLAG,
 t.SUB_SUB_GROUP = s.SUB_SUB_GROUP,
 t.HMIC_CRIME_TREE_LEVEL_3 = s.HMIC_CRIME_TREE_LEVEL_3,
 t.HMIC_CRIME_TREE_LEVEL_2 = s.HMIC_CRIME_TREE_LEVEL_2,
 t.D_MSV = s.D_MSV,
 t.D_CRIME_TREE_LEVEL_3A = s.D_CRIME_TREE_LEVEL_3A,
 t.HMIC_CRIME_TREE_LEVEL_1 = s.HMIC_CRIME_TREE_LEVEL_1,
 t.HMIC_CRIME_TREE_LEVEL_1_GCV = s.HMIC_CRIME_TREE_LEVEL_1_GCV,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (URN, FULL_OFFENCE_TITLE, GROUP_GCV, SUB_GROUP_GCV, SUB_SUB_GROUP_GCV, CLASSIFICATION_CODE, HOME_OFFICE_CLASSIFICATION, HMIC_CRIME_TREE_LEVEL_2_GCV, HMIC_CRIME_TREE_LEVEL_3_GCV, NOTIFIABLE, CHANGE_FLAG, SUB_SUB_GROUP, HMIC_CRIME_TREE_LEVEL_3, HMIC_CRIME_TREE_LEVEL_2, D_MSV, D_CRIME_TREE_LEVEL_3A, HMIC_CRIME_TREE_LEVEL_1, HMIC_CRIME_TREE_LEVEL_1_GCV, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.URN, s.FULL_OFFENCE_TITLE, s.GROUP_GCV, s.SUB_GROUP_GCV, s.SUB_SUB_GROUP_GCV, s.CLASSIFICATION_CODE, s.HOME_OFFICE_CLASSIFICATION, s.HMIC_CRIME_TREE_LEVEL_2_GCV, s.HMIC_CRIME_TREE_LEVEL_3_GCV, s.NOTIFIABLE, s.CHANGE_FLAG, s.SUB_SUB_GROUP, s.HMIC_CRIME_TREE_LEVEL_3, s.HMIC_CRIME_TREE_LEVEL_2, s.D_MSV, s.D_CRIME_TREE_LEVEL_3A, s.HMIC_CRIME_TREE_LEVEL_1, s.HMIC_CRIME_TREE_LEVEL_1_GCV, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_inv_classification, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_inv_classification OUTPUT;
 SET @run_id_rprt_tbl_d_inv_classification = @table_name_rprt_tbl_d_inv_classification + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_inv_classification + N': ' + CAST(@rows_affected_rprt_tbl_d_inv_classification AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_inv_classification + N')';
 SET @sql_log_success_rprt_tbl_d_inv_classification =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_inv_classification,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_inv_classification,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_inv_classification,
 @rows = @rows_affected_rprt_tbl_d_inv_classification,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_inv_classification = N'rprt.tbl_d_inv_classification' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_inv_classification = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_inv_classification =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_inv_classification' + N' \n Message=' + @err_msg_rprt_tbl_d_inv_classification + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_inv_classification AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_inv_classification AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_inv_classification: ' + @err_msg_rprt_tbl_d_inv_classification + N' (run_id=' + @run_id_rprt_tbl_d_inv_classification + N')';
 SET @sql_log_error_rprt_tbl_d_inv_classification =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_inv_classification,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_inv_classification',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_inv_classification,
 @runid = @run_id_rprt_tbl_d_inv_classification,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #1: rprt.tbl_d_person SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_person NVARCHAR(255) = N'rprt.tbl_d_person';
DECLARE @rows_affected_rprt_tbl_d_person INT = 0;
DECLARE @run_id_rprt_tbl_d_person NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_person NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_person NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_person NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_person NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_person NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_person AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_person AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.D_PERSON_ID = s.D_PERSON_ID,
 t.LoadID = s.LoadID,
 t.D_PERSON_ETHNICITY = s.D_PERSON_ETHNICITY,
 t.D_PERSON_GENDER = s.D_PERSON_GENDER,
 t.D_PERSON_REF = s.D_PERSON_REF,
 t.D_PERSON_DOB = s.D_PERSON_DOB,
 t.D_PERSON_MH_MARKER = s.D_PERSON_MH_MARKER,
 t.D_PERSON_PNC_ID = s.D_PERSON_PNC_ID,
 t.D_PERSON_DEAD = s.D_PERSON_DEAD,
 t.D_PERSON_DATE_OF_DEATH = s.D_PERSON_DATE_OF_DEATH,
 t.D_PERSON_VIOLENT_MARKER = s.D_PERSON_VIOLENT_MARKER,
 t.D_PERSON_VISOR_MARKER = s.D_PERSON_VISOR_MARKER,
 t.D_PERSON_NATIONALITY = s.D_PERSON_NATIONALITY,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (D_PERSON_ID, LoadID, D_PERSON_ETHNICITY, D_PERSON_GENDER, D_PERSON_REF, D_PERSON_DOB, D_PERSON_MH_MARKER, D_PERSON_PNC_ID, D_PERSON_DEAD, D_PERSON_DATE_OF_DEATH, D_PERSON_VIOLENT_MARKER, D_PERSON_VISOR_MARKER, D_PERSON_NATIONALITY, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.D_PERSON_ID, s.LoadID, s.D_PERSON_ETHNICITY, s.D_PERSON_GENDER, s.D_PERSON_REF, s.D_PERSON_DOB, s.D_PERSON_MH_MARKER, s.D_PERSON_PNC_ID, s.D_PERSON_DEAD, s.D_PERSON_DATE_OF_DEATH, s.D_PERSON_VIOLENT_MARKER, s.D_PERSON_VISOR_MARKER, s.D_PERSON_NATIONALITY, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_person, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_person OUTPUT;
 SET @run_id_rprt_tbl_d_person = @table_name_rprt_tbl_d_person + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_person + N': ' + CAST(@rows_affected_rprt_tbl_d_person AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_person + N')';
 SET @sql_log_success_rprt_tbl_d_person =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_person,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_person,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_person,
 @rows = @rows_affected_rprt_tbl_d_person,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_person = N'rprt.tbl_d_person' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_person = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_person =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_person' + N' \n Message=' + @err_msg_rprt_tbl_d_person + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_person AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_person AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_person: ' + @err_msg_rprt_tbl_d_person + N' (run_id=' + @run_id_rprt_tbl_d_person + N')';
 SET @sql_log_error_rprt_tbl_d_person =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_person,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_person',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_person,
 @runid = @run_id_rprt_tbl_d_person,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #15: rprt.tbl_d_tag SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_tag NVARCHAR(255) = N'rprt.tbl_d_tag';
DECLARE @rows_affected_rprt_tbl_d_tag INT = 0;
DECLARE @run_id_rprt_tbl_d_tag NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_tag NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_tag NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_tag NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_tag NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_tag NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_tag AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_tag AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.TagNaturalID = s.TagNaturalID,
 t.LoadID = s.LoadID,
 t.TagCode = s.TagCode,
 t.TagCategory = s.TagCategory,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (TagNaturalID, LoadID, TagCode, TagCategory, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.TagNaturalID, s.LoadID, s.TagCode, s.TagCategory, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_tag, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_tag OUTPUT;
 SET @run_id_rprt_tbl_d_tag = @table_name_rprt_tbl_d_tag + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_tag + N': ' + CAST(@rows_affected_rprt_tbl_d_tag AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_tag + N')';
 SET @sql_log_success_rprt_tbl_d_tag =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_tag,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_tag,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_tag,
 @rows = @rows_affected_rprt_tbl_d_tag,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_tag = N'rprt.tbl_d_tag' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_tag = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_tag =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_tag' + N' \n Message=' + @err_msg_rprt_tbl_d_tag + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_tag AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_tag AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_tag: ' + @err_msg_rprt_tbl_d_tag + N' (run_id=' + @run_id_rprt_tbl_d_tag + N')';
 SET @sql_log_error_rprt_tbl_d_tag =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_tag,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_tag',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_tag,
 @runid = @run_id_rprt_tbl_d_tag,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #16: rprt.tbl_d_court_orders SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_court_orders NVARCHAR(255) = N'rprt.tbl_d_court_orders';
DECLARE @rows_affected_rprt_tbl_d_court_orders INT = 0;
DECLARE @run_id_rprt_tbl_d_court_orders NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_court_orders NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_court_orders NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_court_orders NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_court_orders NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_court_orders NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_court_orders AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_court_orders AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.FK_D_PERSON_ID = s.FK_D_PERSON_ID,
 t.D_OBJECT_REF = s.D_OBJECT_REF,
 t.FK_D_CRIME_ID = s.FK_D_CRIME_ID,
 t.D_ORDER_TYPE_GCV = s.D_ORDER_TYPE_GCV,
 t.D_VALID_FROM_DATE = s.D_VALID_FROM_DATE,
 t.D_EXPIRY_DATE = s.D_EXPIRY_DATE,
 t.D_ORDER_DETAILS = s.D_ORDER_DETAILS,
 t.D_ISSUING_COURT = s.D_ISSUING_COURT,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (FK_D_PERSON_ID, D_OBJECT_REF, FK_D_CRIME_ID, D_ORDER_TYPE_GCV, D_VALID_FROM_DATE, D_EXPIRY_DATE, D_ORDER_DETAILS, D_ISSUING_COURT, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.FK_D_PERSON_ID, s.D_OBJECT_REF, s.FK_D_CRIME_ID, s.D_ORDER_TYPE_GCV, s.D_VALID_FROM_DATE, s.D_EXPIRY_DATE, s.D_ORDER_DETAILS, s.D_ISSUING_COURT, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_court_orders, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_court_orders OUTPUT;
 SET @run_id_rprt_tbl_d_court_orders = @table_name_rprt_tbl_d_court_orders + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_court_orders + N': ' + CAST(@rows_affected_rprt_tbl_d_court_orders AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_court_orders + N')';
 SET @sql_log_success_rprt_tbl_d_court_orders =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_court_orders,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_court_orders,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_court_orders,
 @rows = @rows_affected_rprt_tbl_d_court_orders,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_court_orders = N'rprt.tbl_d_court_orders' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_court_orders = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_court_orders =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_court_orders' + N' \n Message=' + @err_msg_rprt_tbl_d_court_orders + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_court_orders AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_court_orders AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_court_orders: ' + @err_msg_rprt_tbl_d_court_orders + N' (run_id=' + @run_id_rprt_tbl_d_court_orders + N')';
 SET @sql_log_error_rprt_tbl_d_court_orders =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_court_orders,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_court_orders',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_court_orders,
 @runid = @run_id_rprt_tbl_d_court_orders,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #17: rprt.tbl_d_court_warrant SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_court_warrant NVARCHAR(255) = N'rprt.tbl_d_court_warrant';
DECLARE @rows_affected_rprt_tbl_d_court_warrant INT = 0;
DECLARE @run_id_rprt_tbl_d_court_warrant NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_court_warrant NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_court_warrant NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_court_warrant NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_court_warrant NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_court_warrant NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_court_warrant AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_court_warrant AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.D_COURT_WARRANT_OBJECT_REF = s.D_COURT_WARRANT_OBJECT_REF,
 t.D_COURT_WARRANT_FORCE = s.D_COURT_WARRANT_FORCE,
 t.D_COURT_WARRANT_BCU_GCV = s.D_COURT_WARRANT_BCU_GCV,
 t.D_COURT_WARRANT_DISTRICT_GCV = s.D_COURT_WARRANT_DISTRICT_GCV,
 t.D_COURT_WARRANT_ALLOCATED_TO_OTHER_FORCE_ID_GCV = s.D_COURT_WARRANT_ALLOCATED_TO_OTHER_FORCE_ID_GCV,
 t.D_COURT_WARRANT_ALLOCATED_TO_OTHER_FORCE_ID = s.D_COURT_WARRANT_ALLOCATED_TO_OTHER_FORCE_ID,
 t.D_COURT_WARRANT_WARRANT_REFERENCE = s.D_COURT_WARRANT_WARRANT_REFERENCE,
 t.D_COURT_WARRANT_UPDATE_DATE = s.D_COURT_WARRANT_UPDATE_DATE,
 t.D_COURT_WARRANT_UPDATE_TIME = s.D_COURT_WARRANT_UPDATE_TIME,
 t.D_COURT_WARRANT_DATE_RECEIVED = s.D_COURT_WARRANT_DATE_RECEIVED,
 t.D_COURT_WARRANT_DATE_ISSUED = s.D_COURT_WARRANT_DATE_ISSUED,
 t.D_COURT_WARRANT_WARRANT_TYPE_GCV = s.D_COURT_WARRANT_WARRANT_TYPE_GCV,
 t.D_COURT_WARRANT_CATEGORY = s.D_COURT_WARRANT_CATEGORY,
 t.D_COURT_WARRANT_STATUS = s.D_COURT_WARRANT_STATUS,
 t.D_COURT_WARRANT_RETURNED_TO_COURT = s.D_COURT_WARRANT_RETURNED_TO_COURT,
 t.D_COURT_WARRANT_BAILED_TO_DATE = s.D_COURT_WARRANT_BAILED_TO_DATE,
 t.D_COURT_WARRANT_SUBJECT_BAILED = s.D_COURT_WARRANT_SUBJECT_BAILED,
 t.D_COURT_WARRANT_ENTERED_BY = s.D_COURT_WARRANT_ENTERED_BY,
 t.D_COURT_WARRANT_WITHDRAWN = s.D_COURT_WARRANT_WITHDRAWN,
 t.D_COURT_WARRANT_DATE_COMPLETED = s.D_COURT_WARRANT_DATE_COMPLETED,
 t.D_COURT_WARRANT_TIME_COMPLETED = s.D_COURT_WARRANT_TIME_COMPLETED,
 t.D_COURT_WARRANT_OFFICER_IN_CHARGE = s.D_COURT_WARRANT_OFFICER_IN_CHARGE,
 t.D_COURT_WARRANT_OFFICER_IN_CHARGE_UNIT = s.D_COURT_WARRANT_OFFICER_IN_CHARGE_UNIT,
 t.D_COURT_WARRANT_OWNING_UNIT = s.D_COURT_WARRANT_OWNING_UNIT,
 t.D_COURT_WARRANT_TRIAL_MODE = s.D_COURT_WARRANT_TRIAL_MODE,
 t.D_COURT_WARRANT_PERSON_REF = s.D_COURT_WARRANT_PERSON_REF,
 t.D_COURT_WARRANT_LINK_TO_OBJECT_KEY = s.D_COURT_WARRANT_LINK_TO_OBJECT_KEY,
 t.D_COURT_WARRANT_EMPLOYEE_NO = s.D_COURT_WARRANT_EMPLOYEE_NO,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (D_COURT_WARRANT_OBJECT_REF, D_COURT_WARRANT_FORCE, D_COURT_WARRANT_BCU_GCV, D_COURT_WARRANT_DISTRICT_GCV, D_COURT_WARRANT_ALLOCATED_TO_OTHER_FORCE_ID_GCV, D_COURT_WARRANT_ALLOCATED_TO_OTHER_FORCE_ID, D_COURT_WARRANT_WARRANT_REFERENCE, D_COURT_WARRANT_UPDATE_DATE, D_COURT_WARRANT_UPDATE_TIME, D_COURT_WARRANT_DATE_RECEIVED, D_COURT_WARRANT_DATE_ISSUED, D_COURT_WARRANT_WARRANT_TYPE_GCV, D_COURT_WARRANT_CATEGORY, D_COURT_WARRANT_STATUS, D_COURT_WARRANT_RETURNED_TO_COURT, D_COURT_WARRANT_BAILED_TO_DATE, D_COURT_WARRANT_SUBJECT_BAILED, D_COURT_WARRANT_ENTERED_BY, D_COURT_WARRANT_WITHDRAWN, D_COURT_WARRANT_DATE_COMPLETED, D_COURT_WARRANT_TIME_COMPLETED, D_COURT_WARRANT_OFFICER_IN_CHARGE, D_COURT_WARRANT_OFFICER_IN_CHARGE_UNIT, D_COURT_WARRANT_OWNING_UNIT, D_COURT_WARRANT_TRIAL_MODE, D_COURT_WARRANT_PERSON_REF, D_COURT_WARRANT_LINK_TO_OBJECT_KEY, D_COURT_WARRANT_EMPLOYEE_NO, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.D_COURT_WARRANT_OBJECT_REF, s.D_COURT_WARRANT_FORCE, s.D_COURT_WARRANT_BCU_GCV, s.D_COURT_WARRANT_DISTRICT_GCV, s.D_COURT_WARRANT_ALLOCATED_TO_OTHER_FORCE_ID_GCV, s.D_COURT_WARRANT_ALLOCATED_TO_OTHER_FORCE_ID, s.D_COURT_WARRANT_WARRANT_REFERENCE, s.D_COURT_WARRANT_UPDATE_DATE, s.D_COURT_WARRANT_UPDATE_TIME, s.D_COURT_WARRANT_DATE_RECEIVED, s.D_COURT_WARRANT_DATE_ISSUED, s.D_COURT_WARRANT_WARRANT_TYPE_GCV, s.D_COURT_WARRANT_CATEGORY, s.D_COURT_WARRANT_STATUS, s.D_COURT_WARRANT_RETURNED_TO_COURT, s.D_COURT_WARRANT_BAILED_TO_DATE, s.D_COURT_WARRANT_SUBJECT_BAILED, s.D_COURT_WARRANT_ENTERED_BY, s.D_COURT_WARRANT_WITHDRAWN, s.D_COURT_WARRANT_DATE_COMPLETED, s.D_COURT_WARRANT_TIME_COMPLETED, s.D_COURT_WARRANT_OFFICER_IN_CHARGE, s.D_COURT_WARRANT_OFFICER_IN_CHARGE_UNIT, s.D_COURT_WARRANT_OWNING_UNIT, s.D_COURT_WARRANT_TRIAL_MODE, s.D_COURT_WARRANT_PERSON_REF, s.D_COURT_WARRANT_LINK_TO_OBJECT_KEY, s.D_COURT_WARRANT_EMPLOYEE_NO, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_court_warrant, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_court_warrant OUTPUT;
 SET @run_id_rprt_tbl_d_court_warrant = @table_name_rprt_tbl_d_court_warrant + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_court_warrant + N': ' + CAST(@rows_affected_rprt_tbl_d_court_warrant AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_court_warrant + N')';
 SET @sql_log_success_rprt_tbl_d_court_warrant =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_court_warrant,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_court_warrant,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_court_warrant,
 @rows = @rows_affected_rprt_tbl_d_court_warrant,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_court_warrant = N'rprt.tbl_d_court_warrant' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_court_warrant = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_court_warrant =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_court_warrant' + N' \n Message=' + @err_msg_rprt_tbl_d_court_warrant + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_court_warrant AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_court_warrant AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_court_warrant: ' + @err_msg_rprt_tbl_d_court_warrant + N' (run_id=' + @run_id_rprt_tbl_d_court_warrant + N')';
 SET @sql_log_error_rprt_tbl_d_court_warrant =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_court_warrant,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_court_warrant',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_court_warrant,
 @runid = @run_id_rprt_tbl_d_court_warrant,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #18: rprt.tbl_d_case SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_case NVARCHAR(255) = N'rprt.tbl_d_case';
DECLARE @rows_affected_rprt_tbl_d_case INT = 0;
DECLARE @run_id_rprt_tbl_d_case NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_case NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_case NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_case NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_case NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_case NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_case AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_case AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.D_CASE_ID = s.D_CASE_ID,
 t.LoadID = s.LoadID,
 t.D_CASE_START_DATE = s.D_CASE_START_DATE,
 t.D_CASE_END_DATE = s.D_CASE_END_DATE,
 t.D_CASE_LENGTH = s.D_CASE_LENGTH,
 t.D_CASE_TYPE = s.D_CASE_TYPE,
 t.D_CASE_OUTCOME = s.D_CASE_OUTCOME,
 t.D_CASE_CRIME_TYPE = s.D_CASE_CRIME_TYPE,
 t.D_CASE_PROCESSED = s.D_CASE_PROCESSED,
 t.D_CASE_DETAILS = s.D_CASE_DETAILS,
 t.D_CASE_HARM_SCORE = s.D_CASE_HARM_SCORE,
 t.D_CASE_CRIME_CATEGORY = s.D_CASE_CRIME_CATEGORY,
 t.D_CASE_HAS_SUSPECT = s.D_CASE_HAS_SUSPECT,
 t.D_CASE_HAS_VICTIM = s.D_CASE_HAS_VICTIM,
 t.D_CASE_RISK_LEVEL = s.D_CASE_RISK_LEVEL,
 t.D_CASE_HIGH_HARM = s.D_CASE_HIGH_HARM,
 t.D_CASE_CRIME_ID = s.D_CASE_CRIME_ID,
 t.D_CASE_OFFICER_ID = s.D_CASE_OFFICER_ID,
 t.D_CASE_PERSONNEL_EMPLOYEE_NO = s.D_CASE_PERSONNEL_EMPLOYEE_NO,
 t.D_CASE_REFERENCE = s.D_CASE_REFERENCE,
 t.D_CASE_ENTERED_IN_ERROR = s.D_CASE_ENTERED_IN_ERROR,
 t.D_CASE_NUM_DETENTION = s.D_CASE_NUM_DETENTION,
 t.D_CASE_NUM_VOL_ATTENDANCE = s.D_CASE_NUM_VOL_ATTENDANCE,
 t.D_STAFF_MOVE_ID = s.D_STAFF_MOVE_ID,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (D_CASE_ID, LoadID, D_CASE_START_DATE, D_CASE_END_DATE, D_CASE_LENGTH, D_CASE_TYPE, D_CASE_OUTCOME, D_CASE_CRIME_TYPE, D_CASE_PROCESSED, D_CASE_DETAILS, D_CASE_HARM_SCORE, D_CASE_CRIME_CATEGORY, D_CASE_HAS_SUSPECT, D_CASE_HAS_VICTIM, D_CASE_RISK_LEVEL, D_CASE_HIGH_HARM, D_CASE_CRIME_ID, D_CASE_OFFICER_ID, D_CASE_PERSONNEL_EMPLOYEE_NO, D_CASE_REFERENCE, D_CASE_ENTERED_IN_ERROR, D_CASE_NUM_DETENTION, D_CASE_NUM_VOL_ATTENDANCE, D_STAFF_MOVE_ID, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.D_CASE_ID, s.LoadID, s.D_CASE_START_DATE, s.D_CASE_END_DATE, s.D_CASE_LENGTH, s.D_CASE_TYPE, s.D_CASE_OUTCOME, s.D_CASE_CRIME_TYPE, s.D_CASE_PROCESSED, s.D_CASE_DETAILS, s.D_CASE_HARM_SCORE, s.D_CASE_CRIME_CATEGORY, s.D_CASE_HAS_SUSPECT, s.D_CASE_HAS_VICTIM, s.D_CASE_RISK_LEVEL, s.D_CASE_HIGH_HARM, s.D_CASE_CRIME_ID, s.D_CASE_OFFICER_ID, s.D_CASE_PERSONNEL_EMPLOYEE_NO, s.D_CASE_REFERENCE, s.D_CASE_ENTERED_IN_ERROR, s.D_CASE_NUM_DETENTION, s.D_CASE_NUM_VOL_ATTENDANCE, s.D_STAFF_MOVE_ID, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_case, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_case OUTPUT;
 SET @run_id_rprt_tbl_d_case = @table_name_rprt_tbl_d_case + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_case + N': ' + CAST(@rows_affected_rprt_tbl_d_case AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_case + N')';
 SET @sql_log_success_rprt_tbl_d_case =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_case,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_case,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_case,
 @rows = @rows_affected_rprt_tbl_d_case,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_case = N'rprt.tbl_d_case' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_case = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_case =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_case' + N' \n Message=' + @err_msg_rprt_tbl_d_case + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_case AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_case AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_case: ' + @err_msg_rprt_tbl_d_case + N' (run_id=' + @run_id_rprt_tbl_d_case + N')';
 SET @sql_log_error_rprt_tbl_d_case =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_case,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_case',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_case,
 @runid = @run_id_rprt_tbl_d_case,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #19: rprt.tbl_d_vcc SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_vcc NVARCHAR(255) = N'rprt.tbl_d_vcc';
DECLARE @rows_affected_rprt_tbl_d_vcc INT = 0;
DECLARE @run_id_rprt_tbl_d_vcc NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_vcc NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_vcc NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_vcc NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_vcc NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_vcc NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_vcc AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_vcc AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.D_VCC_ID = s.D_VCC_ID,
 t.LoadID = s.LoadID,
 t.D_VCC_CRIME_REF_NO = s.D_VCC_CRIME_REF_NO,
 t.D_VCC_OFFICER_ID = s.D_VCC_OFFICER_ID,
 t.D_VCC_LINKED_CRIME_REF_FLAG = s.D_VCC_LINKED_CRIME_REF_FLAG,
 t.D_VCC_CREATION_DATE_TIME = s.D_VCC_CREATION_DATE_TIME,
 t.D_VCC_CRIME_TYPE = s.D_VCC_CRIME_TYPE,
 t.D_VCC_CRIME_SUB_TYPE = s.D_VCC_CRIME_SUB_TYPE,
 t.D_VCC_OFFENCE_DESCRIPTION = s.D_VCC_OFFENCE_DESCRIPTION,
 t.D_VCC_LAST_CONTACT_MADE = s.D_VCC_LAST_CONTACT_MADE,
 t.D_VCC_NEXT_CONTACT_DUE = s.D_VCC_NEXT_CONTACT_DUE,
 t.D_VCC_UPDATE_FREQUENCY = s.D_VCC_UPDATE_FREQUENCY,
 t.D_VCC_OPT_OUT = s.D_VCC_OPT_OUT,
 t.D_VCC_LIVE_HISTORIC = s.D_VCC_LIVE_HISTORIC,
 t.D_VCC_HATE_INDICATOR = s.D_VCC_HATE_INDICATOR,
 t.D_VCC_DA_INCIDENT = s.D_VCC_DA_INCIDENT,
 t.D_VCC_UPDATE_METHOD = s.D_VCC_UPDATE_METHOD,
 t.D_VCC_LATEST_EVENT = s.D_VCC_LATEST_EVENT,
 t.D_VCC_LATEST_EVENT_DATE = s.D_VCC_LATEST_EVENT_DATE,
 t.D_VCC_CLOSED_DATE = s.D_VCC_CLOSED_DATE,
 t.D_VCC_VCC_CATEGORY_CHOSEN = s.D_VCC_VCC_CATEGORY_CHOSEN,
 t.D_VCC_RESTRICTED_FLAG = s.D_VCC_RESTRICTED_FLAG,
 t.D_VCC_SUGGESTED_ACTION = s.D_VCC_SUGGESTED_ACTION,
 t.D_VCC_OVERDUE_VCC = s.D_VCC_OVERDUE_VCC,
 t.D_VCC_OVERDUE_DAYS = s.D_VCC_OVERDUE_DAYS,
 t.D_VCC_DRIVERS_MISSED = s.D_VCC_DRIVERS_MISSED,
 t.D_VCC_DAYS_UNTIL_NEXT_UPDATE = s.D_VCC_DAYS_UNTIL_NEXT_UPDATE,
 t.D_VCC_UPCOMING_FLAG = s.D_VCC_UPCOMING_FLAG,
 t.D_VCC_1ST_OFFICER_ALLOCATED = s.D_VCC_1ST_OFFICER_ALLOCATED,
 t.FK_D_ATHENA_GEO_ID = s.FK_D_ATHENA_GEO_ID,
 t.D_VICTIM_TYPE = s.D_VICTIM_TYPE,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (D_VCC_ID, LoadID, D_VCC_CRIME_REF_NO, D_VCC_OFFICER_ID, D_VCC_LINKED_CRIME_REF_FLAG, D_VCC_CREATION_DATE_TIME, D_VCC_CRIME_TYPE, D_VCC_CRIME_SUB_TYPE, D_VCC_OFFENCE_DESCRIPTION, D_VCC_LAST_CONTACT_MADE, D_VCC_NEXT_CONTACT_DUE, D_VCC_UPDATE_FREQUENCY, D_VCC_OPT_OUT, D_VCC_LIVE_HISTORIC, D_VCC_HATE_INDICATOR, D_VCC_DA_INCIDENT, D_VCC_UPDATE_METHOD, D_VCC_LATEST_EVENT, D_VCC_LATEST_EVENT_DATE, D_VCC_CLOSED_DATE, D_VCC_VCC_CATEGORY_CHOSEN, D_VCC_RESTRICTED_FLAG, D_VCC_SUGGESTED_ACTION, D_VCC_OVERDUE_VCC, D_VCC_OVERDUE_DAYS, D_VCC_DRIVERS_MISSED, D_VCC_DAYS_UNTIL_NEXT_UPDATE, D_VCC_UPCOMING_FLAG, D_VCC_1ST_OFFICER_ALLOCATED, FK_D_ATHENA_GEO_ID, D_VICTIM_TYPE, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.D_VCC_ID, s.LoadID, s.D_VCC_CRIME_REF_NO, s.D_VCC_OFFICER_ID, s.D_VCC_LINKED_CRIME_REF_FLAG, s.D_VCC_CREATION_DATE_TIME, s.D_VCC_CRIME_TYPE, s.D_VCC_CRIME_SUB_TYPE, s.D_VCC_OFFENCE_DESCRIPTION, s.D_VCC_LAST_CONTACT_MADE, s.D_VCC_NEXT_CONTACT_DUE, s.D_VCC_UPDATE_FREQUENCY, s.D_VCC_OPT_OUT, s.D_VCC_LIVE_HISTORIC, s.D_VCC_HATE_INDICATOR, s.D_VCC_DA_INCIDENT, s.D_VCC_UPDATE_METHOD, s.D_VCC_LATEST_EVENT, s.D_VCC_LATEST_EVENT_DATE, s.D_VCC_CLOSED_DATE, s.D_VCC_VCC_CATEGORY_CHOSEN, s.D_VCC_RESTRICTED_FLAG, s.D_VCC_SUGGESTED_ACTION, s.D_VCC_OVERDUE_VCC, s.D_VCC_OVERDUE_DAYS, s.D_VCC_DRIVERS_MISSED, s.D_VCC_DAYS_UNTIL_NEXT_UPDATE, s.D_VCC_UPCOMING_FLAG, s.D_VCC_1ST_OFFICER_ALLOCATED, s.FK_D_ATHENA_GEO_ID, s.D_VICTIM_TYPE, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_vcc, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_vcc OUTPUT;
 SET @run_id_rprt_tbl_d_vcc = @table_name_rprt_tbl_d_vcc + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_vcc + N': ' + CAST(@rows_affected_rprt_tbl_d_vcc AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_vcc + N')';
 SET @sql_log_success_rprt_tbl_d_vcc =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_vcc,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_vcc,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_vcc,
 @rows = @rows_affected_rprt_tbl_d_vcc,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_vcc = N'rprt.tbl_d_vcc' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_vcc = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_vcc =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_vcc' + N' \n Message=' + @err_msg_rprt_tbl_d_vcc + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_vcc AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_vcc AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_vcc: ' + @err_msg_rprt_tbl_d_vcc + N' (run_id=' + @run_id_rprt_tbl_d_vcc + N')';
 SET @sql_log_error_rprt_tbl_d_vcc =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_vcc,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_vcc',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_vcc,
 @runid = @run_id_rprt_tbl_d_vcc,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #20: rprt.tbl_d_vcc_history SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_vcc_history NVARCHAR(255) = N'rprt.tbl_d_vcc_history';
DECLARE @rows_affected_rprt_tbl_d_vcc_history INT = 0;
DECLARE @run_id_rprt_tbl_d_vcc_history NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_vcc_history NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_vcc_history NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_vcc_history NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_vcc_history NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_vcc_history NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 ;WITH s_src AS (
 SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_vcc_history AS s
 ),
 s_dedup AS (
 SELECT s_src.*,
 ROW_NUMBER() OVER (
 PARTITION BY s_src.OA_RECORDID
 ORDER BY s_src.OA_REC_CREATED_DATE DESC, s_src.OA_VERSION DESC, s_src.OA_REC_PROCESSED_DATE DESC
 ) AS rn
 FROM s_src
 )
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_vcc_history AS t
 USING (SELECT * FROM s_dedup WHERE rn = 1) AS s
 ON t.OA_RECORDID = s.OA_RECORDID
 WHEN MATCHED THEN
 UPDATE SET
 t.D_VCC_HISTORY_ID = s.D_VCC_HISTORY_ID,
 t.LoadID = s.LoadID,
 t.FK_D_VCC_ID = s.FK_D_VCC_ID,
 t.FK_D_VCC_DUE_DATE_ID = s.FK_D_VCC_DUE_DATE_ID,
 t.D_VCC_OFFICER_ID = s.D_VCC_OFFICER_ID,
 t.D_VCC_CONTACT_DUE = s.D_VCC_CONTACT_DUE,
 t.D_VCC_UPDATE_FREQUENCY = s.D_VCC_UPDATE_FREQUENCY,
 t.D_VCC_MISSED = s.D_VCC_MISSED,
 t.D_VCC_OVERDUE_DAYS = s.D_VCC_OVERDUE_DAYS,
 t.D_VCC_DRIVERS_MISSED = s.D_VCC_DRIVERS_MISSED,
 t.D_VCC_OPT_OUT = s.D_VCC_OPT_OUT,
 t.D_STAFF_MOVE_ID = s.D_STAFF_MOVE_ID,
 t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE,
 t.OA_REC_CREATED_DATE = s.OA_REC_CREATED_DATE,
 t.OA_REC_END_DATE = s.OA_REC_END_DATE,
 t.OA_IS_ACTIVE = s.OA_IS_ACTIVE,
 t.OA_VERSION = s.OA_VERSION
 WHEN NOT MATCHED THEN
 INSERT (D_VCC_HISTORY_ID, LoadID, FK_D_VCC_ID, FK_D_VCC_DUE_DATE_ID, D_VCC_OFFICER_ID, D_VCC_CONTACT_DUE, D_VCC_UPDATE_FREQUENCY, D_VCC_MISSED, D_VCC_OVERDUE_DAYS, D_VCC_DRIVERS_MISSED, D_VCC_OPT_OUT, D_STAFF_MOVE_ID, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
 VALUES (s.D_VCC_HISTORY_ID, s.LoadID, s.FK_D_VCC_ID, s.FK_D_VCC_DUE_DATE_ID, s.D_VCC_OFFICER_ID, s.D_VCC_CONTACT_DUE, s.D_VCC_UPDATE_FREQUENCY, s.D_VCC_MISSED, s.D_VCC_OVERDUE_DAYS, s.D_VCC_DRIVERS_MISSED, s.D_VCC_OPT_OUT, s.D_STAFF_MOVE_ID, s.OA_REC_PROCESSED_DATE, s.OA_REC_CREATED_DATE, s.OA_REC_END_DATE, s.OA_IS_ACTIVE, s.OA_VERSION, s.OA_RECORDID);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_vcc_history, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_vcc_history OUTPUT;
 SET @run_id_rprt_tbl_d_vcc_history = @table_name_rprt_tbl_d_vcc_history + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_vcc_history + N': ' + CAST(@rows_affected_rprt_tbl_d_vcc_history AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_vcc_history + N')';
 SET @sql_log_success_rprt_tbl_d_vcc_history =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_vcc_history,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_vcc_history,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_vcc_history,
 @rows = @rows_affected_rprt_tbl_d_vcc_history,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_vcc_history = N'rprt.tbl_d_vcc_history' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_vcc_history = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_vcc_history =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_vcc_history' + N' \n Message=' + @err_msg_rprt_tbl_d_vcc_history + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_vcc_history AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_vcc_history AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_vcc_history: ' + @err_msg_rprt_tbl_d_vcc_history + N' (run_id=' + @run_id_rprt_tbl_d_vcc_history + N')';
 SET @sql_log_error_rprt_tbl_d_vcc_history =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_vcc_history,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_vcc_history',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_vcc_history,
 @runid = @run_id_rprt_tbl_d_vcc_history,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ==================================================================
 MERGE #21: rprt.tbl_d_eq_date SOURCE = 'Athena'
 ================================================================== */
DECLARE @table_name_rprt_tbl_d_eq_date NVARCHAR(255) = N'rprt.tbl_d_eq_date';
DECLARE @rows_affected_rprt_tbl_d_eq_date INT = 0;
DECLARE @run_id_rprt_tbl_d_eq_date NVARCHAR(1000);
DECLARE @err_msg_rprt_tbl_d_eq_date NVARCHAR(MAX);
DECLARE @err_details_rprt_tbl_d_eq_date NVARCHAR(MAX);
DECLARE @sql_log_success_rprt_tbl_d_eq_date NVARCHAR(MAX);
DECLARE @sql_log_error_rprt_tbl_d_eq_date NVARCHAR(MAX);

BEGIN TRY
 DECLARE @sql_rprt_tbl_d_eq_date NVARCHAR(MAX) = N'
BEGIN TRY
 SET NOCOUNT ON;
 MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_eq_date AS t
 USING ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_eq_date AS s
 ON t.ED_ID = s.ED_ID
 WHEN MATCHED THEN
 UPDATE SET
 t.Date = s.Date,
 t.Week = s.Week,
 t.DayName = s.DayName,
 t.Eq_Date = s.Eq_Date,
 t.Yr_Count = s.Yr_Count
 WHEN NOT MATCHED THEN
 INSERT (ED_ID, Date, Week, DayName, Eq_Date, Yr_Count)
 VALUES (s.ED_ID, s.Date, s.Week, s.DayName, s.Eq_Date, s.Yr_Count);
 SET @rows = @@ROWCOUNT;
END TRY
BEGIN CATCH
 DECLARE @msg NVARCHAR(MAX) = ERROR_MESSAGE();
 THROW 50001, @msg, 1;
END CATCH
';
 EXEC sp_executesql @sql_rprt_tbl_d_eq_date, N'@rows INT OUTPUT', @rows_affected_rprt_tbl_d_eq_date OUTPUT;
 SET @run_id_rprt_tbl_d_eq_date = @table_name_rprt_tbl_d_eq_date + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 PRINT N'COMPLETE - SUCCESS \n ' + @table_name_rprt_tbl_d_eq_date + N': ' + CAST(@rows_affected_rprt_tbl_d_eq_date AS NVARCHAR(20)) + N' rows affected (run_id=' + @run_id_rprt_tbl_d_eq_date + N')';
 SET @sql_log_success_rprt_tbl_d_eq_date =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 1, @folder);';
 EXEC sp_executesql
 @sql_log_success_rprt_tbl_d_eq_date,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = @table_name_rprt_tbl_d_eq_date,
 @st = N'COMPLETE - SUCCESS',
 @err = NULL,
 @runid = @run_id_rprt_tbl_d_eq_date,
 @rows = @rows_affected_rprt_tbl_d_eq_date,
 @src = @source,
 @folder = @runFolder;
END TRY
BEGIN CATCH
 SET @run_id_rprt_tbl_d_eq_date = N'rprt.tbl_d_eq_date' + N'_' + CONVERT(VARCHAR(8), SYSDATETIME(), 112) + N'-' + REPLACE(CONVERT(VARCHAR(8), SYSDATETIME(), 108), N':', N'');
 SET @err_msg_rprt_tbl_d_eq_date = ERROR_MESSAGE();
 SET @err_details_rprt_tbl_d_eq_date =
 N'Status=COMPLETE WITH ERROR' + N' \n Table=' + N'rprt.tbl_d_eq_date' + N' \n Message=' + @err_msg_rprt_tbl_d_eq_date + N' \n MergeSnippet=' +
 LEFT(N'WITH s_src AS (SELECT * FROM ' + QUOTENAME(@lh_db) + N'.rprt.tbl_d_eq_date AS s) MERGE INTO ' + QUOTENAME(@wh_db) + N'.rprt.tbl_d_eq_date AS t ...', 800)
 PRINT N'COMPLETE WITH ERROR \n rprt.tbl_d_eq_date: ' + @err_msg_rprt_tbl_d_eq_date + N' (run_id=' + @run_id_rprt_tbl_d_eq_date + N')';
 SET @sql_log_error_rprt_tbl_d_eq_date =
 N'INSERT INTO ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 (NOTEBOOK_NAME, STATUS, ERROR_SUMMARY, Updated_DateTime, RUN_ID, ROWS_AFFECTED, Source, Successful, FolderDateTime)
 VALUES (@nb, @st, @err, SYSDATETIME(), @runid, @rows, @src, 0, @folder);';
 EXEC sp_executesql
 @sql_log_error_rprt_tbl_d_eq_date,
 N'@nb nvarchar(255), @st nvarchar(50), @err nvarchar(max), @runid nvarchar(1000), @rows int, @src nvarchar(50), @folder varchar(14)',
 @nb = N'rprt.tbl_d_eq_date',
 @st = N'COMPLETE WITH ERROR',
 @err = @err_details_rprt_tbl_d_eq_date,
 @runid = @run_id_rprt_tbl_d_eq_date,
 @rows = 0,
 @src = @source,
 @folder = @runFolder;
END CATCH;

/* ============================================================ 
 Final consolidated grid for this cell (no table variables)
 ============================================================ */
DECLARE @sql_show NVARCHAR(MAX) =
 N'SELECT
 STATUS AS Status,
 NOTEBOOK_NAME AS TableName,
 ROWS_AFFECTED AS RowsAffected,
 RUN_ID AS RunId
 FROM ' + QUOTENAME(@wh_db) + N'.[ctrl].[tbl_DWLoadLog]
 WHERE FolderDateTime = @f
 ORDER BY TableName;';
EXEC sp_executesql
 @sql_show,
 N'@f varchar(14)',
 @f = @runFolder;

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse",
-- META   "frozen": false,
-- META   "editable": true
-- META }

-- MARKDOWN ********************

-- ###### **TEST**

-- CELL ********************

SELECT * FROM
-- DELETE
[WH_400_Gold_Test].[ctrl].[tbl_DWLoadLog]
WHERE NOTEBOOK_NAME LIKE ('rprt.tbl_d_%')
AND Successful = 0
ORDER BY 9 DESC

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse",
-- META   "frozen": true,
-- META   "editable": false
-- META }
