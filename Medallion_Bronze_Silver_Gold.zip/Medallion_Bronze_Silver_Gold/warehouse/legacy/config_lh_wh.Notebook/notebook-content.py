# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "42396a50-8b85-4951-9850-b36abfe2a28d",
# META       "default_lakehouse_name": "LH_300_Gold_Test",
# META       "default_lakehouse_workspace_id": "a3e4d0e6-6b32-498b-addc-1629a4b29a47",
# META       "known_lakehouses": [
# META         {
# META           "id": "42396a50-8b85-4951-9850-b36abfe2a28d"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# #### **WH CONFIG**

# CELL ********************

import com.microsoft.spark.fabric
from com.microsoft.spark.fabric import Constants
from concurrent.futures import ThreadPoolExecutor
import concurrent.futures
import time
from pyspark.sql import Row
from datetime import datetime
from pyspark.sql.functions import col
import sys

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# v1
def execute_warehouse_sql(sql_command, warehouse="WH_400_Gold_Test"):
    """Execute SQL in warehouse and return results"""
    try:
        return spark.read.synapsesql(warehouse).sql(sql_command)
    except Exception as e:
        raise Exception(f"SQL Execution Failed: {str(e)}")

def backup_foreign_keys(schema=None, warehouse="WH_400_Gold_Test"):
    """Backup foreign keys"""
    print("📋 Backing up foreign keys...")
    start = time.time()
    
    try:
        # Build SQL with optional schema parameter
        if schema:
            sql = f"EXEC backup_foreign_keys @schema_name = '{schema}'"
        else:
            sql = "EXEC backup_foreign_keys"
        
        result = execute_warehouse_sql(sql, warehouse)
        duration = time.time() - start
        print(f"✅ Foreign keys backed up ({duration:.1f}s)")
        return {"success": True, "duration": duration}
    except Exception as e:
        duration = time.time() - start
        print(f"⚠️  Backup warning: {str(e)[:100]} ({duration:.1f}s)")
        return {"success": False, "error": str(e), "duration": duration}

def drop_foreign_keys(dry_run=True, schema="rprt", warehouse="WH_400_Gold_Test"):
    """Drop foreign keys (dry_run=True for testing)"""
    mode = "DRY RUN" if dry_run else "EXECUTE"
    print(f"🗑️  Dropping foreign keys ({mode})...")
    start = time.time()
    
    try:
        # Pass debug flag and schema parameter
        debug_flag = 1 if dry_run else 0
        sql = f"EXEC drop_foreign_keys @debug = {debug_flag}, @schema_name = '{schema}'"
        
        result = execute_warehouse_sql(sql, warehouse)
        duration = time.time() - start
        
        if dry_run:
            print(f"✅ Dry run completed ({duration:.1f}s)")
        else:
            print(f"✅ Foreign keys dropped ({duration:.1f}s)")
        
        return {"success": True, "dry_run": dry_run, "duration": duration}
    except Exception as e:
        duration = time.time() - start
        print(f"❌ Drop failed: {str(e)[:100]} ({duration:.1f}s)")
        return {"success": False, "error": str(e), "duration": duration}

def restore_foreign_keys(dry_run=False, schema=None, warehouse="WH_400_Gold_Test"):
    """Restore foreign keys"""
    mode = "DRY RUN" if dry_run else "EXECUTE"
    print(f"🔧 Restoring foreign keys ({mode})...")
    start = time.time()
    
    try:
        # Pass debug flag and optional schema parameter
        debug_flag = 1 if dry_run else 0
        if schema:
            sql = f"EXEC restore_foreign_keys @debug = {debug_flag}, @schema_name = '{schema}'"
        else:
            sql = f"EXEC restore_foreign_keys @debug = {debug_flag}"
        
        result = execute_warehouse_sql(sql, warehouse)
        duration = time.time() - start
        
        if dry_run:
            print(f"✅ Dry run completed ({duration:.1f}s)")
        else:
            print(f"✅ Foreign keys restored ({duration:.1f}s)")
        
        return {"success": True, "dry_run": dry_run, "duration": duration}
    except Exception as e:
        duration = time.time() - start
        print(f"❌ Restore failed: {str(e)[:100]} ({duration:.1f}s)")
        return {"success": False, "error": str(e), "duration": duration}

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

def execute_warehouse_sql(sql_command, warehouse="WH_400_Gold_Test"):
    """Execute SQL in warehouse and return results"""
    try:
        # Set warehouse context first
        spark.sql(f"USE WAREHOUSE {warehouse}")
        # Execute the SQL command
        return spark.sql(sql_command)
    except Exception as e:
        raise Exception(f"SQL Execution Failed: {str(e)}")

def backup_foreign_keys(schema=None, warehouse="WH_400_Gold_Test"):
    """Backup foreign keys"""
    print("📋 Backing up foreign keys...")
    start = time.time()
    
    try:
        # Build SQL with optional schema parameter
        if schema:
            sql = f"EXEC backup_foreign_keys @schema_name = '{schema}'"
        else:
            sql = "EXEC backup_foreign_keys"
        
        result = execute_warehouse_sql(sql, warehouse)
        duration = time.time() - start
        print(f"✅ Foreign keys backed up ({duration:.1f}s)")
        return {"success": True, "duration": duration}
    except Exception as e:
        duration = time.time() - start
        print(f"⚠️  Backup warning: {str(e)[:100]} ({duration:.1f}s)")
        return {"success": False, "error": str(e), "duration": duration}

def drop_foreign_keys(dry_run=True, schema="rprt", warehouse="WH_400_Gold_Test"):
    """Drop foreign keys (dry_run=True for testing)"""
    mode = "DRY RUN" if dry_run else "EXECUTE"
    print(f"🗑️  Dropping foreign keys ({mode})...")
    start = time.time()
    
    try:
        # Pass debug flag and schema parameter
        debug_flag = 1 if dry_run else 0
        sql = f"EXEC drop_foreign_keys @debug = {debug_flag}, @schema_name = '{schema}'"
        
        result = execute_warehouse_sql(sql, warehouse)
        duration = time.time() - start
        
        if dry_run:
            print(f"✅ Dry run completed ({duration:.1f}s)")
        else:
            print(f"✅ Foreign keys dropped ({duration:.1f}s)")
        
        return {"success": True, "dry_run": dry_run, "duration": duration}
    except Exception as e:
        duration = time.time() - start
        print(f"❌ Drop failed: {str(e)[:100]} ({duration:.1f}s)")
        return {"success": False, "error": str(e), "duration": duration}

def restore_foreign_keys(dry_run=False, schema=None, warehouse="WH_400_Gold_Test"):
    """Restore foreign keys"""
    mode = "DRY RUN" if dry_run else "EXECUTE"
    print(f"🔧 Restoring foreign keys ({mode})...")
    start = time.time()
    
    try:
        # Pass debug flag and optional schema parameter
        debug_flag = 1 if dry_run else 0
        if schema:
            sql = f"EXEC restore_foreign_keys @debug = {debug_flag}, @schema_name = '{schema}'"
        else:
            sql = f"EXEC restore_foreign_keys @debug = {debug_flag}"
        
        result = execute_warehouse_sql(sql, warehouse)
        duration = time.time() - start
        
        if dry_run:
            print(f"✅ Dry run completed ({duration:.1f}s)")
        else:
            print(f"✅ Foreign keys restored ({duration:.1f}s)")
        
        return {"success": True, "dry_run": dry_run, "duration": duration}
    except Exception as e:
        duration = time.time() - start
        print(f"❌ Restore failed: {str(e)[:100]} ({duration:.1f}s)")
        return {"success": False, "error": str(e), "duration": duration}

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

# v3

def backup_foreign_keys(schema=None):
    """Backup foreign keys - SIMPLE VERSION"""
    print("📋 Backing up foreign keys...")
    start = time.time()
    
    try:
        # Build the SQL command
        if schema:
            sql = f"CALL backup_foreign_keys('{schema}')"
            # sql = f"SELECT * FROM backup_foreign_keys {schema}"
            # sql = f"CALL backup_foreign_keys @schema_name = '{schema}'"
        else:
            sql = "SELECT * FROM backup_foreign_keys"
            # sql = "CALL backup_foreign_keys"
        
        # Execute it directly with spark.sql
        spark.sql(sql)
        duration = time.time() - start
        print(f"✅ Foreign keys backed up ({duration:.1f}s)")
        return {"success": True, "duration": duration}
    except Exception as e:
        duration = time.time() - start
        print(f"❌ Backup failed: {str(e)[:100]} ({duration:.1f}s)")
        return {"success": False, "error": str(e), "duration": duration}

def drop_foreign_keys(dry_run=True, schema="rprt"):
    """Drop foreign keys - SIMPLE VERSION"""
    mode = "DRY RUN" if dry_run else "EXECUTE"
    print(f"🗑️  Dropping foreign keys ({mode})...")
    start = time.time()
    
    try:
        debug_flag = 1 if dry_run else 0
        sql = f"CALL drop_foreign_keys @debug = {debug_flag}, @schema_name = '{schema}'"
        
        spark.sql(sql)
        duration = time.time() - start
        
        if dry_run:
            print(f"✅ Dry run completed ({duration:.1f}s)")
        else:
            print(f"✅ Foreign keys dropped ({duration:.1f}s)")
        
        return {"success": True, "dry_run": dry_run, "duration": duration}
    except Exception as e:
        duration = time.time() - start
        print(f"❌ Drop failed: {str(e)[:100]} ({duration:.1f}s)")
        return {"success": False, "error": str(e), "duration": duration}

def restore_foreign_keys(schema=None):
    """Restore foreign keys - SIMPLE VERSION"""
    print(f"🔧 Restoring foreign keys...")
    start = time.time()
    
    try:
        if schema:
            sql = f"CALL restore_foreign_keys @schema_name = '{schema}'"
        else:
            sql = "CALL restore_foreign_keys"
        
        spark.sql(sql)
        duration = time.time() - start
        print(f"✅ Foreign keys restored ({duration:.1f}s)")
        return {"success": True, "duration": duration}
    except Exception as e:
        duration = time.time() - start
        print(f"❌ Restore failed: {str(e)[:100]} ({duration:.1f}s)")
        return {"success": False, "error": str(e), "duration": duration}

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

def execute_warehouse_sql(sql_command):
    """Execute SQL using spark.read.synapsesql with table reference"""
    try:
        # Method 1: Try as a query
        return spark.read.format("synapsesql") \
            .option("query", sql_command) \
            .load()
    except:
        # Method 2: Try direct spark.sql with CALL
        return spark.sql(sql_command)

def backup_foreign_keys(schema="rprt"):
    print(f"📋 Backing up foreign keys for schema: {schema}")
    
    # Try both EXEC and CALL syntax
    sql_attempts = [
        f"CALL backup_foreign_keys('{schema}')",  # Spark SQL syntax
        f"EXEC backup_foreign_keys @schema_name = '{schema}'",  # T-SQL syntax
    ]
    
    for sql in sql_attempts:
        print(f"Trying: {sql}")
        try:
            result = execute_warehouse_sql(sql)
            print(f"✅ Success with: {sql}")
            if result:
                result.show()
            return {"success": True}
        except Exception as e:
            print(f"❌ Failed: {str(e)[:80]}")
    
    return {"success": False, "error": "All syntax attempts failed"}

backup_foreign_keys("rprt")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# # Basic usage - uses current schema
# backup_foreign_keys(warehouse="WH_400_Gold_Test")

# # With specific schema
# backup_foreign_keys(schema="rprt", warehouse="WH_400_Gold_Test")

# # Dry run drop (just shows what would be dropped)
# drop_foreign_keys(dry_run=True, schema="rprt", warehouse="WH_400_Gold_Test")

# # Actual drop
# drop_foreign_keys(dry_run=False, schema="rprt", warehouse="WH_400_Gold_Test")

# # Dry run restore (just shows what would be restored)
# restore_foreign_keys(dry_run=True, schema="rprt", warehouse="WH_400_Gold_Test")

# # Actual restore
# restore_foreign_keys(dry_run=False, schema="rprt", warehouse="WH_400_Gold_Test")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Sync with specific table pattern across multiple schemas
fnc_cdc_sync(
    schemas=["rprt", "calc"], #["*"]
    table_pattern=["tbl_f_*", "tbl_b_*", "tbl_d_*"],  # Only fact/b tables
    warehouse="WH_400_Gold_Test"
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

# # Default - sync all tables in mpc, rprt, dbo schemas
# fnc_cdc_sync()

# # Sync specific schemas
# fnc_cdc_sync(schemas=["rprt", "calc"])

# # Sync single schema (backward compatible)
# fnc_cdc_sync(schemas="mpc")

# # Sync with specific table pattern across multiple schemas
# fnc_cdc_sync(
#     schemas=["dbo", "rprt", "calc"],
#     table_pattern="tbl_f_*",  # Only fact tables
#     warehouse="WH_400_Gold_Prod"
# )

# # Sync all tables in specific schemas with more workers
# fnc_cdc_sync(
#     schemas=["rprt", "calc"],
#     table_pattern="*",
#     max_workers=15
# )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Parallel Run: Original - working just 3 files failing. 
def fnc_cdc_sync(warehouse=None, schemas=None, table_pattern=None, max_workers=10):
    """Smart CDC sync that handles foreign key constraints with parallel execution for multiple schemas and table patterns"""
    
    # Set sensible defaults that can be easily overridden
    warehouse = warehouse or "WH_400_Gold_Test"
    schemas = schemas or ["mpc", "rprt", "dbo"]  # Support multiple schemas
    table_pattern = table_pattern or ["*"]  # Default to all tables
    
    # Ensure inputs are always lists for consistent processing
    if isinstance(schemas, str):
        schemas = [schemas]
    if isinstance(table_pattern, str):
        table_pattern = [table_pattern]

    def safe_table_sync(schema, table, source_df, has_cdc, target_exists, target_count, warehouse):
        """Safe table sync with retry logic for foreign key constraints"""
        from pyspark.sql.functions import col
        max_retries = 2
        
        for attempt in range(max_retries):
            try:
                if not has_cdc:
                    return _handle_non_cdc_table(schema, table, source_df, source_df.count(), target_exists, target_count, warehouse)
                else:
                    return _handle_cdc_table(schema, table, source_df, source_df.count(), target_exists, target_count, warehouse)
                    
            except Exception as e:
                error_msg = str(e)
                if ("FOREIGN KEY" in error_msg or "truncate" in error_msg.lower()) and attempt < max_retries - 1:
                    print(f"⚠️  Foreign key constraint detected for {schema}.{table}, retrying with DELETE approach (attempt {attempt + 1})...")
                    
                    # Force use of DELETE approach on retry
                    if not has_cdc:
                        # For non-CDC tables: DELETE + APPEND
                        source_count = source_df.count()
                        spark.sql(f"DELETE FROM {warehouse}.{schema}.{table}")
                        source_df.write.mode("append").synapsesql(f"{warehouse}.{schema}.{table}")
                        return True, f"📦 Refreshed with DELETE fallback ({source_count} records)", (source_count, source_count, 0, source_count)
                    else:
                        # For CDC tables: DELETE + APPEND active records only
                        source_active = source_df.filter(col("OA_IS_ACTIVE") == 1)
                        source_active_count = source_active.count()
                        spark.sql(f"DELETE FROM {warehouse}.{schema}.{table}")
                        source_active.write.mode("append").synapsesql(f"{warehouse}.{schema}.{table}")
                        return True, f"✅ Refreshed with DELETE fallback ({source_active_count} active records)", (source_active_count, source_active_count, 0, source_active_count)
                else:
                    # Re-raise the exception if not a foreign key error or out of retries
                    raise e

    def sync_single_table(schema, table):
        try:
            start_time = time.time()
            print(f"🏁 Starting: {schema}.{table} ....")
            
            # Read source data from Lakehouse
            source_df = spark.read.table(f"{schema}.{table}")
            source_cols = source_df.columns
            source_count = source_df.count()

            # Check if target table exists
            try:
                target_df = spark.read.synapsesql(f"{warehouse}.{schema}.{table}")
                target_count = target_df.count()
                target_exists = True
            except:
                target_exists = False
                target_count = 0

            # Check CDC capability
            has_cdc = all(col in source_cols for col in ['OA_RECORDID', 'OA_IS_ACTIVE', 'OA_REC_PROCESS_DATETIME'])
            
            # Use safe table sync with retry logic
            result = safe_table_sync(schema, table, source_df, has_cdc, target_exists, target_count, warehouse)
            
            duration = time.time() - start_time
            print(f"✅ Success: {schema}.{table} ({duration:.1f}s)")
            return True, result[1], result[2]
            
        except Exception as e:
            duration = time.time() - start_time
            print(f"❌ Failed: {schema}.{table} - {str(e)} ({duration:.1f}s)")
            return False, f"❌ {schema}.{table}: {str(e)}", (0, 0, 0, 0)

    def _handle_non_cdc_table(schema, table, source_df, source_count, target_exists, target_count, warehouse):
        """Handle non-CDC tables - use DELETE to avoid foreign key constraints"""
        if not target_exists:
            # Create new table
            source_df.write.mode("overwrite").synapsesql(f"{warehouse}.{schema}.{table}")
            return True, f"📦 Created ({source_count} records)", (source_count, source_count, 0, source_count)
        
        elif source_count != target_count:
            # Always use DELETE instead of TRUNCATE to avoid foreign key constraint issues
            try:
                spark.sql(f"DELETE FROM {warehouse}.{schema}.{table}")
                source_df.write.mode("append").synapsesql(f"{warehouse}.{schema}.{table}")
                return True, f"📦 Refreshed with DELETE ({source_count} records, was {target_count})", (source_count, source_count, 0, source_count)
            except Exception as delete_error:
                # If DELETE fails, use overwrite as fallback
                source_df.write.mode("overwrite").synapsesql(f"{warehouse}.{schema}.{table}")
                return True, f"📦 Refreshed with overwrite ({source_count} records)", (source_count, source_count, 0, source_count)
        
        else:
            return True, f"✅ No changes ({source_count} records)", (source_count, 0, 0, 0)

    def _handle_cdc_table(schema, table, source_df, source_count, target_exists, target_count, warehouse):
        """Handle CDC tables with incremental sync logic"""
        from pyspark.sql.functions import col

        # Get active records from source
        source_active = source_df.filter(col("OA_IS_ACTIVE") == 1)
        source_active_count = source_active.count()

        if not target_exists:
            # Initial sync - create table with active records only
            source_active.write.mode("overwrite").synapsesql(f"{warehouse}.{schema}.{table}")
            return True, f"✅ Initial sync ({source_active_count} active records)", (source_active_count, source_active_count, 0, source_active_count)

        # Get latest timestamp from target
        try:
            target_time_df = spark.sql(f"SELECT MAX(OA_REC_PROCESS_DATETIME) as max_time FROM {warehouse}.{schema}.{table}")
            last_sync_time = target_time_df.collect()[0]['max_time']
        except:
            last_sync_time = None

        if last_sync_time:
            # Incremental sync - only process new/changed records
            new_records = source_active.filter(col("OA_REC_PROCESS_DATETIME") > last_sync_time)
            new_count = new_records.count()

            if new_count > 0:
                # Handle updates - use targeted DELETE for specific records
                record_ids = [str(r.OA_RECORDID) for r in new_records.select("OA_RECORDID").distinct().collect()]
                
                if record_ids:
                    ids_str = "','".join(record_ids)
                    try:
                        # Delete existing records that will be updated
                        spark.sql(f"DELETE FROM {warehouse}.{schema}.{table} WHERE OA_RECORDID IN ('{ids_str}')")
                        # Insert updated records
                        new_records.write.mode("append").synapsesql(f"{warehouse}.{schema}.{table}")
                        return True, f"✅ {new_count} updated records", (new_count, 0, new_count, 0)
                    
                    except Exception as e:
                        # If incremental update fails, fall back to full refresh
                        print(f"⚠️  Incremental update failed for {schema}.{table}, falling back to full refresh: {str(e)}")
                        source_active.write.mode("overwrite").synapsesql(f"{warehouse}.{schema}.{table}")
                        return True, f"✅ Full refresh ({source_active_count} active records)", (source_active_count, source_active_count, 0, source_active_count)
            else:
                return True, f"✅ No changes ({source_active_count} active records)", (0, 0, 0, 0)
        else:
            # No timestamp found - do full refresh
            source_active.write.mode("overwrite").synapsesql(f"{warehouse}.{schema}.{table}")
            return True, f"✅ Re-synced ({source_active_count} active records)", (source_active_count, source_active_count, 0, source_active_count)

    # Collect all tables from all schemas and all patterns
    all_tables = []
    for schema in schemas:
        schema_tables = []
        for pattern in table_pattern:
            try:
                tables = [r.tableName for r in spark.sql(f"SHOW TABLES IN {schema} LIKE '{pattern}'").collect()]
                schema_tables.extend([(schema, table) for table in tables])
                print(f"📋 Found {len(tables)} tables in schema '{schema}' with pattern '{pattern}'")
            except Exception as e:
                print(f"⚠️ Could not access schema '{schema}' with pattern '{pattern}': {str(e)}")
        
        # Remove duplicates (in case patterns overlap)
        schema_tables = list(set(schema_tables))
        all_tables.extend(schema_tables)

    if not all_tables:
        print("❌ No tables found to sync!")
        return {}

    print(f"🔄 Smart CDC sync for {len(all_tables)} tables across {len(schemas)} schemas with {len(table_pattern)} patterns -> {warehouse}...")

    # Execute with concurrent workers
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(sync_single_table, schema, table): (schema, table)
            for schema, table in all_tables
        }
        
        results = {
            futures[future]: future.result()
            for future in concurrent.futures.as_completed(futures)
        }

    # Print final summary
    print(f"\n=== CDC SYNC RESULTS ({len(schemas)} schemas, {len(table_pattern)} patterns -> {warehouse}) ===")
    
    # Group results by schema for better readability
    for schema in schemas:
        schema_results = {f"{s}.{t}": result for (s, t), result in results.items() if s == schema}
        if schema_results:
            print(f"\n--- Schema: {schema} ---")
            for table_key, (success, message, stats) in schema_results.items():
                if success:
                    print(f"  {table_key}: {message} - SuccessCount: {stats[0]}, AffectedRows: {stats[1]}, UpdatedRows: {stats[2]}, InsertedRows: {stats[3]}")
                else:
                    print(f"  {table_key}: {message}")

    print(f"\nALL TABLES SYNC COMPLETED across {len(schemas)} schemas with {len(table_pattern)} patterns\n")
    return results

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": true
# META }

# MARKDOWN ********************

# ###### Logging

# CELL ********************

# Config_Notebook_Logger
notebook_name = "notebookName from Parameter"
run_id = mssparkutils.env.getJobId()
all_errors = []

print(f"📝 Starting notebook logging for: {notebook_name}")
print(f"🏃 Run ID: {run_id}")

def capture_error(msg):
    """Capture error messages without stopping execution"""
    all_errors.append(msg)
    print(f"❌ CAPTURED ERROR: {msg}")
    # print(f"🔍 DEBUG: Total errors captured so far: {len(all_errors)}")

def finalise_notebook_logging():
    """Finalize logging and exit - call this at the END of your notebook"""
    # print(f"🔍 DEBUG: Starting finalise_notebook_logging()")
    # print(f"🔍 DEBUG: All errors: {all_errors}")
    
    # Determine final status
    if any("NOTEBOOK CRASHED" in error for error in all_errors):
        status = "FAILED"
    elif all_errors:
        status = "COMPLETED_WITH_ERRORS"
    else:
        status = "SUCCESS"
    
    # print(f"🔍 DEBUG: Determined status: {status}")
    
    # Create error summary
    error_summary = " | ".join(all_errors)[:2000] if all_errors else None
    # print(f"🔍 DEBUG: Error summary: {error_summary}")
    
    # Log to existing monitoring table in ctlr schema
    try:
        # print("🔍 DEBUG: Attempting to write to table...")
        
        if error_summary:
            # Escape single quotes for SQL
            error_summary_escaped = error_summary.replace("'", "''")
            insert_sql = f"""
            INSERT INTO ctlr.notebook_process_logs 
            VALUES ('{notebook_name}', '{status}', '{error_summary_escaped}', CURRENT_TIMESTAMP, '{run_id}')
            """
        else:
            insert_sql = f"""
            INSERT INTO ctlr.notebook_process_logs (notebook_name, status, timestamp, run_id)
            VALUES ('{notebook_name}', '{status}', CURRENT_TIMESTAMP, '{run_id}')
            """
        
        # print(f"🔍 DEBUG: SQL: {insert_sql}")
        spark.sql(insert_sql)
        print(f"✅ Logged to ctlr.notebook_process_logs: {status}")
        
    except Exception as e:
        print(f"⚠️ Failed to write to ctlr.notebook_process_logs: {str(e)}")
    
    # Exit for pipeline
    mssparkutils.notebook.exit(status)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }
