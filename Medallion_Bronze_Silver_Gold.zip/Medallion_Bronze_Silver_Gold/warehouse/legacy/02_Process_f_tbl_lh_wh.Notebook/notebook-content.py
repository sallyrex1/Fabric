# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "42396a50-8b85-4951-9850-b36abfe2a28d",
# META       "default_lakehouse_name": "LH_300_Gold_Test",
# META       "default_lakehouse_workspace_id": "a3e4d0e6-6b32-498b-addc-1629a4b29a47",
# META       "known_lakehouses": [
# META         {
# META           "id": "42396a50-8b85-4951-9850-b36abfe2a28d"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# #### **WH F LOAD**

# CELL ********************

%run /config_lh_wh

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

# F tables
p_Wh_GlodLayer = "WH_400_Gold_Test"
p_Wh_schema = "rprt"
p_wh_talbeName = ["*"]      #["tbl_f_*"]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

fnc_cdc_sync(p_Wh_GlodLayer, p_Wh_schema , p_wh_talbeName)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
