# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "42396a50-8b85-4951-9850-b36abfe2a28d",
# META       "default_lakehouse_name": "LH_300_Gold_Test",
# META       "default_lakehouse_workspace_id": "a3e4d0e6-6b32-498b-addc-1629a4b29a47",
# META       "known_lakehouses": [
# META         {
# META           "id": "42396a50-8b85-4951-9850-b36abfe2a28d"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# #### **WH D TABLE LOAD**

# CELL ********************

%run /config_lh_wh

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

# B tables
p_Wh_GlodLayer = "WH_400_Gold_Test"
p_Wh_schema = "rprt"
p_wh_talbeName = ["tbl_d_*"]
# p_wh_talbeName = ["tbl_d_org","tbl_d_custody_arrest", "tbl_d_case", "tbl_d_vcc"]
# p_max_workers = 10


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Basic usage - uses current schema
# backup_foreign_keys(schema = p_Wh_schema, warehouse = p_Wh_GlodLayer)
backup_foreign_keys(schema="dbo")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

execute_warehouse_sql("EXEC backup_foreign_keys @schema_name = 'rprt'","WH_400_Gold_Test")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from notebookutils import mssparkutils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Dry run drop (just shows what would be dropped)
drop_foreign_keys(dry_run=True, schema = p_Wh_schema, warehouse = p_Wh_GlodLayer)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

fnc_cdc_sync(p_Wh_GlodLayer, p_Wh_schema , p_wh_talbeName)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
