# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "42396a50-8b85-4951-9850-b36abfe2a28d",
# META       "default_lakehouse_name": "LH_300_Gold_Test",
# META       "default_lakehouse_workspace_id": "a3e4d0e6-6b32-498b-addc-1629a4b29a47",
# META       "known_lakehouses": [
# META         {
# META           "id": "42396a50-8b85-4951-9850-b36abfe2a28d"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# # **STORM GOLD LOAD**

# MARKDOWN ********************

# ###### CONFIG

# CELL ********************

%run /config_gold_layer

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

# Only activate for Testing
p_current_domain = "Essex_STORM"
print(f"✅ STARTING {p_current_domain} PROCESSING")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": true
# META }

# CELL ********************

create_temp_views_by_domains(silverPath, p_current_domain)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### CREATE TABLE

# CELL ********************

                                    # ======================
                                    #     calc TABLES
                                    # ======================

createTable([

# calc.tbl_storm_priority
("calc.tbl_storm_priority",
"""CREATE TABLE IF NOT EXISTS calc.tbl_storm_priority (
    PriorityID INT,
    Priority INT,
    TargetReponseTime INT,
    TargetAllocationTime INT,
    OA_REC_PROCESSED_DATE TIMESTAMP,
    OA_REC_CREATED_DATE TIMESTAMP,
    OA_REC_END_DATE TIMESTAMP,
    OA_IS_ACTIVE INT,
    OA_VERSION INT,
    OA_RECORDID STRING
) USING DELTA;
""")

])


#                                     # ======================
#                                     #     rprt TABLES
#                                     # ======================


createTable([

# rprt.tbl_d_servicecode
("rprt.tbl_d_servicecode",
"""CREATE TABLE IF NOT EXISTS rprt.tbl_d_servicecode(
    ServiceCodeNaturalID STRING NOT NULL
    ,LoadID int
    ,ServiceCode STRING NOT NULL
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_REC_CREATED_DATE TIMESTAMP
    ,OA_REC_END_DATE TIMESTAMP
    ,OA_IS_ACTIVE INT
    ,OA_VERSION INT
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# rprt.tbl_d_priority
("rprt.tbl_d_priority",
"""CREATE TABLE IF NOT EXISTS rprt.tbl_d_priority(
    PriorityID	INT NOT NULL
    ,LoadID	INT
    ,Priority	INT NOT NULL
    ,TargetReponseTime	INT
    ,TargetAllocationTime	INT
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_REC_CREATED_DATE TIMESTAMP
    ,OA_REC_END_DATE TIMESTAMP
    ,OA_IS_ACTIVE INT
    ,OA_VERSION INT
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# rprt.tbl_d_storm_isr
("rprt.tbl_d_storm_isr",
"""CREATE TABLE IF NOT EXISTS rprt.tbl_d_storm_isr(
    ISR_NO STRING
    ,DISPATCH_LEVEL STRING
    ,LOC_ID INT
    ,LOC_NAME STRING
    ,LOC_TYPE STRING
    ,LEVEL1 STRING
    ,LEVEL2 STRING
    ,LEVEL3 STRING
    ,LEVEL4 STRING
    ,LEVEL5 STRING
    ,FINAL_SERV_CODE STRING
    ,INITIAL_SERV_CODE STRING
    ,P_ORIGIN STRING
    ,PRIORITY INT
    ,HANDLING_UNIT STRING
    ,DP_ID INT
    ,DP_BADGE_NO STRING
    ,SUPER_ID INT
    ,SUPER_BADGE_NO STRING
    ,OFF_ID1 INT
    ,OFF_ID2 INT
    ,OFF_BADGE_NO1 STRING
    ,OFF_BADGE_NO2 STRING
    ,S_STATUS STRING
    ,S_STATUS_NOTE STRING
    ,LONGITUDE INT
    ,LATITUDE INT
    ,PERSON INT
    ,LOG INT
    ,MOD_LOC INT
    ,MOD_SERV_CODE INT
    ,MOD_PRIORITY INT
    ,CREA_LOGINNAME INT
    ,CREA_PERSONNEL_ID INT
    ,MOD_DATE DATE
    ,MOD_TIME STRING
    ,OIC_BADGE_NO STRING
    ,OIC_ID STRING
    ,ORIGINAL_PRIORITY INT
    ,STATUS1_DATE DATE
    ,STATUS1_TIME STRING
    ,STATUS2_DATE DATE
    ,STATUS2_TIME STRING
    ,STATUS3_DATE DATE
    ,STATUS3_TIME STRING
    ,STATUS4_DATE DATE
    ,STATUS4_TIME STRING
    ,STATUS5_DATE DATE
    ,STATUS5_TIME STRING
    ,STATUS6_DATE DATE
    ,STATUS6_TIME STRING
    ,source_table STRING
    ,CRITICALITY STRING
    ,DISPOSE_CODE1 STRING
    ,VSS STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_REC_CREATED_DATE TIMESTAMP
    ,OA_REC_END_DATE TIMESTAMP
    ,OA_IS_ACTIVE INT
    ,OA_VERSION INT
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# rprt.tbl_d_location
("rprt.tbl_d_location",
"""CREATE TABLE IF NOT EXISTS rprt.tbl_d_location(
     LocationID	INT NOT NULL
     ,LoadID INT
    ,LocationSegment	STRING NOT NULL
    ,DistrictName	STRING NOT NULL
    ,City	STRING NOT NULL
    ,LocationName	STRING NOT NULL
    ,LocationEnvironment	STRING NOT NULL
    ,PostCode	STRING NOT NULL
    ,Latitude	STRING
    ,Longitude	STRING
    ,DateMod	STRING
    ,TimeMod	STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_REC_CREATED_DATE TIMESTAMP
    ,OA_REC_END_DATE TIMESTAMP
    ,OA_IS_ACTIVE INT
    ,OA_VERSION INT
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# rprt.tbl_d_personnel
("rprt.tbl_d_personnel",
"""CREATE TABLE IF NOT EXISTS rprt.tbl_d_personnel(
    PersonnelID	INT NOT NULL
    ,LoadID INT
    ,AgencyCode	STRING NOT NULL
    ,EmployeeNo	STRING NOT NULL
    ,BadgeNo	STRING
    ,FamilyName	STRING NOT NULL
    ,FirstName	STRING NOT NULL
    ,Rank	STRING NOT NULL
    ,Department	STRING NOT NULL
    ,TeamSchedule	STRING NOT NULL
    ,SecurityGroup	STRING NOT NULL
    ,Active	INT NOT NULL
    ,CalltakerExperience	INT NOT NULL
    ,DispatcherExperience	INT NOT NULL
    ,MD5Concat	BINARY
    ,DateStart	DATE
    ,DateEnd	DATE
    ,CurrentFlag	INT
    ,In_Storm	INT
    ,Storm_PersonnelID	INT
    ,In_Athena	INT
    ,Athena_Employee_ID	INT
    ,Athena_Employee_Iteration_ID	INT
    ,Athena_Employee_Rank_GCV	STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_REC_CREATED_DATE TIMESTAMP
    ,OA_REC_END_DATE TIMESTAMP
    ,OA_IS_ACTIVE INT
    ,OA_VERSION INT
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# rprt.tbl_d_geo
("rprt.tbl_d_geo",
"""CREATE TABLE IF NOT EXISTS rprt.tbl_d_geo(
    GeoNaturalID	STRING NOT NULL
    ,LoadID	INT
    ,LPACode	STRING NOT NULL
    ,LPADescription	STRING NOT NULL
    ,DPACode	STRING NOT NULL
    ,DPADescription	STRING NOT NULL
    ,DivisionCode	STRING NOT NULL
    ,DivisionDescription	STRING NOT NULL
    ,DistrictCode	STRING NOT NULL
    ,DistrictDescription	STRING NOT NULL
    ,NeighbourhoodCode	STRING NOT NULL
    ,NeighbourhoodDescription	STRING
    ,NeighbourhoodID	STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_REC_CREATED_DATE TIMESTAMP
    ,OA_REC_END_DATE TIMESTAMP
    ,OA_IS_ACTIVE INT
    ,OA_VERSION INT
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# rprt.tbl_d_unit_activity
("rprt.tbl_d_unit_activity",
"""CREATE TABLE IF NOT EXISTS rprt.tbl_d_unit_activity(
    ISR_NUMBER STRING
    ,UNIT STRING
    ,P_UNIT_TYPE1 STRING
    ,PLAN_NUMBER STRING
    ,UA_DATE STRING
    ,UA_TIME STRING
    ,SEQ_NO STRING
    ,OFFICER_PERS_ID1 STRING
    ,OFFICER_PERS_ID2 STRING
    ,OFFICER_PERS_ID3 STRING
    ,OFFICER_PERS_ID4 STRING
    ,OFFICER_PERS_ID5 STRING
    ,OFFICER_PERS_ID6 STRING
    ,OFFICER_PERS_ID7 STRING
    ,OFFICER_PERS_ID8 STRING
    ,OFFICER_PERS_ID9 STRING
    ,OFFICER_PERS_ID10 STRING
    ,OFFICER_PERS_ID11 STRING
    ,OFFICER_PERS_ID12 STRING
    ,RIDERS STRING
    ,PRIORITY STRING
    ,S_STATUS STRING
    ,S_FUNCTION STRING
    ,DISPATCH_LEVEL STRING
    ,LONGITUDE INT
    ,LATITUDE INT
    ,MOD_DATE STRING
    ,MOD_TIME STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_REC_CREATED_DATE TIMESTAMP
    ,OA_REC_END_DATE TIMESTAMP
    ,OA_IS_ACTIVE INT
    ,OA_VERSION INT
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# rprt.tbl_d_storm_isr_timestamps
("rprt.tbl_d_storm_isr_timestamps",
"""CREATE TABLE IF NOT EXISTS rprt.tbl_d_storm_isr_timestamps(
    ISR_NO STRING
    ,MOD_DATE DATE
    ,MOD_TIME STRING
    ,TIMESTAMP7 TIMESTAMP
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_REC_CREATED_DATE TIMESTAMP
    ,OA_REC_END_DATE TIMESTAMP
    ,OA_IS_ACTIVE INT
    ,OA_VERSION INT
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# rprt.tbl_d_incident
("rprt.tbl_d_incident",
"""CREATE TABLE IF NOT EXISTS rprt.tbl_d_incident(
    IncidentNaturalID	STRING NOT NULL
    ,LoadID	INT
    ,DateSaved	TIMESTAMP
    ,TimeSaved	STRING
    ,DateTimeSaved	TIMESTAMP
    ,HandlingUnit	STRING
    ,CriticalityCode	STRING
    ,StatusCode	STRING
    ,IncidentTagCode	STRING
    ,DispatchLevel	STRING
    ,FinalDisposeCode	STRING
    ,AvailableUnitsDPA	INT
    ,AvailableUnitsLPA	INT
    ,FK_DateSavedID	INT
    ,FK_DateSavedPoliceID	INT
    ,FK_TimeSavedID	INT
    ,FK_GeoID	STRING
    ,FK_LocationID	INT
    ,FK_DispatcherID	INT
    ,FK_CallerTakerID	INT
    ,FK_InitialServiceCodeID	STRING
    ,FK_PriorityID	INT
    ,FinalServCode	STRING
    ,VSS	STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_REC_CREATED_DATE TIMESTAMP
    ,OA_REC_END_DATE TIMESTAMP
    ,OA_IS_ACTIVE INT
    ,OA_VERSION INT
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# rprt.tbl_f_IncidentOfficerResponse
("rprt.tbl_f_IncidentOfficerResponse",
"""CREATE TABLE IF NOT EXISTS rprt.tbl_f_IncidentOfficerResponse(
    PK_IncidentOfficerResponse	STRING
    ,IncidentNaturalID	STRING NOT NULL
    ,UnitNo	STRING
    ,PersonnelID	INT NOT NULL
    ,LoadID	INT
    ,UnitType	STRING NOT NULL
    ,ArrivalOrder	INT
    ,FirstArrived	STRING
    ,MaxArrivalOrder	INT
    ,MinProximityToShiftHandover	INT
    ,NonResponseUnitFlag	INT
    ,DateTransfer	TIMESTAMP
    ,TimeTransfer	STRING
    ,DateAllocated	TIMESTAMP
    ,TimeAllocated	STRING
    ,DateArrived	TIMESTAMP
    ,TimeArrived	STRING
    ,MinDiffSavedtoTransfer	FLOAT
    ,MinDiffSavedtoAllocated	FLOAT
    ,MinDiffSavedtoArrived	FLOAT
    ,MinDiffTransfertoAllocated	FLOAT
    ,MinDiffTransfertoArrived	FLOAT
    ,MinDiffAllocatedtoTarget	FLOAT
    ,MissedResponseFlag	STRING
    ,MissedAllocationFlag	STRING
    ,PriorityID	INT
    ,DistancedTravelled	FLOAT
    ,First_Lat	FLOAT
    ,First_Long	FLOAT
    ,Last_Lat	FLOAT
    ,Last_Long	FLOAT
    ,FK_IncidentID	STRING
    ,FK_DateSavedActualID	INT
    ,FK_DateSavedPoliceID	INT
    ,FK_TimeSavedID	INT
    ,FK_GeoID	STRING NOT NULL
    ,FK_LocationID	INT NOT NULL
    ,FK_CallerTakerID	INT NOT NULL
    ,FK_DispatcherID	INT
    ,FK_InitialServiceCodeID	STRING NOT NULL
    ,FK_PriorityID	INT NOT NULL
    ,FK_OfficerID	INT NOT NULL
    ,FK_DistanceID	INT NOT NULL
    ,AllocationOrder	INT
    ,maxallocationorder	INT
    ,FirstAllocated	STRING
    ,FinalServCode	STRING
    ,OfficerEmployeeNo	STRING
    ,Off_Staff_Move_ID	STRING
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_REC_CREATED_DATE TIMESTAMP
    ,OA_REC_END_DATE TIMESTAMP
    ,OA_IS_ACTIVE INT
    ,OA_VERSION INT
    ,OA_RECORDID STRING
)USING DELTA;
"""),

# rprt.tbl_f_Incident
("rprt.tbl_f_Incident",
"""CREATE TABLE IF NOT EXISTS rprt.tbl_f_incident(
	IncidentNaturalID	STRING NOT NULL
    ,LoadID	INT
    ,DateAllocated	TIMESTAMP
    ,TimeAllocated	STRING
    ,DateAssigned	TIMESTAMP
    ,TimeAssigned	STRING
    ,DateArrived	TIMESTAMP
    ,TimeArrived	STRING
    ,TransferDate	TIMESTAMP
    ,TransferTime	STRING
    ,DispatchedLevel	STRING
    ,ComplAddInfo	STRING
    ,FinalServCode	STRING
    ,Origin	STRING
    ,Description	STRING
    ,FirstUnitArrived	STRING
    ,FirstUnitDispatched	STRING
    ,FK_IncidentID	STRING
    ,FK_GeoID	STRING
    ,FK_LocationID	INT
    ,FK_OfficerID	INT
    ,FK_DispatcherID	INT
    ,FK_CallerTakerID	INT
    ,FK_DistanceID	INT
    ,FK_PriorityID	INT
    ,FK_InitialServiceCodeID	STRING
    ,SupervisorPIN	STRING
    ,DisposedURN	STRING
    ,ModifiedLocation	STRING
    ,ModifiedServCode	STRING
    ,HandlingUnit	STRING
    ,MinDiff_SavedtoTransfer	DECIMAL
    ,MinDiff_SavedtoArrived	DECIMAL
    ,MinDiff_TransfertoAllocation	DECIMAL
    ,MinDiff_AllocatedtoArrived	DECIMAL
    ,MinDiff_SavedtoDispatched	DECIMAL
    ,TravelTimeAvailable	DECIMAL
    ,DistanceTravelled	DECIMAL
    ,MissedResponseFlag	STRING
    ,MissedAllocationFlag	STRING
    ,FK_DateSavedActualID	INT
    ,FK_DateSavedPoliceID	INT
    ,FK_TimeSavedID	INT
    ,AvailableUnitsDPA	INT
    ,AvailableUnitsLPA	INT
    ,HandlerEmployeeNo	STRING
    ,Handler_Staff_Move_ID	STRING
    ,Dispatcher_Staff_Move_ID	STRING
    ,DispatcherEmployeeNo	STRING
    ,Original_Priority	INT
    ,OA_REC_PROCESSED_DATE TIMESTAMP
    ,OA_REC_CREATED_DATE TIMESTAMP
    ,OA_REC_END_DATE TIMESTAMP
    ,OA_IS_ACTIVE INT
    ,OA_VERSION INT
    ,OA_RECORDID STRING
)USING DELTA;
""")

])


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### INGEST GOLD LAYER

# CELL ********************



                                                                                # ==================================
                                                                                # calc -TABLE LOAD 
                                                                                # ==================================

run_parallel_queries_gold([

# calc.tbl_storm_priority
("calc.tbl_storm_priority",
"""WITH version_data AS (
    SELECT PRIORITYID, MAX(OA_VERSION) AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate 
    FROM calc.tbl_storm_priority 
    GROUP BY PRIORITYID
),
prepared_source AS (
    SELECT s.*, 
           COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW, 
           CURRENT_TIMESTAMP() AS OA_REC_PROCESSED_DATE_NEW,
           CASE WHEN s.PRIORITYID = v.PRIORITYID THEN v.min_createdDate ELSE CURRENT_TIMESTAMP() END AS OA_REC_CREATED_DATE
    FROM temp_tbl_storm_priority s
    LEFT JOIN version_data v ON s.PRIORITYID = v.PRIORITYID
)

MERGE INTO calc.tbl_storm_priority AS t
USING prepared_source s
ON t.PRIORITYID = s.PRIORITYID AND t.OA_IS_ACTIVE = 1

WHEN MATCHED AND t.OA_RECORDID <> s.OA_RECORDID THEN
    UPDATE SET t.OA_IS_ACTIVE = 0, 
               t.OA_REC_END_DATE = s.OA_REC_PROCESSED_DATE_NEW, 
               t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE_NEW

WHEN NOT MATCHED THEN
    INSERT (PRIORITYID, PRIORITY, TargetReponseTime, TARGETALLOCATIONTIME, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
    VALUES (s.PRIORITYID, s.PRIORITY, s.TARGETRESPONSETIME, s.TARGETALLOCATIONTIME, s.OA_REC_PROCESSED_DATE_NEW, s.OA_REC_CREATED_DATE, TO_TIMESTAMP('9999-12-31'), 1, s.OA_VERSION_NEW, s.OA_RECORDID);
""")

])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

                                                                    #========================================
                                                                    # d rprt TABLES LOAD -approx xmins
                                                                    # =======================================


run_parallel_queries_gold([

# rprt.tbl_d_servicecode
("rprt.tbl_d_servicecode",
        """ WITH version_data AS(SELECT SERVICECODENATURALID, MAX(OA_VERSION) AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate FROM rprt.tbl_d_servicecode GROUP BY SERVICECODENATURALID),
    
        prepared_source AS(
            SELECT s.*, COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW, CURRENT_TIMESTAMP() AS OA_REC_PROCESSED_DATE_NEW, CASE WHEN s.SERVICECODENATURALID = v.SERVICECODENATURALID THEN v.min_createdDate ELSE CURRENT_TIMESTAMP() END OA_REC_CREATED_DATE
            FROM temp_tbl_storm_service_code s
        LEFT JOIN version_data v ON s.SERVICECODENATURALID = v.SERVICECODENATURALID
        WHERE s.OA_REC_PROCESSED_DATE = (SELECT MAX(OA_REC_PROCESSED_DATE) FROM temp_tbl_storm_service_code)
        )

            MERGE INTO rprt.tbl_d_servicecode AS t
            USING prepared_source AS s
            ON t.ServiceCodeNaturalID = s.SERVICECODENATURALID

            WHEN MATCHED AND t.OA_RECORDID <> s.OA_RECORDID THEN
                UPDATE SET t.OA_IS_ACTIVE = 0, t.OA_REC_END_DATE = OA_REC_PROCESSED_DATE_NEW, t.OA_REC_PROCESSED_DATE = OA_REC_PROCESSED_DATE_NEW

            WHEN NOT MATCHED THEN
                INSERT (ServiceCodeNaturalID, LoadID, ServiceCode, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
                VALUES (s.SERVICECODENATURALID, NULL, s.SERVICECODE, s.OA_REC_PROCESSED_DATE_NEW, s.OA_REC_CREATED_DATE, TO_TIMESTAMP('9999-12-31'), 1,s.OA_VERSION_NEW,s.OA_RECORDID)
        """),

# tbl_d_priority
("rprt.tbl_d_priority",
            """ WITH version_data AS(SELECT PRIORITYID, MAX(OA_VERSION) AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate FROM rprt.tbl_d_priority GROUP BY PRIORITYID),

        prepared_source AS(
            SELECT s.*, COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW, CURRENT_TIMESTAMP() AS OA_REC_PROCESSED_DATE_NEW, CASE WHEN s.PRIORITYID = v.PRIORITYID THEN v.min_createdDate ELSE CURRENT_TIMESTAMP() END OA_REC_CREATED_DATE
            FROM temp_tbl_storm_priority s
        LEFT JOIN version_data v ON s.PRIORITYID = v.PRIORITYID
        WHERE s.OA_REC_PROCESSED_DATE = (SELECT MAX(OA_REC_PROCESSED_DATE) FROM temp_tbl_storm_priority)
        )
            MERGE INTO rprt.tbl_d_priority AS t 
            USING prepared_source AS s 
            ON t.PRIORITYID = s.PRIORITYID

            WHEN MATCHED AND t.OA_RECORDID <> s.OA_RECORDID THEN
                UPDATE SET t.OA_IS_ACTIVE = 0, t.OA_REC_END_DATE = OA_REC_PROCESSED_DATE_NEW, t.OA_REC_PROCESSED_DATE = OA_REC_PROCESSED_DATE_NEW

                        WHEN NOT MATCHED THEN 
                INSERT(PRIORITYID,LoadID,PRIORITY,TARGETREPONSETIME,TARGETALLOCATIONTIME, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
                VALUES(s.PRIORITYID,NULL,s.PRIORITY,s.TARGETRESPONSETIME,s.TARGETALLOCATIONTIME, s.OA_REC_PROCESSED_DATE_NEW, s.OA_REC_CREATED_DATE, TO_TIMESTAMP('9999-12-31'), 1,s.OA_VERSION_NEW,s.OA_RECORDID)
"""),

# tbl_d_storm_isr
("rprt.tbl_d_storm_isr", 
        """ WITH version_data AS(SELECT ISR_NO, MAX(OA_VERSION) AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate FROM rprt.tbl_d_storm_isr GROUP BY ISR_NO),
    
        -- Step 3: Prepare source data with versions
        prepared_source AS(
        SELECT  s.*, COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW,  CURRENT_TIMESTAMP() AS OA_REC_PROCESSED_DATE_NEW, CASE WHEN s.ISR_NO = v.ISR_NO THEN v.min_createdDate ELSE CURRENT_TIMESTAMP() END OA_REC_CREATED_DATE
        FROM temp_tbl_storm_isr s
        LEFT JOIN version_data v ON s.ISR_NO = v.ISR_NO
        WHERE s.OA_REC_PROCESSED_DATE = (SELECT MAX(OA_REC_PROCESSED_DATE) FROM temp_tbl_storm_isr) ) 

        MERGE INTO rprt.tbl_d_storm_isr AS t
        USING prepared_source s
        ON t.ISR_NO = s.ISR_NO AND t.OA_IS_ACTIVE = 1


        WHEN MATCHED AND t.OA_RECORDID <> s.OA_RECORDID THEN
            UPDATE SET t.OA_IS_ACTIVE = 0, t.OA_REC_END_DATE = OA_REC_PROCESSED_DATE_NEW, t.OA_REC_PROCESSED_DATE = OA_REC_PROCESSED_DATE_NEW

        WHEN NOT MATCHED THEN
            INSERT (ISR_NO, DISPATCH_LEVEL, LOC_ID, LOC_NAME, LOC_TYPE, LEVEL1, LEVEL2, LEVEL3, LEVEL4, LEVEL5, FINAL_SERV_CODE, INITIAL_SERV_CODE, P_ORIGIN, PRIORITY, HANDLING_UNIT, DP_ID, DP_BADGE_NO, SUPER_ID, SUPER_BADGE_NO, OFF_ID1, OFF_ID2, OFF_BADGE_NO1, OFF_BADGE_NO2, S_STATUS, S_STATUS_NOTE, LONGITUDE, LATITUDE, PERSON, LOG, MOD_LOC, MOD_SERV_CODE, MOD_PRIORITY, CREA_LOGINNAME, CREA_PERSONNEL_ID, MOD_DATE, MOD_TIME, OIC_BADGE_NO, OIC_ID, ORIGINAL_PRIORITY, STATUS1_DATE, STATUS1_TIME, STATUS2_DATE, STATUS2_TIME, STATUS3_DATE, STATUS3_TIME, STATUS4_DATE, STATUS4_TIME, STATUS5_DATE, STATUS5_TIME, STATUS6_DATE, STATUS6_TIME, SOURCE_TABLE, CRITICALITY, DISPOSE_CODE1, VSS, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
            VALUES (s.ISR_NO, s.DISPATCH_LEVEL, s.LOC_ID, s.LOC_NAME, s.LOC_TYPE, s.LEVEL1, s.LEVEL2, s.LEVEL3, s.LEVEL4, s.LEVEL5, s.FINAL_SERV_CODE, s.INITIAL_SERV_CODE, s.P_ORIGIN, s.PRIORITY, s.HANDLING_UNIT, s.DP_ID, s.DP_BADGE_NO, s.SUPER_ID, s.SUPER_BADGE_NO, s.OFF_ID1, s.OFF_ID2, s.OFF_BADGE_NO1, s.OFF_BADGE_NO2, s.S_STATUS, s.S_STATUS_NOTE, s.LONGITUDE, s.LATITUDE, s.PERSON, s.LOG, s.MOD_LOC, s.MOD_SERV_CODE, s.MOD_PRIORITY, s.CREA_LOGINNAME, s.CREA_PERSONNEL_ID, s.MOD_DATE, s.MOD_TIME, s.OIC_BADGE_NO, s.OIC_ID, s.ORIGINAL_PRIORITY, s.STATUS1_DATE, s.STATUS1_TIME, s.STATUS2_DATE, s.STATUS2_TIME, s.STATUS3_DATE, s.STATUS3_TIME, s.STATUS4_DATE, s.STATUS4_TIME, s.STATUS5_DATE, s.STATUS5_TIME, s.STATUS6_DATE, s.STATUS6_TIME, s.SOURCE_TABLE, s.CRITICALITY, s.DISPOSE_CODE1, s.VSS, s.OA_REC_PROCESSED_DATE_NEW, s.OA_REC_CREATED_DATE, TO_TIMESTAMP('9999-12-31'), 1, s.OA_VERSION_NEW, s.OA_RECORDID)
        """),

# tbl_d_location
("rprt.tbl_d_location", 
        """ WITH version_data AS(SELECT LOCATIONID, MAX(OA_VERSION) AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate FROM rprt.tbl_d_location GROUP BY LOCATIONID),
    
        prepared_source AS(
            SELECT s.*, COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW, CURRENT_TIMESTAMP() AS OA_REC_PROCESSED_DATE_NEW, CASE WHEN s.LOCATIONID = v.LOCATIONID THEN v.min_createdDate ELSE CURRENT_TIMESTAMP() END OA_REC_CREATED_DATE
            FROM temp_tbl_storm_location s
        LEFT JOIN version_data v ON s.LOCATIONID = v.LOCATIONID
        WHERE s.OA_REC_PROCESSED_DATE = (SELECT MAX(OA_REC_PROCESSED_DATE) FROM temp_tbl_storm_location)
        )

        MERGE INTO rprt.tbl_d_location AS t 
        USING prepared_source AS s 
        ON t.locationID = s.LOCATIONID

        WHEN MATCHED AND t.OA_RECORDID <> s.OA_RECORDID THEN
            UPDATE SET t.OA_IS_ACTIVE = 0, t.OA_REC_END_DATE = OA_REC_PROCESSED_DATE_NEW, t.OA_REC_PROCESSED_DATE = OA_REC_PROCESSED_DATE_NEW

        WHEN NOT MATCHED THEN 
        INSERT(LOCATIONID,LoadID, LOCATIONSEGMENT,DISTRICTNAME,CITY,LOCATIONNAME,LOCATIONENVIRONMENT,POSTCODE,LONGITUDE,LATITUDE,DATEMOD,TIMEMOD, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
        VALUES(s.LOCATIONID,NULL,s.LOCATIONSEGMENT,s.DISTRICTNAME,s.CITY,s.LOCATIONNAME,s.LOCATIONENVIRONMENT,s.POSTCODE,s.LONGITUDE,s.LATITUDE,s.DATEMOD,s.TIMEMOD, s.OA_REC_PROCESSED_DATE_NEW, 
        s.OA_REC_CREATED_DATE, TO_TIMESTAMP('9999-12-31'), 1,s.OA_VERSION_NEW,s.OA_RECORDID);
        """),

# tbl_d_personnel
("rprt.tbl_d_personnel", 
        """ WITH version_data AS(SELECT PERSONNELID, MAX(OA_VERSION) AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate FROM rprt.tbl_d_personnel GROUP BY PERSONNELID),
    
        -- Step 3: Prepare source data with versions
        prepared_source AS(
        SELECT  s.*, COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW,  CURRENT_TIMESTAMP() AS OA_REC_PROCESSED_DATE_NEW, CASE WHEN s.PERSONNELID = v.PERSONNELID THEN v.min_createdDate ELSE CURRENT_TIMESTAMP() END OA_REC_CREATED_DATE
        FROM temp_tbl_personnel s
        LEFT JOIN version_data v ON s.PERSONNELID = v.PERSONNELID
        --WHERE s.OA_REC_PROCESSED_DATE = (SELECT MAX(OA_REC_PROCESSED_DATE) FROM temp_tbl_storm_personnel) 
        ) 

        MERGE INTO rprt.tbl_d_personnel AS t
        USING prepared_source s
        ON t.PERSONNELID = s.PERSONNELID AND t.OA_IS_ACTIVE = 1


        WHEN MATCHED AND t.OA_RECORDID <> s.OA_RECORDID THEN
            UPDATE SET t.OA_IS_ACTIVE = 0, t.OA_REC_END_DATE = OA_REC_PROCESSED_DATE_NEW, t.OA_REC_PROCESSED_DATE = OA_REC_PROCESSED_DATE_NEW

        WHEN NOT MATCHED THEN
            INSERT (PERSONNELID, LoadID ,AGENCYCODE ,EMPLOYEENO ,BADGENO ,FAMILYNAME ,FIRSTNAME ,RANK ,DEPARTMENT ,TEAMSCHEDULE ,SECURITYGROUP ,ACTIVE ,CALLTAKEREXPERIENCE ,DISPATCHEREXPERIENCE ,MD5CONCAT ,DATESTART ,DATEEND ,CURRENTFLAG ,IN_STORM ,STORM_PERSONNELID 
            ,IN_ATHENA ,ATHENA_EMPLOYEE_ID ,ATHENA_EMPLOYEE_ITERATION_ID ,ATHENA_EMPLOYEE_RANK_GCV ,OA_REC_PROCESSED_DATE ,OA_REC_CREATED_DATE ,OA_REC_END_DATE ,OA_IS_ACTIVE ,OA_VERSION ,OA_RECORDID)
               
            VALUES (s.PERSONNELID, NULL, s.AGENCYCODE, s.EMPLOYEENO, s.BADGENO, s.FAMILYNAME, s.FIRSTNAME, s.RANK, s.DEPARTMENT, s.TEAMSCHEDULE, s.SECURITYGROUP, s.ACTIVE, s.CALLTAKEREXPERIENCE, s.DISPATCHEREXPERIENCE, s.MD5CONCAT, s.DATESTART, s.DATEEND, 
            s.CURRENTFLAG, s.IN_STORM, s.STORM_PERSONNELID, s.IN_ATHENA, s.ATHENA_EMPLOYEE_ID, s.ATHENA_EMPLOYEE_ITERATION_ID, s.ATHENA_EMPLOYEE_RANK_GCV, s.OA_REC_PROCESSED_DATE_NEW, s.OA_REC_CREATED_DATE, TO_TIMESTAMP('9999-12-31'), 1,s.OA_VERSION_NEW,s.OA_RECORDID);
        """),

#   tbl_d_geo
("rprt.tbl_d_geo", 
    """ WITH version_data AS(SELECT GEONATURALID, MAX(OA_VERSION) AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate  FROM rprt.tbl_d_geo GROUP BY GEONATURALID),
        prepared_source AS(
        SELECT s.*, COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW, CURRENT_TIMESTAMP() AS OA_REC_PROCESSED_DATE_NEW ,CASE WHEN s.GEONATURALID = v.GEONATURALID THEN v.min_createdDate ELSE CURRENT_TIMESTAMP() END OA_REC_CREATED_DATE
    
    FROM temp_tbl_storm_force_structure_loc s
    LEFT JOIN version_data v ON s.GEONATURALID = v.GEONATURALID
    WHERE s.OA_REC_PROCESSED_DATE = (SELECT MAX(OA_REC_PROCESSED_DATE) 
    FROM temp_tbl_storm_force_structure_loc)
    )
     MERGE INTO rprt.tbl_d_geo AS t
    USING prepared_source s
    ON t.GEONATURALID = s.GEONATURALID AND t.OA_IS_ACTIVE = 1
    
    WHEN MATCHED AND t.OA_RECORDID <> s.OA_RECORDID THEN
        UPDATE SET t.OA_IS_ACTIVE = 0, t.OA_REC_END_DATE = OA_REC_PROCESSED_DATE_NEW, t.OA_REC_PROCESSED_DATE = OA_REC_PROCESSED_DATE_NEW
    
    WHEN NOT MATCHED THEN
    INSERT (GeoNaturalID, LoadID, LPACode, LPADescription, DPACode, DPADescription, DivisionCode, DivisionDescription, DistrictCode, DistrictDescription, NeighbourhoodCode, NeighbourhoodDescription, NeighbourhoodID, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
    VALUES (s.GeoNaturalID, NULL, TRY_CAST(s.LPACode AS INT), s.LPADescription, TRY_CAST(s.DPACode AS INT), s.DPADescription, s.DivisionCode, s.DivisionDescription, s.DistrictCode, s.DistrictDescription, s.NeighbourhoodCode, s.NeighbourhoodDescription, s.NeighbourhoodID, s.OA_REC_PROCESSED_DATE_NEW, s.OA_REC_CREATED_DATE, TO_TIMESTAMP('9999-12-31'), 1,s.OA_VERSION_NEW,s.OA_RECORDID);
    """),

# tbl_d_unit_activity
("rprt.tbl_d_unit_activity",
    """ WITH version_data AS(SELECT ISR_NUMBER, MAX(OA_VERSION) AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate FROM rprt.tbl_d_unit_activity GROUP BY ISR_NUMBER),

    prepared_source AS(
        SELECT s.*, COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW, CURRENT_TIMESTAMP() AS OA_REC_PROCESSED_DATE_NEW, CASE WHEN s.ISR_NUMBER = v.ISR_NUMBER THEN v.min_createdDate ELSE CURRENT_TIMESTAMP() END OA_REC_CREATED_DATE
        FROM temp_tbl_storm_unit_activity s
        LEFT JOIN version_data v ON s.ISR_NUMBER = v.ISR_NUMBER
        WHERE s.ISR_NUMBER != '0' AND s.ISR_NUMBER <> ' ' 
        AND s.OA_REC_PROCESSED_DATE = (SELECT MAX(OA_REC_PROCESSED_DATE) FROM temp_tbl_storm_unit_activity)
        )
    
        MERGE INTO rprt.tbl_d_unit_activity t 
        USING prepared_source AS  s     
        ON t.ISR_NUMBER = s.ISR_NUMBER AND t.OA_RECORDID = s.OA_RECORDID
    
        WHEN MATCHED AND t.OA_RECORDID <> s.OA_RECORDID THEN
            UPDATE SET t.OA_IS_ACTIVE = 0, t.OA_REC_END_DATE = OA_REC_PROCESSED_DATE_NEW, t.OA_REC_PROCESSED_DATE = OA_REC_PROCESSED_DATE_NEW
    
        WHEN NOT MATCHED THEN
            INSERT(ISR_NUMBER,UNIT,P_UNIT_TYPE1,PLAN_NUMBER,UA_DATE,UA_TIME,SEQ_NO,OFFICER_PERS_ID1 ,OFFICER_PERS_ID2 ,OFFICER_PERS_ID3 ,OFFICER_PERS_ID4 ,OFFICER_PERS_ID5 ,OFFICER_PERS_ID6 ,OFFICER_PERS_ID7 ,OFFICER_PERS_ID8 ,OFFICER_PERS_ID9 
            ,PRIORITY ,S_STATUS ,S_FUNCTION,DISPATCH_LEVEL,LONGITUDE,LATITUDE ,MOD_DATE ,MOD_TIME, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
            VALUES(s.ISR_NUMBER,s.UNIT,s.P_UNIT_TYPE1,s.PLAN_NUMBER,s.UA_DATE,s.UA_TIME,TRY_CAST(s.SEQ_NO AS INT),s.OFFICER_PERS_ID1 ,s.OFFICER_PERS_ID2 ,s.OFFICER_PERS_ID3 ,s.OFFICER_PERS_ID4 ,s.OFFICER_PERS_ID5 ,s.OFFICER_PERS_ID6 ,s.OFFICER_PERS_ID7 ,s.OFFICER_PERS_ID8 
            ,s.OFFICER_PERS_ID9 ,s.PRIORITY ,s.S_STATUS ,s.S_FUNCTION,s.DISPATCH_LEVEL,s.LONGITUDE,s.LATITUDE ,s.MOD_DATE ,s.MOD_TIME, s.OA_REC_PROCESSED_DATE_NEW, s.OA_REC_CREATED_DATE, TO_TIMESTAMP('9999-12-31'), 1,s.OA_VERSION_NEW,s.OA_RECORDID)
        """),                                                                

# tbl_d_storm_isr_timestamps
("rprt.tbl_d_storm_isr_timestamps", 
        """ WITH version_data AS (SELECT ISR_NO, MAX(OA_VERSION) AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate FROM rprt.tbl_d_storm_isr_timestamps GROUP BY ISR_NO),

        prepared_source AS (
            SELECT  s.*, COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW,  CURRENT_TIMESTAMP() AS OA_REC_PROCESSED_DATE_NEW, CASE WHEN s.ISR_NO = v.ISR_NO THEN v.min_createdDate ELSE CURRENT_TIMESTAMP() END AS OA_REC_CREATED_DATE
            FROM temp_tbl_storm_isr_timestamps s
            LEFT JOIN version_data v ON s.ISR_NO = v.ISR_NO
            WHERE s.OA_REC_PROCESSED_DATE = (SELECT MAX(OA_REC_PROCESSED_DATE) FROM temp_tbl_storm_isr_timestamps)
        )

        MERGE INTO rprt.tbl_d_storm_isr_timestamps AS t
        USING prepared_source AS s
        ON t.ISR_NO = s.ISR_NO AND t.OA_IS_ACTIVE = 1

        WHEN MATCHED AND t.OA_RECORDID <> s.OA_RECORDID THEN
            UPDATE SET t.OA_IS_ACTIVE = 0, t.OA_REC_END_DATE = s.OA_REC_PROCESSED_DATE_NEW, t.OA_REC_PROCESSED_DATE = s.OA_REC_PROCESSED_DATE_NEW

        WHEN NOT MATCHED THEN
            INSERT (ISR_NO, MOD_DATE, MOD_TIME, TIMESTAMP7, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
            VALUES (s.ISR_NO, s.MOD_DATE, s.MOD_TIME, s.TIMESTAMP7, s.OA_REC_PROCESSED_DATE_NEW, s.OA_REC_CREATED_DATE, TO_TIMESTAMP('9999-12-31'), 1, s.OA_VERSION_NEW, s.OA_RECORDID);
                """)

])

# d_Incident    
run_parallel_queries_gold([  

("rprt.tbl_d_incident",
        """ WITH version_data AS(SELECT INCIDENTNATURALID, MAX(OA_VERSION) AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate FROM rprt.tbl_d_incident GROUP BY INCIDENTNATURALID),
    
    -- select * from version_data limit 2;
    
        d_IncidentCTE AS (
        SELECT 
            isr.ISR_NO AS IncidentNaturalID,
            isr.CREA_PERSONNEL_ID AS FK_CallerTakerID,
            isr.INITIAL_SERV_CODE AS FK_InitialServiceCodeID,
            CAST(REPLACE(isr.STATUS3_DATE, '-', '') AS INT) AS FK_DateSavedID,
            (CASE 
            WHEN STATUS3_DATE IS NULL THEN NULL
            WHEN (STATUS3_TIME > '00:00:00' AND STATUS3_TIME < '06:00:00') 
            THEN CAST(REPLACE(isr.STATUS3_DATE, '-', '') AS INT) - 1
            ELSE CAST(REPLACE(isr.STATUS3_DATE, '-', '') AS INT)
            END) AS FK_DateSavedPoliceID,
            CAST(REPLACE(isr.STATUS3_TIME, ':', '') AS INT) AS FK_TimeSavedID,
            isr.LEVEL5 AS FK_GeoID,
            isr.LOC_ID AS FK_LocationID,
            isr.DP_ID AS FK_DispatcherID,
            isr.PRIORITY AS FK_PriorityID,
            isr.STATUS3_DATE AS DateSaved,
            TO_TIMESTAMP(isr.STATUS3_TIME, 'HH:mm:ss') AS TimeSaved,
            TO_TIMESTAMP(CONCAT(CAST(isr.STATUS3_DATE AS STRING), ' ', isr.STATUS3_TIME), 'yyyy-MM-ss HH:mm:ss') AS DateTimeSaved,
            isr.HANDLING_UNIT AS HandlingUnit,
            isr.CRITICALITY AS CriticalityCode,
            isr.S_STATUS AS StatusCode,
            NULL AS IncidentTagCode,
            isr.DISPATCH_LEVEL AS DispatchLevel,
            isr.DISPOSE_CODE1 AS FinalDisposeCode,
            isr.FINAL_SERV_CODE AS FinalServCode,
            CASE 
                WHEN isr.VSS = 'Y' THEN 'Yes'
                WHEN isr.VSS = 'N' THEN 'No'
                ELSE 'Incomplete'
            END AS VSS,
            ROW_NUMBER() OVER(PARTITION BY isr.ISR_NO ORDER BY isr.MOD_DATE) d_incident_duplicate,
            COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW, 
            CURRENT_TIMESTAMP() AS OA_REC_PROCESSED_DATE_NEW,
            OA_REC_PROCESSED_DATE,
            CASE WHEN isr.ISR_NO = v.INCIDENTNATURALID THEN v.min_createdDate ELSE CURRENT_TIMESTAMP() END OA_REC_CREATED_DATE,
            OA_RECORDID
    
        FROM rprt.tbl_d_storm_isr isr
        LEFT JOIN version_data v ON isr.ISR_NO = v.INCIDENTNATURALID
        WHERE isr.ISR_NO IS NOT NULL 
        AND isr.ISR_NO != '0'
        --AND isr.ISR_NO <> ' ' 
        -- AND isr.OA_REC_PROCESSED_DATE = (SELECT MAX(OA_REC_PROCESSED_DATE) FROM temp_tbl_storm_isr)
    )
    
    -- select * from d_IncidentCTE limit 10;
    
    ,Source_d_incident AS(
        SELECT DISTINCT
            u.IncidentNaturalID,
            TRY_CAST(COALESCE(dd.DateID, -1) AS INT) AS FK_DateSavedID,
            TRY_CAST(COALESCE(ddp.DateID, -1) AS INT) AS FK_DateSavedPoliceID,
            TRY_CAST(COALESCE(dt.TimeID, -1) AS INT) AS FK_TimeSavedID,
            TRY_CAST(COALESCE(dgeo.GeoNaturalID, '-1') AS INT) AS FK_GeoID,
            TRY_CAST(COALESCE(dloc.LocationID, -1) AS INT) AS FK_LocationID,
            CAST(COALESCE(dpd.PersonnelID, -1) AS INT) AS FK_DispatcherID,              -- comment out this when you fix the personnel dim
            CAST(COALESCE(dpct.PersonnelID, -1) AS INT) AS FK_CallerTakerID,
            COALESCE(dsc.ServiceCodeNaturalID, '-1') AS FK_InitialServiceCodeID,
            TRY_CAST(COALESCE(dprt.PriorityID, -1) AS INT) AS FK_PriorityID,
            u.DateSaved,
            u.TimeSaved,
            u.DateTimeSaved,
            u.HandlingUnit,
            u.CriticalityCode,
            u.StatusCode,
            u.IncidentTagCode,
            u.DispatchLevel,
            u.FinalDisposeCode,
            u.FinalServCode,
            u.VSS,
            u.OA_VERSION_NEW,
            u.OA_REC_PROCESSED_DATE_NEW,
            u.OA_REC_CREATED_DATE,
            u.OA_RECORDID
    
        FROM d_IncidentCTE u
        LEFT JOIN rprt.tbl_d_priority dprt ON u.FK_PriorityID = dprt.PriorityID
        LEFT JOIN rprt.tbl_d_geo dgeo ON u.FK_GeoID = dgeo.GeoNaturalID
        LEFT JOIN rprt.tbl_d_location dloc ON u.FK_LocationID = dloc.LocationID
        LEFT JOIN rprt.tbl_d_personnel dpct ON u.FK_CallerTakerID = dpct.PersonnelID
        LEFT JOIN rprt.tbl_d_personnel dpd ON u.FK_DispatcherID = dpd.PersonnelID
        LEFT JOIN rprt.tbl_d_servicecode dsc ON u.FK_InitialServiceCodeID = dsc.ServiceCodeNaturalID
        LEFT JOIN rprt.tbl_d_time dt ON u.FK_TimeSavedID = dt.TimeID
        LEFT JOIN rprt.tbl_d_date dd ON u.FK_DateSavedID = dd.DateID
        LEFT JOIN rprt.tbl_d_date ddp ON u.FK_DateSavedPoliceID = ddp.DateID
        WHERE d_incident_duplicate = 1
        -- AND LEFT(u.INCIDENTNATURALID,2) IN ('EP')                    -- Find out from Lewis: when this activated data is blank
        -- AND u.INCIDENTNATURALID LIKE 'EP%'
    )
    -- select * from Source_d_incident limit 5;
        
         MERGE INTO rprt.tbl_d_incident tgt
         USING Source_d_incident src
         ON tgt.IncidentNaturalID = src.IncidentNaturalID AND tgt.OA_IS_ACTIVE = 1

         WHEN MATCHED AND tgt.OA_RECORDID <> src.OA_RECORDID THEN
                 UPDATE SET tgt.OA_IS_ACTIVE = 0, tgt.OA_REC_END_DATE = src.OA_REC_CREATED_DATE, tgt.OA_REC_PROCESSED_DATE = src.OA_REC_CREATED_DATE

         WHEN NOT MATCHED THEN
             INSERT (IncidentNaturalID, LoadID,DateSaved,TimeSaved,DateTimeSaved,HandlingUnit,CriticalityCode,StatusCode,IncidentTagCode,DispatchLevel,FinalDisposeCode,FK_DateSavedID,FK_DateSavedPoliceID,FK_TimeSavedID,FK_GeoID,FK_LocationID,
             FK_DispatcherID, 
             FK_CallerTakerID,
             FK_InitialServiceCodeID,FK_PriorityID,FinalServCode,VSS, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
             VALUES (src.IncidentNaturalID, NUll, src.DateSaved,src.TimeSaved,src.DateTimeSaved,src.HandlingUnit,src.CriticalityCode,src.StatusCode,src.IncidentTagCode,src.DispatchLevel,src.FinalDisposeCode,src.FK_DateSavedID,src.FK_DateSavedPoliceID,src.FK_TimeSavedID,src.FK_GeoID,src.FK_LocationID,
             src.FK_DispatcherID,
             src.FK_CallerTakerID,
             src.FK_InitialServiceCodeID, src.FK_PriorityID,src.FinalServCode,src.VSS, src.OA_REC_PROCESSED_DATE_NEW, src.OA_REC_CREATED_DATE, TO_TIMESTAMP('9999-12-31'), 1,src.OA_VERSION_NEW,src.OA_RECORDID)
         """)

])

                                                            
                                                                    #========================================
                                                                    # f STORM TABLES LOAD -approx xmins
                                                                    # =======================================


# f_incidentResponseOffice (please note this is a lenghty script)
run_parallel_queries_gold([ 

("rprt.tbl_f_incidentofficerresponse",
    #  -- Get max version and min created date for each incident
"""WITH version_data AS ( SELECT PK_IncidentOfficerResponse, IncidentNaturalID, MAX(OA_VERSION) AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate FROM rprt.tbl_f_incidentofficerresponse GROUP BY PK_IncidentOfficerResponse, IncidentNaturalID),
-- Prepare source data with new version info
RawSource AS(
	SELECT
		
		ua.ISR_NUMBER
		,ua.UNIT
		,ua.P_UNIT_TYPE1
		,ua.PLAN_NUMBER
		,ua.UA_DATE
		,ua.UA_TIME
		,ua.SEQ_NO
		,ua.OFFICER_PERS_ID1
		,ua.OFFICER_PERS_ID2
		,ua.OFFICER_PERS_ID3
		,ua.OFFICER_PERS_ID4
		,ua.OFFICER_PERS_ID5
		,ua.OFFICER_PERS_ID6
		,ua.OFFICER_PERS_ID7
		,ua.OFFICER_PERS_ID8
		,ua.OFFICER_PERS_ID9
		,ua.OFFICER_PERS_ID10
		,ua.OFFICER_PERS_ID11
		,ua.OFFICER_PERS_ID12
		,ua.RIDERS
		,ua.PRIORITY
		,ua.S_STATUS
		,ua.S_FUNCTION
		,ua.DISPATCH_LEVEL
		,ua.LONGITUDE
		,ua.LATITUDE
		,ua.MOD_DATE
		,ua.MOD_TIME
		
		,COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW
		,CURRENT_TIMESTAMP AS OA_REC_PROCESSED_DATE_NEW
		,CASE
			WHEN ua.ISR_NUMBER = v.IncidentNaturalID THEN v.min_createdDate
			ELSE CURRENT_TIMESTAMP
			END AS OA_REC_CREATED_DATE
		,CAST('9999-12-31' AS TIMESTAMP) AS OA_REC_END_DATE
		,1 AS OA_IS_ACTIVE
		,ua.OA_RECORDID
		,v.PK_IncidentOfficerResponse
		,ROW_NUMBER() OVER(PARTITION BY ua.OA_RECORDID  ORDER BY ua.UA_DATE) ISRcOUNT
	FROM rprt.tbl_d_unit_activity ua
	LEFT JOIN version_data v ON ua.ISR_NUMBER = v.IncidentNaturalID
)

-- SELECT * FROM RawSource 
-- WHERE ISRcOUNT >1
-- LIMIT 100;

 -- Unpivot officer data and filter relevant records
,UnpivotedData AS (
	SELECT
		rs.PK_IncidentOfficerResponse,
		ISR_NUMBER AS IncidentNaturalID,
		PersonnelID,
		UNIT AS UnitNo,
		P_UNIT_TYPE1 AS UnitType,
		PLAN_NUMBER AS PlanNumber,
		TRY_CAST(CONCAT(COALESCE(UA_DATE, '9999-12-31'), ' ',COALESCE(UA_TIME, '00:00:00')) AS TIMESTAMP) AS DatetimeUA,
		-- (CONCAT(UA_DATE, ' ', UA_TIME)) AS DatetimeUA,
		-- UA_TIME,
		-- UA_DATE,
		-- TRY_CAST(SEQ_NO AS INT) AS SEQNo,
		TRY_CAST(TRY_CAST(SEQ_NO AS FLOAT) AS INT)  AS SEQNo,
		-- TRY_CAST(RIDERS AS INT) AS Riders,
		TRY_CAST(TRY_CAST(RIDERS AS FLOAT) AS INT)  AS Riders,
		-- SEQ_NO,
		-- RIDERS,
		S_STATUS AS Status,
		CASE
		WHEN S_STATUS IN ('DP05', 'DP', 'DP05V') THEN 'Allocated'
		WHEN S_STATUS IN ('AR', 'AS','AR00','AR06','AR06D','AR06L','AR23','AR24','AR25') THEN 'Arrived'
		ELSE NULL
		END AS DateType,    -- JUST DROPED IN CL AND AR TO GET VALUSE IN THERE.
		S_FUNCTION AS Function,
		DISPATCH_LEVEL AS DispatchLevel,
		FIRST_VALUE(LONGITUDE) OVER(PARTITION BY ISR_NUMBER, UNIT, S_STATUS ORDER BY TO_TIMESTAMP(CONCAT(UA_DATE, ' ', UA_TIME)) ) AS Longitude,
		FIRST_VALUE(LATITUDE) OVER(PARTITION BY ISR_NUMBER, UNIT, S_STATUS ORDER BY TO_TIMESTAMP(CONCAT(UA_DATE, ' ', UA_TIME))	) AS Latitude,
		MOD_DATE AS DateMod,
		MOD_TIME AS TimeMod,
		rs.OA_REC_PROCESSED_DATE_NEW,
		rs.OA_REC_CREATED_DATE,
		rs.OA_REC_END_DATE,
		rs.OA_IS_ACTIVE,
		rs.OA_VERSION_NEW,
		rs.OA_RECORDID
	FROM RawSource rs
	LATERAL VIEW EXPLODE(ARRAY(
	OFFICER_PERS_ID1, OFFICER_PERS_ID2, OFFICER_PERS_ID3, OFFICER_PERS_ID4,
	OFFICER_PERS_ID5, OFFICER_PERS_ID6, OFFICER_PERS_ID7, OFFICER_PERS_ID8,
	OFFICER_PERS_ID9, OFFICER_PERS_ID10, OFFICER_PERS_ID11, OFFICER_PERS_ID12
	)) t AS PersonnelID
	WHERE ISR_NUMBER IS NOT NULL AND ISR_NUMBER != ''
	AND UNIT IS NOT NULL AND UNIT != ''
	AND PersonnelID IS NOT NULL AND PersonnelID > 0 AND PersonnelID != ''
	AND S_STATUS IN ('DP05', 'DP', 'DP05V')
	 -- AND DateType IS NOT NULL
)

--  SELECT OA_RECORDID, PK_IncidentOfficerResponse, * FROM UnpivotedData LIMIT 100;

 -- Group data to find min/max sequence numbers
,GroupedData AS (
	SELECT IncidentNaturalID, PersonnelID, UnitNo, DateType, MAX(SEQNo) AS Max_SEQ, MIN(SEQNo) AS Min_SEQ,
	MAX(CASE WHEN UnitType = 'RESPONSE' THEN 1 ELSE 0 END) AS IsResponse
	FROM UnpivotedData
	GROUP BY IncidentNaturalID, PersonnelID, UnitNo, DateType
)

--  SELECT * FROM GroupedData LIMIT 5;

 -- Calculate key timestamps and locations
,ProcessedData AS (
	SELECT
		ud.IncidentNaturalID,
		ud.PersonnelID,
		ud.UnitNo,
		MAX(gd.IsResponse) AS IsResponse,
		CASE WHEN MAX(gd.IsResponse) = 1 THEN 'RESPONSE'
		ELSE MAX(CASE WHEN NULLIF(ud.UnitType, '') IS NULL THEN NULL ELSE ud.UnitType END)
		END AS UnitType,
		ud.DateType,
		MIN(CASE WHEN ud.SEQNo = gd.Min_SEQ THEN ud.DatetimeUA ELSE TO_TIMESTAMP('9999-12-31') END) AS DateTimeUA,
		MAX(CASE WHEN ud.SEQNo = gd.Min_SEQ AND ud.DateType = 'Allocated' THEN ud.Latitude ELSE 0 END) AS First_Lat,
		MAX(CASE WHEN ud.SEQNo = gd.Min_SEQ AND ud.DateType = 'Allocated' THEN ud.Longitude ELSE 0 END) AS First_Long,
		MAX(CASE WHEN ud.SEQNo = gd.Max_SEQ AND ud.DateType = 'Arrived' THEN ud.Latitude ELSE 0 END) AS Last_Lat,
		MAX(CASE WHEN ud.SEQNo = gd.Max_SEQ AND ud.DateType = 'Arrived' THEN ud.Longitude ELSE 0 END) AS Last_Long,
		MAX(CASE WHEN ud.SEQNo = gd.Max_SEQ THEN ud.DateMod ELSE '1900-01-01' END) AS DateMod,
		MAX(CASE WHEN ud.SEQNo = gd.Max_SEQ THEN ud.TimeMod ELSE '00:00:00' END) AS TimeMod,
		ud.OA_REC_PROCESSED_DATE_NEW,
		ud.OA_REC_CREATED_DATE,
		ud.OA_REC_END_DATE,
		ud.OA_IS_ACTIVE,
		ud.OA_VERSION_NEW,
		ud.OA_RECORDID
	FROM UnpivotedData ud
	JOIN GroupedData gd ON ud.IncidentNaturalID = gd.IncidentNaturalID
	AND ud.PersonnelID = gd.PersonnelID
	AND ud.UnitNo = gd.UnitNo
	AND ud.DateType = gd.DateType
	GROUP BY ud.IncidentNaturalID, ud.PersonnelID, ud.UnitNo, gd.Max_SEQ, gd.Min_SEQ, ud.DateType,
	ud.OA_REC_PROCESSED_DATE_NEW, ud.OA_REC_CREATED_DATE, ud.OA_REC_END_DATE,
	ud.OA_IS_ACTIVE, ud.OA_VERSION_NEW, ud.OA_RECORDID
)

-- SELECT * FROM ProcessedData
-- where 1=1
-- and First_Lat <> 0
-- and First_Long <> 0
-- LIMIT 100;

-- Pivot to get allocated and arrived times
,DateCalculations AS (
	SELECT
		IncidentNaturalID,
		PersonnelID,
		UnitNo,
		UnitType,
		IsResponse,
		DateMod,
		TimeMod,
		MAX(CASE WHEN DateType = 'Allocated' THEN DateTimeUA END) AS DatetimeAllocated,
		MAX(CASE WHEN DateType = 'Arrived' THEN DateTimeUA END) AS DatetimeArrived,
		MAX(First_Lat) AS First_Lat,
		MAX(First_Long) AS First_Long,
		MAX(Last_Lat) AS Last_Lat,
		MAX(Last_Long) AS Last_Long,
		OA_REC_PROCESSED_DATE_NEW,
		OA_REC_CREATED_DATE,
		OA_REC_END_DATE,
		OA_IS_ACTIVE,
		OA_VERSION_NEW,
		OA_RECORDID
	FROM ProcessedData

	where 1=1
	-- and First_Lat <> 0
	-- and First_Long <> 0

	GROUP BY IncidentNaturalID, PersonnelID, UnitNo, UnitType, IsResponse,DateMod,TimeMod,
	OA_REC_PROCESSED_DATE_NEW, OA_REC_CREATED_DATE, OA_REC_END_DATE,
	OA_IS_ACTIVE, OA_VERSION_NEW, OA_RECORDID
	
)

--  SELECT * FROM DateCalculations LIMIT 100;

-- Join with dimension tables for all required fields
 ,EnrichedData AS (
	SELECT
		dc.IncidentNaturalID,
		dc.PersonnelID,
		dc.UnitNo,
		dc.UnitType,
		dc.IsResponse,
		dinc.DateTimeSaved,
		ts.TIMESTAMP7 AS DateTimeTransfer,
		dc.DatetimeAllocated,
		dc.DatetimeArrived,
		dc.First_Lat,
		dc.First_Long,
		dc.Last_Lat,
		dc.Last_Long,
		dc.DateMod,
		dc.TimeMod,
		dinc.FinalServCode,
		p.EmployeeNo AS OfficerEmployeeNo,
		sh.STAFF_MOVE_ID AS Off_Staff_Move_ID,
		dprt.PriorityID,
		dgeo.DPACode,
		dgeo.LPACode,
		COALESCE(dinc.IncidentNaturalID, '-1') AS FK_IncidentID,
		COALESCE(dd.DateID, -1) AS FK_DateSavedActualID,
		COALESCE(ddp.DateID, -1) AS FK_DateSavedPoliceID,
		COALESCE(dt.TimeID, -1) AS FK_TimeSavedID,
		COALESCE(dgeo.GeoNaturalID, '-1') AS FK_GeoID,
		COALESCE(dloc.LocationID, -1) AS FK_LocationID,
		COALESCE(dpct.PersonnelID, -1) AS FK_CallerTakerID,
		COALESCE(dpd.PersonnelID, -1) AS FK_DispatcherID,
		COALESCE(dsc.ServiceCodeNaturalID, '-1') AS FK_InitialServiceCodeID,
		COALESCE(dprt.PriorityID, -1) AS FK_PriorityID,
		COALESCE(dpsn.PersonnelID, -1) AS FK_OfficerID,
		COALESCE(dorg.OrgID, -1) AS FK_OrgID,                                     --replace it back when sorted with Lewis 
        -- COALESCE(dorg.PERSONNELNUMBER, -1) AS FK_OrgID,                              --this row is fake
		dc.OA_REC_PROCESSED_DATE_NEW,
		dc.OA_REC_CREATED_DATE,
		dc.OA_REC_END_DATE,
		dc.OA_IS_ACTIVE,
		dc.OA_VERSION_NEW,
		dc.OA_RECORDID,
					-- Calculate time differences and flags
  		CASE
  		  WHEN abs(unix_timestamp(date_format(dinc.DateTimeSaved, 'HH:mm:ss'), 'HH:mm:ss') - unix_timestamp('22:00:00', 'HH:mm:ss')) <
  		       abs(unix_timestamp(date_format(dinc.DateTimeSaved, 'HH:mm:ss'), 'HH:mm:ss') - unix_timestamp('16:00:00', 'HH:mm:ss')) AND
  		       abs(unix_timestamp(date_format(dinc.DateTimeSaved, 'HH:mm:ss'), 'HH:mm:ss') - unix_timestamp('22:00:00', 'HH:mm:ss')) <
  		       abs(unix_timestamp(date_format(dinc.DateTimeSaved, 'HH:mm:ss'), 'HH:mm:ss') - unix_timestamp('06:00:00', 'HH:mm:ss'))
  		  THEN abs(unix_timestamp(date_format(dinc.DateTimeSaved, 'HH:mm:ss'), 'HH:mm:ss') - unix_timestamp('22:00:00', 'HH:mm:ss')) / 60
  		  WHEN abs(unix_timestamp(date_format(dinc.DateTimeSaved, 'HH:mm:ss'), 'HH:mm:ss') - unix_timestamp('16:00:00', 'HH:mm:ss')) <
  		       abs(unix_timestamp(date_format(dinc.DateTimeSaved, 'HH:mm:ss'), 'HH:mm:ss') - unix_timestamp('22:00:00', 'HH:mm:ss')) AND
  		       abs(unix_timestamp(date_format(dinc.DateTimeSaved, 'HH:mm:ss'), 'HH:mm:ss') - unix_timestamp('16:00:00', 'HH:mm:ss')) <
  		       abs(unix_timestamp(date_format(dinc.DateTimeSaved, 'HH:mm:ss'), 'HH:mm:ss') - unix_timestamp('06:00:00', 'HH:mm:ss'))
  		  THEN abs(unix_timestamp(date_format(dinc.DateTimeSaved, 'HH:mm:ss'), 'HH:mm:ss') - unix_timestamp('16:00:00', 'HH:mm:ss')) / 60
  		  ELSE abs(unix_timestamp(date_format(dinc.DateTimeSaved, 'HH:mm:ss'), 'HH:mm:ss') - unix_timestamp('06:00:00', 'HH:mm:ss')) / 60
  		END AS MinProximityToShiftHandover,

		-- 0. Minutes from DateTimeSaved to TIMESTAMP7
		CASE 
			WHEN dc.UnitType <> 'RESPONSE' THEN 1 ELSE 0 END AS NonResponseUnitFlag,
		CASE 
  			WHEN dinc.DateTimeSaved > ts.TIMESTAMP7 THEN 0
  		ELSE (unix_timestamp(ts.TIMESTAMP7) - unix_timestamp(dinc.DateTimeSaved)) / 60
		END AS MinDiffSavedToTransfer,

		-- 1. Minutes from DateTimeSaved to DatetimeAllocated
		CASE 
			WHEN dinc.DateTimeSaved > dc.DatetimeAllocated THEN 0
		ELSE (unix_timestamp(dc.DatetimeAllocated) - unix_timestamp(dinc.DateTimeSaved)) / 60
		END AS MinDiffSavedToAllocated,

		-- 2. Minutes from DateTimeSaved to DatetimeArrived
		CASE 
			WHEN dinc.DateTimeSaved > dc.DatetimeArrived THEN 0
		ELSE (unix_timestamp(dc.DatetimeArrived) - unix_timestamp(dinc.DateTimeSaved)) / 60
		END AS MinDiffSavedToArrived,

		-- 3. Minutes from TIMESTAMP7 to DatetimeAllocated
		CASE 
			WHEN ts.TIMESTAMP7 > dc.DatetimeAllocated THEN 0
		ELSE (unix_timestamp(dc.DatetimeAllocated) - unix_timestamp(ts.TIMESTAMP7)) / 60
		END AS MinDiffTransferToAllocated,

		-- 4. Minutes from DatetimeAllocated to DatetimeArrived
		CASE 
			WHEN dc.DatetimeAllocated > dc.DatetimeArrived THEN 0
		ELSE (unix_timestamp(dc.DatetimeArrived) - unix_timestamp(dc.DatetimeAllocated)) / 60
		END AS MinDiffTransferToArrived,

		-- 5. Minutes from DatetimeAllocated to Target Response Time
		CASE 
  			WHEN dc.DatetimeAllocated > from_unixtime(unix_timestamp(dinc.DateTimeSaved) + TRY_CAST(dprt.TargetReponseTime AS INT) * 60)
  		THEN 0
  		ELSE (unix_timestamp(from_unixtime(unix_timestamp(dinc.DateTimeSaved) + TRY_CAST(dprt.TargetReponseTime AS INT) * 60)) - unix_timestamp(dc.DatetimeAllocated)) / 60
  		END AS MinDiffAllocatedToTarget,


		-- 6. Missed Response Flag
		CASE
			WHEN dinc.DateTimeSaved IS NOT NULL AND dprt.TargetReponseTime IS NOT NULL AND
			(unix_timestamp(COALESCE(dc.DatetimeArrived, CURRENT_TIMESTAMP)) - unix_timestamp(dinc.DateTimeSaved)) / 60 > dprt.TargetReponseTime
		THEN 'Yes' ELSE 'No'
		END AS MissedResponseFlag,

		-- 7. Missed Allocation Flag
		CASE
			WHEN dinc.DateTimeSaved IS NOT NULL AND dprt.TargetAllocationTime IS NOT NULL AND
			(unix_timestamp(COALESCE(dc.DatetimeAllocated, CURRENT_TIMESTAMP)) - unix_timestamp(dinc.DateTimeSaved)) / 60 > dprt.TargetAllocationTime
		THEN 'Yes' ELSE 'No'
		END AS MissedAllocationFlag

	FROM DateCalculations dc
	LEFT JOIN rprt.tbl_d_storm_isr_timestamps ts ON dc.IncidentNaturalID = ts.ISR_NO
	LEFT JOIN rprt.tbl_d_incident dinc ON dc.IncidentNaturalID = dinc.IncidentNaturalID
	LEFT JOIN rprt.tbl_d_priority dprt ON dinc.FK_PriorityID = dprt.PriorityID
	LEFT JOIN rprt.tbl_d_personnel dpsn ON dc.PersonnelID = CAST(dpsn.PersonnelID AS STRING)
	LEFT JOIN rprt.tbl_d_geo dgeo ON dinc.FK_GeoID = CAST(dgeo.GeoNaturalID AS STRING)
	LEFT JOIN rprt.tbl_d_org dorg ON dpsn.EmployeeNo = CAST(dorg.PERSONNELNUMBER AS STRING)   -- THIS DIM HAS TO BE CREATED 1ST Also there is not column here as OrgID check row 528. Test replace with PERSONNEL_NUMBER 
	LEFT JOIN rprt.tbl_d_location dloc ON dinc.FK_LocationID = dloc.LocationID
	LEFT JOIN rprt.tbl_d_personnel dpct ON dinc.FK_CallerTakerID = dpct.PersonnelID
	LEFT JOIN rprt.tbl_d_personnel dpd ON dinc.FK_DispatcherID = dpd.PersonnelID
	LEFT JOIN rprt.tbl_d_servicecode dsc ON dinc.FK_InitialServiceCodeID = dsc.ServiceCodeNaturalID
	LEFT JOIN rprt.tbl_d_time dt ON dinc.FK_TimeSavedID = dt.TimeID
	LEFT JOIN rprt.tbl_d_date dd ON dinc.FK_DateSavedID = dd.DateID
	LEFT JOIN rprt.tbl_d_date ddp ON dinc.FK_DateSavedPoliceID = ddp.DateID
	LEFT JOIN rprt.tbl_d_personnel p ON p.PersonnelID = dc.PersonnelID
	LEFT JOIN rprt.tbl_d_staff_history sh ON sh.PERSONNELNUMBER = p.EmployeeNo AND COALESCE(DATE(dc.DatetimeAllocated), DATE(dc.DatetimeArrived)) BETWEEN sh.StartDate AND sh.EndDate

	where 1=1
	-- and dc.IncidentNaturalID = 'EP-20070208-0680'  used as test
	and dc.First_Lat <> 0
	and dc.First_Long <> 0
)

-- SELECT * FROM EnrichedData 
-- where 1=1
-- and IncidentNaturalID = 'EP-20070208-0680'
-- 	and First_Lat <> 0
-- 	and First_Long <> 0
-- LIMIT 100;


-- Calculate distance traveled
,SourceWithDistance AS (
	SELECT
		*,
		CASE 
			WHEN (First_Lat = 0 OR First_Long = 0 OR Last_Lat = 0 OR Last_Long = 0) THEN NULL
		ELSE SQRT(POWER((First_Long - Last_Long), 2) + POWER((First_Lat - Last_Lat), 2)) / 1609.34
		END AS DistancedTravelled
	FROM EnrichedData
)

-- SELECT * FROM SourceWithDistance LIMIT 5;

-- -- Determine arrival order
,ArrivalOrder AS (
	SELECT
		IncidentNaturalID,
		UnitNo,
		DateArrived,
		TimeArrived,
		DateAllocated,
		TimeAllocated,
		-- Arrival order per unit
		SUM(CASE WHEN DateArrived IS NOT NULL THEN 1 ELSE 0 END) 
		OVER (PARTITION BY IncidentNaturalID ORDER BY DateArrived ASC, TimeArrived ASC, UnitNo ASC) AS ArrivalOrder,

		-- Allocation order per unit
		SUM(CASE WHEN DateAllocated IS NOT NULL THEN 1 ELSE 0 END) 
		OVER (PARTITION BY IncidentNaturalID ORDER BY DateAllocated ASC, TimeAllocated ASC, UnitNo ASC) AS AllocationOrder,

		-- Max arrival order per incident
		MAX(SUM(CASE WHEN DateArrived IS NOT NULL THEN 1 ELSE 0 END) 
		OVER (PARTITION BY IncidentNaturalID ORDER BY DateArrived ASC, TimeArrived ASC, UnitNo ASC))
		OVER (PARTITION BY IncidentNaturalID) AS MaxArrivalOrder,

		-- Max allocation order per incident
		MAX(SUM(CASE WHEN DateAllocated IS NOT NULL THEN 1 ELSE 0 END) 
		OVER (PARTITION BY IncidentNaturalID ORDER BY DateAllocated ASC, TimeAllocated ASC, UnitNo ASC))
		OVER (PARTITION BY IncidentNaturalID) AS MaxAllocationOrder,
		ROW_NUMBER() OVER (PARTITION BY OA_RECORDID ORDER BY IncidentNaturalID DESC) AS EnrichedData_duplicate

		FROM (SELECT DISTINCT
		IncidentNaturalID,
		UnitNo,
		DATE(DatetimeArrived) AS DateArrived,
		DatetimeArrived AS TimeArrived,
		TO_TIMESTAMP(date_format(DatetimeArrived, 'HH:mm:ss'), 'HH:mm:ss') AS TimeArrived2,

		DATE(DatetimeAllocated) AS DateAllocated,
		DatetimeAllocated AS TimeAllocated,
		TO_TIMESTAMP(date_format(DatetimeAllocated, 'HH:mm:ss'), 'HH:mm:ss') AS TimeAllocated2,
		OA_RECORDID
        
	FROM EnrichedData
) T
) 

-- SELECT * FROM ArrivalOrder LIMIT 10;

-- Final source data for merge
,FinalSource AS (
	SELECT
		CONCAT(ed.IncidentNaturalID, ':', ed.UnitNo, ':', CAST(ed.PersonnelID AS STRING)) AS PK_IncidentOfficerResponse,
		ed.*,
		ao.ArrivalOrder,
		ao.MaxArrivalOrder,
		ao.AllocationOrder,
		ao.MaxAllocationOrder,
		CASE WHEN ao.ArrivalOrder = 1 AND ao.DateArrived IS NOT NULL THEN 'Yes' ELSE 'No' END AS FirstArrived,
		CASE WHEN ao.AllocationOrder = 1 AND ao.DateAllocated IS NOT NULL THEN 'Yes' ELSE 'No' END AS FirstAllocated,
		COALESCE(d.DistanceID, -1) AS FK_DistanceID
		
	FROM SourceWithDistance ed
	JOIN ArrivalOrder ao ON ed.IncidentNaturalID = ao.IncidentNaturalID AND ed.UnitNo = ao.UnitNo
	LEFT JOIN rprt.tbl_d_distance d ON 	CASE WHEN ed.DistancedTravelled IS NULL THEN NULL ELSE ed.DistancedTravelled END >= d.MinDistance
	AND CASE WHEN ed.DistancedTravelled IS NULL THEN NULL ELSE ed.DistancedTravelled END < d.MaxDistance
    WHERE ao.EnrichedData_duplicate =1
)


---SELECT * FROM FinalSource 
-- -- where IncidentNaturalID in ('EP-20041230-0556')
-- -- and PersonnelID in ('7269')
--- LIMIT 10;


-- -- MERGE statement to update target table with all columns
MERGE INTO rprt.tbl_f_IncidentOfficerResponse AS tgt
	USING FinalSource AS src
	ON tgt.IncidentNaturalID = src.IncidentNaturalID AND tgt.OA_RECORDID = src.OA_RECORDID AND tgt.UnitNo = src.UnitNo AND tgt.PersonnelID = src.PersonnelID AND tgt.OA_IS_ACTIVE = 1

WHEN MATCHED AND tgt.OA_RECORDID <> src.OA_RECORDID THEN
	UPDATE SET
		tgt.OA_IS_ACTIVE = 0,
		tgt.OA_REC_END_DATE = src.OA_REC_CREATED_DATE,
		tgt.OA_REC_PROCESSED_DATE = src.OA_REC_CREATED_DATE
WHEN NOT MATCHED THEN
	INSERT ( PK_IncidentOfficerResponse, IncidentNaturalID, UnitNo, PersonnelID, LoadID, UnitType, ArrivalOrder, FirstArrived, MaxArrivalOrder, MinProximityToShiftHandover, NonResponseUnitFlag
		, DateTransfer, TimeTransfer, DateAllocated, TimeAllocated, DateArrived, TimeArrived, MinDiffSavedToTransfer, MinDiffSavedToAllocated, MinDiffSavedToArrived, MinDiffTransferToAllocated, MinDiffTransferToArrived
		, MinDiffAllocatedToTarget, MissedResponseFlag, MissedAllocationFlag, PriorityID, DistancedTravelled, First_Lat, First_Long, Last_Lat, Last_Long, FK_IncidentID, FK_DateSavedActualID, FK_DateSavedPoliceID, FK_TimeSavedID
		, FK_GeoID, FK_LocationID, FK_CallerTakerID, FK_DispatcherID, FK_InitialServiceCodeID, FK_PriorityID, FK_OfficerID, FK_DistanceID, AllocationOrder, MaxAllocationOrder, FirstAllocated, FinalServCode, OfficerEmployeeNo, Off_Staff_Move_ID
		, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)
	VALUES ( src.PK_IncidentOfficerResponse, src.IncidentNaturalID, src.UnitNo, TRY_CAST(TRY_CAST(src.PersonnelID AS FLOAT) AS INT), NULL, COALESCE(src.UnitType, '')
		, src.ArrivalOrder, src.FirstArrived, src.MaxArrivalOrder, src.MinProximityToShiftHandover, src.NonResponseUnitFlag, DATE(src.DateTimeTransfer), src.DateTimeTransfer, DATE(src.DatetimeAllocated), src.DatetimeAllocated
		, DATE(src.DatetimeArrived), src.DatetimeArrived, CAST(src.MinDiffSavedToTransfer AS DECIMAL(18,6)), CAST(src.MinDiffSavedToAllocated AS DECIMAL(18,6)), CAST(src.MinDiffSavedToArrived AS DECIMAL(18,6))
		, CAST(src.MinDiffTransferToAllocated AS DECIMAL(18,6)), CAST(src.MinDiffTransferToArrived AS DECIMAL(18,6)), CAST(src.MinDiffAllocatedToTarget AS DECIMAL(18,6)), src.MissedResponseFlag, src.MissedAllocationFlag, src.PriorityID
		, CAST(src.DistancedTravelled AS DECIMAL(18,6)), CAST(src.First_Lat AS DECIMAL(18,6)), CAST(src.First_Long AS DECIMAL(18,6)), CAST(src.Last_Lat AS DECIMAL(18,6)), CAST(src.Last_Long AS DECIMAL(18,6)), src.FK_IncidentID
		, src.FK_DateSavedActualID, src.FK_DateSavedPoliceID, src.FK_TimeSavedID, src.FK_GeoID, src.FK_LocationID, src.FK_CallerTakerID, src.FK_DispatcherID, src.FK_InitialServiceCodeID, src.FK_PriorityID, src.FK_OfficerID, src.FK_DistanceID
		, src.AllocationOrder, src.MaxAllocationOrder, src.FirstAllocated, src.FinalServCode, src.OfficerEmployeeNo, src.Off_Staff_Move_ID
		, src.OA_REC_PROCESSED_DATE_NEW, src.OA_REC_CREATED_DATE, src.OA_REC_END_DATE, 1, src.OA_VERSION_NEW, src.OA_RECORDID)


    """)

])

# f_incident
run_parallel_queries_gold([ 

("rprt.tbl_f_incident",
       """
WITH
version_data AS (
  SELECT INCIDENTNATURALID AS ISR_NO, MAX(OA_VERSION)   AS max_version, MIN(OA_REC_CREATED_DATE) AS min_createdDate FROM rprt.tbl_f_incident GROUP BY INCIDENTNATURALID
),

-- 2) First dispatched unit per ISR
FirstDispatchedUnits AS (
  SELECT
    X.ISR_NUMBER AS ISR_NO,
    MIN(UA.UNIT) AS FirstUnitDispatched,
    MIN(TRY_CAST(UA.LONGITUDE AS DECIMAL(19,5))) AS Disp_Long,
    MIN(TRY_CAST(UA.LATITUDE  AS DECIMAL(19,5))) AS Disp_Lat
  FROM (
    SELECT ISR_NUMBER, MIN(SEQ_NO) AS SEQ_NUMBER
    FROM temp_tbl_storm_unit_activity
    WHERE S_STATUS IN ('DP05', 'DP', 'DP05V')
    GROUP BY ISR_NUMBER
  ) X
  INNER JOIN temp_tbl_storm_unit_activity UA
    ON X.SEQ_NUMBER = UA.SEQ_NO
   AND X.ISR_NUMBER = UA.ISR_NUMBER
  GROUP BY X.ISR_NUMBER
)

-- select * from FirstDispatchedUnits limit 10;

-- 3) First arrived unit per ISR
,FirstArrivedUnits AS (
  SELECT
    X.ISR_NUMBER AS ISR_NO,
    MIN(UA.UNIT) AS FirstUnitArrived
  FROM (
    SELECT ISR_NUMBER, MIN(SEQ_NO) AS SEQ_NUMBER
    FROM temp_tbl_storm_unit_activity
    WHERE S_STATUS IN ('AR','AR00','AR06','AR06D','AR06L','AR23','AR24','AR25')
    GROUP BY ISR_NUMBER
  ) X
  INNER JOIN temp_tbl_storm_unit_activity UA
    ON X.SEQ_NUMBER = UA.SEQ_NO
   AND X.ISR_NUMBER = UA.ISR_NUMBER
  GROUP BY X.ISR_NUMBER
)

-- select * from FirstArrivedUnits limit 10;

-- 4) Latest active personnel record per BadgeNo (remove duplicates)
,LatestPersonnel AS (
  SELECT *
  FROM (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY BADGENO ORDER BY DATESTART DESC) AS rn
    FROM rprt.tbl_d_personnel
    WHERE active = 1 AND (badgeno <> 0 OR badgeno IS NOT NULL)
  ) a
  WHERE rn = 1
)

-- select * from LatestPersonnel limit 10;

-- 5) Main source (ISR + timestamps + unit-activity + version fields)
,Source_f_Data AS (
  SELECT
    I.ISR_NO                       AS IncidentNaturalID,

    -- Status date/times
    I.STATUS5_DATE                 AS DateAllocated,
    I.STATUS5_TIME                 AS TimeAllocated,
    I.STATUS4_DATE                 AS DateAssigned,
    I.STATUS4_TIME                 AS TimeAssigned,
    I.STATUS6_DATE                 AS DateArrived,
    I.STATUS6_TIME                 AS TimeArrived,

    -- Transfer date/time (date + 'HH:mm:ss' string)
    CASE WHEN COALESCE(IST.TIMESTAMP7, '') = '' THEN NULL
         ELSE TRY_CAST(IST.TIMESTAMP7 AS DATE)
    END                            AS TransferDate,
    CASE WHEN COALESCE(IST.TIMESTAMP7, '') = '' THEN NULL
         ELSE DATE_FORMAT(TRY_CAST(IST.TIMESTAMP7 AS TIMESTAMP), 'HH:mm:ss')
    END                            AS TransferTime,

    -- ISR fields present in the proc
    I.DISPATCH_LEVEL               AS DispatchedLevel,
    I.FINAL_SERV_CODE              AS FinalServCode,
    I.P_ORIGIN                     AS Origin,

    -- First unit derived fields
    AR_UA.FirstUnitArrived,
    DP_UA.FirstUnitDispatched,

    -- Distance travelled (only if same unit dispatched & arrived, coords present)
    CASE
      WHEN AR_UA.FirstUnitArrived = DP_UA.FirstUnitDispatched
       AND DP_UA.Disp_Long IS NOT NULL AND DP_UA.Disp_Lat IS NOT NULL
       AND I.LONGITUDE IS NOT NULL AND I.LATITUDE IS NOT NULL
       THEN SQRT(
              POWER(TRY_CAST(I.LONGITUDE AS DECIMAL(19,5)) - DP_UA.Disp_Long, 2) +
              POWER(TRY_CAST(I.LATITUDE  AS DECIMAL(19,5)) - DP_UA.Disp_Lat,  2)
            ) / 1609.34
      ELSE NULL
    END                            AS DistanceTravelled,

    -- FK seeds from ISR
    I.ISR_NO                       AS FK_IncidentID,
    COALESCE(CAST(DATE_FORMAT(I.STATUS3_DATE, 'yyyyMMdd') AS INT), -1) AS FK_DateSavedActualID,
    I.STATUS3_DATE,
    I.STATUS3_TIME,
    CASE
      WHEN I.STATUS3_DATE IS NULL THEN NULL
      WHEN (I.STATUS3_TIME > '00:00:00' AND I.STATUS3_TIME < '06:00:00')
        THEN COALESCE(CAST(DATE_FORMAT(DATE_SUB(I.STATUS3_DATE, 1), 'yyyyMMdd') AS INT), -1)
      ELSE COALESCE(CAST(DATE_FORMAT(I.STATUS3_DATE, 'yyyyMMdd') AS INT), -1)
    END                            AS FK_DateSavedPoliceID,
    COALESCE(CAST(REPLACE(I.STATUS3_TIME, ':','') AS INT), -1) AS FK_TimeSavedID,

    I.LEVEL5                       AS FK_GeoID,
    I.LOC_ID                       AS FK_LocationID,
    I.OFF_BADGE_NO1                AS FK_OfficerID,
    I.DP_ID                        AS FK_DispatcherID,
    I.CREA_PERSONNEL_ID            AS FK_CallerTakerID,

    -- Priority (-1 when blank)
    CASE
      WHEN COALESCE(I.PRIORITY, '') = '' THEN -1
      ELSE TRY_CAST(I.PRIORITY AS INT)
    END                            AS FK_PriorityID,

    I.INITIAL_SERV_CODE            AS FK_InitialServiceCodeID,
    I.HANDLING_UNIT                AS HandlingUnit,
    I.SUPER_BADGE_NO               AS SupervisorPIN,
    I.MOD_LOC                      AS ModifiedLocation,
    I.MOD_SERV_CODE                AS ModifiedServCode,
    I.ORIGINAL_PRIORITY            AS Original_Priority,

    -- -- Versioning (same as proc intent)
    COALESCE(v.max_version, 0) + 1 AS OA_VERSION_NEW,
    CURRENT_TIMESTAMP()            AS OA_REC_PROCESSED_DATE_NEW,
    CASE WHEN I.ISR_NO = v.ISR_NO THEN v.min_createdDate ELSE CURRENT_TIMESTAMP() END AS OA_REC_CREATED_DATE,
    I.OA_RECORDID
       

  FROM rprt.tbl_d_storm_isr I
  LEFT JOIN version_data      v   ON I.ISR_NO = v.ISR_NO
  LEFT JOIN rprt.tbl_d_storm_isr_timestamps IST ON IST.ISR_NO = I.ISR_NO
  LEFT JOIN FirstDispatchedUnits DP_UA         ON I.ISR_NO = DP_UA.ISR_NO
  LEFT JOIN FirstArrivedUnits   AR_UA          ON I.ISR_NO = AR_UA.ISR_NO
  WHERE I.ISR_NO IS NOT NULL AND I.ISR_NO <> '0'
)

-- select * limit 100;

-- 6) Final projection with dimensions, minute-diffs, flags, and version fields
,f_incident AS (
  SELECT DISTINCT
    src.IncidentNaturalID,
    src.DateAllocated,
    src.TimeAllocated,
    src.DateAssigned,
    src.TimeAssigned,
    src.DateArrived,
    src.TimeArrived,
    src.TransferDate,
    src.TransferTime,
    src.DispatchedLevel,
    src.FinalServCode,
    src.Origin,
    src.FirstUnitArrived,
    src.FirstUnitDispatched,

    -- Dimension lookups
    COALESCE(dinc.IncidentNaturalID, '-1') AS FK_IncidentID,
    COALESCE(dgeo.GeoNaturalID,  '-1')     AS FK_GeoID,
    COALESCE(dloc.LocationID,    -1)       AS FK_LocationID,
    COALESCE(dpo.PersonnelID,    -1)       AS FK_OfficerID,
    COALESCE(dpd.PersonnelID,    -1)       AS FK_DispatcherID,
    COALESCE(dpct.PersonnelID,   -1)       AS FK_CallerTakerID,
    COALESCE(ddi.DistanceID,     -1)       AS FK_DistanceID,
    COALESCE(dprt.PriorityID,    -1)       AS FK_PriorityID,
    COALESCE(dsc.ServiceCodeNaturalID, '-1') AS FK_InitialServiceCodeID,

    src.SupervisorPIN,
    src.ModifiedLocation,
    src.ModifiedServCode,
    src.HandlingUnit,
    src.Original_Priority,

    -- Minutes: Saved -> Transfer
    CASE
      WHEN src.STATUS3_DATE IS NULL OR src.STATUS3_TIME IS NULL
           OR src.TransferDate IS NULL OR src.TransferTime IS NULL THEN NULL
      WHEN to_timestamp(concat(cast(src.STATUS3_DATE as string), ' ', cast(src.STATUS3_TIME as string))) >
           to_timestamp(concat(cast(src.TransferDate as string),  ' ', cast(src.TransferTime as string))) THEN 0
      ELSE (
        unix_timestamp(to_timestamp(concat(cast(src.TransferDate as string),  ' ', cast(src.TransferTime as string)))) -
        unix_timestamp(to_timestamp(concat(cast(src.STATUS3_DATE as string), ' ', cast(src.STATUS3_TIME as string))))
      ) / 60.0
    END AS MinDiff_SavedtoTransfer,

    -- Minutes: Saved -> Arrived
    CASE
      WHEN src.STATUS3_DATE IS NULL OR src.STATUS3_TIME IS NULL
           OR src.DateArrived IS NULL OR src.TimeArrived IS NULL THEN NULL
      WHEN to_timestamp(concat(cast(src.STATUS3_DATE as string), ' ', cast(src.STATUS3_TIME as string))) >
           to_timestamp(concat(cast(src.DateArrived as string),  ' ', cast(src.TimeArrived as string))) THEN 0
      ELSE (
        unix_timestamp(to_timestamp(concat(cast(src.DateArrived as string),  ' ', cast(src.TimeArrived as string)))) -
        unix_timestamp(to_timestamp(concat(cast(src.STATUS3_DATE as string), ' ', cast(src.STATUS3_TIME as string))))
      ) / 60.0
    END AS MinDiff_SavedtoArrived,

    -- Minutes: Transfer -> Allocation
    CASE
      WHEN src.TransferDate IS NULL OR src.TransferTime IS NULL
           OR src.DateAllocated IS NULL OR src.TimeAllocated IS NULL THEN NULL
      WHEN to_timestamp(concat(cast(src.TransferDate as string),  ' ', cast(src.TransferTime as string))) >
           to_timestamp(concat(cast(src.DateAllocated as string), ' ', cast(src.TimeAllocated as string))) THEN 0
      ELSE (
        unix_timestamp(to_timestamp(concat(cast(src.DateAllocated as string), ' ', cast(src.TimeAllocated as string)))) -
        unix_timestamp(to_timestamp(concat(cast(src.TransferDate as string),  ' ', cast(src.TransferTime as string))))
      ) / 60.0
    END AS MinDiff_TransfertoAllocation,

    -- Minutes: Allocation -> Arrived
    CASE
      WHEN src.DateAllocated IS NULL OR src.TimeAllocated IS NULL
           OR src.DateArrived   IS NULL OR src.TimeArrived   IS NULL THEN NULL
      WHEN to_timestamp(concat(cast(src.DateAllocated as string), ' ', cast(src.TimeAllocated as string))) >
           to_timestamp(concat(cast(src.DateArrived   as string), ' ', cast(src.TimeArrived   as string))) THEN 0
      ELSE (
        unix_timestamp(to_timestamp(concat(cast(src.DateArrived   as string), ' ', cast(src.TimeArrived   as string)))) -
        unix_timestamp(to_timestamp(concat(cast(src.DateAllocated as string), ' ', cast(src.TimeAllocated as string))))
      ) / 60.0
    END AS MinDiff_AllocatedtoArrived,

    -- Minutes: Saved -> Dispatched
    CASE
      WHEN src.STATUS3_DATE IS NULL OR src.STATUS3_TIME IS NULL
           OR src.DateAllocated IS NULL OR src.TimeAllocated IS NULL THEN NULL
      WHEN to_timestamp(concat(cast(src.STATUS3_DATE as string), ' ', cast(src.STATUS3_TIME as string))) >
           to_timestamp(concat(cast(src.DateAllocated as string), ' ', cast(src.TimeAllocated as string))) THEN 0
      ELSE (
        unix_timestamp(to_timestamp(concat(cast(src.DateAllocated as string), ' ', cast(src.TimeAllocated as string)))) -
        unix_timestamp(to_timestamp(concat(cast(src.STATUS3_DATE as string), ' ', cast(src.STATUS3_TIME as string))))
      ) / 60.0
    END AS MinDiff_SavedtoDispatched,

    -- Missed flags with original guardrail
    CASE
      WHEN src.STATUS3_DATE IS NULL OR dprt.TargetReponseTime IS NULL THEN NULL
      WHEN COALESCE(src.FK_PriorityID, -1) NOT IN (1,2,3,4) THEN 'No'
      WHEN (
        unix_timestamp(to_timestamp(concat(cast(coalesce(src.DateArrived,  current_date)   as string), ' ',
                                           cast(coalesce(src.TimeArrived, current_timestamp) as string)))) -
        unix_timestamp(to_timestamp(concat(cast(src.STATUS3_DATE as string), ' ',
                                           cast(src.STATUS3_TIME as string))))
      ) / 60.0 > dprt.TargetReponseTime
      THEN 'Yes' ELSE 'No'
    END AS MissedResponseFlag,

    CASE
      WHEN src.STATUS3_DATE IS NULL OR dprt.TargetAllocationTime IS NULL THEN NULL
      WHEN COALESCE(src.FK_PriorityID, -1) NOT IN (1,2,3,4) THEN 'No'
      WHEN (
        unix_timestamp(to_timestamp(concat(cast(coalesce(src.DateAllocated,  current_date)   as string), ' ',
                                           cast(coalesce(src.TimeAllocated, current_timestamp) as string)))) -
        unix_timestamp(to_timestamp(concat(cast(src.STATUS3_DATE as string), ' ',
                                           cast(src.STATUS3_TIME as string))))
      ) / 60.0 > dprt.TargetAllocationTime
      THEN 'Yes' ELSE 'No'
    END AS MissedAllocationFlag,

    -- TravelTimeAvailable = max(0, TargetReponseTime - MinDiff_SavedtoDispatched)
    CASE
      WHEN dprt.TargetReponseTime IS NULL OR MinDiff_SavedtoDispatched IS NULL THEN NULL
      WHEN dprt.TargetReponseTime < MinDiff_SavedtoDispatched THEN 0
      ELSE dprt.TargetReponseTime - MinDiff_SavedtoDispatched
    END AS TravelTimeAvailable,

    src.DistanceTravelled,

    -- Date/Time FKs
    COALESCE(dd.DateID,  -1) AS FK_DateSavedActualID,
    COALESCE(ddp.DateID, -1) AS FK_DateSavedPoliceID,
    COALESCE(dt.TimeID,  -1) AS FK_TimeSavedID,

    -- Handler/dispatcher numbers + staff move IDs
    COALESCE(p.EmployeeNo,  '-1') AS HandlerEmployeeNo,
    COALESCE(dp.EmployeeNo, '-1') AS DispatcherEmployeeNo,
    COALESCE(sh.STAFF_MOVE_ID,  '-1') AS Handler_Staff_Move_ID,
    COALESCE(shd.STAFF_MOVE_ID, '-1') AS Dispatcher_Staff_Move_ID,

    -- Versioning
    src.OA_VERSION_NEW,
    src.OA_REC_PROCESSED_DATE_NEW,
    src.OA_REC_CREATED_DATE,
    src.OA_RECORDID

  FROM Source_f_Data src
  LEFT JOIN rprt.tbl_d_incident      dinc ON src.FK_IncidentID        = dinc.IncidentNaturalID
  LEFT JOIN rprt.tbl_d_priority      dprt ON src.FK_PriorityID        = dprt.PriorityID
  LEFT JOIN rprt.tbl_d_geo           dgeo ON src.FK_GeoID             = dgeo.GeoNaturalID
  LEFT JOIN rprt.tbl_d_location      dloc ON src.FK_LocationID        = dloc.LocationID
  LEFT JOIN LatestPersonnel          dpo  ON src.FK_OfficerID         = dpo.BadgeNo
  LEFT JOIN rprt.tbl_d_personnel     dpct ON src.FK_CallerTakerID     = dpct.PersonnelID
  LEFT JOIN rprt.tbl_d_personnel     dpd  ON src.FK_DispatcherID      = dpd.PersonnelID
  LEFT JOIN rprt.tbl_d_servicecode   dsc  ON src.FK_InitialServiceCodeID = dsc.ServiceCodeNaturalID
  LEFT JOIN rprt.tbl_d_time          dt   ON src.FK_TimeSavedID       = dt.TimeID
  LEFT JOIN rprt.tbl_d_date          dd   ON src.FK_DateSavedActualID = dd.DateID
  LEFT JOIN rprt.tbl_d_date          ddp  ON src.FK_DateSavedPoliceID = ddp.DateID
  LEFT JOIN rprt.tbl_d_distance      ddi  ON src.DistanceTravelled >= ddi.MinDistance AND src.DistanceTravelled <  ddi.MaxDistance
  LEFT JOIN rprt.tbl_d_personnel     p    ON p.PersonnelID            = src.FK_CallerTakerID
  LEFT JOIN rprt.tbl_d_staff_history sh   ON sh.PERSONNELNUMBER = p.EmployeeNo AND TRY_CAST(TRY_CAST(src.FK_DateSavedPoliceID AS VARCHAR(8)) AS DATE) BETWEEN sh.StartDate AND sh.EndDate
  LEFT JOIN rprt.tbl_d_personnel     dp   ON dp.PersonnelID           = src.FK_DispatcherID
  LEFT JOIN rprt.tbl_d_staff_history shd  ON shd.PERSONNELNUMBER = dp.EmployeeNo AND src.DateAllocated BETWEEN shd.StartDate AND shd.ENDDATE
)

-- select * from f_incident limit 50;

-- 7) MERGE (same behavior as your proc snippet)

MERGE INTO rprt.tbl_f_incident AS t
USING f_incident AS s
ON  t.IncidentNaturalID = s.IncidentNaturalID
AND t.OA_IS_ACTIVE = 1

WHEN MATCHED AND t.OA_RECORDID <> s.OA_RECORDID THEN
  UPDATE SET
    t.OA_IS_ACTIVE          = 0,
    t.OA_REC_END_DATE       = s.OA_REC_CREATED_DATE,
    t.OA_REC_PROCESSED_DATE = s.OA_REC_CREATED_DATE

WHEN NOT MATCHED THEN
  INSERT (IncidentNaturalID, LoadID, DateAllocated, TimeAllocated, DateAssigned, TimeAssigned, DateArrived, TimeArrived, TransferDate, TransferTime, DispatchedLevel, ComplAddInfo, FinalServCode, 
  Origin, Description, FirstUnitArrived, FirstUnitDispatched, FK_IncidentID, FK_GeoID, FK_LocationID, FK_OfficerID, FK_DispatcherID, FK_CallerTakerID, FK_DistanceID, FK_PriorityID, FK_InitialServiceCodeID, 
  SupervisorPIN, DisposedURN, ModifiedLocation, ModifiedServCode, HandlingUnit, MinDiff_SavedtoTransfer, MinDiff_SavedtoArrived, MinDiff_TransfertoAllocation, MinDiff_AllocatedtoArrived, MinDiff_SavedtoDispatched, 
  TravelTimeAvailable, DistanceTravelled, MissedResponseFlag, MissedAllocationFlag, FK_DateSavedActualID, FK_DateSavedPoliceID, FK_TimeSavedID, AvailableUnitsDPA, AvailableUnitsLPA, HandlerEmployeeNo, 
  Handler_Staff_Move_ID, Dispatcher_Staff_Move_ID, DispatcherEmployeeNo, Original_Priority, OA_REC_PROCESSED_DATE, OA_REC_CREATED_DATE, OA_REC_END_DATE, OA_IS_ACTIVE, OA_VERSION, OA_RECORDID)

  VALUES (s.IncidentNaturalID, NULL,s.DateAllocated, s.TimeAllocated, s.DateAssigned, s.TimeAssigned, s.DateArrived, s.TimeArrived, s.TransferDate, s.TransferTime, s.DispatchedLevel, NULL,s.FinalServCode, 
    s.Origin, NULL, s.FirstUnitArrived, s.FirstUnitDispatched, s.FK_IncidentID, s.FK_GeoID, s.FK_LocationID, s.FK_OfficerID, s.FK_DispatcherID, s.FK_CallerTakerID, s.FK_DistanceID, s.FK_PriorityID, 
    s.FK_InitialServiceCodeID, s.SupervisorPIN, NULL, s.ModifiedLocation, s.ModifiedServCode, s.HandlingUnit, s.MinDiff_SavedtoTransfer, s.MinDiff_SavedtoArrived, s.MinDiff_TransfertoAllocation, 
    s.MinDiff_AllocatedtoArrived, s.MinDiff_SavedtoDispatched, s.TravelTimeAvailable, s.DistanceTravelled, s.MissedResponseFlag, s.MissedAllocationFlag, s.FK_DateSavedActualID, s.FK_DateSavedPoliceID, 
    s.FK_TimeSavedID, NULL, NULL, s.HandlerEmployeeNo, s.Handler_Staff_Move_ID, s.Dispatcher_Staff_Move_ID, s.DispatcherEmployeeNo, s.Original_Priority, s.OA_REC_PROCESSED_DATE_NEW,    
    s.OA_REC_CREATED_DATE, TO_TIMESTAMP('9999-12-31'), 1, s.OA_VERSION_NEW, s.OA_RECORDID)
    
  """)
   

]) 

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### LOGGING

# CELL ********************

# finalise_notebook_logging()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ###### TEST

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
