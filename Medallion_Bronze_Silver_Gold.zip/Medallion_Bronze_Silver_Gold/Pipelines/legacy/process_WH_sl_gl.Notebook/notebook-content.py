# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "warehouse": {
# META       "default_warehouse": "65b85860-6e65-95e7-4399-e89ee955f64e",
# META       "known_warehouses": [
# META         {
# META           "id": "65b85860-6e65-95e7-4399-e89ee955f64e",
# META           "type": "Datawarehouse"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import com.microsoft.spark.fabric
from com.microsoft.spark.fabric.Constants import Constants

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run /config_gold_layer

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

goldPath_lh = "abfss://Fabric_SandBox@onelake.dfs.fabric.microsoft.com/LH_300_Gold_Test.Lakehouse/Tables"
goldPath_wh = "abfss://Fabric_SandBox@onelake.dfs.fabric.microsoft.com/LH_300_Gold_Test.Lakehouse/Tables"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

create_temp_views_by_domains(silverPath, "Bail")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

sl_tables = ["rprt.tbl_b_bailtoathena","rprt.tbl_b_crime_person_info","rprt.tbl_b_custody_arrest"]

for tables in sl_tables:
    df_tbl = spark.read.option(Constants.WorkspaceId, "a3e4d0e6-6b32-498b-addc-1629a4b29a47").synapsesql(f"{goldPath_lh}.rprt.{tables}")
    tempView = f"temp_{tables}"
    # df_tbl.createOrReplaceTempView(tempView)

    print(tempView)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

abfss://Fabric_SandBox@onelake.dfs.fabric.microsoft.com/LH_300_Gold_Test.Lakehouse/Tables

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
